create_clock -name clk -period 16.667 [get_ports {clk}]
