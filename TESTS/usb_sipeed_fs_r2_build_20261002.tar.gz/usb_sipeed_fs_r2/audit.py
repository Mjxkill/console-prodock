#!/usr/bin/env python3
"""Audit avant P&R : provenance, ports, contraintes, syntaxe et ROM FS."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

s = Path(__file__).resolve().parent
a = s/'audit'
a.mkdir(exist_ok=True)
m = json.loads((s/'sources.json').read_text())
sha = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,digest in m['files'].items():
    assert sha(s/'project'/name)==digest,name
for name,digest in m['reference_files'].items():
    assert sha(s/'source'/name)==sha(Path(m['reference'])/name)==digest,name
for name,digest in m['controller_files'].items():
    assert sha(s/'controller_provenance'/name)==digest,name
assert sha(s/'project/src/usb_device_controller_fs/usb_device_controller.vg') == sha(s/'controller_provenance/usb_device_controller.vg')
assert 'Clock_Frequency=60MHz' in (s/'source/src/usb_softphy/usb_softphy.ipc').read_text()
top=(s/'project/src/TOP.v').read_text()
assert re.search(r'\.HSSUPPORT\s*\(0\s*\)',top)
prior=s.parent/'usb_sipeed_fs_r1'
old_rxready = 'assign usb_rxrdy     = ep_usb_rxrdy;'
new_rxready = "assign usb_rxrdy     = (endpt_sel == ENDPT_UART_CONFIG) ? 1'b1 : ep_usb_rxrdy;"
assert top.count(new_rxready)==1
assert top.replace(new_rxready,old_rxready)==(prior/'project/src/TOP.v').read_text()
for name in m['active_order']:
    if name!='src/TOP.v':
        assert sha(s/'project'/name)==sha(prior/'project'/name),name

assert '.usb_dp_io(usb_term_dp_io)' in top and '.usb_dn_io(usb_term_dn_io)' in top
assert "assign usb_pullup_en_o = 1'b1;" in top
for bad in ('USB2_0_SoftPHY_Top','usb_dxp_io','usb_dxn_io','usb_rxdp_i','usb_rxdn_i','fclk_960M'):
    assert bad not in top,bad
cst=(s/'project/src/usb_ref.cst').read_text()
for pin in ('M21','M22','U21','V21','T20','U20'):
    assert pin not in cst,pin
original=(s/'source/src/usb_ref.sdc').read_text().splitlines()
current=(s/'project/src/usb_ref.sdc').read_text().splitlines()
assert all(line in original for line in current)
assert [x for x in current if x.startswith('set_false_path')] == [x for x in original if x.startswith('set_false_path')]
assert len([x for x in current if x.startswith('create_')])==3

# Déclarations publiques uniquement : contrôle des ports du top, sans simuler
# ni réécrire les corps des IP chiffrées ou le transport.
modules={
 'Gowin_PLL_F':'gowin_pll/gowin_pll_f.v','Gowin_PLL_B':'gowin_pll/gowin_pll_b.v',
 'UART':'uart/uart.v','usb_fifo':'sync_fifo/usb_fifo.v',
 'usb_uart_config':'uart/usb_uart_config.v',
 'USB_SoftPHY_Top':'usb_softphy/usb_softphy.v',
 'USB_Device_Controller_Top':'usb_device_controller_fs/usb_device_controller.vg'}
stubs='// Audit des interfaces publiques uniquement ; aucune fonction PHY simulée.\n'
for module,name in modules.items():
    text=(s/'project/src'/name).read_text()
    match=re.search(r'^module\s+'+module+r'\b.*?^endmodule',text,re.M|re.S)
    body=match.group(0)
    prefix='\n'.join(re.findall(r'^`define[^\n]*',text[:match.start()],re.M))
    header_end=re.search(r'\)\s*;',body).end()
    header=body[:header_end]
    tail=body[header_end:]
    declarations='\n'.join(re.findall(r'^\s*(?:input|output|inout|parameter)\b[^;]*;',tail,re.M))
    stubs+=prefix+'\n'+header+'\n'+declarations+'\nendmodule\n'
(a/'public_interfaces.v').write_text(stubs)
cmd=['verilator','--lint-only','-Wno-fatal','--top-module','Top',str(s/'project/src/TOP.v'),str(s/'project/src/usb_descriptor.v'),str(a/'public_interfaces.v')]
with (a/'top_syntax.log').open('w') as out:
    subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,check=True)

tb='''`timescale 1ns/1ps
module usb_fs_descriptor_tb;
reg clk=0, rst=0; always #5 clk=~clk;
reg [15:0] addr=0; wire [7:0] data;
usb_desc #(.HSSUPPORT(0), .VENDORID(16'h359f), .PRODUCTID(16'h2010)) d(
 .CLK(clk),.RESET(rst),.i_pid(16'd0),.i_vid(16'd0),
 .i_descrom_raddr(addr),.o_descrom_rdat(data));
task check_byte(input [15:0] index,input [7:0] expected);
 begin addr=index; repeat(2) @(posedge clk); #1;
  if(data!==expected) $fatal(1,"Descriptor[%0d] = %h expected %h",index,data,expected);
 end
endtask
initial begin
 #1 rst=1; repeat(2) @(posedge clk); #1 rst=0;
 check_byte(2,8'h10); check_byte(3,8'h01); check_byte(7,8'd64);
 check_byte(8,8'h9f); check_byte(9,8'h35); check_byte(10,8'h10); check_byte(11,8'h20);
 check_byte(32+55,8'h02); check_byte(32+57,8'd64); check_byte(32+58,8'd0);
 check_byte(32+62,8'h82); check_byte(32+64,8'd64); check_byte(32+65,8'd0);
 $display("PASS FS descriptor: USB1.10, VID359f:2010, EP0/EP2IN/EP2OUT max64"); $finish;
end
endmodule
'''
(a/'usb_fs_descriptor_tb.sv').write_text(tb)
cmd=['verilator','--binary','--timing','-Wno-fatal','--top-module','usb_fs_descriptor_tb','--Mdir',str(a/'obj'),str(a/'usb_fs_descriptor_tb.sv'),str(s/'project/src/usb_descriptor.v')]
with (a/'descriptor_build.log').open('w') as out:
    subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,check=True)
with (a/'descriptor_test.log').open('w') as out:
    subprocess.run([str(a/'obj/Vusb_fs_descriptor_tb')],stdout=out,stderr=subprocess.STDOUT,check=True)
result=dict(status='PASS_PREBUILD_AUDIT',source_checks=True,public_interface_syntax=True,
            descriptor_test=True,phy_clock_mhz=60,expected_usb_speed_mbps=12,
            hs_ports_removed=True,constraint_periods_unchanged=True,
            uart_false_paths_unchanged=True,netlists_unchanged=True,
            limits=['Les interfaces publiques servent uniquement au lint du top ; aucun comportement PHY/contrôleur simulé.',
                    'Aucune équivalence HS/FS revendiquée.'])
(s/'audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
