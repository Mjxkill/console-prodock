// Audit des interfaces publiques uniquement ; aucune fonction PHY simulée.

module Gowin_PLL_F (lock, clkout0, clkin, reset);


output lock;
output clkout0;
input clkin;
input reset;
endmodule

module Gowin_PLL_B (lock, clkout0, clkout1, clkin, reset);


output lock;
output clkout0;
output clkout1;
input clkin;
input reset;
endmodule

module UART 
#(    parameter CLK_FREQ    = 30'd60000000 // set system clock frequency in Hz
      //parameter BAUD_RATE   = 4000000   // baud rate value
     // parameter P_PARITY_BIT  = "none"   // legal values: "none", "even", "odd", "mark", "space"
)
(
    input              CLK        , // clock
    input              RST        , // reset
        // UART INTERFACE
    output             UART_TXD   ,
    input              UART_RXD   ,
    output             UART_RTS   , // when UART_RTS = 0, UART This Device Ready to receive.
    input              UART_CTS   , // when UART_CTS = 0, UART Opposite Device Ready to receive.
        // UART Control Reg
    input  [31:0]      BAUD_RATE ,
    input  [7:0]       PARITY_BIT,
    input  [7:0]       STOP_BIT  ,
    input  [7:0]       DATA_BITS ,
        // USER DATA INPUT INTERFACE
    input   [15:0]     TX_DATA    , //
    input              TX_DATA_VAL, // when TX_DATA_VAL = 1, data on TX_DATA will be transmit, DATA_SEND can set to 1 only when BUSY = 0
    output             TX_BUSY    , // when BUSY = 1 transiever is busy, you must not set DATA_SEND to 1
        // USER FIFO CONTROL INTERFACE
    output  [15:0]     RX_DATA    , //
    output             RX_DATA_VAL  //
);

endmodule
`define    EP2_IN_EN
`define    EP2_OUT_EN
`define     EP1_IN_BUF_ASIZE     4'd12
`define     EP2_IN_BUF_ASIZE     4'd12
`define     EP3_IN_BUF_ASIZE     4'd12
`define     EP4_IN_BUF_ASIZE     4'd12
`define     EP5_IN_BUF_ASIZE     4'd12
`define     EP6_IN_BUF_ASIZE     4'd12
`define     EP7_IN_BUF_ASIZE     4'd12
`define     EP8_IN_BUF_ASIZE     4'd12
`define     EP9_IN_BUF_ASIZE     4'd12
`define     EP10_IN_BUF_ASIZE    4'd12
`define     EP11_IN_BUF_ASIZE    4'd12
`define     EP12_IN_BUF_ASIZE    4'd12
`define     EP13_IN_BUF_ASIZE    4'd12
`define     EP14_IN_BUF_ASIZE    4'd12
`define     EP15_IN_BUF_ASIZE    4'd12
`define     EP1_OUT_BUF_ASIZE    4'd12
`define     EP2_OUT_BUF_ASIZE    4'd12
`define     EP3_OUT_BUF_ASIZE    4'd12
`define     EP4_OUT_BUF_ASIZE    4'd12
`define     EP5_OUT_BUF_ASIZE    4'd12
`define     EP6_OUT_BUF_ASIZE    4'd12
`define     EP7_OUT_BUF_ASIZE    4'd12
`define     EP8_OUT_BUF_ASIZE    4'd12
`define     EP9_OUT_BUF_ASIZE    4'd12
`define     EP10_OUT_BUF_ASIZE   4'd12
`define     EP11_OUT_BUF_ASIZE   4'd12
`define     EP12_OUT_BUF_ASIZE   4'd12
`define     EP13_OUT_BUF_ASIZE   4'd12
`define     EP14_OUT_BUF_ASIZE   4'd12
`define     EP15_OUT_BUF_ASIZE   4'd12
`define     EP1_OUT_BUF_AFULL    13'd2048
`define     EP2_OUT_BUF_AFULL    13'd2048
`define     EP3_OUT_BUF_AFULL    13'd2048
`define     EP4_OUT_BUF_AFULL    13'd2048
`define     EP5_OUT_BUF_AFULL    13'd2048
`define     EP6_OUT_BUF_AFULL    13'd2048
`define     EP7_OUT_BUF_AFULL    13'd2048
`define     EP8_OUT_BUF_AFULL    13'd2048
`define     EP9_OUT_BUF_AFULL    13'd2048
`define     EP10_OUT_BUF_AFULL   13'd2048
`define     EP11_OUT_BUF_AFULL   13'd2048
`define     EP12_OUT_BUF_AFULL   13'd2048
`define     EP13_OUT_BUF_AFULL   13'd2048
`define     EP14_OUT_BUF_AFULL   13'd2048
`define     EP15_OUT_BUF_AFULL   13'd2048
module usb_fifo
(
     input              i_clk         //clock
    ,input              i_reset       //reset
    ,input      [3:0]   i_usb_endpt   //
    ,input              i_usb_rxact   //
    ,input              i_usb_rxval   //
    ,input              i_usb_rxpktval//
    ,input      [7:0]   i_usb_rxdat   //
    ,output             o_usb_rxrdy   //
    ,input              i_usb_txact   //
    ,input              i_usb_txpop   //
    ,input              i_usb_txpktfin//
    ,output             o_usb_txcork  //
    ,output     [7:0]   o_usb_txdat   //
    ,output     [11:0]  o_usb_txlen   //
    //Endpoint 1
    `ifdef EP1_IN_EN
    ,input              i_ep1_tx_clk  //
    ,input      [11:0]  i_ep1_tx_max //
    ,input              i_ep1_tx_dval //
    ,input      [7:0]   i_ep1_tx_data //
    `endif
    `ifdef EP1_OUT_EN
    ,input              i_ep1_rx_clk  //
    ,input              i_ep1_rx_rdy  //
    ,output             o_ep1_rx_dval //
    ,output     [7:0]   o_ep1_rx_data //
    `endif
    //Endpoint 2
    `ifdef EP2_IN_EN
    ,input              i_ep2_tx_clk  //
    ,input      [11:0]  i_ep2_tx_max //
    ,input              i_ep2_tx_dval //
    ,input      [7:0]   i_ep2_tx_data //
    `endif
    `ifdef EP2_OUT_EN
    ,input              i_ep2_rx_clk  //
    ,input              i_ep2_rx_rdy  //
    ,output             o_ep2_rx_dval //
    ,output     [7:0]   o_ep2_rx_data //
    `endif
    //Endpoint 3
    `ifdef EP3_IN_EN
    ,input              i_ep3_tx_clk  //
    ,input      [11:0]  i_ep3_tx_max //
    ,input              i_ep3_tx_dval //
    ,input      [7:0]   i_ep3_tx_data //
    `endif
    `ifdef EP3_OUT_EN
    ,input              i_ep3_rx_clk  //
    ,input              i_ep3_rx_rdy  //
    ,output             o_ep3_rx_dval //
    ,output     [7:0]   o_ep3_rx_data //
    `endif
    //Endpoint 4
    `ifdef EP4_IN_EN
    ,input              i_ep4_tx_clk  //
    ,input      [11:0]  i_ep4_tx_max //
    ,input              i_ep4_tx_dval //
    ,input      [7:0]   i_ep4_tx_data //
    `endif
    `ifdef EP4_OUT_EN
    ,input              i_ep4_rx_clk  //
    ,input              i_ep4_rx_rdy  //
    ,output             o_ep4_rx_dval //
    ,output     [7:0]   o_ep4_rx_data //
    `endif
    //Endpoint 5
    `ifdef EP5_IN_EN
    ,input              i_ep5_tx_clk  //
    ,input      [11:0]  i_ep5_tx_max //
    ,input              i_ep5_tx_dval //
    ,input      [7:0]   i_ep5_tx_data //
    `endif
    `ifdef EP5_OUT_EN
    ,input              i_ep5_rx_clk  //
    ,input              i_ep5_rx_rdy  //
    ,output             o_ep5_rx_dval //
    ,output     [7:0]   o_ep5_rx_data //
    `endif
    //Endpoint 6
    `ifdef EP6_IN_EN
    ,input              i_ep6_tx_clk  //
    ,input      [11:0]  i_ep6_tx_max //
    ,input              i_ep6_tx_dval //
    ,input      [7:0]   i_ep6_tx_data //
    `endif
    `ifdef EP6_OUT_EN
    ,input              i_ep6_rx_clk  //
    ,input              i_ep6_rx_rdy  //
    ,output             o_ep6_rx_dval //
    ,output     [7:0]   o_ep6_rx_data //
    `endif
    //Endpoint 7
    `ifdef EP7_IN_EN
    ,input              i_ep7_tx_clk  //
    ,input      [11:0]  i_ep7_tx_max //
    ,input              i_ep7_tx_dval //
    ,input      [7:0]   i_ep7_tx_data //
    `endif
    `ifdef EP7_OUT_EN
    ,input              i_ep7_rx_clk  //
    ,input              i_ep7_rx_rdy  //
    ,output             o_ep7_rx_dval //
    ,output     [7:0]   o_ep7_rx_data //
    `endif
    //Endpoint 8
    `ifdef EP8_IN_EN
    ,input              i_ep8_tx_clk  //
    ,input      [11:0]  i_ep8_tx_max //
    ,input              i_ep8_tx_dval //
    ,input      [7:0]   i_ep8_tx_data //
    `endif
    `ifdef EP8_OUT_EN
    ,input              i_ep8_rx_clk  //
    ,input              i_ep8_rx_rdy  //
    ,output             o_ep8_rx_dval //
    ,output     [7:0]   o_ep8_rx_data //
    `endif
    //Endpoint 9
    `ifdef EP9_IN_EN
    ,input              i_ep9_tx_clk  //
    ,input      [11:0]  i_ep9_tx_max //
    ,input              i_ep9_tx_dval //
    ,input      [7:0]   i_ep9_tx_data //
    `endif
    `ifdef EP9_OUT_EN
    ,input              i_ep9_rx_clk  //
    ,input              i_ep9_rx_rdy  //
    ,output             o_ep9_rx_dval //
    ,output     [7:0]   o_ep9_rx_data //
    `endif
    //Endpoint 10
    `ifdef EP10_IN_EN
    ,input              i_ep10_tx_clk  //
    ,input      [11:0]  i_ep10_tx_max //
    ,input              i_ep10_tx_dval //
    ,input      [7:0]   i_ep10_tx_data //
    `endif
    `ifdef EP10_OUT_EN
    ,input              i_ep10_rx_clk  //
    ,input              i_ep10_rx_rdy  //
    ,output             o_ep10_rx_dval //
    ,output     [7:0]   o_ep10_rx_data //
    `endif
    //Endpoint 11
    `ifdef EP11_IN_EN
    ,input              i_ep11_tx_clk  //
    ,input      [11:0]  i_ep11_tx_max //
    ,input              i_ep11_tx_dval //
    ,input      [7:0]   i_ep11_tx_data //
    `endif
    `ifdef EP11_OUT_EN
    ,input              i_ep11_rx_clk  //
    ,input              i_ep11_rx_rdy  //
    ,output             o_ep11_rx_dval //
    ,output     [7:0]   o_ep11_rx_data //
    `endif
    //Endpoint 12
    `ifdef EP12_IN_EN
    ,input              i_ep12_tx_clk  //
    ,input      [11:0]  i_ep12_tx_max //
    ,input              i_ep12_tx_dval //
    ,input      [7:0]   i_ep12_tx_data //
    `endif
    `ifdef EP12_OUT_EN
    ,input              i_ep12_rx_clk  //
    ,input              i_ep12_rx_rdy  //
    ,output             o_ep12_rx_dval //
    ,output     [7:0]   o_ep12_rx_data //
    `endif
    //Endpoint 13
    `ifdef EP13_IN_EN
    ,input              i_ep13_tx_clk  //
    ,input      [11:0]  i_ep13_tx_max //
    ,input              i_ep13_tx_dval //
    ,input      [7:0]   i_ep13_tx_data //
    `endif
    `ifdef EP13_OUT_EN
    ,input              i_ep13_rx_clk  //
    ,input              i_ep13_rx_rdy  //
    ,output             o_ep13_rx_dval //
    ,output     [7:0]   o_ep13_rx_data //
    `endif
    //Endpoint 14
    `ifdef EP14_IN_EN
    ,input              i_ep14_tx_clk  //
    ,input      [11:0]  i_ep14_tx_max //
    ,input              i_ep14_tx_dval //
    ,input      [7:0]   i_ep14_tx_data //
    `endif
    `ifdef EP14_OUT_EN
    ,input              i_ep14_rx_clk  //
    ,input              i_ep14_rx_rdy  //
    ,output             o_ep14_rx_dval //
    ,output     [7:0]   o_ep14_rx_data //
    `endif
    //Endpoint 15
    `ifdef EP15_IN_EN
    ,input              i_ep15_tx_clk  //
    ,input      [11:0]  i_ep15_tx_max //
    ,input              i_ep15_tx_dval //
    ,input      [7:0]   i_ep15_tx_data //
    `endif
    `ifdef EP15_OUT_EN
    ,input              i_ep15_rx_clk  //
    ,input              i_ep15_rx_rdy  //
    ,output             o_ep15_rx_dval //
    ,output     [7:0]   o_ep15_rx_data //
    `endif

);

endmodule

module usb_uart_config 
(
    input              PHY_CLKOUT        ,// clock
    input              RESET_IN          ,// reset
    input              setup_active      ,
    input   [3:0]      endpt_sel         ,
    input              usb_rxval         ,
    input              usb_rxact         ,
    input   [7:0]      usb_rxdat         ,
    input              usb_txact         ,
    input              usb_txpop         ,
    output  [11:0]     usb_txdat_len_o   ,
    output  [7:0]      endpt0_dat_o      ,
    output             endpt0_send_o     ,
    output             uart1_en_o        ,
    output  [31:0]     uart1_BAUD_RATE_o ,
    output  [7:0]      uart1_PARITY_BIT_o,
    output  [7:0]      uart1_STOP_BIT_o  ,
    output  [7:0]      uart1_DATA_BITS_o
);


parameter ENDPT_UART_CONFIG =4'h0;
parameter ENDPT_UART1_DATA  =4'h1;
parameter ENDPT_UART2_DATA  =4'h2;
parameter ENDPT_UART3_DATA  =4'h3;
parameter ENDPT_I2C1        =4'h4;
parameter ENDPT_I2C2        =4'h5;
parameter ENDPT_I2C3        =4'h6;
parameter ENDPT_I2C4        =4'h7;
parameter ENDPT_PARALLEL20  =4'h8;
endmodule

module USB_SoftPHY_Top (
  clk_i,
  rst_i,
  utmi_data_out_i,
  utmi_txvalid_i,
  utmi_op_mode_i,
  utmi_xcvrselect_i,
  utmi_termselect_i,
  utmi_data_in_o,
  utmi_txready_o,
  utmi_rxvalid_o,
  utmi_rxactive_o,
  utmi_rxerror_o,
  utmi_linestate_o,
  usb_dp_io,
  usb_dn_io
)
;

input clk_i;
input rst_i;
input [7:0] utmi_data_out_i;
input utmi_txvalid_i;
input [1:0] utmi_op_mode_i;
input [1:0] utmi_xcvrselect_i;
input utmi_termselect_i;
output [7:0] utmi_data_in_o;
output utmi_txready_o;
output utmi_rxvalid_o;
output utmi_rxactive_o;
output utmi_rxerror_o;
output [1:0] utmi_linestate_o;
inout usb_dp_io;
inout usb_dn_io;
endmodule

module USB_Device_Controller_Top (
  clk_i,
  reset_i,
  usbrst_o,
  highspeed_o,
  suspend_o,
  online_o,
  txdat_i,
  txval_i,
  txdat_len_i,
  txiso_pid_i,
  txcork_i,
  txpop_o,
  txact_o,
  txpktfin_o,
  rxdat_o,
  rxval_o,
  rxrdy_i,
  rxact_o,
  rxpktval_o,
  setup_o,
  endpt_o,
  sof_o,
  inf_alter_i,
  inf_alter_o,
  inf_sel_o,
  inf_set_o,
  descrom_raddr_o,
  desc_index_o,
  desc_type_o,
  descrom_rdata_i,
  desc_dev_addr_i,
  desc_dev_len_i,
  desc_qual_addr_i,
  desc_qual_len_i,
  desc_fscfg_addr_i,
  desc_fscfg_len_i,
  desc_hscfg_addr_i,
  desc_hscfg_len_i,
  desc_oscfg_addr_i,
  desc_hidrpt_addr_i,
  desc_hidrpt_len_i,
  desc_bos_addr_i,
  desc_bos_len_i,
  desc_strlang_addr_i,
  desc_strvendor_addr_i,
  desc_strvendor_len_i,
  desc_strproduct_addr_i,
  desc_strproduct_len_i,
  desc_strserial_addr_i,
  desc_strserial_len_i,
  desc_have_strings_i,
  utmi_dataout_o,
  utmi_txvalid_o,
  utmi_txready_i,
  utmi_datain_i,
  utmi_rxactive_i,
  utmi_rxvalid_i,
  utmi_rxerror_i,
  utmi_linestate_i,
  utmi_opmode_o,
  utmi_xcvrselect_o,
  utmi_termselect_o,
  utmi_reset_o
)
;

input clk_i;
input reset_i;
output usbrst_o;
output highspeed_o;
output suspend_o;
output online_o;
input [7:0] txdat_i;
input txval_i;
input [11:0] txdat_len_i;
input [3:0] txiso_pid_i;
input txcork_i;
output txpop_o;
output txact_o;
output txpktfin_o;
output [7:0] rxdat_o;
output rxval_o;
input rxrdy_i;
output rxact_o;
output rxpktval_o;
output setup_o;
output [3:0] endpt_o;
output sof_o;
input [7:0] inf_alter_i;
output [7:0] inf_alter_o;
output [7:0] inf_sel_o;
output inf_set_o;
output [15:0] descrom_raddr_o;
output [7:0] desc_index_o;
output [7:0] desc_type_o;
input [7:0] descrom_rdata_i;
input [15:0] desc_dev_addr_i;
input [15:0] desc_dev_len_i;
input [15:0] desc_qual_addr_i;
input [15:0] desc_qual_len_i;
input [15:0] desc_fscfg_addr_i;
input [15:0] desc_fscfg_len_i;
input [15:0] desc_hscfg_addr_i;
input [15:0] desc_hscfg_len_i;
input [15:0] desc_oscfg_addr_i;
input [15:0] desc_hidrpt_addr_i;
input [15:0] desc_hidrpt_len_i;
input [15:0] desc_bos_addr_i;
input [15:0] desc_bos_len_i;
input [15:0] desc_strlang_addr_i;
input [15:0] desc_strvendor_addr_i;
input [15:0] desc_strvendor_len_i;
input [15:0] desc_strproduct_addr_i;
input [15:0] desc_strproduct_len_i;
input [15:0] desc_strserial_addr_i;
input [15:0] desc_strserial_len_i;
input desc_have_strings_i;
output [7:0] utmi_dataout_o;
output utmi_txvalid_o;
input utmi_txready_i;
input [7:0] utmi_datain_i;
input utmi_rxactive_i;
input utmi_rxvalid_i;
input utmi_rxerror_i;
input [1:0] utmi_linestate_i;
output [1:0] utmi_opmode_o;
output [1:0] utmi_xcvrselect_o;
output utmi_termselect_o;
output utmi_reset_o;
endmodule
