`timescale 1ns/1ps
module usb_fs_descriptor_tb;
reg clk=0, rst=0; always #5 clk=~clk;
reg [15:0] addr=0; wire [7:0] data;
usb_desc #(.HSSUPPORT(0), .VENDORID(16'h359f), .PRODUCTID(16'h2010)) d(
 .CLK(clk),.RESET(rst),.i_pid(16'd0),.i_vid(16'd0),
 .i_descrom_raddr(addr),.o_descrom_rdat(data));
task check_byte(input [15:0] index,input [7:0] expected);
 begin addr=index; repeat(2) @(posedge clk); #1;
  if(data!==expected) $fatal(1,"Descriptor[%0d] = %h expected %h",index,data,expected);
 end
endtask
initial begin
 #1 rst=1; repeat(2) @(posedge clk); #1 rst=0;
 check_byte(2,8'h10); check_byte(3,8'h01); check_byte(7,8'd64);
 check_byte(8,8'h9f); check_byte(9,8'h35); check_byte(10,8'h10); check_byte(11,8'h20);
 check_byte(32+55,8'h02); check_byte(32+57,8'd64); check_byte(32+58,8'd0);
 check_byte(32+62,8'h82); check_byte(32+64,8'd64); check_byte(32+65,8'd0);
 $display("PASS FS descriptor: USB1.10, VID359f:2010, EP0/EP2IN/EP2OUT max64"); $finish;
end
endmodule
