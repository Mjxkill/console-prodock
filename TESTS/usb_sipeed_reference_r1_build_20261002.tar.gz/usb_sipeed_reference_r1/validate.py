#!/usr/bin/env python3
"""Vérifie les entrées Sipeed intactes et le timing de ce build isolé."""
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

stage = Path(__file__).resolve().parent
manifest = json.loads((stage/'sources.json').read_text())
origin = Path(manifest['origin'])
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
checks = {}
for name, record in manifest['files'].items():
    checks[name] = {
        'origin_unchanged': sha(origin/name) == record['sha256'],
        'snapshot_unchanged': sha(stage/'source'/name) == record['sha256'],
        'build_input_unchanged': sha(stage/'project'/name) == record['sha256'],
    }
    assert checks[name]['origin_unchanged'] and checks[name]['snapshot_unchanged'], name
    if name != 'impl/usb_uart_loopback_process_config.json':
        assert checks[name]['build_input_unchanged'], name

before = json.loads((stage/'source/impl/usb_uart_loopback_process_config.json').read_text())
after = json.loads((stage/'project/impl/usb_uart_loopback_process_config.json').read_text())
delta = {k: {'before': before.get(k), 'after': after.get(k)}
         for k in sorted(before.keys() | after.keys()) if before.get(k) != after.get(k)}
expected_delta = {
    'Generate_Plain_Text_Timing_Report': {'before': False, 'after': True},
    'MULTIBOOT_MODE': {'before': 'Normal', 'after': 'Single'},
    'MULTIJUMP_MODE': {'before': 'Normal', 'after': 'Single'},
    'SerDes_retiming': {'before': None, 'after': False},
}
assert delta == expected_delta, delta
assert before['Multi_Boot'] is False and before['MSPI_JUMP'] is False
assert after['Multi_Boot'] is False and after['MSPI_JUMP'] is False

pnr = stage/'project/impl/pnr'
cmd = (pnr/'cmd.do').read_text()
for option in ('-place_option 1', '-route_option 0', '-clock_route_order 0',
               '-correct_hold 1', '-route_maxfan 23', '-timing', '-cst_error',
               '-convert_sdp32_36_to_sdp16_18', '-tr'):
    assert option in cmd.splitlines(), option
syn = ET.parse(stage/'project/impl/gwsynthesis/usb_uart_loopback.prj').getroot()
compiled_files = [str(Path(f.attrib['path']).relative_to(stage/'project'))
                  for f in syn.findall('./FileList/File')]
assert compiled_files == [p for p in manifest['active_order'] if p.endswith(('.v', '.vhd'))]
options = {o.attrib['type']: o.attrib['value'] for o in syn.findall('./OptionList/Option')}
assert options['top_module'] == 'Top'
assert options['verilog_language'] == 'verilog-2001'
assert options['vhdl_language'] == 'vhdl-2008'

report = (pnr/'usb_uart_loopback.tr').read_text()
all_slacks = [float(v) for v in re.findall(r'^Slack\s*:\s*([-\d.]+)', report, re.M)]
assert len(all_slacks) == 110 and min(all_slacks) >= 0
tns = re.findall(r'^\s*(\S+)\s+(setup|hold)\s+([-\d.]+)\s+(\d+)\s*$', report, re.M)
assert len(tns) == 10 and all(float(s) == 0 and int(n) == 0 for _, _, s, n in tns)
for kind in ('Setup', 'Hold'):
    assert f'<Numbers of {kind} Violated Endpoints>:0' in report
minima = {}
for command, block in re.findall(r'^Report Command:([^\n]*)\n(.*?)(?=^Report Command:|\Z)', report, re.M | re.S):
    slacks = [float(v) for v in re.findall(r'^Slack\s*:\s*([-\d.]+)', block, re.M)]
    if slacks:
        minima[command] = {'count': len(slacks), 'minimum_ns': min(slacks)}
assert len(minima) == 5 and sum(v['count'] for v in minima.values()) == 110
artifacts = ['build.tcl', 'build.log', 'sources.json', 'validate.py',
             'project/impl/gwsynthesis/usb_uart_loopback.prj',
             'project/impl/pnr/usb_uart_loopback.fs', 'project/impl/pnr/usb_uart_loopback.tr',
             'project/impl/pnr/usb_uart_loopback.rpt.txt',
             'project/impl/pnr/cmd.do', 'project/impl/pnr/device.cfg',
             'project/impl/usb_uart_loopback_process_config.json']
result = dict(status='PASS_BUILD_AND_TIMING', hardware_tested=False,
              active_count=manifest['active_count'], input_checks=checks,
              configuration_delta=delta,
              configuration_notes='Normal→Single : normalisation de deux fonctions de multiboot désactivées ; SerDes_retiming=false ajouté par Gowin 1.9.12.',
              compiled_files=compiled_files, synthesis_options=options,
              minimum_slack_ns=min(all_slacks), detailed_slacks=len(all_slacks),
              minima_by_command=minima,
              tns=[dict(clock=c, analysis=t, tns_ns=float(s), violated_endpoints=int(n)) for c,t,s,n in tns],
              artifacts={p: dict(sha256=sha(stage/p), bytes=(stage/p).stat().st_size) for p in artifacts},
              limits=['Timing évalué avec les SDC/CST Sipeed d’origine, y compris groupes asynchrones et faux chemins.',
                      'Aucun test sur carte dans cette validation.',
                      'PR1014 : CLK_IN_d utilise une ressource de routage générique ; avertissement conservé.'])
(stage/'validation.json').write_text(json.dumps(result, indent=2)+'\n')
digest = sha(pnr/'usb_uart_loopback.fs')
(stage/'bitstream.sha256').write_text(f'{digest}  project/impl/pnr/usb_uart_loopback.fs\n')
print(json.dumps({k: result[k] for k in ('status', 'hardware_tested', 'minimum_slack_ns', 'detailed_slacks', 'minima_by_command')}, indent=2))
print('SHA256 bitstream:', digest)
