open_project {/home/michael/console/tang/impl/usb_sipeed_reference_r1/project/usb_uart_loopback.gprj}
set_option -gen_text_timing_rpt 1
run all
