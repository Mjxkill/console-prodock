#!/usr/bin/env python3
"""Run the exact autonomous scene under UBSan; compose pixels independently."""
import argparse,ctypes,json,struct,subprocess,tempfile
from pathlib import Path
import numpy as np
from PIL import Image
from render_gpu_demo import brace_block
from gpu_compose import compose,frame_hash,palette_rgb,signed16
ROOT=Path(__file__).resolve().parents[1]
class Info(ctypes.Structure):
    _fields_=[(n,ctypes.c_uint if i<4 else ctypes.c_int) for i,n in enumerate(('frame','chapter','sprites','light','camera_x','camera_y','hero_x','hero_y'))]
class Scene:
    def __init__(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='luma_scene_');work=Path(self.tmp.name)
        driver=(ROOT/'fw_console/gpu.c').read_text()
        source='#include "luma_scene.h"\n'+'\n'.join(brace_block(driver,s) for s in ('gpu_layer gpu_make_layer(','gpu_sprite gpu_make_sprite('))+'\nvoid scene(unsigned f,gpu_layer *l,gpu_sprite *s,luma_info *i){luma_scene(f,l,s,i);}\nuint32_t color(uint32_t c,unsigned i,unsigned f,unsigned light){return luma_color(c,i,f,light);}\n'
        (work/'scene.c').write_text(source)
        subprocess.run(['cc','-std=c11','-O2','-Wall','-Wextra','-Wno-unused-function','-fsanitize=undefined','-fno-sanitize-recover=all','-shared','-fPIC','-I',str(ROOT/'fw_console'),str(work/'scene.c'),'-o',str(work/'scene.so')],check=True)
        self.lib=ctypes.CDLL(str(work/'scene.so'));self.lib.color.restype=ctypes.c_uint32
        self.raw=(ROOT/'assets/luma/packed/luma.bin').read_bytes()
        self.manifest=json.loads((ROOT/'assets/luma/packed/manifest.json').read_text());self.base=self.manifest['base']
        self.palette=struct.unpack('<256I',self.read(self.manifest['regions']['palette']['address'],1024))
    def read(self,addr,n):
        assert self.base<=addr<=self.base+len(self.raw)-n,(hex(addr),n)
        return self.raw[addr-self.base:addr-self.base+n]
    def get(self,f):
        l=((ctypes.c_uint32*8)*16)();s=((ctypes.c_uint32*4)*64)();i=Info();self.lib.scene(f,l,s,ctypes.byref(i))
        return [tuple(a) for a in l],[tuple(a) for a in s],i
    def fast(self,layers,sprites):
        # Fast preview only; exact poses are cross-checked with gpu_compose.
        out=Image.new('L',(800,480))
        for num,w in enumerate(layers):
            if w[6]&1:
                base,wh,xy,v,scroll,stride,flags,_=w;sw,sh=wh&65535,wh>>16
                assert not flags&4
                im=Image.frombytes('L',(stride,sh),self.read(base,stride*sh))
                sx,sy=scroll&65535,scroll>>16
                im=im.crop((sx,sy,min(sw,sx+(v&65535)),min(sh,sy+(v>>16))))
                out.paste(im,(signed16(xy&65535),signed16(xy>>16)),im.point(lambda x:255 if x else 0) if flags&2 else None)
            for base,xy,p,_ in sprites:
                if p&65536 and (p>>20)&15==num:
                    w,h=p&255,(p>>8)&255
                    im=Image.frombytes('L',(32,h),self.read(base,32*h)).crop((0,0,w,h))
                    if p&131072:im=im.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
                    if p&262144:im=im.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
                    out.paste(im,(signed16(xy&65535),signed16(xy>>16)),im.point(lambda x:255 if x else 0))
        return out.tobytes()
    def render(self,f,exact=False):
        l,s,info=self.get(f);indices=self.fast(l,s)
        if exact:assert indices==bytes(compose(l,s,self.read)),f
        im=Image.frombytes('P',(800,480),indices)
        pal=struct.pack('<256I',*(self.lib.color(c,i,f%5600,info.light) for i,c in enumerate(self.palette)))
        im.putpalette(palette_rgb(pal))
        return im.convert('RGB'),indices,info
    def sweep(self):
        maximum=0
        for f in range(5600):
            l,s,i=self.get(f);assert 0<=i.camera_x<=736 and 0<=i.camera_y<=544 and i.sprites<=64
            maximum=max(maximum,i.sprites)
            for b,xy,p,_ in s:
                if p&65536:
                    assert b%32==0 and 1<=(p&255)<=32 and 1<=((p>>8)&255)<=32
                    self.read(b,1024)
        print(f'PASS: 5600 frames under UBSan, bounded reads, max {maximum} visible sprites')
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,default=ROOT/'TESTS/luma_20261004/preview');p.add_argument('--animation',action='store_true');p.add_argument('--sweep',action='store_true');a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    sc=Scene()
    if a.sweep:sc.sweep()
    records=[]
    for f in (100,800,1600,2305,2640,2958,3480,3880,4115,4490,4900,5390,5560):
        im,raw,info=sc.render(f,True);im.save(a.out/f'frame_{f:04}.png');record=dict(frame=f,hash=f'{frame_hash(raw):08x}',sprites=info.sprites,chapter=info.chapter);records.append(record);print(record)
    (a.out/'expected.json').write_text(json.dumps(records,indent=2)+'\n')
    if a.animation:
        # A full-loop video stays much smaller than an animated WebP of a
        # detailed scrolling background. Playback has the measured panel rate.
        command=['ffmpeg','-v','error','-y','-f','rawvideo','-pixel_format','rgb24',
                 '-video_size','800x480','-framerate','5.0036','-i','-',
                 '-an','-c:v','libx264','-preset','medium','-crf','20',
                 '-pix_fmt','yuv420p','-movflags','+faststart',str(a.out/'luma.mp4')]
        with subprocess.Popen(command,stdin=subprocess.PIPE) as encoder:
            for f in range(0,5600,11):encoder.stdin.write(sc.render(f)[0].tobytes())
            encoder.stdin.close()
            if encoder.wait():raise RuntimeError('Preview video encoding failed')
        print(a.out/'luma.mp4')
