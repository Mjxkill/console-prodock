create_clock -name PHY_CLKOUT -period 16.666667 [get_ports {phy_clk}]
