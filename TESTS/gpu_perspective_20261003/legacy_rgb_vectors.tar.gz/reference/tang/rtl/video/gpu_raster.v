// L13/L14/L15 RGB565 fragment engine. Ordered by the legacy command FIFO.
// Native DDR addresses are 32-bit words, bursts 256 bits. No new clock.
// See ARCHI/GPU_L13_L15_RGB_DEPTH.md for fixed-point and memory contracts.
`default_nettype none
module gpu_raster #(
    parameter WIDTH=800, HEIGHT=480
) (
    input wire clk, rst, start,
    input wire [255:0] command,
    output wire busy,
    output reg done,
    output reg [31:0] rejected, fragments, passed,
    output reg valid, write,
    output reg [28:0] addr,
    output reg [255:0] wr_data,
    output reg [31:0] wr_mask,
    input wire ready,
    input wire [255:0] rd_data,
    input wire rd_valid
);
    localparam IDLE=0, FINISH=1, BAD=2, TEX_ADDR=3, TEX_REQ=4,
        TEX_WAIT=5, TEX_COPY=6, TEX_NEXT=7, TRI_START=8, TRI_BOOT=9,
        TRI_WAIT=10, SPAN0=11, SPAN1=12, SPAN2=13, CHUNK=14,
        COLOR_REQ=15, COLOR_WAIT=16, Z_PREP=17, Z_REQ=18, Z_WAIT=19,
        PIX_PRIME=20, PIX_SAMPLE=21, PIX_TEST=22, PIX_BLEND=23, PIX_STORE=24,
        COLOR_WRITE=25, COLOR_SENT=26, Z_WRITE=27, Z_SENT=28, ADVANCE=29,
        CLEAR_PREP=30, CLEAR_SEND=31, CLEAR_NEXT=32;
    reg [5:0] state;
    assign busy=state!=IDLE;
    wire [31:0] w0=command[31:0], w1=command[63:32], w2=command[95:64],
        w3=command[127:96], w4=command[159:128], w5=command[191:160],
        w6=command[223:192], w7=command[255:224];
    reg configured, texture_valid;
    reg [2:0] plane_valid;
    reg [3:0] color_page, z_page, flags;
    reg [8:0] alpha;
    reg [15:0] solid;
    reg signed [47:0] u0,v0,z0;
    reg signed [31:0] ux,uy,vx,vy,zx,zy;
    // One guard bit beyond the 48-bit origin covers both screen products.
    reg signed [48:0] u,v,z;
    reg signed [47:0] xu,yu,xv,yv,xz,yz;
    reg [10:0] px, span_left;
    reg [9:0] py;
    reg [19:0] row_offset;
    reg [28:0] color_addr,z_addr;
    reg [4:0] chunk_count, chunk_left;
    reg [3:0] lane;
    reg [255:0] color_buf,z_buf;
    reg [31:0] pixel_mask;
    reg [15:0] source_pixel,background,depth;
    reg sample_inside, sample_depth_ok, visible;
    reg [14:0] mix_r,mix_g,mix_b;
    wire [8:0] inverse_alpha=9'd256-alpha;
    wire [15:0] blended={mix_r[12:8],mix_g[13:8],mix_b[12:8]};

    reg [7:0] tw,th;
    reg [1:0] mode_u,mode_v;
    reg [3:0] texture_page;
    reg [9:0] texture_x,texture_y;
    reg [6:0] load_x,load_y;
    reg [7:0] load_left;
    reg [3:0] load_lane;
    reg [24:0] texture_row;
    reg [255:0] texture_buffer;
    reg [15:0] texture [0:16383];
    reg [15:0] texel;
    wire u_in=u>=0 && u<$signed({24'd0,tw,16'd0});
    wire v_in=v>=0 && v<$signed({24'd0,th,16'd0});
    wire [6:0] tex_u=mode_u==1 ? (u[22:16] & (tw[6:0]-7'd1)) :
        u<0 ? 7'd0 : !u_in ? tw[6:0]-7'd1 : u[22:16];
    wire [6:0] tex_v=mode_v==1 ? (v[22:16] & (th[6:0]-7'd1)) :
        v<0 ? 7'd0 : !v_in ? th[6:0]-7'd1 : v[22:16];
    wire texture_inside=(u_in || mode_u!=0) && (v_in || mode_v!=0);
    always @(posedge clk) begin
        if(state==TEX_COPY)texture[{load_y,load_x}]<=texture_buffer[load_lane*16+:16];
        texel<=texture[{tex_v,tex_u}];
    end

    reg triangle_start;
    wire triangle_busy,triangle_valid;
    wire [10:0] triangle_x,triangle_width;
    wire [9:0] triangle_y;
    gpu_triangle #(.WIDTH(WIDTH),.HEIGHT(HEIGHT)) u_triangle (
        .clk(clk),.rst(rst),.start(triangle_start),
        .x0(w1[31:16]),.y0(w1[15:0]),.x1(w2[31:16]),.y1(w2[15:0]),
        .x2(w3[31:16]),.y2(w3[15:0]),.busy(triangle_busy),
        .valid(triangle_valid),.ready(state==TRI_WAIT),
        .span_x(triangle_x),.span_width(triangle_width),.span_y(triangle_y));
    // Registered products: two settling cycles before loading accumulators.
    always @(posedge clk) begin
        xu<=$signed({1'b0,px})*ux; yu<=$signed({1'b0,py})*uy;
        xv<=$signed({1'b0,px})*vx; yv<=$signed({1'b0,py})*vy;
        xz<=$signed({1'b0,px})*zx; yz<=$signed({1'b0,py})*zy;
    end
    reg signed [48:0] origin_u,origin_v,origin_z;
    always @(posedge clk) begin
        origin_u<=xu+u0;origin_v<=xv+v0;origin_z<=xz+z0;
    end
    reg [1:0] clear_flags;
    reg clearing_depth;
    reg [15:0] clear_color,clear_depth;
    reg [15:0] clear_block;
    wire [4:0] room=5'd16-{1'b0,px[3:0]};
    wire state_words_ok=w0[23:0]==0 && w1[31:8]==0 && w2[31:4]==0 &&
        w3<=256 && w4[31:16]==0 && w5==0 && w6==0 && w7==0 && w1[3:0]!=w1[7:4];
    wire tex_words_ok=w0[23:0]==0 && w1[31:4]==0 && w4[31:4]==0 &&
        w5==0 && w6==0 && w7==0 && w3[31:16]>=1 && w3[31:16]<=128 &&
        w3[15:0]>=1 && w3[15:0]<=128 &&
        ({1'b0,w2[31:16]}+{1'b0,w3[31:16]})<=WIDTH &&
        ({1'b0,w2[15:0]}+{1'b0,w3[15:0]})<=HEIGHT &&
        w4[1:0]!=3 && w4[3:2]!=3 &&
        (w4[1:0]!=1 || (w3[31:16] & (w3[31:16]-16'd1))==0) &&
        (w4[3:2]!=1 || (w3[15:0] & (w3[15:0]-16'd1))==0);
    wire triangle_words_ok=w0[23:0]==0 && w4==0 && w5==0 && w6==0 && w7==0;
    wire plane_words_ok=w0[23:0]==0 && w4[31:17]==0 &&
        (w4[16] || w4[15:0]==0) && w5==0 && w6==0 && w7==0;
    // Extended origin is signed Q32.16; w4=0 retains the initial interface.
    wire signed [47:0] signed_plane_origin=w4[16] ? {w4[15:0],w1}:{{16{w1[31]}},w1};
    wire signed [47:0] depth_plane_origin=w4[16] ? {w4[15:0],w1}:{16'd0,w1};
    always @(posedge clk) begin
        if(rst)begin
            state<=IDLE;done<=0;valid<=0;write<=0;addr<=0;wr_data<=0;wr_mask<=-1;
            configured<=0;texture_valid<=0;plane_valid<=0;rejected<=0;fragments<=0;passed<=0;
            color_page<=0;z_page<=0;flags<=0;alpha<=256;solid<=0;
            u0<=0;v0<=0;z0<=0;ux<=0;uy<=0;vx<=0;vy<=0;zx<=0;zy<=0;
            u<=0;v<=0;z<=0;px<=0;py<=0;span_left<=0;row_offset<=0;
            color_addr<=0;z_addr<=0;chunk_count<=0;chunk_left<=0;lane<=0;
            color_buf<=0;z_buf<=0;pixel_mask<=-1;source_pixel<=0;background<=0;depth<=0;
            sample_inside<=0;sample_depth_ok<=0;visible<=0;mix_r<=0;mix_g<=0;mix_b<=0;
            tw<=0;th<=0;mode_u<=0;mode_v<=0;texture_page<=0;texture_x<=0;texture_y<=0;
            load_x<=0;load_y<=0;load_left<=0;load_lane<=0;texture_row<=0;texture_buffer<=0;
            triangle_start<=0;clear_flags<=0;clearing_depth<=0;clear_color<=0;clear_depth<=0;clear_block<=0;
        end else begin
            done<=0;triangle_start<=0;
            case(state)
            IDLE:if(start)begin
                case(w0[31:24])
                14:begin
                    configured<=state_words_ok;
                    color_page<=w1[3:0];z_page<=w1[7:4];flags<=w2[3:0];alpha<=w3[8:0];solid<=w4[15:0];
                    state<=state_words_ok ? FINISH:BAD;
                end
                15:begin
                    texture_valid<=0;tw<=w3[23:16];th<=w3[7:0];mode_u<=w4[1:0];mode_v<=w4[3:2];
                    texture_page<=w1[3:0];texture_x<=w2[25:16];texture_y<=w2[9:0];
                    load_x<=0;load_y<=0;state<=tex_words_ok ? TEX_ADDR:BAD;
                end
                16:begin u0<=signed_plane_origin;ux<=w2;uy<=w3;plane_valid[0]<=plane_words_ok;state<=plane_words_ok ? FINISH:BAD;end
                17:begin v0<=signed_plane_origin;vx<=w2;vy<=w3;plane_valid[1]<=plane_words_ok;state<=plane_words_ok ? FINISH:BAD;end
                18:begin z0<=depth_plane_origin;zx<=w2;zy<=w3;plane_valid[2]<=plane_words_ok;state<=plane_words_ok ? FINISH:BAD;end
                19:begin
                    if(!configured || !triangle_words_ok ||
                       (flags[0] && (!texture_valid || plane_valid[1:0]!=3)) ||
                       ((flags[1] || flags[2]) && !plane_valid[2]))state<=BAD;
                    else state<=alpha==0 ? FINISH:TRI_START;
                end
                20:begin
                    clear_flags<=w1[1:0];clear_color<=w2[15:0];clear_depth<=w3[15:0];
                    clear_block<=0;clearing_depth<=!w1[0];
                    state<=!configured || w0[23:0]!=0 || w1[31:2]!=0 || w2[31:16]!=0 ||
                        w3[31:16]!=0 || w4!=0 || w5!=0 || w6!=0 || w7!=0 ? BAD:
                        w1[1:0]==0 ? FINISH:CLEAR_PREP;
                end
                default:state<=BAD;
                endcase
            end
            BAD:begin rejected<=rejected+1'b1;state<=FINISH;end
            FINISH:begin done<=1;state<=IDLE;end
            TEX_ADDR:begin
                texture_row<=25'h0800000+{1'b0,texture_page,20'b0}+
                    (texture_y+{3'b0,load_y})*(WIDTH*2)+{14'd0,texture_x,1'b0};
                load_x<=0;load_left<=tw;state<=TEX_NEXT;
            end
            TEX_NEXT:begin
                addr<={6'b0,texture_row[24:5],3'b0};load_lane<=texture_row[4:1];
                valid<=1;write<=0;state<=TEX_REQ;
            end
            TEX_REQ:if(ready)begin valid<=0;state<=TEX_WAIT;end
            TEX_WAIT:if(rd_valid)begin texture_buffer<=rd_data;state<=TEX_COPY;end
            TEX_COPY:begin
                load_x<=load_x+1'b1;load_left<=load_left-1'b1;load_lane<=load_lane+1'b1;
                if(load_left==1)begin
                    if({1'b0,load_y}+8'd1==th)begin texture_valid<=1;state<=FINISH;end
                    else begin load_y<=load_y+1'b1;state<=TEX_ADDR;end
                end else if(load_lane==15)begin
                    texture_row<={texture_row[24:5]+20'd1,5'b0};state<=TEX_NEXT;
                end
            end
            TRI_START:begin triangle_start<=1;state<=TRI_BOOT;end
            TRI_BOOT:state<=TRI_WAIT;
            TRI_WAIT:begin
                if(triangle_valid)begin px<=triangle_x;py<=triangle_y;span_left<=triangle_width;state<=SPAN0;end
                else if(!triangle_busy)state<=FINISH;
            end
            SPAN0:begin row_offset<=py*(WIDTH*2);state<=SPAN1;end
            SPAN1:state<=SPAN2;
            SPAN2:begin u<=origin_u+yu;v<=origin_v+yv;z<=origin_z+yz;state<=CHUNK;end
            CHUNK:begin
                color_addr<=(29'h0800000+{5'd0,color_page,20'd0}+row_offset+({18'd0,px}<<1))>>2;
                z_addr<=(29'h0800000+{5'd0,z_page,20'd0}+row_offset+({18'd0,px}<<1))>>2;
                lane<=px[3:0];chunk_count<=span_left>{6'd0,room} ? room:span_left[4:0];
                chunk_left<=span_left>{6'd0,room} ? room:span_left[4:0];
                color_buf<=0;z_buf<=0;pixel_mask<=-1;state<=COLOR_REQ;
            end
            COLOR_REQ:begin
                if(alpha!=256)begin addr<={color_addr[28:3],3'b0};valid<=1;write<=0;state<=COLOR_WAIT;end
                else state<=Z_PREP;
            end
            COLOR_WAIT:begin
                if(valid && ready)valid<=0;
                if(rd_valid)begin color_buf<=rd_data;state<=Z_PREP;end
            end
            Z_PREP:begin
                if(flags[1])begin addr<={z_addr[28:3],3'b0};valid<=1;write<=0;state<=Z_WAIT;end
                else state<=PIX_PRIME;
            end
            Z_WAIT:begin
                if(valid && ready)valid<=0;
                if(rd_valid)begin z_buf<=rd_data;state<=PIX_PRIME;end
            end
            PIX_PRIME:state<=PIX_SAMPLE;
            PIX_SAMPLE:begin
                source_pixel<=flags[0] ? texel:solid;background<=color_buf[lane*16+:16];
                depth<=z[31:16];sample_depth_ok<=z>=0 && z<48'sh000100000000;
                sample_inside<=!flags[0] || texture_inside;state<=PIX_TEST;
            end
            PIX_TEST:begin
                visible<=sample_inside && !(flags[3] && source_pixel==0) &&
                    (!(flags[1] || flags[2]) || sample_depth_ok) &&
                    (!flags[1] || depth<z_buf[lane*16+:16]);
                fragments<=fragments+1'b1;state<=PIX_BLEND;
            end
            PIX_BLEND:begin
                mix_r<=source_pixel[15:11]*alpha+background[15:11]*inverse_alpha+15'd128;
                mix_g<=source_pixel[10:5]*alpha+background[10:5]*inverse_alpha+15'd128;
                mix_b<=source_pixel[4:0]*alpha+background[4:0]*inverse_alpha+15'd128;
                state<=PIX_STORE;
            end
            PIX_STORE:begin
                if(visible)begin
                    color_buf[lane*16+:16]<=blended;z_buf[lane*16+:16]<=depth;
                    pixel_mask[lane*2+:2]<=0;passed<=passed+1'b1;
                end
                u<=u+ux;v<=v+vx;z<=z+zx;lane<=lane+1'b1;chunk_left<=chunk_left-1'b1;
                state<=chunk_left==1 ? COLOR_WRITE:PIX_PRIME;
            end
            COLOR_WRITE:begin
                if(pixel_mask==32'hffffffff)state<=ADVANCE;
                else begin
                    addr<={color_addr[28:3],3'b0};wr_data<=color_buf;wr_mask<=pixel_mask;
                    valid<=1;write<=1;state<=COLOR_SENT;
                end
            end
            COLOR_SENT:if(ready)begin valid<=0;state<=flags[2] ? Z_WRITE:ADVANCE;end
            Z_WRITE:begin
                addr<={z_addr[28:3],3'b0};wr_data<=z_buf;wr_mask<=pixel_mask;
                valid<=1;write<=1;state<=Z_SENT;
            end
            Z_SENT:if(ready)begin valid<=0;state<=ADVANCE;end
            ADVANCE:begin
                px<=px+chunk_count;span_left<=span_left-chunk_count;
                state<=span_left=={6'd0,chunk_count} ? TRI_WAIT:CHUNK;
            end
            CLEAR_PREP:begin
                addr<=29'h0200000+{7'd0,(clearing_depth ? z_page:color_page),18'd0}+{10'd0,clear_block,3'b0};
                wr_data<={16{clearing_depth ? clear_depth:clear_color}};wr_mask<=0;
                valid<=1;write<=1;state<=CLEAR_SEND;
            end
            CLEAR_SEND:if(ready)begin valid<=0;state<=CLEAR_NEXT;end
            CLEAR_NEXT:begin
                clear_block<=clear_block+1'b1;
                if(clear_block==WIDTH*HEIGHT/16-1)begin
                    if(!clearing_depth && clear_flags[1])begin clearing_depth<=1;clear_block<=0;state<=CLEAR_PREP;end
                    else state<=FINISH;
                end else state<=CLEAR_PREP;
            end
            default:begin valid<=0;state<=BAD;end
            endcase
        end
    end
endmodule
`default_nettype wire
