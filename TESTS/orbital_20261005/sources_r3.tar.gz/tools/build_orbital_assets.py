#!/usr/bin/env python3
"""Pack original ORBITAL art for R31: RGB565/ARGB4444 plus native indexed HUD."""
from pathlib import Path
import colorsys,hashlib,json,math,struct,zlib
import numpy as np
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'assets/orbital/packed';BASE=0x05000000

def font(n):return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',n)
def label(im,xy,text,n=14,color=(155,236,247,255)):
 ImageDraw.Draw(im).text(xy,text,font=font(n),fill=color)
def main():
 OUT.mkdir(parents=True,exist_ok=True)
 # The rifle aims: 17 frames turned about a pivot on the lower edge, from -20 to +20 degrees.
 # The canvas is larger than the 416x248 rifle so that the turned barrel is never cropped;
 # the cut wrists stay below the bottom HUD band.
 source=Image.open(ROOT/'assets/orbital/source/weapon.png').convert('RGBA');scale=416/source.width
 FW,FH,OX,OY=512,320,96,72;pivot=(OX+258,OY+248);muzzle0=(OX+127,OY+29);weapons=[];muzzles=[]
 for i in range(17):
  angle=(i-8)*2.5;big=Image.new('RGBA',(int(FW/scale),int(FH/scale)));big.paste(source,(int(OX/scale),int(OY/scale)))
  turned=big.rotate(angle,resample=Image.Resampling.BICUBIC,center=(pivot[0]/scale,pivot[1]/scale)).resize((FW,FH),Image.Resampling.LANCZOS)
  weapons.append(turned);a=math.radians(-angle);dx,dy=muzzle0[0]-pivot[0],muzzle0[1]-pivot[1]
  muzzles.append((round(pivot[0]+dx*math.cos(a)-dy*math.sin(a)),round(pivot[1]+dx*math.sin(a)+dy*math.cos(a))))
 weapon=weapons[8]
 top=Image.new('RGBA',(800,48));d=ImageDraw.Draw(top);d.rectangle((0,0,799,47),fill=(7,16,27,255));d.line((0,47,799,47),fill=(48,116,148,255))
 label(top,(18,8),'ORBITAL',22);label(top,(652,9),'AUTO // R31',14);label(top,(318,8),'BOUCLIER',10)
 bottom=Image.new('RGBA',(800,38));d=ImageDraw.Draw(bottom);d.rectangle((0,0,799,37),fill=(7,16,27,255));d.line((0,0,799,0),fill=(48,116,148,255));label(bottom,(18,10),'STATION AURORA  /  SECTEUR 07',12);label(bottom,(300,10),'DÉMONSTRATION AUTOMATIQUE',12);label(bottom,(584,12),'DRONES',11);label(bottom,(700,12),'AR-7',11)
 captions=[]
 for a,b in [('SAS D’AMARRAGE','Station Aurora · Drones hostiles à bord'),('BAIE D’OBSERVATION','Traverser la plate-forme panoramique'),('MONTE-CHARGE','Descente vers le cœur de la station'),('SALLE DU RÉACTEUR','Le cœur est instable · Rester à couvert'),('LE GARDIEN','Détruire la machine de guerre'),('ALERTE','Réacteur critique · Évacuation immédiate'),('PONT EXTÉRIEUR','Les renforts arrivent')]:
  im=Image.new('RGBA',(448,64),(7,20,31,255));d=ImageDraw.Draw(im);d.line((0,0,447,0),fill=(64,203,228,255));label(im,(16,7),a,17);label(im,(16,34),b,12);captions.append(im)
 title=Image.new('RGBA',(512,150),(7,20,31,230));label(title,(63,16),'ORBITAL',69);label(title,(99,106),'DÉMONSTRATION GPU  /  PRO DOCK',14)
 finish=Image.new('RGBA',(512,110),(7,20,31,230));label(finish,(56,10),'STATION SÉCURISÉE',35);label(finish,(95,65),'ORBITAL  ·  LE VOYAGE RECOMMENCE',14)
 # Motion tracker, guardian gauge and counters of the native HUD.
 tracker=Image.new('RGBA',(96,96));d=ImageDraw.Draw(tracker);d.ellipse((0,0,95,95),fill=(7,20,31,255),outline=(64,203,228,255))
 for r in (16,32):d.ellipse((48-r,48-r,48+r,48+r),outline=(40,110,150,255))
 d.line((48,4,48,92),fill=(40,110,150,255));d.line((4,48,92,48),fill=(40,110,150,255));d.polygon([(48,42),(53,54),(43,54)],fill=(155,236,247,255))
 gauge=Image.new('RGBA',(320,32),(7,20,31,255));d=ImageDraw.Draw(gauge);d.rectangle((0,0,319,31),outline=(244,85,201,255));label(gauge,(10,7),'GARDIEN',14,(255,211,90,255))
 images=weapons+[top,bottom,title,finish,tracker,gauge]+captions
 colors=np.concatenate([np.asarray(im)[:,:,:3][np.asarray(im)[:,:,3]>=128] for im in images]);colors=colors[:len(colors)//256*256]
 trained=Image.fromarray(colors.reshape(-1,256,3)).quantize(colors=239,method=Image.Quantize.MEDIANCUT)
 pal=[(0,0,0)]+list(zip(*[iter(trained.getpalette()[:239*3])]*3))+[(240,250,255),(80,220,255),(255,211,90),(244,85,201),(10,27,43),(80,170,200),(255,255,220),(40,110,150),(255,150,50),(110,200,244),(122,244,255),(255,80,40),(255,235,140),(25,60,95),(77,130,170),(0,0,0)]
 palette=Image.new('P',(1,1));palette.putpalette(sum((list(c) for c in pal),[]))
 def quant(im):
  a=np.asarray(im.convert('RGB').quantize(palette=palette,dither=Image.Dither.NONE)).copy();opaque=np.asarray(im)[:,:,3]>=128;a[~opaque]=0;a[opaque&(a==0)]=244;return a
 data=bytearray(1024);regions={}
 def add(name,raw,**meta):
  data.extend(bytes((-len(data))%32));off=len(data);data.extend(raw);regions[name]=dict(address=BASE+off,offset=off,bytes=len(raw),**meta)
 def rgb565(im):
  a=np.asarray(im.convert('RGB')).astype(np.uint32);return (((a[:,:,0]*31+127)//255<<11)|((a[:,:,1]*63+127)//255<<5)|((a[:,:,2]*31+127)//255)).astype('<u2').tobytes()
 add('palette',struct.pack('<256I',*[((r*63+127)//255<<12)|((g*63+127)//255<<6)|((b*63+127)//255) for r,g,b in pal]))
 sky=Image.open(ROOT/'assets/orbital/source/sky.png').convert('RGB').resize((512,256),Image.Resampling.LANCZOS);add('sky',rgb565(sky),width=512,height=256,stride=1024)
 add('weapon',b''.join(quant(im).tobytes() for im in weapons),width=FW,height=FH,frames=17)
 for name,im in [('top',top),('bottom',bottom),('title',title),('finish',finish),('tracker',tracker),('gauge',gauge)]+[(f'caption{i}',im) for i,im in enumerate(captions)]:add(name,quant(im).tobytes(),width=im.width,height=im.height)
 enemy=Image.open(ROOT/'assets/orbital/source/drones.png').convert('RGBA')
 # Three kinds of enemies from the one generated sheet: the drone itself, a crimson elite
 # (hue turned) and the Guardian, a 256x256 war machine assembled from five turned drones.
 def hue(im,turn,gain=1.0):
  a=np.asarray(im).astype(np.float32)/255;out=a.copy()
  for y in range(a.shape[0]):
   for x in range(a.shape[1]):
    if a[y,x,3]>0:
     h,sat,v=colorsys.rgb_to_hsv(*a[y,x,:3])
     # only the violet armour turns; amber eyes and cyan thrusters keep their colour
     if 0.62<h<0.92:h=(h+turn)%1.0;v=min(1.0,v*gain)
     out[y,x,:3]=colorsys.hsv_to_rgb(h,sat,v)
  return Image.fromarray((out*255+.5).astype(np.uint8),'RGBA')
 def argb(im):
  a=np.asarray(im).astype(np.uint16);return ((a[:,:,3]*15+127)//255<<12)|((a[:,:,0]//17)<<8)|((a[:,:,1]//17)<<4)|(a[:,:,2]//17)
 def occupancy(v,cell):
  occupied=(v>>12).reshape(8,cell,8,cell).max(axis=(1,3))>0;return [int(sum(1<<c for c in range(8) if row[c])) for row in occupied]
 poses=[];cells=[]
 for i in range(4):
  x=i%2;y=i//2;poses.append(enemy.crop((x*enemy.width//2,y*enemy.height//2,(x+1)*enemy.width//2,(y+1)*enemy.height//2)))
 for kind,turn in (('drone',0.0),('elite',0.22)):
  for i in range(4):
   im=poses[i].resize((128,128),Image.Resampling.LANCZOS)
   if turn:im=hue(im,turn,1.15)
   v=argb(im);add(f'{kind}{i}',v.astype('<u2').tobytes(),width=128,height=128,stride=256);cells.append(occupancy(v,16))
 for i in range(4):
  im=Image.new('RGBA',(256,256))
  # two escorts as side cannons, two as lower claws, behind a large golden-crimson core
  for px,py,size,flip in ((6,70,104,False),(146,70,104,True),(40,140,96,False),(120,140,96,True)):
   part=hue(poses[1 if i==1 else i].resize((size,size),Image.Resampling.LANCZOS),0.30,0.8)
   if flip:part=part.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
   im.alpha_composite(part,(px,py))
  core=hue(poses[i].resize((200,200),Image.Resampling.LANCZOS),0.36,1.25);im.alpha_composite(core,(28,18))
  v=argb(im);add(f'guardian{i}',v.astype('<u2').tobytes(),width=256,height=256,stride=512);cells.append(occupancy(v,32))
 # Repeating inset mechanical strip: small real perspective-mapped panels.
 metal=Image.new('RGB',(64,64),(33,52,61));d=ImageDraw.Draw(metal);d.rectangle((2,2,61,61),outline=(90,125,132),width=2);d.rectangle((8,6,56,40),fill=(48,66,70));d.rectangle((12,10,52,15),fill=(60,173,196));
 for y in range(22,38,5):d.line((14,y,50,y),fill=(15,30,39),width=2)
 for x in (7,56):
  for y in (7,56):d.rectangle((x,y,x+1,y+1),fill=(145,155,153))
 add('metal',rgb565(metal),width=64,height=64,stride=128)
 # Reactor pillar cladding and hazard stripes, procedural.
 pillar=Image.new('RGB',(64,64),(52,58,70));d=ImageDraw.Draw(pillar);d.rectangle((0,0,63,63),outline=(96,108,124),width=2);d.rectangle((10,8,53,26),fill=(30,36,46));d.rectangle((14,12,49,15),fill=(255,150,50));d.rectangle((14,19,38,21),fill=(80,220,255))
 for y in range(34,58,6):d.line((10,y,53,y),fill=(24,28,36),width=2)
 add('pillar',rgb565(pillar),width=64,height=64,stride=128)
 hazard=Image.new('RGB',(64,64),(34,34,38));d=ImageDraw.Draw(hazard)
 for k in range(-64,64,32):d.polygon([(k,64),(k+16,64),(k+80,0),(k+64,0)],fill=(236,180,40))
 d.rectangle((0,0,63,63),outline=(20,20,22),width=3);add('hazard',rgb565(hazard),width=64,height=64,stride=128)
 # Native crosshair, shield and an indexed particles/flash atlas.
 cross=Image.new('L',(32,32));d=ImageDraw.Draw(cross);d.line((4,16,11,16),fill=241);d.line((21,16,28,16),fill=241);d.line((16,4,16,11),fill=241);d.line((16,21,16,28),fill=241);d.point((16,16),fill=240);add('crosshair',cross.tobytes())
 add('shield',bytes([241])*256*8)
 fx=[]
 for k in range(16):
  im=Image.new('L',(32,32));d=ImageDraw.Draw(im);r=3+(k%4)*3;c=242 if k<8 else 243
  if k<4:d.ellipse((16-r,16-r,16+r,16+r),fill=c);d.ellipse((14-r//2,14-r//2,18+r//2,18+r//2),fill=246)
  elif k<8:d.polygon([(16,1),(19,12),(30,8),(22,17),(31,25),(20,21),(16,31),(12,21),(1,25),(9,17),(2,7),(13,12)],fill=c);d.ellipse((12,12,20,20),fill=246)
  else:d.line((16-r,16,16+r,16),fill=c,width=2);d.line((16,16-r,16,16+r),fill=c,width=2)
  fx.append(im.tobytes())
 add('effects',b''.join(fx))
 digits=[]
 for k in range(10):
  im=Image.new('L',(32,32));ImageDraw.Draw(im).text((7,2),str(k),font=font(22),fill=250);digits.append(bytes(250 if v>110 else 0 for v in im.tobytes()))
 add('digits',b''.join(digits))
 blips=[]
 for c in (251,248,243):
  im=Image.new('L',(32,32));ImageDraw.Draw(im).ellipse((13,13,19,19),fill=c);blips.append(im.tobytes())
 add('blips',b''.join(blips))
 data.extend(bytes((-len(data))%32));crc=zlib.crc32(data[1024:]);struct.pack_into('<4I',data,0,0x4f524249,1,len(data),crc);(OUT/'orbital.bin').write_bytes(data)
 m=dict(version=1,base=BASE,bytes=len(data),crc32=f'{crc:08x}',sha256=hashlib.sha256(data).hexdigest(),regions=regions,sources={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'assets/orbital/source').glob('*.png'))});(OUT/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
 h=['// Generated by tools/build_orbital_assets.py','#ifndef ORBITAL_ASSETS_H','#define ORBITAL_ASSETS_H',f'#define ORBITAL_BASE 0x{BASE:08x}UL',f'#define ORBITAL_BYTES {len(data)}UL',f'#define ORBITAL_CRC 0x{crc:08x}U']+[f'#define ORBITAL_{name.upper()} 0x{r["address"]:08x}UL' for name,r in regions.items()]+['#define ORBITAL_CELLS {'+','.join('{'+','.join(f'0x{v:02x}' for v in pose)+'}' for pose in cells)+'}',f'#define ORBITAL_WEAPON_W {FW}',f'#define ORBITAL_WEAPON_H {FH}',f'#define ORBITAL_PIVOT_X {pivot[0]}',f'#define ORBITAL_PIVOT_Y {pivot[1]}','#define ORBITAL_MUZZLES {'+','.join(f'{{{x},{y}}}' for x,y in muzzles)+'}']+['#endif',''];(ROOT/'fw_console/orbital_assets.h').write_text('\n'.join(h));print(json.dumps({k:m[k] for k in ('bytes','crc32','sha256')},indent=2))
if __name__=='__main__':main()
