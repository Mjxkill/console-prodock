// ORBITAL: autonomous FPS on the unchanged R31 GPU. Shared AE350/host scene.
#ifndef ORBITAL_SCENE_H
#define ORBITAL_SCENE_H
#include <stdint.h>
#include <string.h>
#include "gpu_v1.h"
#include "orbital_assets.h"
#define ORBITAL_FRAMES 3800U
#define ORBITAL_STRIDE 800U
// Depth haze: the hardware fog formula of GPU_V1_FOG on the Z16 value, with the same three
// constants for the triangles (gpu_material) and for the rows and bars shaded by the CPU.
#define ORB_FOG_NEAR 56000
#define ORB_FOG_SCALE 2950U
#define ORB_FOG_COLOR 0x228eU
typedef struct { int x,y,z,u,v; } orb_point;
typedef struct { int x,z,yaw,bob; } orb_camera;
typedef struct { unsigned frame,chapter,sprites,shots;int aim_x,aim_y; } orb_info;
static const int16_t orb_sines[65]={0,402,804,1205,1606,2006,2404,2801,3196,3590,3981,4370,4756,5139,5520,5897,6270,6639,7005,7366,7723,8076,8423,8765,9102,9434,9760,10080,10394,10702,11003,11297,11585,11866,12140,12406,12665,12916,13160,13395,13623,13842,14053,14256,14449,14635,14811,14978,15137,15286,15426,15557,15679,15791,15893,15986,16069,16143,16207,16261,16305,16340,16364,16379,16384};
static int orb_sin(unsigned p){p&=255;int v=orb_sines[(p&64)?64-(p&63):p&63];return p&128?-v:v;}
static int orb_cos(unsigned p){return orb_sin(p+64);}
static int orb_clamp(int v,int a,int b){return v<a?a:v>b?b:v;}
static int orb_lerp(int a,int b,int t,int n){return a+(b-a)*t/n;}
static orb_camera orb_view(unsigned t)
{
 static const int keys[][2]={{0,0},{400,180},{800,320},{1300,610},{1800,890},{2200,1170},{2500,1260},{3100,1270},{3800,1270}};
 unsigned i=0;while(i+1<sizeof(keys)/sizeof(*keys) && (int)t>keys[i+1][0])++i;
 int z=orb_lerp(keys[i][1],keys[i+1][1],(int)t-keys[i][0],keys[i+1][0]-keys[i][0]);
 int yaw=t<2200?orb_sin(t/8)*3/16384:orb_sin((t-2200)/9)*12/16384;
 return (orb_camera){orb_sin(t/7)*18/16384,z,yaw,orb_sin(t*2)*2/16384};
}
static orb_point orb_transform(orb_point p,orb_camera c)
{int x=p.x-c.x,z=p.z-c.z;return (orb_point){(x*orb_cos(c.yaw)-z*orb_sin(c.yaw))/16384,p.y,(z*orb_cos(c.yaw)+x*orb_sin(c.yaw))/16384,p.u,p.v};}
// Bench only (firmware command B): 1 flat, 2 textured, 4 emissive quads skipped,
// 8 station without Z, 16 no Z clear, 32 no sky copy, 64 no combat, 128 no floor/ceiling rows,
// 256 full-screen sky copy (coverage proof). Always 0 in the demo.
static unsigned orb_skip;
static int orb_depth(int z){return 60000-1600000/z;}
static int orb_clip(const orb_point *in,int count,orb_point *out,int plane,int far)
{
 int n=0;for(int i=0;i<count;++i){orb_point a=in[i],b=in[(i+1)%count];int ia=far?a.z<=plane:a.z>=plane,ib=far?b.z<=plane:b.z>=plane;
  if(ia)out[n++]=a;
  if(ia!=ib){int d=b.z-a.z,t=plane-a.z;out[n++]=(orb_point){a.x+(int)((int64_t)(b.x-a.x)*t/d),a.y+(int)((int64_t)(b.y-a.y)*t/d),plane,a.u+(int)((int64_t)(b.u-a.u)*t/d),a.v+(int)((int64_t)(b.v-a.v)*t/d)};}
 }return n;
}
static int orb_quad(gpu_v1_context *c,orb_camera camera,const orb_point points[4],unsigned color,unsigned type,int bias)
{
 if(orb_skip&(1U<<type))return 1;
 orb_point a[10],b[10];for(unsigned i=0;i<4;++i)a[i]=orb_transform(points[i],camera);
 int count=orb_clip(a,4,b,64,0);if(count<3)return 1;count=orb_clip(b,count,a,1800,1);if(count<3)return 1;
 gpu_vertex v[10];for(int i=0;i<count;++i){int light=type==2?256:orb_clamp(310-a[i].z/6+a[i].y/6,95,256);
  v[i]=(gpu_vertex){200+a[i].x*180/a[i].z,120-a[i].y*180/a[i].z+camera.bob,a[i].u,a[i].v,orb_depth(a[i].z)-bias,16777216/a[i].z,light,light,light};}
 int minx=10000,maxx=-10000,miny=10000,maxy=-10000;
 for(int i=0;i<count;++i){if(v[i].x<minx)minx=v[i].x;if(v[i].x>maxx)maxx=v[i].x;if(v[i].y<miny)miny=v[i].y;if(v[i].y>maxy)maxy=v[i].y;}
 if(maxx<0||minx>=400||maxy<24||miny>=221)return 1;
 gpu_material m={(orb_skip&8?0:GPU_Z_TEST|GPU_Z_WRITE)|(type==2?0:GPU_V1_GOURAUD|GPU_V1_FOG)|(type==1?GPU_RASTER_TEXTURE|GPU_PERSPECTIVE:0),256,color,256,256,256,ORB_FOG_NEAR,ORB_FOG_COLOR,ORB_FOG_SCALE};
 if(!gpu_v1_material(c,&m))return 0;
 if(type==1){gpu_texture_level tex={ORBITAL_METAL,64,64,128,GPU_RGB565,GPU_TEX_CLAMP,GPU_TEX_CLAMP,0};if(!gpu_v1_texture(c,&tex))return 0;}
 for(int i=1;i<count-1;++i){gpu_vertex q[3]={v[0],v[i],v[i+1]};int64_t area=(int64_t)(q[1].x-q[0].x)*(q[2].y-q[0].y)-(int64_t)(q[2].x-q[0].x)*(q[1].y-q[0].y);
  if(area>-16 && area<16)continue;
  if(!gpu_v1_triangle(c,q))return 0;
 }return 1;
}
// Axis-aligned surfaces, projected and near/far clipped in the shared 3D path.
static int orb_floor(gpu_v1_context *c,orb_camera cam,int x0,int x1,int z0,int z1,int y,unsigned col,unsigned type,int bias)
{orb_point v[4]={{x0,y,z0,0,63},{x1,y,z0,63,63},{x1,y,z1,63,0},{x0,y,z1,0,0}};return orb_quad(c,cam,v,col,type,bias);}
static int orb_wall(gpu_v1_context *c,orb_camera cam,int x,int z0,int z1,int y0,int y1,unsigned col,unsigned type,int bias)
{orb_point v[4]={{x,y1,z0,0,0},{x,y1,z1,63,0},{x,y0,z1,63,63},{x,y0,z0,0,63}};return orb_quad(c,cam,v,col,type,bias);}
static int orb_front(gpu_v1_context *c,orb_camera cam,int x0,int x1,int z,int y0,int y1,unsigned col,unsigned type,int bias)
{orb_point v[4]={{x0,y1,z,0,0},{x1,y1,z,63,0},{x1,y0,z,63,63},{x0,y0,z,0,63}};return orb_quad(c,cam,v,col,type,bias);}
// Horizontal planes. The camera only yaws, so one screen row of a floor or
// ceiling has a single depth: a row is a few colour+depth rectangle clears
// (opcode 28), about twenty times cheaper per pixel than triangles on R31.
typedef struct { int x0,x1,z0,z1;unsigned color,emissive; } orb_tile;
// Dynamic light of the frame: muzzle flash on near surfaces, orange glow around explosions.
static struct { int muzzle,dawn,blasts,power[2],depth[2]; } orb_env;
static unsigned orb_tone(unsigned color,int light,int z)
{
 light+=orb_env.dawn;if(z<400)light+=orb_env.muzzle*(400-z)/400;
 int r=((int)(color>>11)*light+128)>>8,g=((int)((color>>5)&63)*light+128)>>8,b=((int)(color&31)*light+128)>>8;
 for(int i=0;i<orb_env.blasts;++i){int d=z-orb_env.depth[i];if(d<0)d=-d;if(d<300){int e=orb_env.power[i]*(300-d)/300;r+=e>>3;g+=e>>3;}}
 r=r>31?31:r;g=g>63?63:g;b=b>31?31:b;
 int over=orb_depth(z)-ORB_FOG_NEAR,f=over<=0?0:orb_clamp((int)(((unsigned)over*ORB_FOG_SCALE)>>16),0,256);
 r=(r*(256-f)+(int)(ORB_FOG_COLOR>>11)*f+128)>>8;g=(g*(256-f)+(int)((ORB_FOG_COLOR>>5)&63)*f+128)>>8;b=(b*(256-f)+(int)(ORB_FOG_COLOR&31)*f+128)>>8;
 return (unsigned)(r<<11|g<<5|b);
}
static int orb_floor_div(int a,int b){int q=a/b;return (a%b && (a<0)!=(b<0))?q-1:q;}
// Screen column of a camera-space abscissa in 1/64 unit at depth z, pixel centres.
static int orb_column(int xq,int z){xq=orb_clamp(xq,-96*z,96*z);return orb_floor_div(xq*180+z*12832,z*64);}
static int orb_rows(gpu_v1_context *c,orb_camera cam,int y,const orb_tile *tiles,unsigned count,unsigned base,const gpu_target *sky,int sx,const int gate[2])
{
 int cs=orb_cos(cam.yaw),sn=orb_sin(cam.yaw),cy=120+cam.bob;
 for(int sy=24;sy<221;++sy){int d=2*(sy-cy)+1;if(y>0)d=-d;if(d<=0)continue;
  int z=360*(y<0?-y:y)/d;if(z<64||z>1800)continue;
  int light=orb_clamp(310-z/6+y/6,95,256),depth=orb_depth(z),n=z*cs,reach=((z*10/9+1)*(sn<0?-sn:sn)>>14)+2,zc=cam.z+n/16384;
  int span[48][3];unsigned spans=0;int covered=0;
  for(unsigned i=0;i<count&&spans<48;++i){const orb_tile *t=&tiles[i];if(t->z1<zc-reach||t->z0>zc+reach)continue;
   int a=orb_column(orb_floor_div(((t->x0-cam.x)*16384-z*sn)*64,cs),z),b=orb_column(orb_floor_div(((t->x1-cam.x)*16384-z*sn)*64,cs),z);
   int b0=(t->z0-cam.z)*16384,b1=(t->z1-cam.z)*16384;
   if(!sn){if(n<b0||n>=b1)continue;}
   else{int p=orb_column(orb_clamp(orb_floor_div((n-b0)*16,sn),-24*z,24*z)*4,z),q=orb_column(orb_clamp(orb_floor_div((n-b1)*16,sn),-24*z,24*z)*4,z);
    if(sn>0){if(q>a)a=q;if(p<b)b=p;}else{if(p>a)a=p;if(q<b)b=q;}}
   // From the corridor, the bay is only seen through the bulkhead opening.
   if(t->z0>=1080){if(gate[0]>a)a=gate[0];if(gate[1]<b)b=gate[1];}
   a=orb_clamp(a,0,400);b=orb_clamp(b,0,400);if(b<=a)continue;
   span[spans][0]=a;span[spans][1]=b-a;span[spans][2]=(int)(t->emissive?t->color:orb_tone(t->color,light,z));++spans;
   if(i<base){int l=a>gate[0]?a:gate[0],r=b<gate[1]?b:gate[1];if(r>l)covered+=r-l;}
  }
  // The sky shows wherever the platform does not reach, in the bay or through the bulkhead opening.
  if(sky&&covered<gate[1]-gate[0]&&!gpu_v1_copy(c,sky,sx+gate[0],8+sy,gate[0],sy,(unsigned)(gate[1]-gate[0]),1))return 0;
  for(unsigned i=0;i<spans;++i)if(!gpu_v1_clear(c,3,(unsigned)span[i][2],(unsigned)depth,span[i][0],sy,(unsigned)span[i][1],1))return 0;
 }
 return 1;
}
static int orb_planes(gpu_v1_context *c,orb_camera cam,const gpu_target *sky,int sx,const int gate[2])
{
 orb_tile floor[40],roof[12];unsigned n=0;
 // Corridor slabs stop exactly at the walls, which are drawn first and trimmed by these rows.
 // Bay slabs reach 32 units (3 pixels at the far plane) under the triangle rails and sill.
 for(int k=0;k<10;++k){int z=k*180,wide=z<1080?200:332;
  floor[n++]=(orb_tile){-wide,0,z,z+180,(k&1)?0x4aab:0x52eb,0};floor[n++]=(orb_tile){0,wide,z,z+180,(k&1)?0x52eb:0x4aab,0};}
 for(int k=0;k<10;++k){int z=k*180,wide=z<1080?200:300;
  for(int side=-1;side<=1;side+=2){int x=side*(wide-24);floor[n++]=(orb_tile){x-2,x+2,z+8,z+170,0x3e7f,1};}}
 if(!orb_rows(c,cam,-90,floor,40,20,sky,sx,gate))return 0;
 for(int k=0;k<6;++k)roof[k]=(orb_tile){-200,200,k*180,k*180+180,0x3189,0};
 for(int k=0;k<6;++k)roof[6+k]=(orb_tile){-170,170,k*180+6,k*180+13,0x6f7f,1};
 return orb_rows(c,cam,135,roof,12,6,0,0,gate);
}
// Vertical walls. One screen column of a vertical plane has a single depth, so a wall is a
// set of bars of rectangle clears, wide where the wall is near and its shade varies slowly.
// Bars overshoot the slanted top and bottom edges; the floor, ceiling and sky
// rows drawn afterwards cut those edges exactly.
typedef struct { int side,p,a,b,y0,y1;unsigned color; } orb_slab;  // side: x=p, z in a..b; else z=p, x in a..b
static void orb_camera_point(orb_camera cam,int wx,int wz,int *xq,int *z)
{int dx=wx-cam.x,dz=wz-cam.z,cs=orb_cos(cam.yaw),sn=orb_sin(cam.yaw);*xq=(dx*cs-dz*sn)/256;*z=(dz*cs+dx*sn)/16384;}
static int orb_wall_columns(orb_camera cam,int ax,int az,int bx,int bz,int *ca,int *cb)
{
 int xa,za,xb,zb;orb_camera_point(cam,ax,az,&xa,&za);orb_camera_point(cam,bx,bz,&xb,&zb);if(za<64&&zb<64)return 0;
 if(za<64){xa=xb+(int)((int64_t)(xa-xb)*(zb-64)/(zb-za));za=64;}
 if(zb<64){xb=xa+(int)((int64_t)(xb-xa)*(za-64)/(za-zb));zb=64;}
 int a=orb_clamp(orb_column(xa,za),0,400),b=orb_clamp(orb_column(xb,zb),0,400);*ca=a<b?a:b;*cb=a<b?b:a;return *cb>*ca;
}
// Depth of the wall on the ray through abscissa r/2 pixels - 200; 0 when it is not in front.
static int orb_wall_depth(orb_camera cam,const orb_slab *s,int r)
{
 int cs=orb_cos(cam.yaw),sn=orb_sin(cam.yaw),z;
 if(s->side){int den=r*cs+360*sn;z=den?(s->p-cam.x)*5898240/den:0;}
 else{int den=cs-r*sn/360;z=den>0?(s->p-cam.z)*16384/den:0;}
 return z>=64&&z<=1800?z:0;
}
static int orb_edge(int cy,int y,int z){return orb_floor_div(cy*z-y*180+z/2,z);}
static int orb_bars(gpu_v1_context *c,orb_camera cam,const orb_slab *s,int depth)
{
 int ca,cb,cy=120+cam.bob;
 if(!(s->side?orb_wall_columns(cam,s->p,s->a,s->p,s->b,&ca,&cb):orb_wall_columns(cam,s->a,s->p,s->b,s->p,&ca,&cb)))return 1;
 for(int x=ca,w;x<cb;x+=w){int z=orb_wall_depth(cam,s,2*x+1-400);w=depth?16:!z?1:z<200?16:z<400?8:z<700?4:2;if(w>cb-x)w=cb-x;
  if(depth){int z0=z,z1=orb_wall_depth(cam,s,2*(x+w)-1-400);if(!z0||!z1)continue;
   int ta=orb_edge(cy,s->y1,z0),tb=orb_edge(cy,s->y1,z1),ba=orb_edge(cy,s->y0,z0),bb=orb_edge(cy,s->y0,z1);
   int top=orb_clamp((ta<tb?ta:tb)-2,24,221),bottom=orb_clamp((ba>bb?ba:bb)+2,24,221);
   if(bottom>top&&!gpu_v1_clear(c,2,0,(unsigned)orb_depth(z0<z1?z1:z0),x,top,(unsigned)w,(unsigned)(bottom-top)))return 0;
   continue;}
  // The outer edges take the extreme of both ends of the bar, plus 2 pixels.
  int z0=z,z1=orb_wall_depth(cam,s,2*(x+w)-1-400);z=orb_wall_depth(cam,s,2*x+w-400);if(!z||!z0||!z1)continue;
  int ta=orb_edge(cy,s->y1,z0),tb=orb_edge(cy,s->y1,z1),ba=orb_edge(cy,s->y0,z0),bb=orb_edge(cy,s->y0,z1);
  for(int ya=s->y0,yb;ya<s->y1;ya=yb){yb=ya+45<s->y1?ya+45:s->y1;
   int top=orb_clamp(yb==s->y1?(ta<tb?ta:tb)-2:orb_edge(cy,yb,z),24,221),bottom=orb_clamp(ya==s->y0?(ba>bb?ba:bb)+2:orb_edge(cy,ya,z),24,221);
   if(bottom>top&&!gpu_v1_clear(c,1,orb_tone(s->color,orb_clamp(310-z/6+(ya+yb)/12,95,256),z),0,x,top,(unsigned)w,(unsigned)(bottom-top)))return 0;}
 }
 return 1;
}
// Sky through the glazing of the right wall (world x=200, y -35..95), row by row.
static int orb_window(gpu_v1_context *c,orb_camera cam,const gpu_target *sky,int sx)
{
 int cs=orb_cos(cam.yaw),sn=orb_sin(cam.yaw),cy=120+cam.bob,xe,ze;orb_camera_point(cam,200,1080,&xe,&ze);if(ze<64)return 1;
 int end=orb_column(xe,ze);
 for(int sy=24;sy<221;++sy){int e=2*(cy-sy)-1,z=e>0?95*360/e:35*360/-e,a=end;
  if(z<64)continue;
  if(z<ze){a=orb_column(orb_floor_div(((200-cam.x)*16384-z*sn)*64,cs),z);if(a<end)a=end;}
  a=orb_clamp(a,0,400);if(a<400&&!gpu_v1_copy(c,sky,sx+a,8+sy,a,sy,(unsigned)(400-a),1))return 0;}
 return 1;
}
static int orb_door(unsigned t){return orb_clamp(((int)t-1550)*230/350,0,230);}
static int orb_station(gpu_v1_context *c,orb_camera cam,unsigned t)
{
 for(int k=0;k<10;++k){int z=k*180;if(z+180<cam.z+64)continue;
  // Inset texture panels and narrow emissive guide strips keep fill bounded.
  if(!orb_floor(c,cam,-32,32,z+25,z+120,-89,0,1,12))return 0;
  if(z<1080){
   // Window mullions; the sky is truly behind the open geometry.
   if(!orb_wall(c,cam,198,z,z+14,-35,95,0x9cf3,0,8)||!orb_front(c,cam,190,200,z+14,-35,95,0x31c8,0,8))return 0;
   if(!orb_wall(c,cam,-198,z+50,z+120,-25,55,0,1,18))return 0;
   if(!orb_wall(c,cam,-197,z+3,z+7,-75,110,0x2e5f,2,20))return 0;
  }else{
   for(int side=-1;side<=1;side+=2){int x=side*300;
    if(!orb_wall(c,cam,x,z,z+180,-90,-52,0x528c,0,0)||!orb_wall(c,cam,x,z,z+180,-53,-48,0x5f7f,2,10))return 0;}
  }
 }
 // Sliding bulkhead between corridor and observation bay.
 int opening=orb_door(t);
 if(opening<200){
  if(!orb_front(c,cam,-opening-3,-opening,1078,-80,125,0x67df,2,16)||!orb_front(c,cam,opening,opening+3,1078,-80,125,0x67df,2,16))return 0;}
 // End of the platform: low sill leaves the ringworld visible above it.
 if(!orb_front(c,cam,-300,300,1720,-90,-55,0x52cd,0,0)||!orb_front(c,cam,-300,300,1718,-56,-50,0x4f5f,2,14))return 0;
 return 1;
}
typedef struct { int spawn,kill,x,y,z; } orb_enemy;
// Sorted by depth. Kills are at least 70 phases apart: at most two drones burst at once
// (24 debris sprites); render_orbital.py --sweep checks the 64-sprite limit on every phase.
#define ORB_ENEMIES 10
static const orb_enemy orb_enemies[ORB_ENEMIES]={{300,850,-55,5,600},{420,980,40,30,700},{780,1330,65,20,850},{1000,1500,-70,25,960},{1210,1820,-35,0,1040},
 {2220,2680,-90,22,1510},{2770,3080,-140,40,1540},{2890,3150,130,20,1560},{2420,2940,100,35,1580},{2300,2800,0,60,1650}};
static int orb_enemy_pos(unsigned t,unsigned i,orb_camera camera,orb_point *out)
{
 const orb_enemy *e=&orb_enemies[i];if((int)t<e->spawn||(int)t>e->kill+75)return 0;
 orb_point p={e->x+orb_sin(t/3+i*53)*24/16384,e->y+orb_sin(t+i*31)*12/16384,e->z,0,0};*out=orb_transform(p,camera);return out->z>=64 && out->z<1800;
}
static int orb_shoot(unsigned t,int *target)
{
 *target=-1;for(unsigned i=0;i<ORB_ENEMIES;++i){const orb_enemy *e=&orb_enemies[i];if((int)t>=e->kill-110 && (int)t<e->kill){*target=(int)i;return t%12<3;}}
 return 0;
}
static int orb_glow(gpu_v1_context *c,int x,int y,int r,unsigned color,unsigned alpha)
{
 gpu_material m={GPU_V1_ADDITIVE|GPU_V1_GOURAUD,alpha,color,256,256,256,0,0,0};if(!gpu_v1_material(c,&m))return 0;
 for(unsigned i=0;i<12;++i){unsigned a=i*256/12,b=(i+1)*256/12;gpu_vertex v[3]={{x,y,0,0,0,65536,256,256,256},{x+orb_cos(a)*r/16384,y+orb_sin(a)*r/16384,0,0,0,65536,0,0,0},{x+orb_cos(b)*r/16384,y+orb_sin(b)*r/16384,0,0,0,65536,0,0,0}};if(!gpu_v1_triangle(c,v))return 0;}return 1;
}
// Additive shock wave: a ring of 16 Gouraud quads, bright inside, black outside.
static int orb_ring(gpu_v1_context *c,int x,int y,int r,int w,unsigned color,unsigned alpha)
{
 gpu_material m={GPU_V1_ADDITIVE|GPU_V1_GOURAUD,alpha,color,256,256,256,0,0,0};if(!gpu_v1_material(c,&m))return 0;
 for(unsigned i=0;i<16;++i){unsigned a=i*16,b=a+16;gpu_vertex v[4]={{x+orb_cos(a)*r/16384,y+orb_sin(a)*r/16384,0,0,0,65536,256,256,256},
   {x+orb_cos(a)*(r+w)/16384,y+orb_sin(a)*(r+w)/16384,0,0,0,65536,0,0,0},{x+orb_cos(b)*(r+w)/16384,y+orb_sin(b)*(r+w)/16384,0,0,0,65536,0,0,0},
   {x+orb_cos(b)*r/16384,y+orb_sin(b)*r/16384,0,0,0,65536,256,256,256}};
  if(!gpu_v1_quad(c,v))return 0;}
 return 1;
}
// A drone is drawn as runs of occupied 16-texel cells: transparent texels cost as much as
// opaque ones on R31, so the empty third of each pose is simply not sent.
static int orb_drone(gpu_v1_context *c,unsigned pose,int left,int top,int size,int z)
{
 static const uint8_t cells[4][8]=ORBITAL_DRONE_CELLS;
 for(int row=0;row<8;++row)for(int a=0,b;a<8;a=b+1){unsigned mask=size<32?255U:cells[pose][row];
  for(;a<8&&!(mask>>a&1);++a){}
  for(b=a;b<8&&(mask>>b&1);++b){}
  if(b==a)break;
  int x0=left+size*a/8,x1=left+size*b/8,y0=top+size*row/8,y1=top+size*(row+1)/8;
  gpu_vertex v[4]={{x0,y0,a*16,row*16,z,65536,256,256,256},{x1,y0,b*16,row*16,z,65536,256,256,256},{x1,y1,b*16,row*16+16,z,65536,256,256,256},{x0,y1,a*16,row*16+16,z,65536,256,256,256}};
  if(x1>x0&&y1>y0&&!gpu_v1_quad(c,v))return 0;}
 return 1;
}
static void orb_light(unsigned t,orb_camera cam)
{
 int target;orb_env.muzzle=orb_shoot(t,&target)?56:0;orb_env.blasts=0;orb_env.dawn=orb_clamp(((int)t-3240)*70/260,0,70);
 for(unsigned i=0;i<ORB_ENEMIES&&orb_env.blasts<2;++i){int dt=(int)t-orb_enemies[i].kill;orb_point p;
  if(dt>=0&&dt<40&&orb_enemy_pos(t,i,cam,&p)){orb_env.power[orb_env.blasts]=(40-dt)*4;orb_env.depth[orb_env.blasts++]=p.z;}}
}
static int orb_combat(gpu_v1_context *c,orb_camera cam,unsigned t)
{
 const unsigned long texs[4]={ORBITAL_DRONE0,ORBITAL_DRONE1,ORBITAL_DRONE2,ORBITAL_DRONE3};
 int target,firing=orb_shoot(t,&target);
 for(int i=ORB_ENEMIES-1;i>=0;--i){orb_point p;if(!orb_enemy_pos(t,(unsigned)i,cam,&p))continue;
  const orb_enemy *e=&orb_enemies[i];int dt=(int)t-e->kill,cx=200+p.x*180/p.z,cy=120-p.y*180/p.z+cam.bob;
  int size=orb_clamp(125*180/p.z,10,122);unsigned pose=dt>=0?3:(target==i&&t%12<6)?2:t%160<32?1:0;
  unsigned alpha=dt>=0?(unsigned)(75-dt)*256/75:256;if(dt>=0)size+=dt/3;
  // Arrival: the drone fades in behind a shrinking flash.
  int born=(int)t-e->spawn;if(born<32)alpha=(unsigned)born*8;
  gpu_texture_level tex={texs[pose],128,128,256,GPU_ARGB4444,GPU_TEX_CLAMP,GPU_TEX_CLAMP,0};
  gpu_material m={GPU_RASTER_TEXTURE|GPU_Z_TEST|GPU_Z_WRITE|GPU_V1_FOG,alpha,0,256,256,256,ORB_FOG_NEAR,ORB_FOG_COLOR,ORB_FOG_SCALE};
  if(!gpu_v1_texture(c,&tex)||!gpu_v1_material(c,&m)||!orb_drone(c,pose,cx-size/2,cy-size/2,size,orb_depth(p.z)))return 0;
  if(born<32&&!orb_glow(c,cx,cy,4+(32-born)*size/64,0x9e7f,(unsigned)(32-born)*7))return 0;
  if(dt>=0&&dt<45&&!orb_ring(c,cx,cy,(8+dt*3)*size/96,3+size/16,0xfd88,(unsigned)(45-dt)*5))return 0;
  if(dt>=0 && dt<50 && !orb_glow(c,cx,cy,8+dt/2,0xfc44,(50-dt)*4))return 0;
  // Incoming plasma travels toward the camera; shield response is native HUD.
  unsigned shot=(t+(unsigned)i*37)%160;
  if(dt<0&&shot<50){int d=50-(int)shot;int x=200+(cx-200)*d/50,y=120+(cy-120)*d/50;
   if(!orb_glow(c,x,y,3+(int)shot/7,0xf05f,200))return 0;}
  if(firing&&target==i){gpu_material beam={GPU_V1_ADDITIVE,220,0xffcc,256,256,256,0,0,0};if(!gpu_v1_material(c,&beam))return 0;
   gpu_vertex v[4]={{245,145,0,0,0,65536,256,256,256},{248,144,0,0,0,65536,256,256,256},{cx+1,cy,0,0,0,65536,256,256,256},{cx-1,cy+1,0,0,0,65536,256,256,256}};
   if(!gpu_v1_quad(c,v)||!orb_glow(c,cx,cy,10,0xff85,160))return 0;}
 }
 return 1;
}
static int orbital_render(gpu_v1_context *c,unsigned t,unsigned page)
{
 orb_camera cam=orb_view(t);gpu_target dst={GPU_PAGE_ADDR(page),GPU_PAGE_ADDR(2),400,240,800,800};orb_light(t,cam);
 gpu_target sky={ORBITAL_SKY,0,512,256,1024,1024};int sx=56+cam.yaw*3,bay=cam.z+64>=1080;
 // The HUD hides rows 0..23 and 221..239; they are kept black so that the page is fully defined.
 if(!gpu_v1_target(c,&dst)||!gpu_v1_scissor(c,0,0,400,240)||!gpu_v1_clear(c,1,0,0,0,0,400,24)||!gpu_v1_clear(c,1,0,0,0,221,400,19)||
    (!(orb_skip&16)&&!gpu_v1_clear(c,2,0,65535,0,24,400,197))||!gpu_v1_scissor(c,0,24,400,197))return 0;
 // Sky only where it can be seen: above the horizon in the bay, else through the glazing and the open bulkhead.
 int gate[2]={0,400},door=orb_door(t)<200?orb_door(t):200;
 if((orb_skip&256)&&!gpu_v1_copy(c,&sky,sx,8+24,0,24,400,197))return 0;
 int top=24,horizon=orb_clamp(120+cam.bob+9,24,221);
 if(!bay){
  orb_slab walls[5]={{1,-200,cam.z,1080,-90,135,0x6370},{1,200,cam.z,1080,-90,-35,0x52ed},{1,200,cam.z,1080,95,135,0x6370},
   {0,1080,-200,-door,-90,135,0x746f},{0,1080,door,200,-90,135,0x746f}};
  if(!(orb_skip&1))for(unsigned pass=0;pass<2;++pass)for(unsigned i=0;i<(door<200?5U:3U);++i)if(!orb_bars(c,cam,&walls[i],(int)pass))return 0;
  if(!(orb_skip&32)&&!orb_window(c,cam,&sky,sx))return 0;
  gate[1]=0;
  if(door&&orb_wall_columns(cam,-door,1080,door,1080,&gate[0],&gate[1])){
   int xq,za,zb;orb_camera_point(cam,-door,1080,&xq,&za);orb_camera_point(cam,door,1080,&xq,&zb);if(zb<za)za=zb;if(za<64)za=64;
   top=orb_clamp(orb_edge(120+cam.bob,135,za)-3,24,221);}
 }
 // Above the horizon of the platform; below it, orb_rows completes row by row.
 if(!(orb_skip&32)&&gate[1]>gate[0]&&horizon>top&&!gpu_v1_copy(c,&sky,sx+gate[0],8+top,gate[0],top,(unsigned)(gate[1]-gate[0]),(unsigned)(horizon-top)))return 0;
 if(!(orb_skip&128)&&!orb_planes(c,cam,!(orb_skip&32)&&gate[1]>gate[0]?&sky:0,sx,gate))return 0;
 if(!orb_station(c,cam,t)||!((orb_skip&64)||orb_combat(c,cam,t)))return 0;
 if(t>=3200&&!(orb_skip&64)){
  // Finale: distant chain explosions, then a halo that grows behind the title.
  static const int far[3][3]={{3215,92,70},{3290,318,58},{3365,205,44}};
  for(unsigned i=0;i<3;++i){int dt=(int)t-far[i][0];if(dt<0||dt>=60)continue;
   if(!orb_glow(c,far[i][1],far[i][2]+cam.bob,6+dt/3,0xfdaa,(unsigned)(60-dt)*4)||!orb_ring(c,far[i][1],far[i][2]+cam.bob,4+dt,4,0xfd88,(unsigned)(60-dt)*3))return 0;}
  int grow=orb_clamp(((int)t-3240)*100/260,0,100),radius=grow+orb_sin(t*3)*grow/16384/12;
  if(radius>2&&!orb_glow(c,200,96+cam.bob,radius,0xfed2,210))return 0;}
 return 1;
}
static gpu_layer orb_layer(unsigned long base,int w,int h,int x,int y)
{return gpu_make_layer(base,w,w,h,x,y,w,h,0,0,GPU_LAYER_ENABLE|GPU_LAYER_KEY_ZERO);}
static void orb_fx(gpu_sprite s[64],unsigned *n,unsigned kind,int x,int y,unsigned priority)
{if(*n<64&&x>-32&&x<800&&y>-32&&y<480)s[(*n)++]=gpu_make_sprite(ORBITAL_EFFECTS+kind*1024UL,x,y,32,32,priority,GPU_SPRITE_ENABLE);}
static void orbital_layers(unsigned t,gpu_layer layers[16],gpu_sprite sprites[64],orb_info *info)
{
 memset(layers,0,sizeof(gpu_layer)*16);memset(sprites,0,sizeof(gpu_sprite)*64);unsigned n=0,chapter=t<650?0:t<1550?1:t<2220?2:3;
 orb_camera cam=orb_view(t);int target,firing=orb_shoot(t,&target),ax=400,ay=240;
 if(target>=0){orb_point p;if(orb_enemy_pos(t,(unsigned)target,cam,&p)){ax=400+p.x*360/p.z;ay=240-p.y*360/p.z+cam.bob*2;}}
 int recoil=firing?9:0,wx=350+orb_sin(t*2)*3/16384+recoil,wy=239+orb_sin(t*4)*3/16384+recoil;
 if(t>=3200)wy+=(int)(t-3200)*2;
 layers[9]=orb_layer(ORBITAL_WEAPON,416,248,wx,wy);
 if(t<3200)layers[10]=orb_layer(ORBITAL_CROSSHAIR,32,32,ax-16,ay-16);
 layers[11]=orb_layer(ORBITAL_TOP,800,48,0,0);layers[12]=orb_layer(ORBITAL_BOTTOM,800,38,0,442);
 int shield=220;if(t%160<60 && t>650 && t<3000)shield=180+(int)(t%160)*2/3;
 layers[14]=gpu_make_layer(ORBITAL_SHIELD,256,256,8,318,29,shield,8,0,0,GPU_LAYER_ENABLE);
 const unsigned long caps[4]={ORBITAL_CAPTION0,ORBITAL_CAPTION1,ORBITAL_CAPTION2,ORBITAL_CAPTION3};unsigned starts[4]={0,650,1550,2220};
 if(t-starts[chapter]<130)layers[13]=orb_layer(caps[chapter],448,64,176,65);
 if(t<170)layers[15]=orb_layer(ORBITAL_TITLE,512,150,144,158);
 if(t>=3200)layers[15]=orb_layer(ORBITAL_FINISH,512,110,144,166);
 if(firing){orb_fx(sprites,&n,4+t%4,wx+111,wy+13,10);orb_fx(sprites,&n,2,ax-16,ay-16,10);}
 for(unsigned i=0;i<ORB_ENEMIES;++i){const orb_enemy *e=&orb_enemies[i];int dt=(int)t-e->kill;if(dt<0||dt>75)continue;orb_point p;if(!orb_enemy_pos((unsigned)e->kill,i,cam,&p))continue;
  int x=400+p.x*360/p.z,y=240-p.y*360/p.z;for(unsigned k=0;k<12;++k){unsigned a=k*256/12;int r=dt*2;
   orb_fx(sprites,&n,k%4,x+orb_cos(a)*r/16384-16,y+orb_sin(a)*r/16384+dt*dt/70-16,8);}}
 *info=(orb_info){t,chapter,n,firing,ax,ay};
}
#endif
