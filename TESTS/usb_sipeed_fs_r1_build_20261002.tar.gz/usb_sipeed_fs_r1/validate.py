#!/usr/bin/env python3
"""Contrôle après P&R et manifeste de chargement du témoin FS."""
from pathlib import Path
import hashlib
import json
import re
import xml.etree.ElementTree as ET

s=Path(__file__).resolve().parent
m=json.loads((s/'sources.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((s/'audit.json').read_text())['status']=='PASS_PREBUILD_AUDIT'
for name,digest in m['files'].items():
    if name!='impl/usb_uart_loopback_process_config.json':
        assert sha(s/'project'/name)==digest,name
for name,digest in m['reference_files'].items():
    assert sha(s/'source'/name)==sha(Path(m['reference'])/name)==digest,name
for name,digest in m['controller_files'].items():
    assert sha(s/'controller_provenance'/name)==digest,name
old=json.loads((s/'controller_provenance/origin_sources.json').read_text())
assert sha(s/'project/src/usb_device_controller_fs/usb_device_controller.vg') == old['tang/rtl/usb/usb_device_controller.v']
assert sha(s/'project/src/usb_softphy/usb_softphy.v') == m['reference_files']['src/usb_softphy/usb_softphy.v']
before=json.loads((s/'source/impl/usb_uart_loopback_process_config.json').read_text())
after=json.loads((s/'project/impl/usb_uart_loopback_process_config.json').read_text())
delta={k:[before.get(k),after.get(k)] for k in before.keys()|after.keys() if before.get(k)!=after.get(k)}
assert delta=={'Generate_Plain_Text_Timing_Report':[False,True],
              'MULTIBOOT_MODE':['Normal','Single'],'MULTIJUMP_MODE':['Normal','Single'],
              'SerDes_retiming':[None,False]},delta
syn=ET.parse(s/'project/impl/gwsynthesis/usb_uart_loopback.prj').getroot()
compiled=[str(Path(f.attrib['path']).relative_to(s/'project')) for f in syn.findall('./FileList/File')]
assert compiled==[x for x in m['active_order'] if x.endswith(('.v','.vhd','.vg'))]
pnr=s/'project/impl/pnr'
cmd=(pnr/'cmd.do').read_text()
for option in ('-place_option 1','-route_option 0','-clock_route_order 0','-correct_hold 1','-route_maxfan 23','-timing','-cst_error'):
    assert option in cmd.splitlines(),option
report=(pnr/'usb_uart_loopback.tr').read_text()
slacks=[float(v) for v in re.findall(r'^Slack\s*:\s*([-\d.]+)',report,re.M)]
assert slacks and min(slacks)>=0
tns=re.findall(r'^\s*(\S+)\s+(setup|hold)\s+([-\d.]+)\s+(\d+)\s*$',report,re.M)
assert len(tns)==6 and all(float(v)==0 and int(n)==0 for _,_,v,n in tns)
assert 'sclk' not in report and 'fclk_960M' not in report
for kind in ('Setup','Hold'):
    assert f'<Numbers of {kind} Violated Endpoints>:0' in report
minima={}
for command,block in re.findall(r'^Report Command:([^\n]*)\n(.*?)(?=^Report Command:|\Z)',report,re.M|re.S):
    values=[float(v) for v in re.findall(r'^Slack\s*:\s*([-\d.]+)',block,re.M)]
    if values: minima[command]=dict(count=len(values),minimum_ns=min(values))
assert sum(v['count'] for v in minima.values())==len(slacks)
resources=(pnr/'usb_uart_loopback.rpt.txt').read_text()
ports=resources.split('7. Pinout by Port Name',1)[1].split('8.',1)[0]
for name in ('usb_dxp_io','usb_dxn_io','usb_rxdp_i','usb_rxdn_i','M21/','M22/','U21/','V21/','T20/','U20/'):
    assert name not in ports,name
assert 'usb_term_dp_io' in ports and 'usb_term_dn_io' in ports
result=dict(status='PASS_BUILD_AND_TIMING',hardware_tested=False,expected_speed_mbps=12,
            minimum_slack_ns=min(slacks),detailed_slacks=len(slacks),minima_by_command=minima,
            tns=[dict(clock=c,analysis=t,tns_ns=float(v),violated_endpoints=int(n)) for c,t,v,n in tns],
            active_sources_unchanged_after_build=True,reference_unchanged=True,netlists_unchanged=True,
            hs_ports_absent_in_pnr=True,compiled_files=compiled,configuration_delta=delta,
            controller_sha256=sha(s/'project/src/usb_device_controller_fs/usb_device_controller.vg'),
            phy_sha256=sha(s/'project/src/usb_softphy/usb_softphy.v'),
            limitations=['Témoin FS distinct ; aucune équivalence HS/FS.',
                         'Faux chemins UART Sipeed et politique de broches inutilisées conservés.',
                         'Les marges STA ne prouvent pas la conformité électrique USB.'])
(s/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
bit='project/impl/pnr/usb_uart_loopback.fs'
timing='project/impl/pnr/usb_uart_loopback.tr'
paths={'sources.json','audit.json','validation.json','prepare.py','audit.py','validate.py','changes.patch','build.tcl','build.log',bit,timing,
       'project/impl/pnr/usb_uart_loopback.rpt.txt','project/impl/pnr/cmd.do','project/impl/pnr/device.cfg',
       'project/impl/gwsynthesis/usb_uart_loopback.prj'}
paths.update('project/'+x for x in m['files'])
paths.update('source/'+x for x in m['active_order'] if (s/'source'/x).exists())
paths.update('controller_provenance/'+x for x in m['controller_files'])
paths.update(('source/src/usb2_0_softphy/usb2_0_softphy.v','source/src/usb_device_controller/usb_device_controller.v',
              'source/src/usb_softphy/usb_softphy.ipc','source/usb_uart_loopback.gprj','source/impl/usb_uart_loopback_process_config.json',
              'audit/top_syntax.log','audit/descriptor_test.log','audit/usb_fs_descriptor_tb.sv','audit/public_interfaces.v'))
board=dict(bitstream=bit,timing=timing,expected_speed_mbps=12,
           identity=dict(vid='359f',pid='2010',serial='11252024'),mode='dedicated-full-speed',
           files={name:sha(s/name) for name in sorted(paths)})
(s/'board_test_manifest.json').write_text(json.dumps(board,indent=2)+'\n')
(s/'bitstream.sha256').write_text(sha(s/bit)+'  '+bit+'\n')
print(json.dumps(result,indent=2))
print('SHA256 bitstream:',sha(s/bit))
