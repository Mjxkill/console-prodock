#!/usr/bin/env python3
"""Prépare un témoin FS isolé ; ne modifie aucune entrée fournisseur."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import shutil
import xml.etree.ElementTree as ET

s = Path(__file__).resolve().parent
ref = s.parent/'usb_sipeed_reference_r1/source'
old = s.parent/'gpu_l12_diag_r23_fs'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copytree(ref, s/'source')
shutil.copytree(ref, s/'project')
shutil.copytree(old/'usb_ip', s/'controller_provenance')
shutil.copy2(old/'sources.json', s/'controller_provenance/origin_sources.json')
shutil.copy2(old/'usb_controller.json', s/'controller_provenance/origin_controller.json')
old_manifest = json.loads((old/'sources.json').read_text())
for name in ('usb_device_controller_define.v', 'usb_device_controller_top.v',
             'usb_device_controller.v', 'static_macro_define.v', 'controller.prj'):
    assert sha(s/'controller_provenance'/name) == old_manifest['usb_ip/'+name], name
assert '`define FSSUPPORT\n' in (s/'controller_provenance/usb_device_controller_define.v').read_text()
assert '`define HSSUPPORT' not in (s/'controller_provenance/usb_device_controller_define.v').read_text()
dst = s/'project/src/usb_device_controller_fs'
dst.mkdir()
shutil.copy2(old/'usb_ip/usb_device_controller.vg', dst/'usb_device_controller.vg')

top = (s/'project/src/TOP.v').read_text()
for line in ('    inout      usb_dxp_io     ,\n', '    inout      usb_dxn_io     ,\n',
             '    input      usb_rxdp_i     ,\n', '    input      usb_rxdn_i     ,\n'):
    assert top.count(line) == 1
    top = top.replace(line, '')
assert top.count('.HSSUPPORT       (1                )') == 1
top = top.replace('.HSSUPPORT       (1                )', '.HSSUPPORT       (0                )')
assert '.clkout0(fclk_960M  ),' in top
top = top.replace('.clkout0(fclk_960M  ),', '.clkout0(           ),')
start = top.index('USB2_0_SoftPHY_Top u_USB_SoftPHY_Top')
fs = top.index('    USB_SoftPHY_Top u_USBFS_SoftPHY_Top', start)
end = top.index('*/', fs)
branch = top[fs:end].replace('assign usb_pullup_en_o = 1;', "assign usb_pullup_en_o = 1'b1;")
top = top[:start]+'// Témoin FS : branche Sipeed dédiée, PHY USB 1.1 à 60 MHz.\n'+branch+top[end+2:]
assert 'USB2_0_SoftPHY_Top' not in top and 'fclk_960M' not in top
assert not re.search(r'usb_(dx[ pn]|rxdp|rxdn)', top)
(s/'project/src/TOP.v').write_text(top)

cst = (s/'source/src/usb_ref.cst').read_text()
cst = ''.join(line for line in cst.splitlines(True)
              if not any('"'+name+'"' in line for name in ('usb_dxp_io','usb_rxdp_i','usb_rxdn_i')))
(s/'project/src/usb_ref.cst').write_text(cst)
sdc = (s/'source/src/usb_ref.sdc').read_text()
sdc = ''.join(line for line in sdc.splitlines(True)
              if not (line.startswith('create_clock -name sclk ') or
                      line.startswith('create_generated_clock -name fclk_960M ') or
                      line.startswith('set_clock_groups ')))
assert 'sclk' not in sdc and 'fclk_960M' not in sdc
(s/'project/src/usb_ref.sdc').write_text(sdc)

gprj = (s/'source/usb_uart_loopback.gprj').read_text()
gprj = gprj.replace('src/usb_device_controller/usb_device_controller.v',
                    'src/usb_device_controller_fs/usb_device_controller.vg')
gprj = re.sub(r'^.*path="src/usb2_0_softphy/usb2_0_softphy.v".*\n', '', gprj, flags=re.M)
(s/'project/usb_uart_loopback.gprj').write_text(gprj)
tree = ET.fromstring(gprj)
active = [f.attrib['path'] for f in tree.findall('./FileList/File') if f.attrib.get('enable') == '1']
assert len(active) == 16
names = active + ['usb_uart_loopback.gprj','impl/usb_uart_loopback_process_config.json']
manifest = dict(reference=str(ref), controller_origin=str(old/'usb_ip'),
                mode='dedicated-full-speed', expected_speed_mbps=12,
                active_order=active, files={name:sha(s/'project'/name) for name in names},
                reference_files={str(p.relative_to(ref)):sha(p) for p in ref.rglob('*') if p.is_file()},
                controller_files={str(p.relative_to(s/'controller_provenance')):sha(p)
                                  for p in (s/'controller_provenance').rglob('*') if p.is_file()},
                phy_guide='https://www.gowinsemi.com/upload/database_doc/2119/document/65572aae01c10.pdf')
(s/'sources.json').write_text(json.dumps(manifest,indent=2)+'\n')
patch = ''
for name in ('src/TOP.v','src/usb_ref.cst','src/usb_ref.sdc','usb_uart_loopback.gprj'):
    for line in difflib.unified_diff((s/'source'/name).read_text().splitlines(True),
                                     (s/'project'/name).read_text().splitlines(True),
                                     fromfile='Sipeed/'+name,tofile='FS/'+name):
        patch += line if line.endswith('\n') else line+'\n\\ No newline at end of file\n'
(s/'changes.patch').write_text(patch)
(s/'build.tcl').write_text('open_project {'+str(s/'project/usb_uart_loopback.gprj')+'}\n'
                         'set_option -gen_text_timing_rpt 1\nrun all\n')
print('Préparation FS terminée, 16 entrées actives, netlists intactes, changes.patch prêt')
