#!/usr/bin/env python3
"""Audit de routage des pointeurs Gray des FIFO MSC dans le SDF Gowin.

Toutes les liaisons vers les deux étages synchroniseurs doivent être
présentes et directes depuis une sortie Q. Budget conservateur de 6,25 ns
(demi-période du domaine le plus rapide, 80 MHz), sans modifier le SDC.
Ce contrôle de routage complète les tests CDC/reset ; il ne calcule pas le
MTBF et ne remplace pas l'analyse setup/hold ni la validation du PHY.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re


def audit(path):
    groups = {f'{fifo}_{pointer}_{stage}': {} for fifo in ('tx', 'rx')
              for pointer in ('wr', 'rd') for stage in (1, 2)}
    errors = []
    pattern = re.compile(r'INTERCONNECT (\S+) '
                         r'(u_usb_msc_port/u_(tx|rx)/(wr|rd)_gray_s([12])_(\d+)_s\d+/D) '
                         r'\(([^)]+)\)')
    with path.open() as stream:
        for line in stream:
            if 'INTERCONNECT' not in line or 'u_usb_msc_port\\/u_' not in line:
                continue
            match = pattern.search(line.replace('\\/', '/'))
            if not match:
                continue
            source, target, fifo, pointer, stage, bit, delay = match.groups()
            key = f'{fifo}_{pointer}_{stage}'
            bit = int(bit)
            corners = [float(d) for d in delay.split(':')]
            if bit in groups[key]:
                errors.append(f'Liaison dupliquée : {target}')
            groups[key][bit] = dict(source=source, target=target, corners_ns=corners)
            # Le bit Gray de poids fort peut partager le registre binaire.
            expected = (rf'u_usb_msc_port/u_{fifo}/{pointer}_(gray|bin)_{bit}_s\d+/Q'
                        if stage == '1' else
                        rf'u_usb_msc_port/u_{fifo}/{pointer}_gray_s1_{bit}_s\d+/Q')
            if not re.fullmatch(expected, source):
                errors.append(f'Source synchroniseur inattendue : {source} -> {target}')
            if max(corners) >= 6.25:
                errors.append(f'Budget de routage dépassé : {target}')
    result = {}
    for name, paths in groups.items():
        width = 11 if name.startswith('tx_') else 10
        if set(paths) != set(range(width)):
            errors.append(f'Couverture incomplète : {name}, {sorted(paths)} / {width}')
        delays = [d for p in paths.values() for d in p['corners_ns']]
        result[name] = dict(expected=width, found=len(paths),
                            max_route_ns=max(delays) if delays else None,
                            paths=[dict(bit=b, **p) for b, p in sorted(paths.items())])
    return dict(passed=not errors, errors=errors, groups=result,
                sdf=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                route_budget_ns=6.25, scope='84 liaisons des deux FIFO MSC, Q vers D ; routage uniquement')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sdf', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    report = audit(args.sdf)
    args.out.write_text(json.dumps(report, indent=2) + '\n')
    for name, group in report['groups'].items():
        print(name, group['found'], '/', group['expected'], 'max', group['max_route_ns'], 'ns')
    if not report['passed']:
        raise SystemExit('; '.join(report['errors']))
    print('PASS routage des 84 liaisons Gray MSC')


if __name__ == '__main__':
    main()
