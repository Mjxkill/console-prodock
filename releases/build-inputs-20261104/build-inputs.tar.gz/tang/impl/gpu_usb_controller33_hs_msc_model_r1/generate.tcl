create_project -name controller33_hs -dir {export} -pn {GW5AST-LV138FPG676AC1/I0} -device_version B
set_device -name GW5AST-138B GW5AST-LV138FPG676AC1/I0
add_file {/home/michael/console/tang/impl/gpu_usb_controller33_hs_msc_model_r1/usb_device_controller.vg}
add_file {/home/michael/console/tang/impl/gpu_usb_controller33_hs_msc_model_r1/usb_descriptor.v}
add_file {/home/michael/console/tang/impl/gpu_usb_controller33_hs_msc_model_r1/usb_hs_controller_model.v}
add_file {/home/michael/console/tang/impl/gpu_usb_controller33_hs_msc_model_r1/clock.sdc}
set_option -top_module USB_HS_Controller_Model
set_option -gen_verilog_sim_netlist 1
set_option -gen_text_timing_rpt 1
set_option -use_cpu_as_gpio 1
run all
