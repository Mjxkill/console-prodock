`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// ae350_reset_control
//
// Common AE350 CPU reset sequencer for the G22/R3/R5 and Neo class boards.
// It intentionally does NOT drive PLL_INIT, the PLL, DDR or the reference
// clock.  request_n, pll_ready and ddr_ready are upstream observations only.
//
// Required release topology (after owner review):
//
//   availability ---- async reset -+-> 2-FF bridge in ref_clk -> ref_release
//                                                                    |
//                                     async reset of hold counter and  |
//                                     qualification register <--------+
//                                                    |
//                                             ref_qualified
//                                                    |
//                                     async reset of 2-FF bridge in ahb_clk
//                                                    |
//                                               cpu_reset_n
//
// Key points:
//   * availability only drives the asynchronous reset control of the
//     reference-domain bridge.  It does not directly deassert the counter's
//     async reset, the qualification register, or the AHB bridge.
//   * The reference bridge output, ref_release, is the raw asynchronous
//     control seen by the hold counter and the qualification register.  Both
//     are cleared as soon as ref_release falls.  ref_release itself only rises
//     after two ref_clk rising edges with availability high.
//   * ref_qualified is exactly the qualification register output.  There is
//     no AND with availability, fault_seen, or any raw input.
//   * ref_qualified is the raw asynchronous control of the AHB-domain bridge.
//     cpu_reset_n is exactly the last AHB flip-flop output, with no output
//     AND gate.  It can only rise on an AHB rising edge.
//   * The old fault_seen flag is no longer needed: the first bridge is cleared
//     asynchronously by any digital loss of availability and stays cleared
//     until two reference edges have seen it high again.  A short loss
//     therefore clears qualification and the counter through ref_release and
//     replays the complete hold delay.
//
// Synthesis notes:
//   * The counter target is elaborated from REF_CLK_HZ and HOLD_US using
//     64-bit unsigned constants.  Both the product and the quotient avoid a
//     32-bit overflow, and there is no run-time division.
//   * Register initialisers describe the required configuration start-up
//     state for FPGA logic.  Async resets still provide the on-line safety
//     reset path; the initialisers do not replace it.
//   * No combinational gate is placed on either clock and no output gates a
//     reset path.
//   * X/Z values are not a model of analogue metastability.  The functional
//     contract is defined for 0/1 levels only.
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Reusable two-flop release bridge.
//
// Assertion is asynchronous and immediate: arst_n low clears both stages.
// Deassertion is synchronous: with arst_n high, the data input is tied high so
// that release only rises after two rising edges of clk.  The bridge is used
// once in the reference domain (arst_n = availability) and once in the AHB
// domain (arst_n = ref_qualified).
// -----------------------------------------------------------------------------
module ae350_sync_release_bridge (
    input  wire clk,
    input  wire arst_n,    // asynchronous assertion, active low
    output wire released   // two clk edges after arst_n deasserts
);
    reg [1:0] sync_ff = 2'b00;

    always @(posedge clk or negedge arst_n) begin
        if (!arst_n) begin
            // Asynchronous assertion: no clock edge is required.
            sync_ff <= 2'b00;
        end else begin
            // Constant-high data: synchronous release after two edges.
            sync_ff <= {sync_ff[0], 1'b1};
        end
    end

    assign released = sync_ff[1];
endmodule

module ae350_reset_control #(
    parameter integer REF_CLK_HZ = 50000000,  // reference clock, Hz, > 0
    parameter integer HOLD_US    = 50000      // hold time, us, >= 0
) (
    input  wire ref_clk,
    input  wire ahb_clk,
    input  wire request_n,   // active-low external request
    input  wire pll_ready,   // upstream PLL observation, active high
    input  wire ddr_ready,   // upstream DDR observation, active high
    output wire cpu_reset_n,
    output wire ref_qualified
);

    // -------------------------------------------------------------------------
    // Elaboration-time cycle computation.
    //
    // REF_CLK_HZ * HOLD_US is expressed in Hz*us, i.e. cycles * 1,000,000.
    // Widening both operands to 64 bits before multiplying keeps the
    // 50 MHz / 50 ms product (2,500,000,000,000) far away from 32-bit
    // overflow.  Adding 999,999 before dividing by 1,000,000 realizes:
    //
    //     HOLD_CYCLES = ceil(REF_CLK_HZ * HOLD_US / 1,000,000)
    //
    // The quotient stays 64-bit and only constant division is used.  There is
    // no integer alias and no run-time division.
    // -------------------------------------------------------------------------
    localparam [63:0] REF_HZ_U       = REF_CLK_HZ;
    localparam [63:0] HOLD_US_U      = HOLD_US;
    localparam [63:0] REF_HZ_HOLD    = REF_HZ_U * HOLD_US_U;
    localparam [63:0] HOLD_CYCLES_64 =
        (REF_HZ_HOLD + 64'd999999) / 64'd1000000;

    // At least one counter bit is needed even when HOLD_US is zero.
    localparam integer COUNTER_W =
        (HOLD_CYCLES_64 <= 1) ? 1 : $clog2(HOLD_CYCLES_64);

    // -------------------------------------------------------------------------
    // Raw safety condition.  All three observations must be high.  This net
    // reaches ONLY the asynchronous reset control of the reference bridge.
    // -------------------------------------------------------------------------
    wire availability = request_n & pll_ready & ddr_ready;

    // -------------------------------------------------------------------------
    // Reference-domain release bridge.
    //
    // Availability low asynchronously forces ref_release low.  With
    // availability high, ref_release rises only after two ref_clk rising
    // edges.  A digital low pulse entirely between two reference edges still
    // asynchronously clears the bridge, so no loss is forgotten.
    // -------------------------------------------------------------------------
    wire ref_release;

    ae350_sync_release_bridge ref_bridge (
        .clk      (ref_clk),
        .arst_n   (availability),
        .released (ref_release)
    );

    // -------------------------------------------------------------------------
    // Hold counter and reference qualification register.
    //
    // Their asynchronous reset control is ref_release, never raw availability.
    // When ref_release falls, the counter returns to zero immediately and the
    // qualification register clears.  After ref_release rises, the counter
    // counts complete ref_clk cycles.  Qualification is raised on the edge
    // that closes the HOLD_CYCLES-th complete cycle since release.  HOLD_US=0
    // therefore needs no full hold cycle, but still requires the two-edge
    // reference bridge.  A partially filled counter is held in reset whenever
    // ref_release is low, so an earlier sequence cannot shorten a new delay.
    // -------------------------------------------------------------------------
    reg [COUNTER_W-1:0] hold_count      = {COUNTER_W{1'b0}};
    reg                 ref_qualified_q = 1'b0;

    always @(posedge ref_clk or negedge ref_release) begin
        if (!ref_release) begin
            // Asynchronous assertion of the counter and qualifier.
            hold_count      <= {COUNTER_W{1'b0}};
            ref_qualified_q <= 1'b0;
        end else if (ref_qualified_q) begin
            // Stay qualified until ref_release clears the sequence.
            hold_count      <= hold_count;
        end else if (HOLD_CYCLES_64 == 0) begin
            // Zero hold: no complete cycle is required, but the reference
            // bridge already provided the mandatory synchronization.
            hold_count      <= {COUNTER_W{1'b0}};
            ref_qualified_q <= 1'b1;
        end else if (hold_count >= HOLD_CYCLES_64 - 64'd1) begin
            // The current edge closes the last required complete cycle.
            hold_count      <= hold_count;  // saturate at the target
            ref_qualified_q <= 1'b1;
        end else begin
            hold_count      <= hold_count + 1'b1;
        end
    end

    // ref_qualified is exactly the qualification register output, with no
    // gate and no combination with any raw availability input.
    assign ref_qualified = ref_qualified_q;

    // -------------------------------------------------------------------------
    // AHB-domain release bridge.
    //
    // ref_qualified is the asynchronous reset control, so a reference
    // qualification loss clears this bridge immediately even if ahb_clk is
    // stopped.  Once ref_qualified is high, cpu_reset_n rises only on the
    // second AHB rising edge.  cpu_reset_n is connected directly to the last
    // bridge flip-flop output: there is no AND gate and no clock gate.
    // -------------------------------------------------------------------------
    ae350_sync_release_bridge ahb_bridge (
        .clk      (ahb_clk),
        .arst_n   (ref_qualified),
        .released (cpu_reset_n)
    );

endmodule
