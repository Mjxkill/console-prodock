`define ITCM_SIZE 14
`define ITCM_INIT_PATH "/home/michael/console/tang/impl/prodock_sd_boot_20261029_r4/source/boot_firmware/itcm"
