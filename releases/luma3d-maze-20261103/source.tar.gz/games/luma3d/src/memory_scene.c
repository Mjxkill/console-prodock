#include "memory_scene.h"
#include "memory_art.h"
#include "festival_art.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdio.h>
#define COUNT(a) (sizeof(a)/sizeof(*(a)))
#define FACES (17u<<20)
#define CLASSIC (FACES+524288u)
static float clip(float x,float a,float b){return fminf(b,fmaxf(a,x));}
static float smooth(float x){x=clip(x,0,1);return x*x*(3-2*x);}
static void grid(unsigned level,unsigned *cols,float *size,float *gap){
 static const unsigned c[]={4,5,6};static const float z[]={88,68,54},g[]={10,8,6};*cols=c[level];*size=z[level];*gap=g[level];
}
static L3MemoryPose target(const L3MemoryScene *f,unsigned i){
 unsigned cols;float size,gap;grid(f->view.difficulty,&cols,&size,&gap);
 unsigned rows=f->view.count/cols;float ww=cols*size+(cols-1)*gap,hh=rows*size+(rows-1)*gap;
 L3MemoryPose p={(int)i,f->view.face[i]==255?15:f->view.face[i],0,348-ww/2+(i%cols)*(size+gap),205-hh/2+(i/cols)*(size+gap),size,size,256};
 if(f->view.matched&(1u<<i)){
  unsigned face=f->view.face[i],second=0;
  for(unsigned j=0;j<i;j++)if((f->view.matched&(1u<<j))&&f->view.face[j]==face)second=1;
  p.x=590+(face%3)*34+second*3;p.y=90+(face/3)*48+second*4;p.w=p.h=31;
 }
 return p;
}
static const L3MemoryPose *find(const L3MemoryPose *p,unsigned n,int id){for(unsigned i=0;i<n;i++)if(p[i].id==id)return p+i;return NULL;}
void l3_memory_scene_poses(L3MemoryScene *f){
 f->poses_n=0;float e=smooth(f->elapsed/f->duration);
 /* Cursor light is under the cards and contributes to the damage bounds. */
 if(f->cursor<f->view.count&&!(f->view.matched&(1u<<f->cursor))){L3MemoryPose p=target(f,f->cursor);p.id=100;p.tile=56;p.atlas=1;p.x-=5;p.y-=5;p.w+=10;p.h+=10;p.alpha=150;f->poses[f->poses_n++]=p;}
 for(unsigned i=0;i<f->view.count;i++){
  L3MemoryPose p=target(f,i);const L3MemoryPose *old=find(f->old,f->old_n,p.id);
  if(f->elapsed<f->duration&&old){
   float u=e;
   if(f->trace.count&&f->trace.events[0].kind==L3_MEMORY_DEAL)u=smooth((f->elapsed-i*.012f)/.45f);
   p.x=old->x+(p.x-old->x)*u;p.y=old->y+(p.y-old->y)*u;p.w=old->w+(p.w-old->w)*u;p.h=old->h+(p.h-old->h)*u;p.alpha=old->alpha+(p.alpha-old->alpha)*u;
   if(old->tile!=p.tile){float ratio=fabsf(cosf(3.14159265358979323846f*e));if(e<.5f)p.tile=old->tile;p.x+=p.w*(1-ratio)/2;p.w*=ratio;}
  }
  f->poses[f->poses_n++]=p;
 }
}
static void stable(L3MemoryScene *f){f->duration=1;f->elapsed=1;f->wait=0;f->old_n=0;f->trace.count=0;f->revision++;f->cursor=0;f->page_valid[0]=f->page_valid[1]=0;l3_memory_scene_poses(f);}
static void start_deal(L3MemoryScene *f){
 f->old_n=0;for(unsigned i=0;i<f->view.count;i++){L3MemoryPose p=target(f,i);p.x=356+i*.15f;p.y=180+i*.15f;p.w=p.h=44;p.alpha=0;f->old[f->old_n++]=p;}
 f->elapsed=0;f->duration=.45f+(f->view.count-1)*.012f;f->trace.count=1;f->trace.events[0]=(L3MemoryEvent){L3_MEMORY_DEAL,0,0};
}
int l3_memory_scene_init(L3MemoryScene *f,uint32_t seed,int automatic){if(!f)return 0;memset(f,0,sizeof(*f));if(!l3_memory_init(&f->game,seed)||!l3_memory_view(&f->game,&f->view))return 0;f->automatic=!!automatic;stable(f);start_deal(f);return 1;}
void l3_memory_scene_close(L3MemoryScene *f){if(f){free(f->ui);free(f->background);memset(f,0,sizeof(*f));}}
void l3_memory_scene_invalidate(L3MemoryScene *f){if(!f)return;free(f->ui);free(f->background);f->ui=NULL;f->background=NULL;f->assets=f->asset_w=f->asset_h=0;f->base_ready[0]=f->base_ready[1]=0;f->page_valid[0]=f->page_valid[1]=0;f->ui_revision[0]=f->ui_revision[1]=0;}
int l3_memory_scene_action(L3MemoryScene *f,L3MemoryAction a){
 if(!f||f->elapsed<f->duration||(f->view.phase==L3_MEMORY_TWO&&f->wait<.70f))return 0;
 L3Memory next=f->game;L3MemoryTrace trace;if(!l3_memory_action(&next,a,&trace))return 0;
 l3_memory_scene_poses(f);memcpy(f->old,f->poses,f->poses_n*sizeof(*f->old));f->old_n=f->poses_n;f->game=next;f->trace=trace;l3_memory_view(&f->game,&f->view);
 f->duration=.36f;f->elapsed=f->wait=0;f->revision++;f->actions++;
 for(unsigned i=0;i<trace.count;i++)switch(trace.events[i].kind){
  case L3_MEMORY_REVEAL:f->reveals++;f->cursor=trace.events[i].a;break;
  case L3_MEMORY_PAIR:f->pairs++;f->duration=.48f;for(unsigned j=0;j<f->view.count;j++)if(!(f->view.matched&(1u<<j))){f->cursor=j;break;}break;
  case L3_MEMORY_HIDE:f->mismatches++;break;
  case L3_MEMORY_VICTORY:f->rounds++;break;
  case L3_MEMORY_DEAL:f->cursor=0;start_deal(f);break;
 }
 return 1;
}
void l3_memory_scene_step(L3MemoryScene *f,float dt){
 if(!f||!isfinite(dt)||dt<=0)return;dt=fminf(dt,.1f);
 if(f->elapsed<f->duration){float left=f->duration-f->elapsed;f->elapsed=fminf(f->duration,f->elapsed+dt);if(dt>left)f->wait+=dt-left;return;}
 f->wait+=dt;
 if(f->view.phase==L3_MEMORY_TWO){if(f->wait>=.70f)l3_memory_scene_action(f,(L3MemoryAction){L3_MEMORY_RESOLVE,0});}
 else if(f->automatic&&f->wait>=(f->view.phase==L3_MEMORY_WON?2.0f:.26f)){L3MemoryAction a;if(l3_memory_advice(&f->game,&a))l3_memory_scene_action(f,a);}
}
void l3_memory_scene_key(L3MemoryScene *f,int c){
 if(!f)return;if(c==9||c=='q'||c=='Q'){f->exit_requested=1;return;}if(f->automatic){f->automatic=0;f->escape=c==27?3:0;f->revision++;return;}
 if(f->escape){unsigned old=f->escape;f->escape=0;if((old==1||old==3)&&c=='['){f->escape=old+1;return;}if(old==4)return;if(old==2)c=c=='A'?'w':c=='B'?'s':c=='C'?'d':c=='D'?'a':0;}
 if(c==27){f->escape=1;return;}if(c==9||c=='q'||c=='Q'){f->exit_requested=1;return;}
 unsigned cols;float size,gap;grid(f->view.difficulty,&cols,&size,&gap);unsigned before=f->cursor;
 if(c=='a'&&f->cursor%cols)f->cursor--;if(c=='d'&&f->cursor%cols+1<cols)f->cursor++;
 if(c=='w'&&f->cursor>=cols)f->cursor-=cols;if(c=='s'&&f->cursor+cols<f->view.count)f->cursor+=cols;
 if(before!=f->cursor)f->revision++;
 if(c==' '||c=='e'||c==10||c==13)l3_memory_scene_action(f,(L3MemoryAction){f->view.phase==L3_MEMORY_WON?L3_MEMORY_NEXT:L3_MEMORY_FLIP,f->view.phase==L3_MEMORY_WON?0:f->cursor});
}
int l3_memory_scene_restore(L3MemoryScene *f,const void *data,size_t size){if(!f)return 0;L3Memory next;if(!l3_memory_decode(&next,data,size))return 0;f->game=next;l3_memory_view(&f->game,&f->view);f->escape=f->exit_requested=0;stable(f);return 1;}
static int expand(uint16_t *dst,unsigned pixels,const uint32_t *src,unsigned n){unsigned at=0;for(unsigned i=0;i<n;i++){unsigned k=src[i]>>16;if(!k||k>pixels-at)return 0;for(unsigned j=0;j<k;j++)dst[at++]=(uint16_t)src[i];}return at==pixels;}
static void publish(L3Render *r,unsigned offset,const void *src,unsigned bytes){double measured=r->festival_metrics?l3_measure_now():0;for(unsigned i=0;i<bytes;i+=4){uint32_t v;memcpy(&v,(const uint8_t*)src+i,4);*(volatile uint32_t*)(r->memory+offset+i)=v;}if(r->festival_metrics)l3_measure_publish(r,offset,bytes,measured,18u<<20);}
static int art(L3Render *r,L3MemoryScene *f){
 (void)memory_names; /* Retained atlas metadata; -Werror full-game build. */
 unsigned w=r->width*2,h=r->height*2;if(f->assets&&f->asset_w==w&&f->asset_h==h)return 1;
 double measure_start=r->festival_metrics?l3_measure_now():0;uint64_t measure_bytes=r->festival_publish_bytes,measure_atlas=r->festival_atlas_bytes;double measure_atlas_seconds=r->festival_atlas_seconds;
 if(f->asset_w!=w||f->asset_h!=h)l3_memory_scene_invalidate(f);f->asset_w=w;f->asset_h=h;
 if(!f->ui)f->ui=calloc(w,h);if(!f->background)f->background=malloc(w*h*2);uint16_t *a=malloc(524288);if(!a||!f->ui||!f->background){free(a);return 0;}
 int ok=expand(a,262144,memory_faces,COUNT(memory_faces));if(ok)publish(r,FACES,a,524288);
 ok=ok&&expand(a,262144,festival_classic,COUNT(festival_classic));if(ok)publish(r,CLASSIC,a,524288);free(a);
 ok=ok&&(w==800?expand(f->background,w*h,festival_table_800,COUNT(festival_table_800)):expand(f->background,w*h,festival_table_1280,COUNT(festival_table_1280)));if(!ok)return 0;
 /* Clear quiet title/footer bands instead of writing over the golden frame. */
 for(unsigned y=0;y<h;y++)if(y<65||y>=h-40)for(unsigned x=0;x<w;x++){unsigned d=y<65?y:h-y;f->background[y*w+x]=(uint16_t)((1u<<11)|((4+d/16)<<5)|(5+d/32));}
 publish(r,6u<<20,f->background,w*h*2);gpu_v1_invalidate(&r->gpu);f->assets=1;l3_measure_loaded(r,5,measure_start,measure_bytes,measure_atlas,measure_atlas_seconds);return 1;
}
static int quad(L3Render *r,const L3MemoryPose *p,float scale,unsigned alpha){
 int tw=p->atlas?64:128,cols=p->atlas?8:4,x=lroundf(p->x*scale),y=lroundf(p->y*scale),w=lroundf(p->w*scale),h=lroundf(p->h*scale);if(w<1||h<1||!alpha)return 1;
 gpu_texture_level t={PRODOCK_GPU_BASE+(p->atlas?CLASSIC:FACES),512,512,1024,GPU_ARGB4444,0,0,0};gpu_material m={.flags=1,.alpha=alpha,.r=256,.g=256,.b=256};int u=p->tile%cols*tw,v=p->tile/cols*tw;
 gpu_vertex q[4]={{x,y,u,v,0,65536,256,256,256},{x+w,y,u+tw,v,0,65536,256,256,256},{x+w,y+h,u+tw,v+tw,0,65536,256,256,256},{x,y+h,u,v+tw,0,65536,256,256,256}};
 return gpu_v1_texture(&r->gpu,&t)&&gpu_v1_material(&r->gpu,&m)&&gpu_v1_quad(&r->gpu,q);
}
static int equal(const L3MemoryPose *a,const L3MemoryPose *b){return a->id==b->id&&a->tile==b->tile&&a->atlas==b->atlas&&a->x==b->x&&a->y==b->y&&a->w==b->w&&a->h==b->h&&a->alpha==b->alpha;}
static void bounds(const L3MemoryPose *p,float *x0,float *y0,float *x1,float *y1){*x0=fminf(*x0,p->x-1);*y0=fminf(*y0,p->y-1);*x1=fmaxf(*x1,p->x+p->w+5);*y1=fmaxf(*y1,p->y+p->h+7);}
static int board(L3Render *r,L3MemoryScene *f,struct prodock_scene *scene,int full){
 unsigned w=r->width*2,h=r->height*2,page=r->frame&1,ww=w==800?800:960,hh=w==800?400:480,x=(w-ww)/2,y=(h-hh)/2,offset=y*r->pitch+x*2;float scale=ww/800.0f;
 if(!f->base_ready[page]){publish(r,page*r->page_bytes,f->background,w*h*2);f->base_ready[page]=1;}
 gpu_target t={PRODOCK_GPU_BASE+page*r->page_bytes+offset,PRODOCK_GPU_BASE+2*r->page_bytes+offset,ww,hh,r->pitch,r->pitch};gpu_target bg={PRODOCK_GPU_BASE+(6u<<20)+offset,t.depth,ww,hh,r->pitch,r->pitch};
 l3_memory_scene_poses(f);float x0=800,y0=400,x1=0,y1=0;
 if(full||!f->page_valid[page]){x0=y0=0;x1=800;y1=400;}else{
  for(unsigned i=0;i<f->poses_n;i++){const L3MemoryPose *p=f->poses+i,*old=find(f->pages[page],f->page_n[page],p->id);if(!old||!equal(p,old)){bounds(p,&x0,&y0,&x1,&y1);if(old)bounds(old,&x0,&y0,&x1,&y1);}}
  for(unsigned i=0;i<f->page_n[page];i++)if(!find(f->poses,f->poses_n,f->pages[page][i].id))bounds(f->pages[page]+i,&x0,&y0,&x1,&y1);
 }
 int ix=floorf(clip(x0,0,800)*scale),iy=floorf(clip(y0,0,400)*scale),ex=ceilf(clip(x1,0,800)*scale),ey=ceilf(clip(y1,0,400)*scale);if(ex>(int)ww)ex=ww;if(ey>(int)hh)ey=hh;
 if(ex>ix&&ey>iy){if(!gpu_v1_target(&r->gpu,&t)||!gpu_v1_scissor(&r->gpu,ix,iy,ex-ix,ey-iy)||!gpu_v1_copy(&r->gpu,&bg,ix,iy,ix,iy,ex-ix,ey-iy))return 0;
  for(unsigned pass=0;pass<2;pass++)for(unsigned i=0;i<f->poses_n;i++){L3MemoryPose p=f->poses[i];if(p.x+p.w+5<x0||p.x-1>x1||p.y+p.h+7<y0||p.y-1>y1)continue;
   if(!pass){if(p.id==100)continue;p.x+=3;p.y+=5;p.tile=55;p.atlas=1;if(!quad(r,&p,scale,(unsigned)(90*p.alpha/256)))return 0;}
   else if(!quad(r,&p,scale,(unsigned)p.alpha))return 0;
  }
 }
 memcpy(f->pages[page],f->poses,f->poses_n*sizeof(*f->poses));f->page_n[page]=f->poses_n;f->page_valid[page]=1;scene->base=PRODOCK_GPU_BASE+page*r->page_bytes;scene->stride=r->pitch;scene->format=3;return 1;
}
static void text(L3Render *r,L3MemoryScene *f,int x,int y,const char *s,unsigned color,unsigned width){l3_ui_text(f->ui,r->width*2,r->height*2,x,y,0,s,color,width);}
static int ui(L3Render *r,L3MemoryScene *f,struct prodock_scene *scene){
 unsigned w=r->width*2,h=r->height*2,page=r->frame&1;if(f->ui_revision[page]!=f->revision){
  memset(f->ui,0,w*h);char s[160];text(r,f,w==800?115:250,9,"MEMORY - Les constellations",78,w-230);
  snprintf(s,sizeof(s),"%s  /  %u cartes  /  %u paires  /  %u essais",f->automatic?"VISITE AUTO":"A VOUS",f->view.count,f->view.pairs,f->view.turns);text(r,f,w==800?115:250,w==800?33:37,s,74,w-230);
  float k=w==800?1:1.2f;int ox=w==800?0:160,oy=w==800?40:120;
  text(r,f,ox+590*k,oy+60*k,"LE CIEL",78,130*k);
  snprintf(s,sizeof(s),"%u / %u",f->view.pairs,f->view.count/2);text(r,f,ox+600*k,oy+336*k,s,78,100*k);
  if(f->view.phase==L3_MEMORY_WON){
   text(r,f,ox+175*k,oy+145*k,"LE CIEL SE SOUVIENT",78,340*k);
   snprintf(s,sizeof(s),"%u etoiles  -  %u essais",f->view.stars,f->view.turns);text(r,f,ox+210*k,oy+185*k,s,74,300*k);
   snprintf(s,sizeof(s),"Prochain ciel : %u cartes",f->view.difficulty<2?l3_memory_count(f->view.difficulty+1):30);text(r,f,ox+185*k,oy+225*k,s,74,330*k);
  }
  const char *bottom=f->view.phase==L3_MEMORY_WON?"Ciel complete ! Entree : prochaine constellation":"Fleches / WASD : choisir   E : retourner   Tab : retour";
  text(r,f,w==800?105:210,h-(w==800?30:36),bottom,74,w-210);
  publish(r,(20u<<20)+page*(1u<<20),f->ui,w*h);f->ui_revision[page]=f->revision;
 }
 uint32_t *l=scene->layers[0];l[0]=PRODOCK_GPU_BASE+(20u<<20)+page*(1u<<20);l[1]=w|(h<<16);l[3]=l[1];l[5]=w;l[6]=3;scene->layers_enabled=1;return 1;
}
int l3_memory_scene_render(L3Render *r,L3MemoryScene *f,struct prodock_scene *scene,int full){
 if(!r||!f||!scene||!r->memory||!((r->width==400&&r->height==240)||(r->width==640&&r->height==360))||r->pitch!=r->width*4||r->page_bytes!=(r->width==400?1u<<20:2u<<20))return 0;
 return art(r,f)&&board(r,f,scene,full)&&ui(r,f,scene);
}
