/* SPDX-License-Identifier: custom */
/* L3 submit diagnostic observer implementation. */
#include "submit_diag.h"

/*
 * Record one completed or failed SUBMIT observation.
 *
 * The caller owns the command memory; this function only reads the first eight
 * words of each command and never reorders or modifies them.  All arithmetic for
 * hardware counters uses unsigned 32-bit modulo because the kernel counters
 * are documented as wrapping modulo 2^32.
 */
int l3_submit_diag_observe(L3SubmitDiag *stats, int hardware,
                           const uint32_t commands[][8], unsigned count,
                           const L3SubmitCounters *before,
                           const L3SubmitCounters *after,
                           uint64_t wall_ns, int submit_result)
{
    /* Required argument validation.  A rejected call is side-effect free. */
    if (stats == 0) return 0;
    if (count < 1U || count > 64U) return 0;
    if (commands == 0) return 0;
    if (hardware != 0 && (before == 0 || after == 0)) return 0;

    /* Count command classes without touching the command array. */
    {
        unsigned i;
        uint64_t geometry_commands = 0;
        uint64_t draws = 0;
        for (i = 0; i < count; i++) {
            unsigned op = commands[i][0] >> 24;
            if (op >= 31U && op <= 34U) {
                geometry_commands++;
            }
            if (op == 34U) {
                draws++;
            }
        }
        stats->batches++;
        stats->commands += count;
        stats->geometry_commands += geometry_commands;
        stats->draws += draws;
    }

    /* A failed submit records the failed batch but no timing/counter data. */
    if (submit_result != 0) {
        stats->failed_batches++;
        return 0;
    }

    /* Host submissions are deliberately not hardware measurements. */
    if (hardware == 0) {
        return 1;
    }

    /* Inconsistent error/fault state means the sample cannot be trusted. */
    if (before->errors != after->errors || before->fault != after->fault) {
        stats->invalid_samples++;
        return 0;
    }

    /* Accumulate modulo-2^32 deltas into 64-bit totals. */
    stats->sampled_batches++;
    stats->wall_ns += wall_ns;
    stats->feed_us += (uint32_t)(after->feed_us - before->feed_us);
    stats->wait_us += (uint32_t)(after->wait_us - before->wait_us);
    stats->cache_us += (uint32_t)(after->cache_us - before->cache_us);
    stats->cycles += (uint32_t)(after->cycles - before->cycles);
    stats->vertices += (uint32_t)(after->vertices - before->vertices);
    stats->triangles += (uint32_t)(after->triangles - before->triangles);
    return 1;
}
