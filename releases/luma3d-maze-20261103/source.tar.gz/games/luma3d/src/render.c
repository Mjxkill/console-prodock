#define _POSIX_C_SOURCE 200809L
#include "l3_festival.h"
#include "luma3d_amber.h"
#include "luma3d_activities.h"
#include "luma3d_render.h"
#include "l3_puzzle_presentation.h"
#include "l3_simon_presentation.h"
#include "generated.h"
#include "luma3d_sky_assets.h"
/* VILLAGE_SHARED_SKY_01 */
/* VILLAGE_VISUAL_ROOT_03 */
#include "luma3d_surface.h"
#include "npc_cast.h"
#include "hero_polish.h"
#include "amber_data.h"
#include "prodock-validate.h"
#include <errno.h>
#include <fcntl.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>

/* gpu_v1's emitter has no user pointer. The native application has exactly one
 * producer, and capture uses this identical producer, never CPU projection. */
static L3Render *active;
static double clock_seconds(void) {struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec*1e-9;}
static float dot(L3Vec3 a,L3Vec3 b) {return a.x*b.x+a.y*b.y+a.z*b.z;}
static L3Vec3 sub(L3Vec3 a,L3Vec3 b) {return (L3Vec3){a.x-b.x,a.y-b.y,a.z-b.z};}
static L3Vec3 cross(L3Vec3 a,L3Vec3 b) {return (L3Vec3){a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
static L3Vec3 unit(L3Vec3 a) {float n=sqrtf(dot(a,a));return n>1e-6f?(L3Vec3){a.x/n,a.y/n,a.z/n}:(L3Vec3){0,0,1};}
static unsigned rgb(unsigned r,unsigned g,unsigned b) {return (r*31/255<<11)|(g*63/255<<5)|(b*31/255);}
static int call(L3Render *r,unsigned long op,void *v) {
    if(r->failed)return 0;
    if(op==PRODOCK_PRESENT)r->last_scene=*(const struct prodock_scene *)v;
    if(!r->host&&ioctl(op==PRODOCK_LAYOUT||op==PRODOCK_DISPLAY_INFO?r->display:r->fd,op,v)) {
        perror("LUMA3D GPU");r->failed=1;return 0;
    }return 1;
}
static void flush(L3Render *r) {
    if(!r->batch.count||r->failed)return;
    unsigned diag_count=r->batch.count;
    int diag_enabled=r->submit_diag_enabled;
    struct prodock_geometry_info gb={0},ga={0};
    struct prodock_display_info db={0},da={0};
    L3SubmitCounters cb={0},ca={0};
    int before_ok=0,after_ok=0,submit_ok=0,submit_done=0;
    int clock_start_ok=1,clock_end_ok=0;
    uint64_t wall_ns=0;
    struct timespec ts0,ts1;

    if(diag_enabled && !r->host) {
        before_ok=call(r,PRODOCK_GEOMETRY_INFO,&gb)&&call(r,PRODOCK_DISPLAY_INFO,&db);
        if(before_ok) {
            cb.feed_us=db.feed_us;cb.wait_us=db.wait_us;cb.cache_us=db.cache_us;
            cb.cycles=gb.cycles;cb.vertices=gb.vertices;cb.triangles=gb.triangles;
            cb.errors=db.errors+gb.errors+db.underflows;cb.fault=db.faulted;
        }
    }

    double t=clock_seconds();
    if(diag_enabled) {
        if(clock_gettime(CLOCK_MONOTONIC,&ts0)!=0) { clock_start_ok=0;r->failed=1; }
    }
    if(!r->failed) {
        submit_done=1;
        submit_ok=call(r,PRODOCK_SUBMIT,&r->batch);
        if(diag_enabled) {
            if(clock_gettime(CLOCK_MONOTONIC,&ts1)!=0) { clock_end_ok=0;r->failed=1; }
            else clock_end_ok=1;
        } else {
            clock_end_ok=1;
        }
    }
    r->feed_seconds+=clock_seconds()-t;
    r->total_flushes++;
    r->batch.count=0;

    if(!diag_enabled) return;

    if(r->host) {
        int result=submit_ok?0:-1;
        l3_submit_diag_observe(&r->submit_diag,0,r->batch.commands,diag_count,0,0,0,result);
        return;
    }

    if(!before_ok) {
        r->submit_diag.invalid_samples++;
        r->failed=1;
        return;
    }

    if(!submit_done) {
        r->submit_diag.invalid_samples++;
        r->failed=1;
        return;
    }

    if(clock_start_ok && clock_end_ok) {
        if(ts1.tv_nsec>=ts0.tv_nsec)
            wall_ns=(uint64_t)(ts1.tv_sec-ts0.tv_sec)*1000000000ULL+(uint64_t)(ts1.tv_nsec-ts0.tv_nsec);
        else
            wall_ns=(uint64_t)(ts1.tv_sec-ts0.tv_sec-1)*1000000000ULL+(uint64_t)(1000000000L+ts1.tv_nsec-ts0.tv_nsec);
    }

    if(!submit_ok) {
        ca=cb;
        l3_submit_diag_observe(&r->submit_diag,1,r->batch.commands,diag_count,&cb,&ca,wall_ns,-1);
        return;
    }

    after_ok=call(r,PRODOCK_GEOMETRY_INFO,&ga)&&call(r,PRODOCK_DISPLAY_INFO,&da);
    if(after_ok) {
        ca.feed_us=da.feed_us;ca.wait_us=da.wait_us;ca.cache_us=da.cache_us;
        ca.cycles=ga.cycles;ca.vertices=ga.vertices;ca.triangles=ga.triangles;
        ca.errors=da.errors+ga.errors+da.underflows;ca.fault=da.faulted;
        if(clock_start_ok && clock_end_ok) {
            l3_submit_diag_observe(&r->submit_diag,1,r->batch.commands,diag_count,&cb,&ca,wall_ns,0);
        } else {
            l3_submit_diag_observe(&r->submit_diag,0,r->batch.commands,diag_count,0,0,0,0);
            r->submit_diag.invalid_samples++;
            r->failed=1;
        }
    } else {
        l3_submit_diag_observe(&r->submit_diag,0,r->batch.commands,diag_count,0,0,0,0);
        r->submit_diag.invalid_samples++;
        r->failed=1;
    }
}
static void emit(const gpu_command *c) {
    L3Render *r=active;
    if(!r||r->failed)return;
    if(prodock_command(c->words)) {fprintf(stderr,"Invalid G3D command %u\n",c->words[0]>>24);r->failed=1;return;}
    unsigned op=c->words[0]>>24;
    int slot=op==31?(int)c->words[1]:op==33?3:op==25?4:op==24?5:-1;
    /* G3D DRAW restores MATERIAL and retains MATRIX/LIGHT/TEXTURE. COPY
     * invalidates texture contents, not its descriptor. Keep all descriptors
     * explicit again after TARGET; do not cache raster interpolation planes. */
    if(op==22)r->state_valid=0;
    if(slot>=0&&(r->state_valid&(1U<<slot))&&!memcmp(c,&r->state_cache[slot],sizeof(*c)))return;
    if(r->batch.count==PRODOCK_BATCH_MAX)flush(r);
    if(r->failed)return;
    memcpy(r->batch.commands[r->batch.count++],c->words,32);r->commands++;r->total_commands++;
    if(slot>=0) {r->state_cache[slot]=*c;r->state_valid|=1U<<slot;}
    if(r->capture&&fwrite(c->words,32,1,r->capture)!=1)r->failed=1;
}
static uint32_t upload(L3Render *r,const void *source,unsigned bytes) {
    unsigned offset=(r->uploaded+31)&~31U;
    /* Assets stop before the kernel console framebuffer at relative15 MiB.
     * Indexed HUD pages use20/21 MiB and never share either range. */
    if(offset>(14U<<20)||bytes>(14U<<20)-offset) {r->failed=1;return 0;}
    memcpy(r->memory+offset,source,bytes);
    if(memcmp(r->memory+offset,source,bytes)) {fputs("LUMA3D upload verification failed\n",stderr);r->failed=1;return 0;}
    r->uploaded=offset+bytes;return PRODOCK_GPU_BASE+offset;
}
int l3_render_open(L3Render *r,int host,int wide) {
    memset(r,0,sizeof(*r));r->fd=r->display=-1;r->host=host;r->npc_character=r->hero_part=-1;r->sky_region=~0u;
    if(active) {fputs("Only one GPU producer allowed\n",stderr);return 0;}
    unsigned w=wide?1280:800,h=wide?720:480;
    if(!host) {
        r->fd=open("/dev/prodock-gpu",O_RDWR|O_CLOEXEC);
        r->display=open("/dev/prodock-display",O_RDWR|O_CLOEXEC);
        if(r->fd<0||r->display<0) {perror("LUMA3D open");return 0;}
        struct prodock_info i;
        if(!call(r,PRODOCK_INFO,&i)||i.abi!=PRODOCK_ABI||i.faulted||i.errors||(i.caps&511)!=511)return 0;
        if(!call(r,PRODOCK_GEOMETRY_INFO,&r->initial_geometry)||r->initial_geometry.signature!=PRODOCK_GEOMETRY_SIGNATURE||r->initial_geometry.errors)return 0;
        if(!call(r,PRODOCK_DISPLAY_INFO,&r->initial))return 0;
        w=i.width;h=i.height;
    }
    if(!((w==800&&h==480)||(w==1280&&h==720)))return 0;
    r->width=w/2;r->height=h/2;r->pitch=w*2;r->page_bytes=w==800?1U<<20:2U<<20;
    r->memory=host?calloc(1,L3_MAP_BYTES):mmap(NULL,L3_MAP_BYTES,PROT_READ|PROT_WRITE,MAP_SHARED,r->fd,0);
    if(r->memory==MAP_FAILED)r->memory=NULL;
    if(!r->memory)return 0;
    r->meshes=calloc(l3_asset_group_count,sizeof(*r->meshes));
    r->textures=calloc(l3_asset_texture_count,sizeof(*r->textures));
    if(!r->meshes||!r->textures)return 0;
    r->uploaded=L3_ASSET_OFFSET;
    for(unsigned i=0;i<l3_asset_group_count;i++) {
        const L3AssetGroup *g=l3_asset_groups+i;
        if(!g->nv||g->nv>256||!g->nf||g->material>=l3_asset_material_count)return 0;
        r->meshes[i]=(gpu_geom_mesh){upload(r,g->vertices,g->nv*32),upload(r,g->faces,g->nf*32),g->nv,g->nf};
    }
    for(unsigned i=0;i<l3_asset_texture_count;i++) {
        const L3AssetTexture *t=&l3_asset_textures[i];
        if(!((t->width==128||t->width==256)&&(t->height==128||t->height==256)))return 0;
        r->textures[i]=upload(r,t->pixels,t->width*t->height*2);
    }
    /* Costume geometry is generated once, with corrected normals. Existing
     * world assets retain their exact addresses. Six near parts / one far mesh. */
    for(unsigned n=0;n<3;n++)for(unsigned p=0;p<7;p++) {
        const L3NPCShape *a=&l3_cast[n][p];
        r->npc_mesh[n][p]=(gpu_geom_mesh){upload(r,a->vertices,a->nv*32),upload(r,a->faces,a->nf*32),a->nv,a->nf};
    }
    /* Six articulated authored parts retain the existing pivots and gait.
     * Geometry is immutable; the dedicated atlas at19MiB never overlaps
     * console15..17, activity18, HUD20/21 or dynamic meshes24..27. */
    for(unsigned p=0;p<6;p++) {
        const L3HeroShape *a=&l3_hero_polish[p];
        if(!a->nv||a->nv>256||!a->nf)return 0;
        r->hero_mesh[p]=(gpu_geom_mesh){upload(r,a->vertices,a->nv*32),upload(r,a->faces,a->nf*32),a->nv,a->nf};
    }
    r->hero_texture=PRODOCK_GPU_BASE+(19U<<20);
    const uint8_t *hero_src=(const uint8_t *)l3_hero_polish_texture;
    uint32_t *hero_dst=(uint32_t *)(r->memory+(19U<<20));
    for(unsigned i=0;i<sizeof(l3_hero_polish_texture)/4;i++){uint32_t word;memcpy(&word,hero_src+i*4,4);hero_dst[i]=word;}
    /* Water consumes the existing repeatable texture. Its tiny face/UV banks
     * alternate with frames; vertex geometry and all original assets stay fixed. */
    uint32_t bird_faces[9*8]={0};
    static const unsigned triangles[3][3]={{0,1,2},{0,3,1},{1,4,5}};
    for(unsigned b=0;b<3;b++)for(unsigned f=0;f<3;f++) {
        uint32_t *face=bird_faces+(b*3+f)*8;
        face[0]=(3U<<24)|(b*6+triangles[f][0])|((b*6+triangles[f][1])<<8)|((b*6+triangles[f][2])<<16);
        face[4]=32767;face[6]=42U|(54U<<9)|(63U<<18);
    }
    uint32_t bird_face_base=upload(r,bird_faces,sizeof(bird_faces));
    r->static_end=r->uploaded;r->water_texture=~0U;
    r->water_kind=calloc(l3_asset_group_count,1);
    r->water_faces[0]=calloc(l3_asset_group_count,sizeof(uint32_t));
    r->water_faces[1]=calloc(l3_asset_group_count,sizeof(uint32_t));
    if(!r->water_kind||!r->water_faces[0]||!r->water_faces[1])return 0;
    for(unsigned i=0;i<l3_asset_texture_count;i++)if(!strcmp(l3_asset_textures[i].name,"water"))r->water_texture=i;
    for(unsigned i=0;i<l3_asset_instance_count;i++) {
        const L3AssetInstance *a=&l3_asset_instances[i];
        if(a->kind!=L3_ASSET_WATER&&a->kind!=L3_ASSET_WATERFALL)continue;
        const L3AssetMesh *m=&l3_asset_meshes[a->mesh_id];
        for(unsigned j=0;j<m->group_count;j++) {
            unsigned group=(unsigned)(m->groups+j-l3_asset_groups);
            r->water_kind[group]=(a->kind==L3_ASSET_WATERFALL?2:1)+(i>=AMBER_FIRST_INSTANCE?2:0);
        }
    }
    if(r->water_texture==~0U)return 0;
    for(unsigned page=0;page<2;page++)for(unsigned i=0;i<l3_asset_group_count;i++)if(r->water_kind[i])
        r->water_faces[page][i]=upload(r,l3_asset_groups[i].faces,l3_asset_groups[i].nf*32);
    uint32_t bird_vertices[18*8]={0};
    for(unsigned page=0;page<2;page++)r->bird_mesh[page]=(gpu_geom_mesh){upload(r,bird_vertices,sizeof(bird_vertices)),bird_face_base,18,9};
    if(r->failed)return 0;
#if defined(LUMA_SUBMIT_DIAG) && LUMA_SUBMIT_DIAG
    r->submit_diag_enabled=1;
#else
    {
        const char *l3_submit_diag_env=getenv("LUMA_SUBMIT_DIAG");
        if(l3_submit_diag_env && !strcmp(l3_submit_diag_env,"1"))r->submit_diag_enabled=1;
    }
#endif
    active=r;gpu_v1_init(&r->gpu,emit);
    r->tint[0]=r->tint[1]=r->tint[2]=256;
    if(!l3_hud_open(r)||!l3_mini_ui_open(r)||!l3_puzzle_presentation_open(r)||!l3_simon_presentation_open(r)||!l3_activity_art_open(r)||!l3_shooter_art_open(r))return 0;
    r->near_z=.5f;r->far_z=210;r->focal=r->width*.82f;
    printf("LUMA3D ready: %ux%u G3D1 assets=%u bytes groups=%u textures=%u\n",r->width,r->height,r->uploaded-L3_ASSET_OFFSET,l3_asset_group_count,l3_asset_texture_count);fflush(stdout);
    printf("LUMA3D_SHOOTER_PRELOAD bytes=%u completed_before_first_frame=1\n",r->shooter_upload_bytes);fflush(stdout);
    if(!host) {struct prodock_layout layout={.mode=PRODOCK_GAME};if(!call(r,PRODOCK_LAYOUT,&layout))return 0;}
    return 1;
}
static L3Vec3 object_point(L3Vec3 p,L3Vec3 scale,float yaw,L3Vec3 position) {
    float s=sinf(yaw),c=cosf(yaw),x=p.x*scale.x,z=p.z*scale.z;
    return (L3Vec3){position.x+c*x+s*z,position.y+p.y*scale.y,position.z-s*x+c*z};
}
static int visible(L3Render *r,const L3Game *g,const L3AssetMesh *m,L3Vec3 p,L3Vec3 scale,float yaw,float *distance) {
    L3Vec3 rel=sub(object_point(m->center,scale,yaw,p),g->camera.eye);
    float x=dot(rel,r->right),y=dot(rel,r->down),z=dot(rel,r->forward);
    float radius=m->radius*fmaxf(fabsf(scale.x),fmaxf(fabsf(scale.y),fabsf(scale.z)));
    *distance=sqrtf(dot(rel,rel));
    float sx=r->width*.5f/r->focal,sy=r->height*.5f/r->focal;
    return z+radius>=r->near_z&&z-radius<=r->far_z&&fabsf(x)-z*sx<=radius*sqrtf(1+sx*sx)&&fabsf(y)-z*sy<=radius*sqrtf(1+sy*sy);
}
static int draw_ex(L3Render *r,const L3Game *g,unsigned mesh,L3Vec3 p,L3Vec3 scale,float yaw,float pitch,float roll,int cull) {
    if(mesh>=l3_asset_mesh_count)return 0;
    const L3AssetMesh *m=&l3_asset_meshes[mesh];float distance;
    int custom_npc=r->npc_character>=0,custom_hero=r->hero_part>=0;L3AssetMesh npc_bounds;
    if(custom_npc) {
        const L3NPCShape *a=&l3_cast[r->npc_character][r->npc_part];
        npc_bounds=*m;npc_bounds.center=a->center;npc_bounds.radius=a->radius;m=&npc_bounds;
    }
    if(custom_hero) {
        if(r->hero_part>=6)return 0;
        const L3HeroShape *a=&l3_hero_polish[r->hero_part];
        npc_bounds=*m;npc_bounds.center=a->center;npc_bounds.radius=a->radius;m=&npc_bounds;
    }
    if(r->ambient_active) {npc_bounds=*m;npc_bounds.center=(L3Vec3){0,0,0};npc_bounds.radius=4.6f;m=&npc_bounds;}
    float sp=sinf(pitch),cp=cosf(pitch),sr=sinf(roll),cr=cosf(roll);
    L3Vec3 local_columns[3]={{cr,cp*sr,sp*sr},{-sr,cp*cr,sp*cr},{0,-sp,cp}};
    L3AssetMesh bounds=*m;L3Vec3 center=m->center;
    bounds.center=(L3Vec3){cr*center.x-sr*center.y,
        cp*sr*center.x+cp*cr*center.y-sp*center.z,
        sp*sr*center.x+sp*cr*center.y+cp*center.z};
    if(!visible(r,g,&bounds,p,scale,yaw,&distance)) {r->culled++;return 1;}
    float s=sinf(yaw),c=cosf(yaw);
    L3Vec3 cols[3];float scales[3]={scale.x,scale.y,scale.z};
    /* All meshes bake nonuniform scale into positions/normals at export. */
    if(scale.x<=0||fabsf(scale.x-scale.y)>1e-5f||fabsf(scale.x-scale.z)>1e-5f)return 0;
    for(unsigned k=0;k<3;k++) {
        L3Vec3 v=local_columns[k];
        cols[k]=(L3Vec3){(c*v.x+s*v.z)*scales[k],v.y*scales[k],(-s*v.x+c*v.z)*scales[k]};
    }
    L3Vec3 rows[3]={r->right,r->down,r->forward},rel=sub(p,g->camera.eye);
    gpu_geom_transform transform;
    for(unsigned a=0;a<3;a++) {
        for(unsigned b=0;b<3;b++)if(!gpu_geom_fixed(dot(rows[a],cols[b]),&transform.values[a*4+b]))return 0;
        if(!gpu_geom_fixed(dot(rows[a],rel),&transform.values[a*4+3]))return 0;
    }
    L3Vec3 l=l3_asset_light_direction;
    L3Vec3 local=unit((L3Vec3){dot(cols[0],l),dot(cols[1],l),dot(cols[2],l)});
    unsigned ambient=(unsigned)(l3_asset_ambient*256);
    gpu_geom_light light={(int16_t)(local.x*32767),(int16_t)(local.y*32767),(int16_t)(local.z*32767),ambient,256-ambient};
    if(!gpu_geom_set_transform(&r->gpu,&transform)||!gpu_geom_set_light(&r->gpu,&light))return 0;
    unsigned fog=g->story.region?rgb(225,195,153):rgb(l3_asset_fog_color[0],l3_asset_fog_color[1],l3_asset_fog_color[2]);
    unsigned zn=(unsigned)((1-r->near_z/l3_asset_fog_start)*65534);
    unsigned zf=(unsigned)((1-r->near_z/l3_asset_fog_end)*65534);
    L3Vec3 bound_rel=sub(object_point(bounds.center,scale,yaw,p),g->camera.eye);
    /* A conservative 5 m margin covers fixed-point depth/plane rounding.
     * Removing an ineffective fog flag enables G22r0's opaque pixel path. */
    unsigned fog_flag=dot(bound_rel,r->forward)+m->radius*scale.x>=l3_asset_fog_start-5?128:0;
    gpu_material mat={((custom_npc||r->ambient_active)?(2|4):(1|2|4|16))|fog_flag,256,65535,r->tint[0],r->tint[1],r->tint[2],zn,fog,(256U*65536)/(zf-zn)};
    if(!gpu_v1_material(&r->gpu,&mat))return 0;
    if(r->ambient_active) {
        const gpu_geom_mesh *bird=&r->bird_mesh[r->frame&1];
        if(!gpu_geom_draw(&r->gpu,bird,1))return 0;
        r->draws++;r->triangles+=bird->face_count;r->instances++;return !r->failed;
    }
    if(custom_npc) {
        const gpu_geom_mesh *npc=&r->npc_mesh[r->npc_character][r->npc_part];
        if(!gpu_geom_draw(&r->gpu,npc,1))return 0;
        r->draws++;r->triangles+=npc->face_count;r->instances++;return !r->failed;
    }
    if(custom_hero) {
        const gpu_geom_mesh *hero=&r->hero_mesh[r->hero_part];
        gpu_texture_level texture={r->hero_texture,256,256,512,GPU_RGB565,1,1,0};
        if(!gpu_v1_texture(&r->gpu,&texture)||!gpu_geom_draw(&r->gpu,hero,1))return 0;
        r->draws++;r->triangles+=hero->face_count;r->instances++;return !r->failed;
    }
    for(unsigned j=0;j<m->group_count;j++) {
        const L3AssetGroup *a=&m->groups[j];unsigned idx=(unsigned)(a-l3_asset_groups);
        if(idx>=l3_asset_group_count||a->material>=l3_asset_material_count)return 0;
        unsigned ti=r->water_kind[idx]?r->water_texture:l3_asset_materials[a->material].texture_index;
        if(ti>=l3_asset_texture_count)return 0;
        const L3AssetTexture *texture=&l3_asset_textures[ti];
        gpu_texture_level tex={r->textures[ti],texture->width,texture->height,texture->width*2,GPU_RGB565,1,1,0};
        gpu_geom_mesh current=r->meshes[idx];
        if(r->water_kind[idx])current.faces=r->water_faces[r->frame&1][idx];
        if(!gpu_v1_texture(&r->gpu,&tex)||!gpu_geom_draw(&r->gpu,&current,cull))return 0;
        r->draws++;r->triangles+=a->nf;
    }
    r->instances++;return !r->failed;
}
static int draw(L3Render *r,const L3Game *g,unsigned mesh,L3Vec3 p,L3Vec3 scale,float yaw,int cull) {
    return draw_ex(r,g,mesh,p,scale,yaw,0,0,cull);
}
static void animate_water(L3Render *r,float time,unsigned region) {
    /* Uniform UV translation, evaluated from current simulation time. No saved
     * camera/animation positions and no texture upload. Previous SUBMIT has
     * completed before this inactive face bank can be reused. */
    unsigned page=r->frame&1;r->animated_bytes=0;
    for(unsigned i=0;i<l3_asset_group_count;i++)if(r->water_kind[i]&&(unsigned)(r->water_kind[i]-1)/2==region) {
        const L3AssetGroup *g=&l3_asset_groups[i];
        uint32_t *dst=(uint32_t *)(r->memory+r->water_faces[page][i]-PRODOCK_GPU_BASE);
        int waterfall=(r->water_kind[i]&1)==0;
        int phase=(int)floorf(fmodf(time*(waterfall?18.0f:3.0f),128.0f));
        for(unsigned f=0;f<g->nf;f++) {
            uint32_t words[8];memcpy(words,g->faces+f*8,32);
            for(unsigned k=0;k<3;k++) {
                unsigned v=(words[0]>>(k*8))&255;
                float x=(int32_t)g->vertices[v*8]/65536.0f;
                float y=(int32_t)g->vertices[v*8+1]/65536.0f;
                float z=(int32_t)g->vertices[v*8+2]/65536.0f;
                int dedicated=l3_asset_materials[g->material].texture_index==r->water_texture;
                int u=dedicated?(int16_t)(words[k+1]>>16):(int)floorf(x*6);
                int vv=dedicated?(int16_t)words[k+1]:(int)floorf((waterfall?-y:z)*6);
                u+=waterfall?0:phase;vv+=waterfall?phase:0;
                words[k+1]=((uint32_t)(uint16_t)u<<16)|(uint16_t)vv;
            }
            for(unsigned k=0;k<8;k++)dst[f*8+k]=words[k];
        }
        r->animated_bytes+=g->nf*32;
    }
}
static void animate_birds(L3Render *r,const L3Game *g) {
    float time=g->time;
    r->bird_position=(L3Vec3){(g->story.region?228:70)+12*sinf(time*.13f),0,(g->story.region?55:94)+9*cosf(time*.13f)};
    r->bird_position.y=g->world.height(g->world.context,r->bird_position.x,r->bird_position.z)+8+.6f*sinf(time*.21f);
    uint32_t *dst=(uint32_t *)(r->memory+r->bird_mesh[r->frame&1].vertices-PRODOCK_GPU_BASE);
    for(unsigned b=0;b<3;b++) {
        float offset=(float)b-1,flap=.35f*sinf(time*7+b*1.2f);
        L3Vec3 points[6]={{0,0,.5f},{0,0,-.45f},{-.7f,flap,0},{.7f,flap,0},{-.2f,0,-.8f},{.2f,0,-.8f}};
        for(unsigned v=0;v<6;v++) {
            L3Vec3 p=points[v];p.x+=offset*2.2f;p.z-=fabsf(offset)*1.5f;p.y+=sinf(b*2.0f)*.2f;
            uint32_t words[8]={(uint32_t)(int32_t)(p.x*65536),(uint32_t)(int32_t)(p.y*65536),(uint32_t)(int32_t)(p.z*65536),0,0,0,0,0};
            for(unsigned k=0;k<8;k++)dst[(b*6+v)*8+k]=words[k];
        }
    }
    r->animated_bytes+=18*32;
}
#include "village_visual.h"
#include "garden_visual.h"
int l3_render_frame(L3Render *r,const L3Game *g) {
    if(r->failed||!g->valid)return 0;
    active=r;r->sprite_count=0;
    if(r->festival && r->festival->active){
        r->commands=r->draws=r->triangles=r->instances=r->culled=0;
        struct prodock_scene scene={0};
        if(!l3_festival_render(r,r->festival,&scene)){r->failed=1;return 0;}
        flush(r);if(r->failed)return 0;
        r->last_scene=scene;double now=clock_seconds();
        if(!call(r,PRODOCK_PRESENT,&scene))return 0;
        r->present_seconds+=clock_seconds()-now;r->frame++;return 1;
    }
    if(g->activities.arcade.active){
        if(!l3_presentation_prepare(r,g)){r->failed=1;return 0;}
        r->commands=r->draws=r->triangles=r->instances=r->culled=0;
        unsigned mode=g->activities.arcade.active;
        if(r->activity_mode!=mode){r->maze_static_count=0;r->mini_stamp[0]=r->mini_stamp[1]=0;r->activity_mode=mode;r->activity_stage=~0u;if(mode!=L3_MINI_MAZE+1)l3_maze_motion_reset(&r->maze_motion);}
        if(mode==L3_MINI_MAZE+1||mode==L3_ARCADE_PLATFORM+1){
            if(!(mode==L3_MINI_MAZE+1?l3_maze_render(r,g):l3_arcade_3d_render(r,g)))return 0;
            flush(r);if(r->failed)return 0;
        }
        struct prodock_scene scene={.base=PRODOCK_GPU_BASE+(r->frame&1)*r->page_bytes,.stride=r->pitch,.format=7};
        if(mode==L3_ARCADE_SHOOTER+1&&!l3_shooter_render(r,g,&scene))return 0;
        if(mode==L3_MINI_BLOCKS+1||mode==L3_MINI_MERGE1024+1){
            if(!l3_puzzle_motion_prepare(r,g,&scene,r->presentation_seconds))return 0;
        }else if(mode==L3_ARCADE_SIMON+1){
            if(!l3_simon_presentation_prepare(r,g,&scene,r->presentation_seconds))return 0;
        }else if(!l3_mini_ui_prepare(r,g,&scene))return 0;
        r->last_scene=scene;flush(r);if(r->failed)return 0;
        double t=clock_seconds();if(!call(r,PRODOCK_PRESENT,&scene))return 0;r->present_seconds+=clock_seconds()-t;r->frame++;return 1;
    }
    active=r;r->commands=r->draws=r->triangles=r->instances=r->culled=0;animate_water(r,g->time,g->story.region);animate_birds(r,g);
    r->forward=unit(sub(g->camera.target,g->camera.eye));
    /* World is right-handed Y-up; G3D1 is right/down/forward. Preserve
     * determinant +1, otherwise visible faces are culled and east is mirrored. */
    r->right=unit(cross(r->forward,(L3Vec3){0,1,0}));r->down=cross(r->forward,r->right);
    gpu_target target={PRODOCK_GPU_BASE+(r->frame&1)*r->page_bytes,PRODOCK_GPU_BASE+2*r->page_bytes,r->width,r->height,r->pitch,r->pitch};
    gpu_target background=target;background.color=PRODOCK_GPU_BASE+6U*1024*1024;
    /* The sky is generated once by the same GPU Gouraud operation as R1.
     * It is an angle-independent gradient, not a cached 3D camera image. */
    if(r->frame==0||r->sky_region!=g->story.region) {
    if(!gpu_v1_target(&r->gpu,&background)||!gpu_v1_scissor(&r->gpu,0,0,r->width,r->height))return 0;
    gpu_material sky={GPU_V1_GOURAUD,256,65535,256,256,256,0,0,0};
    gpu_vertex quad[4]={{0,0,0,0,0,0,0,0,0},{r->width,0,0,0,0,0,0,0,0},{r->width,r->height,0,0,0,0,0,0,0},{0,r->height,0,0,0,0,0,0,0}};
    for(unsigned i=0;i<4;i++) {static const uint8_t amber_sky[2][3]={{104,157,194},{238,213,177}};const uint8_t *a=g->story.region?amber_sky[i<2?0:1]:i<2?l3_asset_sky_zenith:l3_asset_sky_horizon;quad[i].r=a[0]*256/255;quad[i].g=a[1]*256/255;quad[i].b=a[2]*256/255;}
    if(!gpu_v1_material(&r->gpu,&sky)||!gpu_v1_quad(&r->gpu,quad))return 0;r->sky_region=g->story.region;
    }
    if(!gpu_v1_target(&r->gpu,&target)||!gpu_v1_scissor(&r->gpu,0,0,r->width,r->height)||
       !gpu_v1_clear(&r->gpu,2,0,65535,0,0,r->width,r->height)||
       !gpu_v1_copy(&r->gpu,&background,0,0,0,0,r->width,r->height))return 0;
    gpu_geom_camera camera={(int32_t)(r->near_z*65536),(int32_t)(r->far_z*65536),(int32_t)(r->focal*65536),(int32_t)(r->focal*65536),r->width/2,r->height/2};
    if(!gpu_geom_set_camera(&r->gpu,&camera))return 0;
    if(!village_environment(r,g))return 0;
    if(g->story.region&&!garden_resources(r,g))return 0;
    if(r->frame==0)gpu_v1_invalidate(&r->gpu);
    for(unsigned i=g->story.region?AMBER_FIRST_INSTANCE:0,end=g->story.region?l3_asset_instance_count:AMBER_FIRST_INSTANCE;i<end;i++) {
        const L3AssetInstance *a=&l3_asset_instances[i];
        if(a->kind==L3_ASSET_ACTOR)continue;
        if(!strcmp(a->id,"arcade_echo_markers")&&!l3_activity_won(g,L3_ARCADE_SIMON))continue;
        if(!strcmp(a->id,"arcade_star_beacon")&&!l3_activity_won(g,L3_ARCADE_SHOOTER))continue;
        if(!strcmp(a->id,"arcade_tower_gate")&&l3_activity_won(g,L3_ARCADE_PLATFORM))continue;
        if(!strcmp(a->id,"amber_garden_gate")&&l3_activity_won(g,L3_MINI_SHAPES))continue;
        if(!strcmp(a->id,"amber_secret_door")&&l3_activity_won(g,L3_MINI_MAZE))continue;
        if(!strcmp(a->id,"amber_house_roof")&&g->player.position.x>217&&g->player.position.x<227&&g->player.position.z>66&&g->player.position.z<76)continue;
        if(!strcmp(a->id,"amber_flow_garden")&&(!g->story.amber_intake||g->story.amber_sluice!=1))continue;
        if(!strcmp(a->id,"amber_flow_basin")&&(!g->story.amber_intake||g->story.amber_sluice!=2))continue;
        if(!strcmp(a->id,"amber_reservoir")){L3Vec3 p=a->position;p.y=7*g->story.amber_lift;if(!draw(r,g,a->mesh_id,p,a->scale,0,1))return 0;continue;}
        if(!strcmp(a->id,"amber_bridge")){L3Vec3 p=a->position;p.y=-9*(1-g->story.amber_lift);if(!draw(r,g,a->mesh_id,p,a->scale,0,1))return 0;continue;}
        if(!strcmp(a->id,"amber_intake")||!strcmp(a->id,"amber_sluice")){float turn=!strcmp(a->id,"amber_intake")?g->story.amber_intake*1.5707963f:g->story.amber_sluice*2.0943951f;if(!draw(r,g,a->mesh_id,a->position,a->scale,turn,1))return 0;continue;}
        if(!strcmp(a->id,"workshop_bell")&&g->story.workshop_phase>=3)continue;
        if(!strcmp(a->id,"village_bell")&&g->story.workshop_phase!=4)continue;
        unsigned mesh=a->mesh_id;float distance;
        L3AssetMesh outer_bounds=l3_asset_meshes[mesh];
        if(!strncmp(a->id,"workshop_",9)||!strcmp(a->id,"village_bell")){
            outer_bounds.radius+=sqrtf(outer_bounds.center.x*outer_bounds.center.x+outer_bounds.center.y*outer_bounds.center.y+outer_bounds.center.z*outer_bounds.center.z);
            outer_bounds.center=(L3Vec3){0};
        }
        if(!strncmp(a->id,"tree_",5))outer_bounds.radius*=1.02f; /* sway can cross a view edge */
        if(!visible(r,g,&outer_bounds,a->position,a->scale,a->yaw,&distance)) {r->culled++;continue;}
        /* Player-near walk surfaces use the exact triangles queried by collision.
         * Other instances and distant patches retain their original LOD rules. */
        if(!l3_surface_near(i,g->player.position.x,g->player.position.z))
            for(unsigned j=0;j<a->lod_count;j++)if(distance>a->lods[j].distance)mesh=a->lods[j].mesh_id;
        if(!strcmp(a->id,"workshop_copper")||!strcmp(a->id,"workshop_blue")){
            float yaw=!strcmp(a->id,"workshop_copper")?g->story.wind_angle_a:g->story.wind_angle_b;
            if(!draw(r,g,mesh,a->position,a->scale,yaw,1))return 0;continue;
        }
        if(!strcmp(a->id,"workshop_door")){
            if(!draw(r,g,mesh,a->position,a->scale,g->story.workshop_phase>=2?1.5707963f:0,1))return 0;continue;
        }
        if(!strcmp(a->id,"workshop_wheel")||!strcmp(a->id,"village_bell")){
            float roll=g->story.workshop_phase>=2?g->time*.8f:0;
            if(!strcmp(a->id,"village_bell"))roll=.18f*sinf(g->time*2);
            if(!draw_ex(r,g,mesh,a->position,a->scale,0,0,roll,1))return 0;continue;
        }
        if(!strcmp(a->id,"windmill")) {
            if(!draw(r,g,l3_asset_windmill_static_mesh,a->position,a->scale,a->yaw,1))return 0;
            L3Vec3 pivot=object_point(l3_asset_windmill_rotor_pivot,a->scale,a->yaw,a->position);
            if(!draw_ex(r,g,l3_asset_windmill_rotor_mesh,pivot,a->scale,a->yaw,0,g->time*.45f,1))return 0;
            continue;
        }
        if(!strncmp(a->id,"tree_",5)&&distance<45) {
            float phase=g->time*1.3f+a->position.x*.13f+a->position.z*.09f;
            if(!draw_ex(r,g,mesh,a->position,a->scale,a->yaw,.006f*sinf(phase*.73f),.009f*sinf(phase),1))return 0;
        } else if(!draw(r,g,mesh,a->position,a->scale,a->yaw,1))return 0;
    }
    if(!garden_environment(r,g))return 0;
    /* One depth-tested G3D flock: nine faces, runtime wing motion and flight. */
    r->ambient_active=1;
    if(!draw(r,g,l3_asset_letter_mesh,r->bird_position,(L3Vec3){1,1,1},1.5707963f-g->time*.13f,1))return 0;
    r->ambient_active=0;
    /* Distinct solid-lit costumes, no extra texture or accessory DRAW. */
    for(unsigned n=0;n<(g->story.region?2u:3u);n++) {
        L3Vec3 pos=l3_story_site(g,g->story.region?(n?15:10):n);float scale=n==0?.94f:n==1?1.08f:1.0f;
        float yaw=atan2f(g->player.position.x-pos.x,g->player.position.z-pos.z);
        r->npc_character=g->story.region?(n?2:0):(int)n;
        if(g->story.region){r->tint[0]=256;r->tint[1]=n?220:185;r->tint[2]=n?175:115;}
        if(dot(sub(pos,g->camera.eye),sub(pos,g->camera.eye))>25*25) {
            r->npc_part=6;
            if(!draw(r,g,l3_asset_hero_mesh,pos,(L3Vec3){scale,scale,scale},yaw,1))return 0;
            continue;
        }
        for(unsigned i=0;i<l3_asset_hero_part_count;i++) {
            r->npc_part=(int)i;
            const L3AssetPart *part=l3_asset_hero_parts+i;
            L3Vec3 size={scale,scale,scale},pivot=object_point(part->pivot,size,yaw,pos);
            float gesture=part->kind==3?.12f+sinf(g->time*1.2f+n)*.08f:part->kind==5?-.12f:0;
            if(!draw_ex(r,g,part->mesh_id,pivot,size,yaw,gesture,0,1))return 0;
        }
    }
    r->npc_character=-1;
    r->tint[0]=r->tint[1]=r->tint[2]=256;
    if(!g->story.region){
    unsigned rock=0;
    for(unsigned i=0;i<l3_asset_mesh_count;i++)if(!strcmp(l3_asset_meshes[i].name,"rock_far_budget"))rock=i;
    static const unsigned stone_colors[3][3]={{256,170,100},{140,256,190},{135,190,256}};
    for(unsigned i=0;i<3;i++) {
        L3Vec3 p=l3_story_site(g,3+i);memcpy(r->tint,stone_colors[i],sizeof(r->tint));
        if(!draw(r,g,rock,p,(L3Vec3){.45f,.45f,.45f},i*.8f,1))return 0;
        if(g->story.relay_step>i||g->story.phase>=3) {
            p.y+=1.2f+.12f*sinf(g->time*2+i);
            if(!draw(r,g,l3_asset_letter_mesh,p,(L3Vec3){.75f,.75f,.75f},g->time+i,1))return 0;
        }
    }
    r->tint[0]=r->tint[1]=r->tint[2]=256;
    if(g->objective_complete) {
        L3Vec3 beacon=g->world.goal;beacon.y+=3.5f+.2f*sinf(g->time);
        if(!draw(r,g,l3_asset_letter_mesh,beacon,(L3Vec3){2,2,2},g->time*.6f,1))return 0;
    }
    }
    L3Vec3 hero=g->player.position;
    hero.y+=fabsf(sinf(g->player.walk_phase))*.035f*fminf(1,g->player.speed);
    float gait=sinf(g->player.walk_phase)*.65f*fminf(1,g->player.speed/4.5f);
    for(unsigned i=0;i<l3_asset_hero_part_count;i++) {
        r->hero_part=(int)i;
        const L3AssetPart *part=l3_asset_hero_parts+i;
        float angle=part->kind==1||part->kind==4?gait:part->kind==2||part->kind==3?-gait:part->kind==5?-.1f-sinf(g->time*2)*.07f:0;
        L3Vec3 pivot=object_point(part->pivot,(L3Vec3){1,1,1},g->player.yaw,hero);
        if(!draw_ex(r,g,part->mesh_id,pivot,(L3Vec3){1,1,1},g->player.yaw,angle,0,1))return 0;
    }
    r->hero_part=-1;
    for(unsigned i=0;i<l3_asset_collectible_count;i++)if(!g->story.region&&!(g->collected_mask&(1U<<i))) {
        L3Vec3 pos=l3_asset_collectibles[i];pos.y+=.16f*sinf(g->time*2+i);
        if(!draw(r,g,l3_asset_letter_mesh,pos,(L3Vec3){1,1,1},g->time*.9f+i,1))return 0;
    }
    flush(r);if(r->failed)return 0;
    struct prodock_scene scene={.base=target.color,.stride=target.stride,.format=7};
    if(!village_glow(r,g))return 0;
    if(g->story.region){if(!garden_transparent(r,g))return 0;flush(r);if(r->failed)return 0;}
    if(!l3_hud_prepare(r,g,&scene))return 0;
    double t=clock_seconds();if(!call(r,PRODOCK_PRESENT,&scene))return 0;r->present_seconds+=clock_seconds()-t;
    r->frame++;return 1;
}
int l3_render_dump(L3Render *r,const char *prefix) {
    char path[1024];if(snprintf(path,sizeof(path),"%s.memory",prefix)>=(int)sizeof(path))return 0;
    FILE *f=fopen(path,"wb");if(!f)return 0;int ok=fwrite(r->memory,1,32U<<20,f)==(32U<<20);if(fclose(f))ok=0;
    if(snprintf(path,sizeof(path),"%s.json",prefix)>=(int)sizeof(path))return 0;
    f=fopen(path,"w");if(!f)return 0;
    unsigned scale=r->last_scene.format==3?1:2;
    fprintf(f,"{\"width\":%u,\"height\":%u,\"scale\":%u,\"pitch\":%u,\"page_bytes\":%u,\"page\":%u,\"bytes\":%u,\"commands\":%u,\"draws\":%u,\"submitted_triangles\":%u,\"instances\":%u,\"culled_instances\":%u,\"hardware\":false}\n",r->width*2/scale,r->height*2/scale,scale,r->pitch,r->page_bytes,(r->frame-1)&1,32U<<20,r->commands,r->draws,r->triangles,r->instances,r->culled);
    if(fclose(f))ok=0;if(!l3_hud_dump(r,prefix))ok=0;return ok;
}
int l3_render_close(L3Render *r) {
    l3_presentation_unbind(r);
    int ok=!r->failed;
    if(!r->host&&r->fd>=0&&!r->failed) {
        struct prodock_geometry_info g;struct prodock_display_info d;
        if(!call(r,PRODOCK_GEOMETRY_INFO,&g)||!call(r,PRODOCK_DISPLAY_INFO,&d))ok=0;
        else {
            printf("LUMA3D_COUNTERS errors=%u underflows=%u fault=%u geometry_errors=%u vertices=%u triangles=%u slivers=%u frames=%u\n",d.errors-r->initial.errors,d.underflows-r->initial.underflows,d.faulted,g.errors-r->initial_geometry.errors,g.vertices-r->initial_geometry.vertices,g.triangles-r->initial_geometry.triangles,g.slivers-r->initial_geometry.slivers,r->frame);
            if(d.errors!=r->initial.errors||d.underflows!=r->initial.underflows||d.faulted||g.errors!=r->initial_geometry.errors)ok=0;
        }
    }
    if(r->memory) {if(r->host)free(r->memory);else munmap(r->memory,L3_MAP_BYTES);}
    l3_puzzle_presentation_close(r);l3_simon_presentation_close(r);l3_mini_ui_close(r);free(r->hud);free(r->meshes);free(r->textures);free(r->water_kind);free(r->water_faces[0]);free(r->water_faces[1]);if(r->fd>=0)close(r->fd);if(r->display>=0)close(r->display);
    if(r->submit_diag_enabled) {
        printf("LUMA3D_SUBMIT_DIAG hardware=%d batches=%llu commands=%llu geometry_commands=%llu draws=%llu failed_batches=%llu sampled_batches=%llu invalid_samples=%llu wall_ns=%llu feed_us=%llu wait_us=%llu cache_us=%llu cycles=%llu vertices=%llu triangles=%llu\n",
               r->host?0:1,
               (unsigned long long)r->submit_diag.batches,
               (unsigned long long)r->submit_diag.commands,
               (unsigned long long)r->submit_diag.geometry_commands,
               (unsigned long long)r->submit_diag.draws,
               (unsigned long long)r->submit_diag.failed_batches,
               (unsigned long long)r->submit_diag.sampled_batches,
               (unsigned long long)r->submit_diag.invalid_samples,
               (unsigned long long)r->submit_diag.wall_ns,
               (unsigned long long)r->submit_diag.feed_us,
               (unsigned long long)r->submit_diag.wait_us,
               (unsigned long long)r->submit_diag.cache_us,
               (unsigned long long)r->submit_diag.cycles,
               (unsigned long long)r->submit_diag.vertices,
               (unsigned long long)r->submit_diag.triangles);
        fflush(stdout);
    }
    if(active==r)active=NULL;return ok;
}
