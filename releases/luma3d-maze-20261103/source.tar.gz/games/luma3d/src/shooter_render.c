#include "luma3d_render.h"
#include "luma3d_activities.h"
#include "shooter_art.h"
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>

/* Static illustrations28..31 MiB: scrolling fields;31..32 MiB: artwork.
 * Boss image layer reserves sprite slots for shots. No raster SUBMIT here. */
#define FIELD_BASE (28U<<20)
#define ART_BASE (31U<<20)
static unsigned align32(unsigned n){return (n+31)&~31u;}
static void publish(uint8_t *dst,const uint8_t *src,unsigned bytes){
 uint32_t *d=(uint32_t *)dst;
 for(unsigned i=0;i<bytes/4;i++){uint32_t word;memcpy(&word,src+i*4,4);d[i]=word;}
}
int l3_shooter_art_open(L3Render *r){
 if(r->shooter_ready)return 1;
 unsigned W=r->width*2,H=r->height*2,w=W-272,h=H-96,pitch=align32(w),bytes=pitch*h*2;
 const L3ShooterArt *bg=sh_background+(r->width==400?0:1);if(bg->w!=w||bg->h!=h)return 0;
 if(FIELD_BASE+2*bytes>ART_BASE||sizeof(sh_pixels)>L3_MAP_BYTES-ART_BASE)return 0;
 uint8_t *pixels=calloc(1,bytes*2);if(!pixels)return 0;
 for(unsigned y=0;y<h;y++)for(unsigned x=0;x<w;x++){
  unsigned v=sh_pixels[bg->offset+y*w+x];
  pixels[y*pitch+x]=pixels[(y+h)*pitch+x]=(uint8_t)v;
 }
 for(unsigned i=0;i<84;i++){
  unsigned x=(i*71+17)%w,y=(i*43+29)%h,len=i%11==0?3:1;
  for(unsigned j=0;j<len&&y+j<h;j++)pixels[bytes+(y+j)*pitch+x]=pixels[bytes+(y+j+h)*pitch+x]=(uint8_t)(i%3?228:230);
 }
 publish(r->memory+FIELD_BASE,pixels,2*bytes);free(pixels);
 publish(r->memory+ART_BASE,sh_pixels,sizeof(sh_pixels));
 for(unsigned i=0;i<112;i++)r->hud_palette.rgb[128+i]=sh_palette[i];
 if(!r->host&&ioctl(r->fd,PRODOCK_PALETTE,&r->hud_palette)){r->failed=1;return 0;}
 r->shooter_upload_bytes=2*bytes+sizeof(sh_pixels);r->shooter_ready=1;return 1;
}
static unsigned tiles(const L3ShooterArt *a){return ((a->w+31)/32)*((a->h+31u)/32);}
static int picture(L3Render *r,struct prodock_scene *s,unsigned art,int x,int y,int cosmetic){
 const L3ShooterArt *a=sh_art+art;unsigned cols=(a->w+31)/32,n=tiles(a);
 if(r->sprite_count+n>64){if(cosmetic){r->cosmetic_dropped+=n;return 1;}return 0;}
 for(unsigned ty=0;ty<(a->h+31u)/32;ty++)for(unsigned tx=0;tx<cols;tx++){
  unsigned sw=a->w-tx*32,sh=a->h-ty*32;if(sw>32)sw=32;if(sh>32)sh=32;
  uint32_t *p=s->sprites[r->sprite_count++];p[0]=PRODOCK_GPU_BASE+ART_BASE+a->offset+(ty*cols+tx)*1024;
  p[1]=(uint16_t)(x+(int)tx*32)|((uint32_t)(uint16_t)(y+(int)ty*32)<<16);p[2]=sw|(sh<<8)|(1u<<16)|(2u<<20);
 }return 1;
}
static void image(struct prodock_scene *s,unsigned layer,unsigned art,int x,int y){
 const L3ShooterArt *a=sh_art+art;uint32_t *l=s->layers[layer];
 l[0]=PRODOCK_GPU_BASE+ART_BASE+a->offset;l[1]=a->w|((unsigned)a->h<<16);l[2]=(uint16_t)x|((uint32_t)(uint16_t)y<<16);l[3]=l[1];l[5]=a->pitch;l[6]=3;
}
static int position(int32_t q,unsigned size,unsigned logical){return (int)((int64_t)q*size/(logical*256));}
int l3_shooter_render(L3Render *r,const L3Game *g,struct prodock_scene *s){
 L3ShooterView v;if(!l3_shooter_view(&g->activities.arcade.shooter,&v))return 0;
 unsigned profile=r->width==400?0:1,base=profile*SH_ART_PROFILE,W=r->width*2,H=r->height*2,w=W-272,h=H-96,pitch=align32(w),bytes=pitch*h*2;
 if(!r->shooter_ready)return 0; /* preload completes before the first game image */
 if(v.elapsed_ms<r->shooter_previous.elapsed_ms){memset(r->shooter_bursts,0,sizeof(r->shooter_bursts));memset(&r->shooter_previous,0,sizeof(r->shooter_previous));}
 for(unsigned f=0;f<2;f++){
  unsigned scroll=(unsigned)(((uint64_t)v.elapsed_ms*(f?29:7)/1000)%h);uint32_t *l=s->layers[f];
  l[0]=PRODOCK_GPU_BASE+FIELD_BASE+f*bytes+scroll*pitch;l[1]=w|(h<<16);l[2]=136u|(48u<<16);l[3]=l[1];l[5]=pitch;l[6]=3;
 }
 /* Defeated actor effects are cosmetic, dropped before any gameplay sprite. */
 if(v.kills>r->shooter_previous.kills)for(unsigned i=0;i<r->shooter_previous.actor_count;i++){
  const L3ShooterActor *a=r->shooter_previous.actors+i;if(a->kind<1||a->kind>4)continue;int found=0;
  for(unsigned j=0;j<v.actor_count;j++)if(v.actors[j].id==a->id&&v.actors[j].kind==a->kind){found=1;break;}
  if(!found)for(unsigned j=0;j<8;j++)if(!r->shooter_bursts[j].active){r->shooter_bursts[j].x256=a->x256;r->shooter_bursts[j].y256=a->y256;r->shooter_bursts[j].started=v.elapsed_ms;r->shooter_bursts[j].active=1;break;}
 }
 r->sprite_count=0;r->sprite_limit=64;const L3ShooterActor *player=NULL;
 for(unsigned i=0;i<v.actor_count;i++){
  const L3ShooterActor *a=v.actors+i;if(a->kind<1||a->kind>10)return 0;unsigned art=base+a->kind-1;const L3ShooterArt *im=sh_art+art;
  int x=136+position(a->x256,w,160)-(int)im->w/2,y=48+position(a->y256,h,192)-(int)im->h/2;
  if(a->kind==L3_SHOOTER_BOSS)image(s,2,art,x,y);else if(!picture(r,s,art,x,y,0))return 0;
  if(a->kind==L3_SHOOTER_PLAYER)player=a;
 }
 if(player){
  unsigned flame=base+18+(v.elapsed_ms/70)%3;const L3ShooterArt *im=sh_art+flame;
  int x=136+position(player->x256,w,160),y=48+position(player->y256,h,192);
  if(!picture(r,s,flame,x-im->w/2,y+sh_art[base+9].h/3,1))return 0;
  if(v.shield_ticks){im=sh_art+base+21;if(!picture(r,s,base+21,x-im->w/2,y-im->h/2,1))return 0;}
 }
 for(unsigned i=0;i<8;i++)if(r->shooter_bursts[i].active){
  unsigned age=v.elapsed_ms-r->shooter_bursts[i].started;if(age>=400){r->shooter_bursts[i].active=0;continue;}
  unsigned art=base+10+age/50;const L3ShooterArt *im=sh_art+art;
  if(!picture(r,s,art,136+position(r->shooter_bursts[i].x256,w,160)-im->w/2,48+position(r->shooter_bursts[i].y256,h,192)-im->h/2,1))return 0;
 }
 r->shooter_previous=v;s->layers_enabled=s->sprites_enabled=1;return 1;
}
