#include "l3_puzzle_gpu.h"
#include <string.h>

int l3_puzzle_gpu_layout(unsigned w,unsigned h,unsigned kind,L3PuzzleLayout *out)
{
    if(!out || !((w==800 && h==480)||(w==1280 && h==720)) ||
       (kind!=L3_MINI_MERGE1024 && kind!=L3_MINI_BLOCKS))return 0;
    unsigned scale=h==720?3:2,top=86*scale/2,bottom=h-54*scale/2;
    unsigned right=w-244*scale/2,area=right-42*scale/2;
    unsigned cols=kind==L3_MINI_BLOCKS?8:4,rows=kind==L3_MINI_BLOCKS?14:4;
    unsigned cell=(bottom-top-14*scale/2)/rows,other=(area-42*scale/2)/cols;
    if(other<cell)cell=other;
    L3PuzzleLayout l={0};l.native_width=w;l.native_height=h;l.cell=cell;
    l.board_width=cell*cols;l.board_height=cell*rows;
    l.board_x=22*scale/2+(area-l.board_width)/2;l.board_y=top+(bottom-top-l.board_height)/2;
    l.window_x=(l.board_x-8)&~15u;l.window_y=l.board_y-8;
    l.window_width=l.board_x+l.board_width+8-l.window_x;l.window_height=l.board_height+16;
    if(l.window_width>1024 || l.window_height>512 || l.window_x+l.window_width>w || l.window_y+l.window_height>h)return 0;
    *out=l;return 1;
}
static int quad(gpu_v1_context *gpu,int x,int y,int w,int h,unsigned u,unsigned v,unsigned tw,unsigned th)
{
    gpu_vertex a[4]={{0}};
    a[0].x=x;a[0].y=y;a[1].x=x+w;a[1].y=y;a[2].x=x+w;a[2].y=y+h;a[3].x=x;a[3].y=y+h;
    a[0].u=a[3].u=(int)u;a[1].u=a[2].u=(int)(u+tw);a[0].v=a[1].v=(int)v;a[2].v=a[3].v=(int)(v+th);
    for(unsigned i=0;i<4;i++){a[i].q=65536;a[i].r=a[i].g=a[i].b=256;}
    return gpu_v1_quad(gpu,a);
}
static unsigned body_index(const L3MiniView *v,const L3MotionPose *p)
{
    if(v->kind==L3_MINI_BLOCKS)return p->color%8u+(p->active?8u:0u);
    unsigned value=p->value,index=0;while(value>2){value>>=1;index++;}return index;
}
static int material(gpu_v1_context *gpu,unsigned flags,unsigned alpha)
{
    gpu_material m={0};m.flags=(uint16_t)flags;m.alpha=(uint16_t)alpha;m.r=m.g=m.b=256;
    return gpu_v1_material(gpu,&m);
}
static int static_frame(const L3MiniView *v,L3MotionFrame *f)
{
    unsigned active[4],n=0;
    *f=(L3MotionFrame){0};f->logical=*v;
    for(unsigned y=0;y<v->height;y++)for(unsigned x=0;x<v->width;x++){
        const L3MiniCell *c=&v->cells[y*20+x];
        if(c->kind!=L3_MINI_CELL_NUMBER && c->kind!=L3_MINI_CELL_BLOCK)continue;
        if(f->count==L3_MOTION_POSES)return 0;
        L3MotionPose *p=&f->poses[f->count++];p->x_q16=(int32_t)x*65536;p->y_q16=(int32_t)y*65536;
        p->value=c->value;p->color=c->color;p->alpha_q8=p->scale_q8=256;p->active=!!(c->flags&L3_MINI_FLAG_ACTIVE);
        if(p->active){if(n==4)return 0;active[n++]=y*20+x;}
    }
    if(v->kind==L3_MINI_BLOCKS && n==4){
        unsigned drop=0;
        for(unsigned d=1;d<14;d++){
            int fit=1;for(unsigned i=0;i<4;i++){
                unsigned q=active[i]+d*20;if(q/20>=14){fit=0;break;}
                const L3MiniCell *c=&v->cells[q];if(c->kind==L3_MINI_CELL_BLOCK && !(c->flags&L3_MINI_FLAG_ACTIVE)){fit=0;break;}
            }
            if(!fit)break;
            drop=d;
        }
        if(drop)for(unsigned i=0;i<4;i++){
            if(f->count==L3_MOTION_POSES)return 0;
            L3MotionPose *p=&f->poses[f->count++];p->x_q16=(int32_t)(active[i]%20)*65536;p->y_q16=(int32_t)(active[i]/20+drop)*65536;
            p->color=v->cells[active[i]].color;p->alpha_q8=80;p->scale_q8=256;p->kind=L3_MOTION_GHOST;
        }
    }
    return 1;
}
/* This candidate owns 14..15MiB; draws may never alias immutable assets. */
static int span(uint32_t base,unsigned stride,unsigned height,uint32_t low,uint32_t high)
{return !(base&31u) && !(stride&31u) && stride && height && base>=low && (uint64_t)base+(uint64_t)stride*height<=high;}
static int apart(uint32_t a,unsigned an,uint32_t b,unsigned bn)
{return (uint64_t)a+an<=b || (uint64_t)b+bn<=a;}
static int texture_ok(const gpu_texture_level *t)
{return t->width && t->width<=512 && t->height && t->height<=512 && t->stride>=t->width*2 &&
        !t->u_mode && !t->v_mode && !t->lod && span(t->base,t->stride,t->height,0x01600000u,0x01700000u);}
int l3_puzzle_gpu_draw(gpu_v1_context *gpu,const L3PuzzleLayout *l,const L3PuzzleGpuAssets *a,
                       const L3MotionFrame *input,uint32_t page,uint32_t depth,unsigned pitch,L3PuzzleGpuStats *stats)
{
    if(!gpu || !gpu->emit || !l || !a || !input || !stats || pitch!=l->native_width*2 ||
       a->body_width!=l->cell || a->body_height<l->cell || a->body_height>l->cell+1 ||
       a->bodies.format!=GPU_RGB565 || a->shadow.format!=GPU_ARGB4444 ||
       a->background.width!=l->window_width || a->background.height!=l->window_height)return 0;
    L3PuzzleLayout checked;
    if(!l3_puzzle_gpu_layout(l->native_width,l->native_height,input->logical.kind,&checked) || memcmp(l,&checked,sizeof(checked)))return 0;
    unsigned cols=input->logical.kind==L3_MINI_BLOCKS?8:4,rows=input->logical.kind==L3_MINI_BLOCKS?14:4;
    if(input->logical.width!=cols || input->logical.height!=rows ||
       !span(page,pitch,l->native_height,0x00800000u,0x01600000u) ||
       !span(depth,pitch,l->native_height,0x00800000u,0x01600000u) ||
       !apart(page,pitch*l->native_height,depth,pitch*l->native_height))return 0;
    if(a->background.stride<a->background.width*2 ||
       !span(a->background.color,a->background.stride,a->background.height,0x01600000u,0x01700000u) ||
       !texture_ok(&a->bodies) || !texture_ok(&a->shadow) ||
       a->body_width>a->bodies.width || a->body_height>a->bodies.height)return 0;
    L3MotionFrame static_view;const L3MotionFrame *f=input;
    if(input->settled){if(!static_frame(&input->logical,&static_view))return 0;f=&static_view;}
    if(f->count>L3_MOTION_POSES)return 0;
    for(unsigned i=0;i<f->count;i++){
        const L3MotionPose *p=&f->poses[i];unsigned idx=body_index(&f->logical,p);
        if(idx>=16 || p->alpha_q8>256 || !p->scale_q8 || p->scale_q8>288 || p->x_q16<0 || p->y_q16<0 ||
           p->x_q16>20*65536 || p->y_q16>20*65536 || a->uv_x[idx]>a->bodies.width-a->body_width || a->uv_y[idx]>a->bodies.height-a->body_height)return 0;
    }
    memset(stats,0,sizeof(*stats));uint32_t offset=l->window_y*pitch+l->window_x*2;
    gpu_target target={page+offset,depth+offset,(uint16_t)l->window_width,(uint16_t)l->window_height,(uint16_t)pitch,(uint16_t)pitch};
    if(!gpu_v1_target(gpu,&target)||!gpu_v1_scissor(gpu,0,0,l->window_width,l->window_height)||
       !gpu_v1_copy(gpu,&a->background,0,0,0,0,l->window_width,l->window_height))return 0;
    stats->copy_pixels=l->window_width*l->window_height;
    for(unsigned pass=0;pass<2;pass++){
        if(!gpu_v1_texture(gpu,pass?&a->bodies:&a->shadow))return 0;
        unsigned previous=~0u;
        for(unsigned i=0;i<f->count;i++){
            const L3MotionPose *p=&f->poses[i];if(!p->alpha_q8 || (!pass && p->kind==L3_MOTION_GHOST))continue;
            unsigned alpha=pass?p->alpha_q8:(p->alpha_q8*112u)/256u;
            if(alpha!=previous){if(!material(gpu,pass?9:1,alpha))return 0;previous=alpha;}
            int size=(int)(l->cell*p->scale_q8+128)/256;
            int x=(int)(l->board_x-l->window_x)+(int)(((int64_t)p->x_q16*l->cell+32768)/65536)+((int)l->cell-size)/2;
            int y=(int)(l->board_y-l->window_y)+(int)(((int64_t)p->y_q16*l->cell+32768)/65536)+((int)l->cell-size)/2;
            if(pass){
                unsigned idx=body_index(&f->logical,p);
                if(!quad(gpu,x,y,size,size,a->uv_x[idx],a->uv_y[idx],a->body_width,l->cell))return 0;
                stats->body_quads++;
            }else{
                if(!quad(gpu,x-3,y+1,size+6,size+6,0,0,a->shadow.width,a->shadow.height))return 0;
                stats->shadow_quads++;
            }
            stats->quads++;
        }
    }
    return 1;
}
