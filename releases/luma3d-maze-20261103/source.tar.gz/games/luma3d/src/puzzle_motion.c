#include "l3_puzzle_motion.h"
#include <math.h>
#include <string.h>

static int view_ok(const L3MiniView *v)
{
    if(!v || !v->width || !v->height || v->width>20 || v->height>20 ||
       v->kind>=L3_MINI_KIND_COUNT || v->status>L3_MINI_LOST)return 0;
    if(v->kind==L3_MINI_MERGE1024 && (v->width!=4 || v->height!=4))return 0;
    if(v->kind==L3_MINI_BLOCKS && (v->width!=8 || v->height!=14))return 0;
    unsigned active=0;
    for(unsigned i=0;i<400;i++){
        if(v->cells[i].kind>L3_MINI_CELL_FINISH)return 0;
        if(v->kind==L3_MINI_BLOCKS && (v->cells[i].flags&L3_MINI_FLAG_ACTIVE)){
            if(i%20>=8 || i/20>=14 || v->cells[i].kind!=L3_MINI_CELL_BLOCK)return 0;
            active++;
        }
    }
    if(v->kind==L3_MINI_BLOCKS && (v->status==L3_MINI_RUNNING?active!=4:active!=0))return 0;
    return 1;
}
static int equal(const L3MiniView *a,const L3MiniView *b)
{
    return a->kind==b->kind && a->status==b->status && a->score==b->score &&
           a->moves==b->moves && a->width==b->width && a->height==b->height &&
           a->progress==b->progress && !memcmp(a->cells,b->cells,sizeof(a->cells));
}
static void snap(L3PuzzleMotion *m,const L3MiniView *v,double now,uint32_t epoch)
{
    m->head=m->count=0;m->valid=1;m->epoch=epoch;m->last_time=now;
    m->latest=m->settled=*v;
}
void l3_puzzle_motion_reset(L3PuzzleMotion *m){if(m)memset(m,0,sizeof(*m));}
static void retire(L3PuzzleMotion *m,double now)
{
    while(m->count){
        L3MotionEvent *e=&m->queue[m->head];
        if(now<e->start+(double)e->duration_ms/1000.0)break;
        m->settled=e->after;m->head=(m->head+1)%L3_MOTION_QUEUE;m->count--;
    }
}
static L3MotionTrack *track(L3MotionEvent *e,unsigned q,unsigned dest,
                            const L3MiniCell *cell,unsigned kind)
{
    if(e->count==L3_MOTION_TRACKS)return NULL;
    L3MotionTrack *t=&e->tracks[e->count++];memset(t,0,sizeof(*t));
    t->from_x=(int16_t)(q%20);t->from_y=(int16_t)(q/20);
    t->via_x=t->from_x;t->via_y=t->from_y;
    t->to_x=(int16_t)(dest%20);t->to_y=(int16_t)(dest/20);
    t->value=t->result_value=cell->value;t->color=t->result_color=cell->color;
    t->kind=(uint8_t)kind;t->active=!!(cell->flags&L3_MINI_FLAG_ACTIVE);
    return t;
}
static unsigned index_dir(unsigned d,unsigned line,unsigned p)
{
    return d==0?p*20+line:d==1?line*20+3-p:d==2?(3-p)*20+line:line*20+p;
}
static int merge_plan(L3MotionEvent *e,uint32_t pressed)
{
    static const unsigned keys[4]={L3_MINI_UP,L3_MINI_RIGHT,L3_MINI_DOWN,L3_MINI_LEFT};
    unsigned d=0,expected[400]={0},score=0,spawns=0;
    const L3MiniView *a=&e->before,*b=&e->after;
    while(d<4 && !(pressed&keys[d]))d++;
    if(d==4 || b->moves!=a->moves+1u)return 0;
    for(unsigned line=0;line<4;line++){
        unsigned packed[4],n=0,k=0;
        for(unsigned p=0;p<4;p++){
            unsigned q=index_dir(d,line,p),v=a->cells[q].value;
            if(v){if(a->cells[q].kind!=L3_MINI_CELL_NUMBER || v<2 || v>1024 || (v&(v-1)))return 0;packed[n++]=q;}
        }
        for(unsigned i=0;i<n;){
            unsigned q=packed[i++],dest=index_dir(d,line,k++),v=a->cells[q].value;
            int merge=i<n && a->cells[packed[i]].value==v;
            L3MotionTrack *t=track(e,q,dest,&a->cells[q],merge?L3_MOTION_MERGE:q==dest?L3_MOTION_KEEP:L3_MOTION_SLIDE);
            if(!t)return 0;
            if(merge){
                unsigned other=packed[i++];v*=2;
                t->active=2; /* primary result of this two-source merge */
                L3MotionTrack *u=track(e,other,dest,&a->cells[other],L3_MOTION_MERGE);
                if(!u)return 0;
                t->result_value=u->result_value=(uint16_t)v;
                t->result_color=u->result_color=b->cells[dest].color;score+=v;
            }
            expected[dest]=v;
        }
    }
    for(unsigned y=0;y<4;y++)for(unsigned x=0;x<4;x++){
        unsigned q=y*20+x,v=b->cells[q].value;
        if(expected[q]){if(v!=expected[q] || b->cells[q].kind!=L3_MINI_CELL_NUMBER)return 0;}
        else if(v){
            if((v!=2 && v!=4) || b->cells[q].kind!=L3_MINI_CELL_NUMBER || ++spawns!=1)return 0;
            if(!track(e,q,q,&b->cells[q],L3_MOTION_SPAWN))return 0;
        }
    }
    if(spawns!=1 || b->score-a->score!=score)return 0;
    e->kind=L3_MOTION_EVENT_MERGE;e->duration_ms=160;return 1;
}
static unsigned active_cells(const L3MiniView *v,unsigned out[4])
{
    unsigned n=0;
    for(unsigned y=0;y<v->height;y++)for(unsigned x=0;x<v->width;x++){
        unsigned q=y*20+x;
        if(v->cells[q].flags&L3_MINI_FLAG_ACTIVE){if(n==4)return 5;out[n++]=q;}
    }
    return n;
}
static int solid(const L3MiniCell *c)
{return c->kind==L3_MINI_CELL_BLOCK && !(c->flags&L3_MINI_FLAG_ACTIVE);}
static int same_static(const L3MiniView *a,const L3MiniView *b)
{
    for(unsigned y=0;y<14;y++)for(unsigned x=0;x<8;x++){
        unsigned q=y*20+x;
        if(solid(&a->cells[q])!=solid(&b->cells[q]))return 0;
        if(solid(&a->cells[q]) && a->cells[q].color!=b->cells[q].color)return 0;
    }
    return 1;
}
static unsigned ghost_distance(const L3MiniView *v,const unsigned cells[4])
{
    unsigned d=0;
    for(unsigned next=1;next<14;next++){
        int fit=1;
        for(unsigned i=0;i<4;i++){
            unsigned q=cells[i]+next*20;
            if(q/20>=14 || solid(&v->cells[q])){fit=0;break;}
        }
        if(!fit)break;
        d=next;
    }
    return d;
}
static int positions_fit(const L3MiniView *v,const int x[4],const int y[4],unsigned out[4])
{
    for(unsigned i=0;i<4;i++){
        if(x[i]<0 || x[i]>=8 || y[i]<0 || y[i]>=14)return 0;
        unsigned q=(unsigned)y[i]*20+(unsigned)x[i];
        if(solid(&v->cells[q]))return 0;
        for(unsigned j=0;j<i;j++)if(out[j]==q)return 0;
        out[i]=q;
    }
    return 1;
}
static void commanded_positions(const L3MiniView *v,const unsigned original[4],uint32_t pressed,unsigned out[4])
{
    static const unsigned keys[4]={L3_MINI_UP,L3_MINI_RIGHT,L3_MINI_DOWN,L3_MINI_LEFT};
    unsigned d=0,candidate[4];int x[4],y[4];
    memcpy(out,original,4*sizeof(*out));
    while(d<4 && !(pressed&keys[d]))d++;
    if(d==1 || d==3){
        for(unsigned i=0;i<4;i++){x[i]=(int)(out[i]%20)+(d==1?1:-1);y[i]=(int)(out[i]/20);}
        if(positions_fit(v,x,y,candidate))memcpy(out,candidate,sizeof(candidate));
    }
    if(d==0 || (pressed&L3_MINI_ROTATE)){
        int cx=99,cy=99,max_y=0;
        for(unsigned i=0;i<4;i++){if((int)(out[i]%20)<cx)cx=(int)(out[i]%20);if((int)(out[i]/20)<cy)cy=(int)(out[i]/20);}
        for(unsigned i=0;i<4;i++)if((int)(out[i]/20)-cy>max_y)max_y=(int)(out[i]/20)-cy;
        for(int kick=0;kick>=-2;kick--){
            for(unsigned i=0;i<4;i++){
                x[i]=cx+kick+max_y-((int)(out[i]/20)-cy);
                y[i]=cy+(int)(out[i]%20)-cx;
            }
            if(positions_fit(v,x,y,candidate)){memcpy(out,candidate,sizeof(candidate));break;}
        }
    }
}
static int block_plan(L3MotionEvent *e,uint32_t pressed)
{
    const L3MiniView *a=&e->before,*b=&e->after;
    unsigned ac[4],bc[4],an=active_cells(a,ac),bn=active_cells(b,bc);
    if(an!=4 || bn>4 || (bn!=4 && b->status==L3_MINI_RUNNING))return 0;
    if(a->moves==b->moves && same_static(a,b) && bn==4){
        int dx=b->cursor_x-a->cursor_x,dy=b->cursor_y-a->cursor_y;
        unsigned map[4]={0},used=0;
        /* Exact translations first. Rotations use the unique four endpoints
         * supplied by the actual engine, with a minimum-distance assignment. */
        int translation=1;
        for(unsigned i=0;i<4;i++){
            int dest=(int)ac[i]+dy*20+dx;unsigned j=0;
            while(j<4 && (int)bc[j]!=dest)j++;
            if(j==4){translation=0;break;}map[i]=j;
        }
        if(!translation){
            unsigned best=~0u;
            for(unsigned p=0;p<256;p++){
                unsigned mask=0,cost=0;int valid=1;
                for(unsigned i=0;i<4;i++){
                    unsigned j=(p>>(i*2))&3u;
                    if(mask&(1u<<j)){valid=0;break;}mask|=1u<<j;
                    int xx=(int)(ac[i]%20)-(int)(bc[j]%20),yy=(int)(ac[i]/20)-(int)(bc[j]/20);
                    cost+=(unsigned)(xx*xx+yy*yy);
                }
                if(valid && cost<best){best=cost;for(unsigned i=0;i<4;i++)map[i]=(p>>(i*2))&3u;}
            }
        }
        for(unsigned y=0;y<14;y++)for(unsigned x=0;x<8;x++){
            unsigned q=y*20+x;
            if(solid(&a->cells[q]) && !track(e,q,q,&a->cells[q],L3_MOTION_KEEP))return 0;
        }
        for(unsigned i=0;i<4;i++){
            if((used&(1u<<map[i])) || a->cells[ac[i]].color!=b->cells[bc[map[i]]].color)return 0;
            used|=1u<<map[i];
            if(!track(e,ac[i],bc[map[i]],&a->cells[ac[i]],L3_MOTION_SLIDE))return 0;
        }
        e->kind=L3_MOTION_EVENT_PIECE;e->duration_ms=75;return 1;
    }
    if(b->moves!=a->moves+1u)return 0;
    /* Apply only observed geometric input, then verify every settled cell
     * against the real after view. No RNG, scoring, time or engine writes. */
    unsigned positioned[4];commanded_positions(a,ac,pressed,positioned);
    uint8_t board[280]={0};unsigned drop=ghost_distance(a,positioned),cleared[14]={0},lines=0;
    for(unsigned y=0;y<14;y++)for(unsigned x=0;x<8;x++){
        unsigned q=y*20+x;if(solid(&a->cells[q]))board[q]=a->cells[q].color;
    }
    for(unsigned i=0;i<4;i++)board[positioned[i]+20*drop]=a->cells[ac[i]].color;
    for(unsigned y=0;y<14;y++){
        int full=1;for(unsigned x=0;x<8;x++)if(!board[y*20+x])full=0;
        cleared[y]=(unsigned)full;lines+=(unsigned)full;
    }
    if(b->progress<a->progress || lines!=(unsigned)(b->progress-a->progress))return 0;
    int dest_y=13;
    for(int y=13;y>=0;y--){
        if(cleared[y])continue;
        for(unsigned x=0;x<8;x++){
            unsigned q=(unsigned)y*20+x,dest=(unsigned)dest_y*20+x;
            if(board[q]!=(solid(&b->cells[dest])?b->cells[dest].color:0))return 0;
        }
        dest_y--;
    }
    for(;dest_y>=0;dest_y--)for(unsigned x=0;x<8;x++)if(solid(&b->cells[(unsigned)dest_y*20+x]))return 0;
    for(unsigned y=0;y<14;y++)for(unsigned x=0;x<8;x++){
        unsigned q=y*20+x;if(!board[q])continue;
        unsigned below=0;for(unsigned yy=y+1;yy<14;yy++)below+=cleared[yy];
        unsigned src=q;const L3MiniCell *cell=&a->cells[q];
        for(unsigned i=0;i<4;i++)if(positioned[i]+20*drop==q){src=ac[i];cell=&a->cells[src];break;}
        L3MotionTrack *t=track(e,src,q+20*below,cell,cleared[y]?L3_MOTION_CLEAR:L3_MOTION_SLIDE);
        if(!t)return 0;
        t->via_x=(int16_t)x;t->via_y=(int16_t)y;
    }
    for(unsigned i=0;i<bn;i++)if(!track(e,bc[i],bc[i],&b->cells[bc[i]],L3_MOTION_SPAWN))return 0;
    e->kind=L3_MOTION_EVENT_LOCK;e->duration_ms=lines?220:110;return 1;
}
int l3_puzzle_motion_observe(L3PuzzleMotion *m,const L3MiniView *before,const L3MiniView *after,
                            uint32_t pressed,uint32_t held,double now,uint32_t epoch)
{
    if(!m || !view_ok(before) || !view_ok(after) || !isfinite(now) || now<0 ||
       ((pressed|held)&~L3_MINI_INPUT_MASK) || (m->valid && now<m->last_time))return L3_MOTION_INVALID;
    m->observations++;retire(m,now);m->last_time=now;
    if(!m->valid || m->epoch!=epoch){snap(m,after,now,epoch);return L3_MOTION_SNAPPED;}
    if(!equal(&m->latest,before)){
        m->discontinuities++;snap(m,after,now,epoch);return L3_MOTION_SNAPPED;
    }
    if(equal(before,after)){m->latest=*after;return L3_MOTION_UNCHANGED;}
    if(m->count==L3_MOTION_QUEUE){m->overflows++;snap(m,after,now,epoch);return L3_MOTION_SNAPPED;}
    L3MotionEvent *e=&m->queue[(m->head+m->count)%L3_MOTION_QUEUE];memset(e,0,sizeof(*e));
    e->before=*before;e->after=*after;
    int valid=before->kind==after->kind && (after->kind==L3_MINI_MERGE1024?merge_plan(e,pressed):after->kind==L3_MINI_BLOCKS?block_plan(e,pressed):0);
    if(!valid){m->unsupported++;snap(m,after,now,epoch);return L3_MOTION_SNAPPED;}
    e->start=now;
    if(m->count){L3MotionEvent *prev=&m->queue[(m->head+m->count-1)%L3_MOTION_QUEUE];e->start=prev->start+(double)prev->duration_ms/1000.0;}
    m->latest=*after;m->count++;m->events++;return L3_MOTION_ANIMATED;
}
static unsigned fraction(double elapsed,unsigned start,unsigned duration)
{
    double p=(elapsed*1000.0-start)/(double)duration;
    return p<=0?0:p>=1?65536u:(unsigned)(p*65536.0);
}
static unsigned easing(unsigned p)
{return (unsigned)(((uint64_t)p*p*(196608u-2u*p))>>32);}
static int32_t lerp(int a,int b,unsigned p)
{return a*65536+(int32_t)(((int64_t)b-a)*(int64_t)p);}
static int add_pose(L3MotionFrame *f,const L3MotionTrack *t,unsigned p,unsigned alpha,
                    unsigned scale,unsigned result,int via)
{
    if(f->count==L3_MOTION_POSES)return 0;
    L3MotionPose *o=&f->poses[f->count++];memset(o,0,sizeof(*o));
    o->x_q16=lerp(via?t->via_x:t->from_x,t->to_x,p);
    o->y_q16=lerp(via?t->via_y:t->from_y,t->to_y,p);
    o->value=result?t->result_value:t->value;o->color=result?t->result_color:t->color;
    o->kind=t->kind;o->active=t->active&1u;o->alpha_q8=(uint16_t)alpha;o->scale_q8=(uint16_t)scale;return 1;
}
int l3_puzzle_motion_sample(L3PuzzleMotion *m,double now,L3MotionFrame *f)
{
    if(!m || !f || !m->valid || !isfinite(now) || now<m->last_time)return 0;
    retire(m,now);m->last_time=now;memset(f,0,sizeof(*f));
    if(!m->count){f->logical=m->latest;f->settled=1;f->progress_q16=65536;return 1;}
    L3MotionEvent *e=&m->queue[m->head];double elapsed=now-e->start;
    f->logical=e->after;f->event_kind=e->kind;f->progress_q16=fraction(elapsed,0,e->duration_ms);
    for(unsigned i=0;i<e->count;i++){
        L3MotionTrack *t=&e->tracks[i];unsigned alpha=256,scale=256,result=0,p=65536;int via=0;
        if(e->kind==L3_MOTION_EVENT_MERGE){
            p=easing(fraction(elapsed,0,100));
            if(t->kind==L3_MOTION_MERGE && p==65536){
                if(!(t->active&2u))continue;
                result=1;
                unsigned pulse=fraction(elapsed,100,60);scale=256+(pulse<32768?pulse:65536-pulse)/1024;
            }
            if(t->kind==L3_MOTION_SPAWN){alpha=fraction(elapsed,100,60)>>8;scale=192+alpha/4;}
        }else if(e->kind==L3_MOTION_EVENT_PIECE)p=easing(fraction(elapsed,0,75));
        else{
            unsigned land=easing(fraction(elapsed,0,70));
            if(land<65536){
                L3MotionTrack tmp=*t;tmp.to_x=t->via_x;tmp.to_y=t->via_y;
                if(t->kind==L3_MOTION_SPAWN)alpha=0;
                if(!add_pose(f,&tmp,land,alpha,scale,result,0))return 0;
                continue;
            }
            via=1;p=easing(fraction(elapsed,110,e->duration_ms>110?e->duration_ms-110:1));
            if(t->kind==L3_MOTION_CLEAR)alpha=256-(fraction(elapsed,70,70)>>8);
            if(t->kind==L3_MOTION_SPAWN)alpha=fraction(elapsed,e->duration_ms>110?150:70,40)>>8;
        }
        if(!add_pose(f,t,p,alpha,scale,result,via))return 0;
    }
    if(e->after.kind==L3_MINI_BLOCKS){
        unsigned cells[4];if(active_cells(&e->after,cells)==4){unsigned drop=ghost_distance(&e->after,cells);
            unsigned old_cells[4],old_drop=active_cells(&e->before,old_cells)==4?ghost_distance(&e->before,old_cells):0;
            if(drop)for(unsigned i=0;i<4;i++){
                L3MotionTrack t;memset(&t,0,sizeof(t));t.to_x=(int16_t)(cells[i]%20);t.to_y=(int16_t)(cells[i]/20+drop);
                t.color=e->after.cells[cells[i]].color;t.kind=L3_MOTION_GHOST;
                unsigned p=65536,alpha=80;
                if(e->kind==L3_MOTION_EVENT_PIECE){
                    for(unsigned j=0;j<e->count;j++){
                        const L3MotionTrack *src=e->tracks+j;
                        if(src->active && src->to_x==t.to_x && src->to_y==(int16_t)(cells[i]/20)){
                            t.from_x=src->from_x;t.from_y=(int16_t)(src->from_y+(int)old_drop);break;
                        }
                    }
                    p=easing(fraction(elapsed,0,75));
                }else alpha=(80*fraction(elapsed,e->duration_ms>110?150:70,40))>>16;
                if(!add_pose(f,&t,p,alpha,256,0,0))return 0;
            }
        }
    }
    return 1;
}
