#include "luma3d_surface.h"
#include <math.h>
#include <stdint.h>
#include "surface_data.h"
static int sample(const SurfaceTriangle *t,float x,float z,float *y) {
 float dx=x-t->x,dz=z-t->z,u=dx*t->ux+dz*t->uz,v=dx*t->vx+dz*t->vz;
 /* Only floating-point edge roundoff is tolerated; at an edge either face
  * represents the same surface. The independent test checks all shared edges. */
 if(u < -0.000001f||v < -0.000001f||u+v > 1.000001f)return 0;
 *y=t->y+u*t->dyu+v*t->dyv;return 1;
}
float l3_surface_ground(float x,float z) {
 if(!isfinite(x)||!isfinite(z))return NAN;
 x=fminf(160,fmaxf(0,x));z=fminf(160,fmaxf(0,z));
 unsigned ix=(unsigned)(x*.5f),iz=(unsigned)(z*.5f);if(ix==80)ix=79;if(iz==80)iz=79;
 unsigned b=iz*80+ix;float y;
 for(unsigned i=surface_offsets[b];i<surface_offsets[b+1];i++)
  if(sample(&surface_triangles[surface_indices[i]],x,z,&y))return y;
 return NAN; /* A malformed/uncovered surface must fail closed in game.c. */
}
int l3_surface_bridge(float x,float z,float radius,float *deck) {
 if(!isfinite(x)||!isfinite(z)||!isfinite(radius)||radius<0||!deck)return 0;
 if(x<107||x>121||fabsf(z-65)>1.5f-radius)return 0;
 for(unsigned i=0;i<sizeof(bridge_triangles)/sizeof(*bridge_triangles);i++)
  if(sample(&bridge_triangles[i],x,z,deck))return 1;
 return 0;
}
int l3_surface_near(unsigned instance,float x,float z) {
 if(instance>=sizeof(surface_bounds)/sizeof(*surface_bounds)||!surface_bounds[instance].valid)return 0;
 const SurfaceBounds *b=&surface_bounds[instance];
 float dx=fmaxf(b->x0-x,fmaxf(0,x-b->x1)),dz=fmaxf(b->z0-z,fmaxf(0,z-b->z1));
 return dx*dx+dz*dz<=3.05f*3.05f;
}
