#include "luma3d_activity_observer.h"
#include <math.h>
#include <string.h>
static struct {const L3Game *game;L3ActivityObserver callback;void *context;
 unsigned mask,valid,has_time,busy;double seconds;uint32_t epoch;} binding;
void l3_activity_observer_bind(const L3Game *game,unsigned mask,L3ActivityObserver callback,void *context){
 if(!game||!callback){memset(&binding,0,sizeof binding);return;}
 if(binding.game!=game||binding.callback!=callback||binding.context!=context){memset(&binding,0,sizeof binding);}
 binding.game=game;binding.callback=callback;binding.context=context;binding.mask=mask&255u;
}
int l3_activity_observer_clock(double seconds,uint32_t epoch){
 if(!isfinite(seconds)||seconds<0){binding.valid=0;return 0;}
 if(binding.has_time&&epoch==binding.epoch&&seconds<binding.seconds){binding.valid=0;return 0;}
 binding.seconds=seconds;binding.epoch=epoch;binding.valid=binding.has_time=1;return 1;
}
int l3_activity_observer_wants(const L3Game *game){
 if(!binding.callback||!binding.valid||binding.busy||game!=binding.game)return 0;
 unsigned active=game->activities.arcade.active;
 return active>0&&active<=8&&!!(binding.mask&(1u<<(active-1)));
}
void l3_activity_observer_emit(const L3Game *game,const L3ArcadeView *before,const L3ArcadeView *after,uint32_t pressed,uint32_t held,const L3MiniTrace *trace){
 /* Exit may have cleared active; the caller already checked before the step. */
 if(game!=binding.game||!binding.callback||!binding.valid||binding.busy)return;
 binding.busy=1;binding.callback(binding.context,before,after,pressed,held,trace,binding.seconds,binding.epoch);binding.busy=0;
}
