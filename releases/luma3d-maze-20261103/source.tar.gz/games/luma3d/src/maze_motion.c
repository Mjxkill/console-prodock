#include "l3_maze_motion.h"
#include <math.h>
#include <string.h>
#include <stdlib.h>
static void settle(L3MazeTrack *t,unsigned x,unsigned y){
 memset(t,0,sizeof *t);t->settled_x=t->logical_x=(uint16_t)x;t->settled_y=t->logical_y=(uint16_t)y;
}
static void retire(L3MazeTrack *t,double time){
 while(t->count){const L3MazeSegment *s=t->segments+t->head;if(time<s->end)break;
  t->settled_x=s->x1;t->settled_y=s->y1;t->head=(t->head+1)%L3_MAZE_SEGMENTS;t->count--;
 }
}
static int open_cell(const L3MiniView *v,unsigned x,unsigned y){
 if(x%256!=128||y%256!=128)return 0;x/=256;y/=256;
 return x<v->width&&y<v->height&&v->cells[y*20+x].kind!=L3_MINI_CELL_WALL;
}
void l3_maze_motion_reset(L3MazeMotion *m){if(m)memset(m,0,sizeof *m);}
int l3_maze_motion_observe_trace(L3MazeMotion *m,const L3MiniView *v,const L3MiniActors *a,double time,uint32_t epoch,unsigned warp){
 if(warp>7||!m||!v||!a||!isfinite(time)||time<0||v->kind!=L3_MINI_MAZE||v->width>20||v->height>20||a->count!=3)return 0;
 for(unsigned i=0;i<3;i++)if(!open_cell(v,a->actors[i].x256,a->actors[i].y256))return 0;
 if(m->valid&&m->epoch==epoch&&time<m->time)return 0;
 int reset=!m->valid||m->epoch!=epoch||a->respawn_ticks>m->latest.respawn_ticks;
 if(reset){for(unsigned i=0;i<3;i++)settle(m->actor+i,a->actors[i].x256,a->actors[i].y256);m->resets++;}
 else for(unsigned i=0;i<3;i++){
  L3MazeTrack *t=m->actor+i;const L3MiniActor *p=a->actors+i;retire(t,time);
  if(warp&(1u<<i)){settle(t,p->x256,p->y256);m->teleports++;continue;}
  int dx=(int)p->x256-t->logical_x,dy=(int)p->y256-t->logical_y;
  if(!dx&&!dy)continue;
  if(abs(dx)+abs(dy)!=256||!open_cell(v,t->logical_x,t->logical_y)){
   settle(t,p->x256,p->y256);m->teleports++;continue;
  }
  if(t->count==L3_MAZE_SEGMENTS){settle(t,p->x256,p->y256);m->overflows++;continue;}
  unsigned tail=(t->head+t->count)%L3_MAZE_SEGMENTS;double start=time;
  if(t->count){double end=t->segments[(tail+L3_MAZE_SEGMENTS-1)%L3_MAZE_SEGMENTS].end;if(end>start)start=end;}
  t->segments[tail]=(L3MazeSegment){start,start+(i?14.:6.)/60.,t->logical_x,t->logical_y,p->x256,p->y256};
  t->logical_x=p->x256;t->logical_y=p->y256;t->count++;m->moves++;
 }
 m->latest=*a;m->time=time;m->epoch=epoch;m->valid=1;return 1;
}
int l3_maze_motion_sample(const L3MazeMotion *m,double time,L3MiniActors *out){
 if(!m||!out||!m->valid||!isfinite(time)||time<m->time)return 0;
 L3MiniActors a=m->latest;
 for(unsigned i=0;i<3;i++){
  const L3MazeTrack *t=m->actor+i;double x=t->settled_x,y=t->settled_y;
  for(unsigned j=0;j<t->count;j++){
   const L3MazeSegment *s=t->segments+(t->head+j)%L3_MAZE_SEGMENTS;
   if(time>=s->end){x=s->x1;y=s->y1;continue;}
   double p=time<=s->start?0:(time-s->start)/(s->end-s->start);
   x=s->x0+(s->x1-s->x0)*p;y=s->y0+(s->y1-s->y0)*p;break;
  }
  a.actors[i].x256=(uint16_t)lround(x);a.actors[i].y256=(uint16_t)lround(y);
 }
 *out=a;return 1;
}

int l3_maze_motion_observe(L3MazeMotion *m,const L3MiniView *v,const L3MiniActors *a,double time,uint32_t epoch){
 return l3_maze_motion_observe_trace(m,v,a,time,epoch,0);
}

static void track_position(const L3MazeTrack *t,double time,unsigned *x,unsigned *y){
 double px=t->settled_x,py=t->settled_y;
 for(unsigned n=0;n<t->count;n++){
  const L3MazeSegment *s=&t->segments[(t->head+n)%L3_MAZE_SEGMENTS];
  if(time>=s->end){px=s->x1;py=s->y1;continue;}
  double k=time<=s->start?0:(time-s->start)/(s->end-s->start);
  px=s->x0+(s->x1-s->x0)*k;py=s->y0+(s->y1-s->y0)*k;break;
 }
 *x=(unsigned)lround(px);*y=(unsigned)lround(py);
}
static int observed_move(L3MazeMotion *m,const L3MiniView *v,unsigned i,unsigned x,unsigned y,double now){
 L3MazeTrack *t=&m->actor[i];retire(t,now);
 if(t->logical_x==x&&t->logical_y==y)return 1;
 if(abs((int)x-t->logical_x)+abs((int)y-t->logical_y)!=256||!open_cell(v,x,y)||t->count==L3_MAZE_SEGMENTS)return 0;
 unsigned tail=(t->head+t->count)%L3_MAZE_SEGMENTS;double start=now;
 if(t->count&&t->segments[(tail+L3_MAZE_SEGMENTS-1)%L3_MAZE_SEGMENTS].end>start)start=t->segments[(tail+L3_MAZE_SEGMENTS-1)%L3_MAZE_SEGMENTS].end;
 t->segments[tail]=(L3MazeSegment){start,start+(i?14.:6.)/60.,t->logical_x,t->logical_y,(uint16_t)x,(uint16_t)y};
 t->logical_x=(uint16_t)x;t->logical_y=(uint16_t)y;t->count++;m->moves++;return 1;
}
/* Re-time only the already observed orthogonal path. The hero's segments
 * are never changed to wait for a ghost. If he is already at the contact,
 * the contact itself may vanish immediately; no ordinary move is invented. */
static int contact_arrival(L3MazeTrack *t,double now,double due){
 unsigned x,y;track_position(t,now,&x,&y);
 if(due<=now){settle(t,t->logical_x,t->logical_y);return 1;}
 /* Preserve earlier contacts/warps if this path already reaches the new
  * contact in time. Re-timing it would move the earlier encounter. */
 if(t->count&&t->segments[(t->head+t->count-1)%L3_MAZE_SEGMENTS].end<=due)return 1;
 /* A prior power-contact warp must keep its original deadline. Only the
  * observed path AFTER the last pending warp may be retimed to this hit. */
 unsigned prefix=0;double start_time=now;unsigned sx=x,sy=y;
 for(unsigned n=0;n<t->count;n++){
  const L3MazeSegment *s=&t->segments[(t->head+n)%L3_MAZE_SEGMENTS];
  if(s->end>now&&s->end==s->start){if(s->end>=due)return 0;prefix=n+1;start_time=s->end;sx=s->x1;sy=s->y1;}
 }
 unsigned xs[L3_MAZE_SEGMENTS],ys[L3_MAZE_SEGMENTS],count=0,total=0,px=sx,py=sy;
 for(unsigned n=prefix;n<t->count;n++){
  const L3MazeSegment *s=&t->segments[(t->head+n)%L3_MAZE_SEGMENTS];if(s->end<=now)continue;
  if(s->end==s->start)return 0;
  unsigned dx=(unsigned)abs((int)s->x1-(int)px),dy=(unsigned)abs((int)s->y1-(int)py);
  if(dx&&dy)return 0;if(!dx&&!dy)continue;
  xs[count]=s->x1;ys[count++]=s->y1;total+=dx+dy;px=s->x1;py=s->y1;
 }
 if(px!=t->logical_x||py!=t->logical_y)return 0;
 L3MazeTrack next={0};next.settled_x=(uint16_t)x;next.settled_y=(uint16_t)y;next.logical_x=t->logical_x;next.logical_y=t->logical_y;
 for(unsigned n=0;n<prefix;n++)next.segments[next.count++]=t->segments[(t->head+n)%L3_MAZE_SEGMENTS];
 if(!count){if(next.count==L3_MAZE_SEGMENTS)return 0;next.segments[next.count++]=(L3MazeSegment){start_time,due,(uint16_t)sx,(uint16_t)sy,(uint16_t)sx,(uint16_t)sy};}
 else {unsigned distance=0;double start=start_time;px=sx;py=sy;
  for(unsigned n=0;n<count;n++){
   distance+=(unsigned)(abs((int)xs[n]-(int)px)+abs((int)ys[n]-(int)py));double end=n+1==count?due:start_time+(due-start_time)*distance/total;
   if(next.count==L3_MAZE_SEGMENTS)return 0;
   next.segments[next.count++]=(L3MazeSegment){start,end,(uint16_t)px,(uint16_t)py,(uint16_t)xs[n],(uint16_t)ys[n]};start=end;px=xs[n];py=ys[n];
  }
 }
 *t=next;return 1;
}
static int contact_warp(L3MazeTrack *t,unsigned x,unsigned y,double now,double due){
 retire(t,now);unsigned px,py;track_position(t,due,&px,&py);L3MazeTrack next=*t;next.head=0;next.count=0;
 for(unsigned n=0;n<t->count;n++){
  L3MazeSegment s=t->segments[(t->head+n)%L3_MAZE_SEGMENTS];if(s.start>due||(s.start==due&&s.end>due))break;
  int clipped=s.end>due;
  if(s.end>due){s.end=due;s.x1=(uint16_t)px;s.y1=(uint16_t)py;}
  if(next.count==L3_MAZE_SEGMENTS)return 0;
  next.segments[next.count++]=s;if(clipped)break;
 }
 if(next.count==0){next.settled_x=(uint16_t)px;next.settled_y=(uint16_t)py;}
 if(px!=x||py!=y){
  if(next.count==L3_MAZE_SEGMENTS)return 0;
  next.segments[next.count++]=(L3MazeSegment){due,due,(uint16_t)px,(uint16_t)py,(uint16_t)x,(uint16_t)y};
 }
 next.logical_x=(uint16_t)x;next.logical_y=(uint16_t)y;*t=next;return 1;
}
int l3_maze_motion_observe_events(L3MazeMotion *m,const L3MiniView *v,const L3MiniActors *a,double now,uint32_t epoch,const L3MiniTrace *trace){
 if(!trace)return l3_maze_motion_observe_trace(m,v,a,now,epoch,0);
 if(!m||!v||trace->event_count>L3_MAZE_TRACE_EVENTS||trace->event_overflow)return 0;
 unsigned contacts=0;
 for(unsigned n=0;n<trace->event_count;n++){
  const L3MazeEvent *e=&trace->events[n];if(e->kind<L3_MAZE_COLLECT||e->kind>L3_MAZE_CONTACT_LOST)return 0;
  if(!open_cell(v,e->x*256u+128,e->y*256u+128))return 0;
  for(unsigned i=0;i<3;i++)if(!open_cell(v,e->actor_x[i]*256u+128,e->actor_y[i]*256u+128))return 0;
  if(e->kind==L3_MAZE_COLLECT)continue;contacts++;
  for(unsigned i=0;i<3;i++)if(!open_cell(v,e->respawn_x[i]*256u+128,e->respawn_y[i]*256u+128))return 0;
 }
 if(!contacts)return l3_maze_motion_observe_trace(m,v,a,now,epoch,trace->maze_warp_mask);
 L3MazeMotion original=*m,fallback=*m;
 if(!l3_maze_motion_observe_trace(&fallback,v,a,now,epoch,trace->maze_warp_mask))return 0;
 if(!original.valid||original.epoch!=epoch)goto fallback;
 L3MazeMotion work=original;
 for(unsigned n=0;n<trace->event_count;n++){
  const L3MazeEvent *e=&trace->events[n];
  for(unsigned i=0;i<3;i++)if(!observed_move(&work,v,i,e->actor_x[i]*256u+128,e->actor_y[i]*256u+128,now))goto fallback;
  if(e->kind==L3_MAZE_COLLECT)continue;
  double due=now;L3MazeTrack *hero=&work.actor[0];
  if(hero->count)due=fmax(due,hero->segments[(hero->head+hero->count-1)%L3_MAZE_SEGMENTS].end);
  unsigned collided=e->kind==L3_MAZE_CONTACT_POWER?e->actor_mask:e->detail;
  if((collided!=2&&collided!=4)||(e->kind!=L3_MAZE_CONTACT_POWER&&e->actor_mask!=7))return 0;
  for(unsigned i=1;i<3;i++)if(collided&(1u<<i))if(!contact_arrival(&work.actor[i],now,due))goto fallback;
  if(e->kind!=L3_MAZE_CONTACT_LOST)for(unsigned i=0;i<3;i++)if(e->actor_mask&(1u<<i)){
   if(!contact_warp(&work.actor[i],e->respawn_x[i]*256u+128,e->respawn_y[i]*256u+128,now,due))goto fallback;work.teleports++;
  }
  work.contacts++;
 }
 for(unsigned i=0;i<3;i++)if(!observed_move(&work,v,i,a->actors[i].x256,a->actors[i].y256,now))goto fallback;
 work.latest=*a;work.time=now;work.epoch=epoch;work.valid=1;*m=work;return 1;
fallback:
 fallback.contacts+=contacts;fallback.contact_fallbacks++;*m=fallback;return 1;
}
