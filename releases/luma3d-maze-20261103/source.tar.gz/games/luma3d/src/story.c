#include "luma3d_amber.h"
#include "luma3d_activities.h"
#include "luma3d_game.h"
#include "luma3d_workshop.h"
#include "luma3d_village.h"
#include "luma3d_garden.h"
/* LUMA3D VILLAGE V6: echo sites are separate from Maelle, Silo and the portal. */
#include <math.h>
#include <string.h>
#include <stdio.h>

/* Story sites use the physical heightfield; these are positions, not poses. */
L3Vec3 l3_story_site(const L3Game *g,unsigned site) {
    static const float xz[9][2]={{29.5f,125},{68.5f,91},{124.5f,36},
        {84,70},{88,69},{86,66},{143,46},{147,46},{146,38}};
    if(site>=L3_GARDEN_FIRST&&site<L3_GARDEN_FIRST+L3_GARDEN_SITES)return l3_garden_site(g,site-L3_GARDEN_FIRST);
    if(site>=L3_VILLAGE_FIRST_NEAREST&&
       site<L3_VILLAGE_FIRST_NEAREST+L3_VILLAGE_SITE_COUNT)
        return l3_village_site(g,site-L3_VILLAGE_FIRST_NEAREST);
    if(site>=L3_ACTIVITY_FIRST_SITE)return l3_activity_site(g,site-L3_ACTIVITY_FIRST_SITE);
    if(site>=9)return l3_amber_site(g,site);
    L3Vec3 p={xz[site][0],0,xz[site][1]};
    p.y=g->world.height(g->world.context,p.x,p.z);return p;
}
static float distance(L3Vec3 a,L3Vec3 b) {
    float dx=a.x-b.x,dz=a.z-b.z;return sqrtf(dx*dx+dz*dz);
}
static void toast(L3Game *g,unsigned value) {
    g->story.toast=value;g->story.toast_time=4;g->story.revision++;
}
void l3_story_init(L3Game *g) {
    memset(&g->story,0,sizeof(g->story));g->story.dialogue=-1;g->story.nearest=-1;
}
static void open_dialogue(L3Game *g,int id) {
    g->story.dialogue=id;g->story.page=0;g->story.dialogue_time=0;g->story.revision++;
}
static void advance_dialogue(L3Game *g) {
    L3Story *s=&g->story;
    if((s->dialogue==0||s->dialogue==1||s->dialogue==2||s->dialogue==6||s->dialogue==7||(s->dialogue>=8&&s->dialogue<=11))&&s->page==0) {
        s->page=1;s->dialogue_time=0;s->revision++;return;
    }
    if(s->dialogue==0&&s->phase==0) {s->phase=1;toast(g,1);}
    else if(s->dialogue==1&&s->phase==1) {
        s->phase=2;g->route_index=6;g->route_direction=1;toast(g,2);
    } else if(s->dialogue==2&&s->phase==3) {
        s->phase=4;g->objective_complete=1;g->completed_routes++;
        g->route_direction=-1;g->route_index=g->world.route_count-2;toast(g,5);
    }
    if(s->dialogue==6){s->workshop_phase=1;s->workshop_mode=0;g->route_direction=-1;g->route_index=13;toast(g,8);}
    if(s->dialogue==7){s->workshop_phase=4;s->workshop_mode=5;toast(g,12);}
    if(s->dialogue>=8&&s->dialogue<14)l3_amber_dialogue_done(g,s->dialogue);
    s->dialogue=-1;s->page=0;s->dialogue_time=0;s->revision++;
}
static void interact(L3Game *g) {
    L3Story *s=&g->story;int n=s->nearest;
    if(n<0)return;
    if(n>=L3_GARDEN_FIRST&&n<L3_GARDEN_FIRST+L3_GARDEN_SITES){l3_garden_interact(g,(unsigned)n-L3_GARDEN_FIRST);return;}
    if(n>=L3_VILLAGE_FIRST_NEAREST&&
       n<L3_VILLAGE_FIRST_NEAREST+L3_VILLAGE_SITE_COUNT) {
        l3_village_interact(g,(unsigned)(n-L3_VILLAGE_FIRST_NEAREST));
        return;
    }
    if(l3_amber_interact(g,n)||l3_workshop_interact(g,n))return;
    if(n==0)open_dialogue(g,s->workshop_phase==3?7:s->phase==0?0:3);
    else if(n==1)open_dialogue(g,s->phase==1&&(g->collected_mask&3)==3?1:4);
    else if(n==2)open_dialogue(g,s->phase==4&&!s->workshop_phase?6:s->phase==3&&g->collected_count==4?2:5);
    else if(s->phase==2) {
        if((unsigned)(n-3)==s->relay_step) {
            s->relay_step++;s->revision++;toast(g,3);
            if(s->relay_step==3) {s->phase=3;g->route_index=8;toast(g,4);}
        } else {s->relay_step=0;s->wrong_sequences++;toast(g,6);}
    }
}
int l3_story_before(L3Game *g,uint32_t pressed,float dt) {
    L3Story *s=&g->story;
    if(pressed&L3_JOURNAL) {s->journal=!s->journal;s->revision++;}
    if(s->toast_time>0) {s->toast_time=fmaxf(0,s->toast_time-dt);if(!s->toast_time)s->revision++;}
    if(s->dialogue>=0) {
        s->dialogue_time+=dt;
        if((pressed&L3_INTERACT)||(g->autopilot&&s->dialogue_time>=5))advance_dialogue(g);
        return 1;
    }
    if(s->journal)return 1;
    if(pressed&L3_INTERACT)interact(g);
    else if(g->autopilot) {
        int amber=l3_amber_wanted(g);
        int wanted=amber>=0?amber:s->phase==0?0:s->phase==1?1:s->phase==2?(int)(3+s->relay_step):s->phase==3?2:l3_workshop_wanted(g);
        if(wanted>=0&&s->nearest==wanted&&
           distance(g->player.position,l3_story_site(g,(unsigned)wanted))<(wanted==8?1.0f:1.8f)&&
           s->workshop_wait<=0&&
           (s->phase!=1||(g->collected_mask&3)==3))interact(g);
    }
    return s->dialogue>=0||g->activities.arcade.active;
}
void l3_story_after(L3Game *g) {
    L3Story *s=&g->story;int nearest=-1;float best=2.5f;
    for(unsigned i=g->story.region?10:0,end=g->story.region?L3_ACTIVITY_FIRST_SITE+L3_ARCADE_COUNT:10;i<end;i++) {
        if(i==13)continue;
        if(i>=3&&i<6&&s->phase!=2)continue;
        if(i==8&&(s->workshop_phase!=2||g->player.position.z>=39.4f))continue;
        L3Vec3 p=l3_story_site(g,i);float d=distance(p,g->player.position);
        if(d<best&&(i!=8||d<1.1f)&&fabsf(p.y-g->player.position.y)<2) {nearest=(int)i;best=d;}
    }
    if(!s->region) {
        /* Echo sites and story sites compete on the same radius: the closest
         * eligible one wins and an exact tie keeps the story site. The village
         * module owns its own reach and verticality checks, so the distance it
         * returns is already the distance of an eligible echo site. */
        float echo_distance=0.0f;
        int echo=l3_village_nearest(g,&echo_distance);
        if(echo>=0&&(nearest<0||echo_distance<best))nearest=L3_VILLAGE_FIRST_NEAREST+echo;
    }
    if(s->region&&nearest<0){int garden=l3_garden_nearest(g);if(garden>=0)nearest=L3_GARDEN_FIRST+garden;}
    if(nearest!=s->nearest) {s->nearest=nearest;s->revision++;}
    if(s->phase>=2&&!s->discovered&&distance(g->player.position,l3_story_site(g,3))<5) {
        s->discovered=1;toast(g,7);
    }
}
L3Vec3 l3_story_auto_target(L3Game *g) {
    L3Vec3 workshop;if(l3_amber_target(g,&workshop)||l3_workshop_target(g,&workshop))return workshop;
    unsigned phase=g->story.phase;
    if(phase==0)return l3_story_site(g,0);
    /* Stop beside Silo, on the path, so the onward segment does not cross
     * his solid body after the conversation. This remains physical walking. */
    if(phase==1&&g->route_index>=5)return g->world.route[5];
    if(phase==2&&g->route_index>=7)return l3_story_site(g,3+g->story.relay_step);
    if(phase==3&&g->route_index>=14)return l3_story_site(g,2);
    return g->world.route[g->route_index];
}
const char *l3_story_objective(const L3Game *g) {
    if(l3_garden_in_zone(g))return l3_garden_objective(g);
    if(!g->story.region&&g->village_phase!=L3_VILLAGE_PHASE_DORMANT&&
       g->village_phase!=L3_VILLAGE_PHASE_DONE&&l3_village_in_zone(g))
        return l3_village_objective(g);
    if(g->story.workshop_phase==4)return l3_amber_objective(g);
    if(g->story.phase==4){switch(g->story.workshop_phase){
    case 0:return "Iria connaît un autre chemin : lui reparler";
    case 1:return "Atelier : CUIVRE vers l’OUEST, BLEUE vers le NORD";
    case 2:return "La roue tourne ! Entrer et prendre la cloche";
    case 3:return "Rapporter la cloche à Maëlle, au village";
    default:return "La cloche retrouve sa place au village";
    }}
    switch(g->story.phase) {
    case 0:return "Parler à Maëlle, la gardienne du courrier";
    case 1:return (g->collected_mask&3)==3?"Retrouver Silo au hameau":"Retrouver les deux lettres du chemin";
    case 2:return "Réveiller le relais : Terre, Vent, Ciel";
    case 3:return g->collected_count==4?"Remettre le courrier à Iria, aux ruines":"Suivre la crête et retrouver la dernière lettre";
    default:return "Courrier remis ! Explorer ou revenir au hameau";
    }
}
const char *l3_story_speaker(const L3Game *g) {
    int d=g->story.dialogue;if(d>=14)return d==14?"SÉLÈNE · Botaniste des serres":"OREN · Gardien du carillon";if(d>=8)return l3_amber_speaker(d);
    return d==0||d==3||d==7?"MAËLLE · Gardienne du courrier":d==1||d==4?"SILO · Facteur des sentiers":"IRIA · Veilleuse des ruines";
}
const char *l3_story_dialogue(const L3Game *g) {
    int d=g->story.dialogue,p=g->story.page;if(d>=14)return l3_garden_dialogue(g);if(d>=8)return l3_amber_dialogue(g);
    if(d==0)return p?"Deux lettres sont tombées sur le chemin du hameau.\nRetrouve-les, puis parle à Silo près de la maison.\nIl connaît le passage vers la porte des nuages.":
        "Le vent a emporté notre courrier !\nIria attend des nouvelles, tout là-haut, dans les ruines.\nTu veux bien lui porter les lettres ?";
    if(d==1)return p?"Au relais, touche les pierres dans cet ordre :\nTERRE, puis VENT, puis CIEL. Une erreur ? Recommence.\nLe signal te guidera ensuite vers Iria.":
        "Tu as retrouvé les lettres ! La crête mène aux ruines,\nmais son ancien relais s'est endormi. Cherche les trois\npierres, au-dessus des roseaux, en suivant le sentier.";
    if(d==2)return p?"Mission accomplie : le courrier du phare.\nLe relais restera allumé pendant cette partie.\nPrends le temps de regarder la vallée avant le retour.":
        "Une lettre de Maëlle... et une réponse de mon frère !\nMerci. Depuis ces ruines, j'avais oublié que le hameau\npensait encore à moi. Le lien est rétabli.";
    if(d==6)return p?"CUIVRE vers l'OUEST (côté lac), BLEUE vers le NORD\n(côté ruines). Le cuivre entraîne les deux ;\nla bleue tourne seule. Regarde la roue !":
        "L'atelier garde encore la cloche du village.\nRedescends au relais, traverse le pont puis suis\nla berge et les bornes jusqu'à la terrasse de l'est.";
    if(d==7)return p?"L'atelier reste ouvert, et le passage t'appartient.\nMerci d'avoir suivi le vent jusqu'à l'autre rive.\nLa cloche est revenue au village.":
        "Tu as retrouvé notre cloche ! Son battant se\nbalance enfin. Autrefois, les voyageurs suivaient\nce son pour retrouver le hameau dans la brume.";
    if(d==3)return "Silo t'attend près du hameau. Les lettres brillent\nau bord du chemin ; approche-toi pour les ramasser.";
    if(d==4)return g->story.phase<2?"Il manque une lettre du chemin. Regarde près du\nvirage et à l'entrée du hameau, puis reviens me voir.":
        "Souviens-toi : Terre, Vent, Ciel. Le relais se trouve\nau-dessus du lac, puis le sentier rejoint la crête.";
    return g->story.phase==4?"Tes pas ont rendu sa voix au vieux relais.\nMerci d'avoir porté ces nouvelles jusqu'ici.":
        "J'attends quatre lettres et le signal du relais.\nSilo, au hameau, sait comment le réveiller.";
}
const char *l3_story_prompt(const L3Game *g) {
    static char activity[160];static char village[256];
    if(g->story.nearest>=L3_GARDEN_FIRST&&g->story.nearest<L3_GARDEN_FIRST+L3_GARDEN_SITES)return l3_garden_prompt(g,(unsigned)g->story.nearest-L3_GARDEN_FIRST);
    if(g->story.nearest>=L3_VILLAGE_FIRST_NEAREST&&
       g->story.nearest<L3_VILLAGE_FIRST_NEAREST+L3_VILLAGE_SITE_COUNT) {
        unsigned k=(unsigned)g->story.nearest-L3_VILLAGE_FIRST_NEAREST;
        snprintf(village,sizeof(village),"%s · %s",l3_village_prompt(g,k),l3_village_clue(k));
        return village;
    }
    if(g->story.region&&g->story.nearest<0&&g->player.position.x>217&&g->player.position.x<227&&g->player.position.z>65&&g->player.position.z<76)return "Maison des lueurs · Les lanternes attendent dans la pièce du fond.";
    if(g->story.nearest>=L3_ACTIVITY_FIRST_SITE){unsigned k=(unsigned)g->story.nearest-L3_ACTIVITY_FIRST_SITE;snprintf(activity,sizeof(activity),"E · %s%s",l3_activity_name(k),l3_activity_won(g,k)?" · récompense obtenue":" · défi facultatif");return activity;}
    if(g->story.nearest>=9)return l3_amber_prompt(g);
    static char mechanism[120];static const char *heading[]={"SUD","EST","NORD","OUEST"};
    if(g->story.nearest==6||g->story.nearest==7){
        int a=g->story.nearest==6;snprintf(mechanism,sizeof(mechanism),"E · %s : %s. %s",a?"CUIVRE":"BLEUE",heading[(a?g->story.wind_a:g->story.wind_b)&3],a?"Tourne aussi la bleue":"Tourne seule");return mechanism;
    }
    static const char *names[]={"E · Parler à Maëlle","E · Parler à Silo","E · Parler à Iria", "E · Pierre TERRE","E · Pierre VENT","E · Pierre CIEL", "E · Tourner le CUIVRE : les deux ailettes", "E · Tourner la BLEUE : elle seule", "E · Prendre la cloche du village"};
    return g->story.nearest>=0?names[g->story.nearest]:"J · Carnet    WASD · Marcher    E · Interagir";
}
