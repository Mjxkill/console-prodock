#define _POSIX_C_SOURCE 200809L
#include "luma3d_render.h"
#include "luma3d_activities.h"
#include "puzzle_art.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <time.h>
static double ui_seconds(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec*1e-9;}

/* Native indexed artwork. 0 is transparent, 1..31 retain their old palette;
 * 32..127 belong to this UI. Shooter sprites own 128..239, console 240..255.
 * Two independent CPU shadows describe the last bytes uploaded to each page. */
#define MINI_BASE (22U<<20)
#define MINI_PAGE (1U<<20)
enum { INK=64,SHADOW,PANEL,EDGE,EDGE_LIGHT,WELL,SLOT,SLOT_LIGHT,MUTED,FAINT,
       TEXT,WHITE,BRASS_DARK,BRASS,GOLD,GOLD_LIGHT,GREEN_DARK,GREEN,GREEN_LIGHT,
       RED_DARK,RED,RED_LIGHT,BLUE_DARK,BLUE };
typedef struct {L3Render *r;uint8_t *pixels;int w,h,scale,wide;} Canvas;
static int unit(const Canvas *c,int n){return n*c->scale/2;}
static int min(int a,int b){return a<b?a:b;}
static int max(int a,int b){return a>b?a:b;}
static void box(Canvas *c,int x,int y,int w,int h,unsigned color){
 int x0=max(x,0),x1=min(x+w,c->w),y0=max(y,0),y1=min(y+h,c->h);
 if(x1<=x0||y1<=y0)return;
 for(int yy=y0;yy<y1;yy++)memset(c->pixels+(size_t)yy*c->w+x0,(int)color,(size_t)(x1-x0));
}
static void pixel(Canvas *c,int x,int y,unsigned color){if(x>=0&&x<c->w&&y>=0&&y<c->h)c->pixels[(size_t)y*c->w+x]=(uint8_t)color;}
static void round_box(Canvas *c,int x,int y,int w,int h,int radius,unsigned color){
 radius=min(radius,min(w,h)/2);if(radius<1){box(c,x,y,w,h,color);return;}
 for(int yy=0;yy<h;yy++){
  int dy=yy<radius?radius-yy-1:yy>=h-radius?yy-(h-radius):0,cut=0;
  if(dy)while(cut<radius && (radius-cut-1)*(radius-cut-1)+dy*dy>radius*radius)cut++;
  box(c,x+cut,y+yy,w-2*cut,1,color);
 }
}
static void circle(Canvas *c,int x,int y,int radius,unsigned color){
 for(int yy=-radius;yy<=radius;yy++){int xx=radius;while(xx>0&&xx*xx+yy*yy>radius*radius)xx--;box(c,x-xx,y+yy,2*xx+1,1,color);}
}
static void line(Canvas *c,int x0,int y0,int x1,int y1,int thick,unsigned color){
 int dx=abs(x1-x0),sx=x0<x1?1:-1,dy=-abs(y1-y0),sy=y0<y1?1:-1,e=dx+dy;
 for(;;){box(c,x0-thick/2,y0-thick/2,thick,thick,color);if(x0==x1&&y0==y1)break;int q=2*e;if(q>=dy){e+=dy;x0+=sx;}if(q<=dx){e+=dx;y0+=sy;}}
}
static void panel(Canvas *c,int x,int y,int w,int h){
 int r=unit(c,10);round_box(c,x,y+unit(c,4),w,h,r,SHADOW);round_box(c,x,y,w,h,r,EDGE);
 round_box(c,x+1,y+1,w-2,h-2,r,PANEL);box(c,x+r,y+1,w-2*r,1,EDGE_LIGHT);
}
static void glass_panel(Canvas *c,int x,int y,int w,int h){
 int radius=unit(c,10);
 for(int yy=0;yy<h;yy++){
  int dy=yy<radius?radius-yy-1:yy>=h-radius?yy-(h-radius):0,cut=0;
  if(dy)while(cut<radius&&(radius-cut-1)*(radius-cut-1)+dy*dy>radius*radius)cut++;
  for(int xx=cut;xx<w-cut;xx++)if(x+xx>=0&&x+xx<c->w&&y+yy>=0&&y+yy<c->h){
   uint8_t *p=c->pixels+(size_t)(y+yy)*c->w+x+xx;
   *p=(xx==cut||xx==w-cut-1||!yy||yy==h-1)?BRASS_DARK:(*p>=32&&*p<128?puzzle_glass_tint[*p-32]:PANEL);
  }
 }
}
static unsigned next_char(const unsigned char **p){
 unsigned c=*(*p)++;if(c>=0xc2&&c<0xe0&&**p>=0x80){c=((c&31)<<6)|(**p&63);(*p)++;}
 else if(c>=0xe0&&c<0xf0&&(*p)[0]&&(*p)[1]){c=((c&15)<<12)|(((*p)[0]&63)<<6)|((*p)[1]&63);*p+=2;}
 if(c==0x2019)return '\'';if(c==0x2014||c==0x2013)return '-';return c<256?c:'?';
}
static int font_index(const Canvas *c,int f){return f+(c->wide?5:0);}
static int text_width(int f,const char *s){
 const unsigned char *p=(const unsigned char *)s;int w=0;while(*p)w+=puzzle_fonts[f].glyph[next_char(&p)].advance;return w;
}
static void label(Canvas *c,int x,int y,int f,const char *s,unsigned color){
 const PuzzleFont *font=puzzle_fonts+f;const unsigned char *p=(const unsigned char *)s;
 while(*p){unsigned ch=next_char(&p);const PuzzleGlyph *g=font->glyph+ch;
  for(unsigned yy=0;yy<font->height;yy++)for(unsigned xx=0;xx<g->width;xx++){
   unsigned pos=yy*g->width+xx,a=(font->pixels[g->offset+pos/4]>>(2*(pos%4)))&3;
   if(a)pixel(c,x+(int)xx,y+(int)yy,a==3?color:a==2?(color==GOLD||color==GOLD_LIGHT?BRASS:MUTED):FAINT);
  }x+=g->advance;
 }
}
static void centered(Canvas *c,int x,int y,int w,int f,const char *s,unsigned color){label(c,x+(w-text_width(f,s))/2,y,f,s,color);}
static int wrapped(Canvas *c,int x,int y,int width,int f,const char *s,unsigned color){
 char row[256]={0};size_t n=0;int start=y;const char *p=s;
 while(*p){while(*p==' ')p++;if(!*p)break;const char *end=p;while(*end&&*end!=' '&&*end!='\n')end++;
  size_t z=(size_t)(end-p);if(z>180)z=180;char trial[512];snprintf(trial,sizeof(trial),"%s%s%.*s",row,n?" ":"",(int)z,p);
  if(n&&text_width(f,trial)>width){label(c,x,y,f,row,color);y+=(int)puzzle_fonts[f].height+unit(c,2);n=0;row[0]=0;}
  if(n&&n+1<sizeof(row))row[n++]=' ';size_t room=sizeof(row)-n-1;if(z>room)z=room;memcpy(row+n,p,z);n+=z;row[n]=0;
  p=end;if(*p=='\n'){label(c,x,y,f,row,color);y+=(int)puzzle_fonts[f].height+unit(c,2);n=0;row[0]=0;p++;}
 }
 if(n){label(c,x,y,f,row,color);y+=(int)puzzle_fonts[f].height;}return y-start;
}
int l3_ui_text(uint8_t *dst,unsigned width,unsigned height,int x,int y,unsigned style,const char *text,unsigned color,unsigned wrap_width){
 if(!dst||!text||!width||!height||width>16384||height>16384||style>2||color>255)return 0;
 Canvas c={NULL,dst,(int)width,(int)height,width>=1000?3:2,width>=1000};int f=font_index(&c,(int)style);
 if(wrap_width)return wrapped(&c,x,y,(int)(wrap_width>width?width:wrap_width),f,text,color);
 label(&c,x,y,f,text,color);return *text?(int)puzzle_fonts[f].height:0;
}
static void meter(Canvas *c,int x,int y,int w,unsigned value,unsigned total,unsigned color){
 int h=unit(c,6);round_box(c,x,y,w,h,h/2,WELL);if(total){unsigned v=value>total?total:value;round_box(c,x,y,(int)((uint64_t)w*v/total),h,h/2,color);}
}
static void key(Canvas *c,int x,int y,const char *s,const char *help,int width){
 int f=font_index(c,0),h=unit(c,23),w=max(unit(c,24),text_width(f,s)+unit(c,12));
 round_box(c,x,y+2,w,h,unit(c,4),SHADOW);round_box(c,x,y,w,h,unit(c,4),EDGE);round_box(c,x+1,y+1,w-2,h-3,unit(c,3),SLOT);
 centered(c,x,y+unit(c,2),w,f,s,TEXT);if(help&&width>w+unit(c,8))label(c,x+w+unit(c,9),y+unit(c,2),f,help,MUTED);
}
static const char *titles[8]={"Circuit des conduites","La fabrique des blocs","Le jardin des formes","Fusion 1024","Maison des lueurs","Les quatre échos","Simulateur des étoiles","Tour des courroies"};
static void footer(Canvas *c,const L3Game *g){
 int y=c->h-unit(c,30),f=font_index(c,0);label(c,unit(c,28),y,f,"R  Recommencer",MUTED);
 label(c,unit(c,184),y,f,"Q  Retour au monde",MUTED);
 const char *s=g->showcase_status==3?"Visite en pause · E pour jouer":g->showcase_status?"DÉMO · E pour jouer":"À votre rythme";
 label(c,c->w-unit(c,28)-text_width(f,s),y,f,s,GOLD);
}
static void header(Canvas *c,unsigned kind,unsigned status,unsigned won){
 int x=unit(c,28);label(c,x,unit(c,12),font_index(c,0),"LUMA   /   ATELIERS D'AMBRE",GOLD);
 label(c,x,unit(c,32),font_index(c,2),titles[kind],WHITE);
 const char *tag=status==L3_MINI_WON?"DÉFI RÉUSSI":won?"SOUVENIR ACQUIS":"DÉFI FACULTATIF";
 int f=font_index(c,0),w=text_width(f,tag)+unit(c,26),xx=c->w-unit(c,28)-w;
 round_box(c,xx,unit(c,23),w,unit(c,28),unit(c,14),PANEL);
 label(c,xx+unit(c,13),unit(c,28),f,tag,status==L3_MINI_WON?GREEN_LIGHT:MUTED);
}
static void tile(Canvas *c,int x,int y,int s,unsigned ramp,int active){
 unsigned b=88+(ramp%8)*5;int r=max(3,s/10),gap=max(2,s/18),w=s-gap*2;
 round_box(c,x+gap,y+gap+3,w,w,r,SHADOW);round_box(c,x+gap,y+gap,w,w,r,b);
 round_box(c,x+gap+1,y+gap+1,w-2,w-4,r,b+1);
 box(c,x+gap+r,y+gap+1,w-r*2,2,b+3);box(c,x+gap+2,y+gap+r,1,w-r*2,b+2);
 box(c,x+gap+r,y+gap+w-3,w-r*2,2,b+4);
 if(active){box(c,x+gap+r,y+gap,w-r*2,1,WHITE);circle(c,x+s/2,y+gap+max(3,s/8),max(1,s/22),b+3);}
}
static void corner_selection(Canvas *c,int x,int y,int s){
 int z=max(7,s/4),t=max(2,s/24);unsigned col=GOLD_LIGHT;
 box(c,x,y,z,t,col);box(c,x,y,t,z,col);box(c,x+s-z,y,z,t,col);box(c,x+s-t,y,t,z,col);
 box(c,x,y+s-t,z,t,col);box(c,x,y+s-z,t,z,col);box(c,x+s-z,y+s-t,z,t,col);box(c,x+s-t,y+s-z,t,z,col);
}
static void wire(Canvas *c,int x,int y,int s,const L3MiniCell *cell){
 int mid=s/2,t=max(3,s/9);unsigned connected=cell->flags&L3_MINI_FLAG_CONNECTED;
 unsigned base=connected?GREEN_DARK:BRASS_DARK,light=connected?GREEN:BRASS,shine=connected?GREEN_LIGHT:GOLD;
 round_box(c,x+2,y+2,s-4,s-4,max(3,s/10),SLOT);box(c,x+7,y+3,s-14,1,SLOT_LIGHT);
 for(int pass=0;pass<3;pass++){
  int thick=pass==0?t*2+2:pass==1?t*2:max(1,t/2),off=pass==0?2:0;unsigned col=pass==0?SHADOW:pass==1?base:light;
  if(cell->value&1)line(c,x+mid,y+mid+off,x+mid,y+off,thick,col);
  if(cell->value&2)line(c,x+mid,y+mid+off,x+s,y+mid+off,thick,col);
  if(cell->value&4)line(c,x+mid,y+mid+off,x+mid,y+s+off,thick,col);
  if(cell->value&8)line(c,x+mid,y+mid+off,x,y+mid+off,thick,col);
 }
 circle(c,x+mid,y+mid,t+3,base);circle(c,x+mid,y+mid,t,light);circle(c,x+mid-1,y+mid-1,max(1,t/3),shine);
 if(cell->kind==L3_MINI_CELL_START||cell->kind==L3_MINI_CELL_FINISH){
  circle(c,x+mid,y+mid,max(5,s/5),SHADOW);circle(c,x+mid,y+mid,max(3,s/5-2),cell->kind==L3_MINI_CELL_START?GREEN:BRASS);
  int z=max(3,s/10);line(c,x+mid-z,y+mid,x+mid+z,y+mid,2,WHITE);line(c,x+mid+z,y+mid,x+mid,y+mid-z,2,WHITE);line(c,x+mid+z,y+mid,x+mid,y+mid+z,2,WHITE);
 }
 if(cell->flags&L3_MINI_FLAG_CURSOR)corner_selection(c,x+1,y+1,s-2);
}
static int drop_distance(const L3MiniView *v){
 int distance=0,found=0;
 for(int d=1;d<(int)v->height;d++){
  int fits=1;for(unsigned y=0;y<v->height;y++)for(unsigned x=0;x<v->width;x++)if(v->cells[y*20+x].flags&L3_MINI_FLAG_ACTIVE){
   found=1;int yy=(int)y+d;if(yy>=v->height){fits=0;continue;}const L3MiniCell *at=&v->cells[(unsigned)yy*20+x];if(at->kind==L3_MINI_CELL_BLOCK&&!(at->flags&L3_MINI_FLAG_ACTIVE))fits=0;
  }if(!fits)break;distance=d;
 }return found?distance:0;
}
static void board(Canvas *c,const L3MiniView *v,int right){
 int top=unit(c,86),bottom=c->h-unit(c,54),area=right-unit(c,42);
 int cell=min((bottom-top-unit(c,14))/(int)v->height,(area-unit(c,42))/(int)v->width);
 int bw=cell*v->width,bh=cell*v->height,left=unit(c,22)+(area-bw)/2,y0=top+(bottom-top-bh)/2;
 int rim=unit(c,10);round_box(c,left-rim,y0-rim+unit(c,5),bw+2*rim,bh+2*rim,unit(c,14),SHADOW);
 round_box(c,left-rim,y0-rim,bw+2*rim,bh+2*rim,unit(c,14),BRASS_DARK);
 round_box(c,left-rim+2,y0-rim+2,bw+2*rim-4,bh+2*rim-4,unit(c,12),BRASS);
 round_box(c,left-rim+3,y0-rim+4,bw+2*rim-6,bh+2*rim-7,unit(c,11),PANEL);
 round_box(c,left-3,y0-3,bw+6,bh+6,unit(c,5),SHADOW);box(c,left,y0,bw,bh,WELL);
 for(int sy=0;sy<2;sy++)for(int sx=0;sx<2;sx++){int xx=left+(sx?bw+rim/2:-rim/2),yy=y0+(sy?bh+rim/2:-rim/2);circle(c,xx,yy,max(1,unit(c,2)),BRASS_DARK);pixel(c,xx,yy-1,GOLD);}
 int ghost=v->kind==L3_MINI_BLOCKS?drop_distance(v):0;
 for(unsigned y=0;y<v->height;y++)for(unsigned x=0;x<v->width;x++){
  const L3MiniCell *a=&v->cells[y*20+x];int xx=left+(int)x*cell,yy=y0+(int)y*cell;
  if(v->kind==L3_MINI_CIRCUIT){wire(c,xx,yy,cell,a);continue;}
  round_box(c,xx+2,yy+2,cell-4,cell-4,max(2,cell/10),SLOT);
  if(v->kind==L3_MINI_MERGE1024){
   if(a->kind==L3_MINI_CELL_NUMBER){unsigned exponent=0,n=a->value;while(n>1){n>>=1;exponent++;}static const unsigned colors[]={0,0,4,1,6,3,2,7,5,5};tile(c,xx,yy,cell,colors[(exponent?exponent-1:0)%10],0);
    char number[12];snprintf(number,sizeof(number),"%u",a->value);int f=font_index(c,3);if(text_width(f,number)>cell-unit(c,14))f=font_index(c,2);if(text_width(f,number)>cell-unit(c,14))f=font_index(c,4);
    int fy=yy+(cell-(int)puzzle_fonts[f].height)/2-1;centered(c,xx,fy,cell,f,number,exponent<=2?INK:WHITE);
    if(a->value>=512){box(c,xx+cell/3,yy+cell-unit(c,10),cell/3,1,exponent==10?WHITE:GOLD_LIGHT);}
   }else{circle(c,xx+cell/2,yy+cell/2,max(1,cell/40),SLOT_LIGHT);}
  }else if(v->kind==L3_MINI_SHAPES){
   unsigned ramp=((a->color>=10?a->color-10:0)+1)%8;
   if(a->kind==L3_MINI_CELL_TARGET){unsigned col=88+ramp*5;round_box(c,xx+3,yy+3,cell-6,cell-6,max(3,cell/10),col);round_box(c,xx+5,yy+5,cell-10,cell-10,max(2,cell/10),WELL);
    box(c,xx+cell/2-1,yy+cell/2-1,3,3,col+2);
   }else if(a->kind==L3_MINI_CELL_BLOCK){tile(c,xx,yy,cell,ramp,a->flags&L3_MINI_FLAG_ACTIVE);if(a->flags&L3_MINI_FLAG_ACTIVE)corner_selection(c,xx+2,yy+2,cell-4);}
  }else if(a->kind==L3_MINI_CELL_BLOCK)tile(c,xx,yy,cell,a->color%8,a->flags&L3_MINI_FLAG_ACTIVE);
 }
 if(ghost)for(unsigned y=0;y<v->height;y++)for(unsigned x=0;x<v->width;x++)if(v->cells[y*20+x].flags&L3_MINI_FLAG_ACTIVE){
  const L3MiniCell *below=&v->cells[(y+(unsigned)ghost)*20+x];if(below->flags&L3_MINI_FLAG_ACTIVE)continue;
  int xx=left+(int)x*cell+3,yy=y0+((int)y+ghost)*cell+3,w=cell-6;
  box(c,xx,yy,w,1,BLUE);box(c,xx,yy+w-1,w,1,BLUE);box(c,xx,yy,1,w,BLUE);box(c,xx+w-1,yy,1,w,BLUE);circle(c,xx+w/2,yy+w/2,1,BLUE);
 }
 if(v->kind==L3_MINI_BLOCKS){int xx=left-unit(c,17);for(unsigned y=0;y<v->height;y++){box(c,xx,y0+(int)y*cell+cell/2,unit(c,5),1,BRASS_DARK);} }
}
static void sidebar(Canvas *c,const L3Game *g,const L3MiniView *v,int x){
 int y=unit(c,86),w=c->w-x-unit(c,28),h=c->h-y-unit(c,54),pad=unit(c,17),f=font_index(c,0),body=font_index(c,1);
 glass_panel(c,x,y,w,h);x+=pad;y+=unit(c,13);w-=pad*2;
 const char *name=v->kind==L3_MINI_BLOCKS?"LIGNES COMPLÈTES":v->kind==L3_MINI_MERGE1024?"MEILLEURE TUILE":v->kind==L3_MINI_SHAPES?"FORMES ASSEMBLÉES":"SOURCE  >  BASSIN";
 label(c,x,y,f,name,GOLD);y+=unit(c,24);char n[48];
 if(v->kind==L3_MINI_CIRCUIT)snprintf(n,sizeof(n),"%u",v->lives);else snprintf(n,sizeof(n),"%u / %u",v->progress,v->target);
 int number=font_index(c,2);if(text_width(number,n)>w)number=body;label(c,x,y,number,n,WHITE);y+=unit(c,38);
 if(v->kind==L3_MINI_CIRCUIT)label(c,x,y-unit(c,4),f,"rotations disponibles",MUTED);
 else meter(c,x,y,w,v->progress,v->target,v->status==L3_MINI_WON?GREEN:GOLD);
 y+=unit(c,20);snprintf(n,sizeof(n),"SCORE  %u",v->score);label(c,x,y,f,n,MUTED);y+=unit(c,22);box(c,x,y,w,1,EDGE);y+=unit(c,16);
 if(v->status!=L3_MINI_RUNNING){
  label(c,x,y,body,v->status==L3_MINI_WON?"Belle réussite !":"Nouvel essai ?",v->status==L3_MINI_WON?GREEN_LIGHT:RED_LIGHT);y+=unit(c,31);
  wrapped(c,x,y,w,f,v->status==L3_MINI_WON?l3_activity_reward(v->kind):"Votre progression dans l'aventure est conservée. R pour recommencer.",MUTED);return;
 }
 const char *hint=v->kind==L3_MINI_BLOCKS?"Complétez quatre lignes. La silhouette indique où tombera la pièce.":v->kind==L3_MINI_MERGE1024?"Glissez les nombres identiques ensemble, jusqu'à 1024.":v->kind==L3_MINI_SHAPES?"Placez chaque pièce sur son empreinte de même couleur.":"Tournez les conduites. Le flux vert doit rejoindre le bassin.";
 y+=wrapped(c,x,y,w,f,hint,TEXT)+unit(c,15);
 if(v->kind==L3_MINI_BLOCKS){key(c,x,y,"A D","Déplacer",w);y+=unit(c,30);key(c,x,y,"W / F","Tourner",w);y+=unit(c,30);key(c,x,y,"E","Chute directe",w);}
 else if(v->kind==L3_MINI_MERGE1024){key(c,x,y,"WASD","Glisser",w);y+=unit(c,32);label(c,x,y,f,"ou les flèches",MUTED);}
 else {key(c,x,y,"WASD","Déplacer",w);y+=unit(c,30);key(c,x,y,"F","Tourner",w);if(v->kind==L3_MINI_SHAPES){y+=unit(c,30);key(c,x,y,"E","Assembler",w);}}
 (void)g;
}
static void lives(Canvas *c,int x,int y,unsigned n,int scaled){
 int s=scaled?unit(c,8):8;for(unsigned i=0;i<3;i++){int xx=x+(int)i*(s*2+6);unsigned color=i<n?RED:EDGE;circle(c,xx-s/3,y,s/2,color);circle(c,xx+s/3,y,s/2,color);for(int row=0;row<s;row++)box(c,xx-s+row,y+row,(s-row)*2+1,1,color);}
}
static void shooter_hud(Canvas *c,const L3Game *g,const L3ShooterView *v,unsigned chrome){
 if(chrome){
 memset(c->pixels,0,(size_t)c->w*c->h);box(c,0,0,c->w,48,INK);box(c,0,c->h-48,c->w,48,INK);
 box(c,0,48,136,c->h-96,INK);box(c,c->w-136,48,136,c->h-96,INK);
 box(c,135,48,1,c->h-96,BRASS_DARK);box(c,c->w-136,48,1,c->h-96,BRASS_DARK);
 label(c,20,9,2,"Simulateur des étoiles",WHITE);const char *state=v->status==L3_MINI_WON?"MISSION ACCOMPLIE":v->status==L3_MINI_LOST?"MISSION TERMINÉE":g->showcase_status?"DÉMO · E pour jouer":"VOL LIBRE";
 label(c,c->w-20-text_width(0,state),15,0,state,v->status==L3_MINI_WON?GREEN_LIGHT:GOLD);
 label(c,18,72,0,"ÉQUIPAGE",GOLD);label(c,18,163,0,"SCORE",MUTED);
 label(c,18,247,0,"PROTECTION",MUTED);label(c,c->w-116,72,0,"VAGUE",GOLD);
 label(c,c->w-116,168,0,"CIBLES",MUTED);
 label(c,18,c->h-32,0,"WASD / flèches  Piloter",MUTED);centered(c,0,c->h-32,c->w,0,"E / espace  Tirer",TEXT);label(c,c->w-18-text_width(0,"R  Rejouer    Q  Retour"),c->h-32,0,"R  Rejouer    Q  Retour",MUTED);
 return;
 }
 int x=18,y=72;lives(c,x+10,y+37,v->lives,0);y+=91;
 char n[30];snprintf(n,sizeof(n),"%u",v->score);label(c,x,y+21,text_width(2,n)>100?1:2,n,WHITE);
 label(c,x,y+108,0,v->shield_ticks?"BOUCLIER":"Standard",v->shield_ticks?BLUE:FAINT);
 label(c,x,y+145,0,v->double_ticks?"DOUBLE TIR":"",GOLD);
 x=c->w-116;y=72;snprintf(n,sizeof(n),"%u / 3",v->wave);label(c,x,y+25,2,n,WHITE);
 snprintf(n,sizeof(n),"%u",v->kills);label(c,x,y+119,2,n,WHITE);
 if(v->boss_hp){label(c,x,y+188,0,"GARDIEN",RED_LIGHT);int fill=min(v->boss_hp,24);box(c,x,y+218,98,6,WELL);box(c,x,y+218,98*fill/24,6,RED);}
}
static void scene_hud(Canvas *c,const L3Game *g,const L3ArcadeView *all,unsigned chrome){
 unsigned k=all->kind,status=all->status;
 int margin=unit(c,18),top=unit(c,10),height=unit(c,64),f=font_index(c,0);
 if(!chrome){char info[120];
 if(k==L3_ARCADE_SIMON){const L3SimonView *s=&all->content.simon;snprintf(info,sizeof(info),"%s   ·   Manche %u / 8   ·   Réponses %u / %u",s->phase==L3_SIMON_INPUT?"À VOUS DE RÉPÉTER":s->phase==L3_SIMON_ROUND_OK?"BIEN JOUÉ":"OBSERVEZ LES CRISTAUX",s->sequence_length,s->input_index,s->sequence_length);}
 else if(k==L3_ARCADE_PLATFORM){const L3PlatformView *v=&all->content.platform;snprintf(info,sizeof(info),"Étage %u / 4   ·   Reprise à l'étage %u   ·   Sauts %u",v->floor,v->checkpoint_floor,v->jumps);lives(c,c->w-margin-unit(c,92),top+unit(c,20),v->lives,1);}
 else {const L3MiniView *v=&all->content.grid;snprintf(info,sizeof(info),"Lueurs retrouvées  %u / %u   ·   Les lanternes éloignent les fantômes",v->progress,v->target);lives(c,c->w-margin-unit(c,92),top+unit(c,20),v->lives,1);}
 label(c,margin+unit(c,17),top+unit(c,34),f,info,GOLD);return;
 }
 memset(c->pixels,0,(size_t)c->w*c->h);panel(c,margin,top,c->w-2*margin,height);
 label(c,margin+unit(c,17),top+unit(c,7),font_index(c,1),titles[k],WHITE);
 int bh=unit(c,status==L3_MINI_RUNNING?64:82),by=c->h-bh-unit(c,10);panel(c,margin,by,c->w-2*margin,bh);
 if(status!=L3_MINI_RUNNING){label(c,margin+unit(c,17),by+unit(c,8),font_index(c,1),status==L3_MINI_WON?"Défi réussi · Votre souvenir est conservé":"Essai terminé · R pour recommencer",status==L3_MINI_WON?GREEN_LIGHT:RED_LIGHT);
  if(status==L3_MINI_WON)label(c,margin+unit(c,17),by+unit(c,34),f,l3_activity_reward(k),TEXT);
 }else{
  const char *controls=k==L3_ARCADE_SIMON?"W / haut : rouge    D / droite : vert    S / bas : bleu    A / gauche : or":k==L3_ARCADE_PLATFORM?"WASD : marcher / échelles    E / espace : sauter":"WASD / flèches : explorer la maison";
  label(c,margin+unit(c,17),by+unit(c,8),f,controls,TEXT);
 }
 const char *bottom=g->showcase_status==3?"Visite en pause · E pour jouer · Q pour revenir":g->showcase_status?"DÉMO · E pour jouer · Q pour revenir":"R : recommencer    Q : revenir au même endroit";
 label(c,margin+unit(c,17),c->h-unit(c,35),f,bottom,MUTED);
}
void l3_mini_ui_close(L3Render *r){free(r->mini_chrome_pixels);r->mini_chrome_pixels=NULL;r->mini_chrome_key=0;r->mini_page_chrome[0]=r->mini_page_chrome[1]=0;free(r->mini_pixels);r->mini_pixels=NULL;r->mini_canvas_stamp=0;for(unsigned i=0;i<2;i++){free(r->mini_shadow[i]);r->mini_shadow[i]=NULL;r->mini_stamp[i]=0;}}
int l3_mini_ui_open(L3Render *r){
 if((r->width!=400||r->height!=240)&&(r->width!=640||r->height!=360))return 0;
 size_t bytes=(size_t)r->width*2*r->height*2;if(!bytes||bytes>MINI_PAGE)return 0;
 r->mini_canvas_stamp=0;r->mini_stamp[0]=r->mini_stamp[1]=0;r->mini_rasterizations=0;
 r->mini_chrome_key=r->mini_page_chrome[0]=r->mini_page_chrome[1]=r->mini_chrome_rebuilds=0;r->mini_scan_bytes=r->mini_restore_bytes=0;
 r->mini_raster_seconds=r->mini_publish_seconds=0;
 r->mini_chrome_pixels=calloc(1,bytes);r->mini_pixels=calloc(1,bytes);r->mini_shadow[0]=calloc(1,bytes);r->mini_shadow[1]=calloc(1,bytes);
 if(!r->mini_chrome_pixels||!r->mini_pixels||!r->mini_shadow[0]||!r->mini_shadow[1]){l3_mini_ui_close(r);return 0;}
 static const unsigned char old[16][3]={{15,24,35},{35,50,64},{246,239,213},{247,188,77},{76,140,158},{113,192,139},{124,197,245},{198,120,175},{231,139,90},{168,155,211},{78,115,104},{118,103,157},{210,89,114},{76,173,183},{215,210,128},{230,234,243}};
 for(unsigned i=0;i<112;i++){const unsigned char *p=i<16?old[i]:puzzle_palette[i-16];r->hud_palette.rgb[16+i]=(p[0]>>2)<<12|(p[1]>>2)<<6|(p[2]>>2);}
 if(!r->host&&ioctl(r->fd,PRODOCK_PALETTE,&r->hud_palette)){r->failed=1;l3_mini_ui_close(r);return 0;}return 1;
}
static unsigned hash_view(const L3MiniView *v,unsigned mode,unsigned won,unsigned showcase,unsigned stage){
 unsigned h=2166136261u;const uint32_t a[]={mode,v->status,v->score,v->target,v->moves,v->width,v->height,v->lives,v->progress,won,showcase,stage};
 for(unsigned i=0;i<sizeof(a)/sizeof(*a);i++)h=(h^a[i])*16777619u;
 for(unsigned i=0;i<400;i++){const L3MiniCell *a=v->cells+i;h=(h^a->value)*16777619u;h=(h^a->kind^((unsigned)a->color<<8)^((unsigned)a->flags<<16)^((unsigned)a->glyph<<24))*16777619u;}return h?h:1;
}
typedef struct {int x,y,w,h;} DirtyRect;
static unsigned hud_rects(const Canvas *c,unsigned kind,DirtyRect *rect){
 if(kind==L3_ARCADE_SHOOTER){rect[0]=(DirtyRect){0,48,136,292};rect[1]=(DirtyRect){c->w-136,48,136,292};return 2;}
 int margin=unit(c,18),top=unit(c,10),x=margin+unit(c,17),sz=unit(c,8);
 rect[0]=(DirtyRect){x,top+unit(c,34),c->w-x,puzzle_fonts[font_index(c,0)].height};
 rect[1]=(DirtyRect){c->w-margin-unit(c,92)-sz,top+unit(c,20)-sz/2,2*(sz*2+6)+2*sz+1,sz+sz/2+1};return kind==L3_ARCADE_SIMON?1:2;
}
static void restore_chrome(Canvas *c,unsigned kind){
 DirtyRect rect[2];unsigned n=hud_rects(c,kind,rect);
 for(unsigned i=0;i<n;i++)for(int y=rect[i].y;y<rect[i].y+rect[i].h;y++){
  size_t at=(size_t)y*c->w+rect[i].x;memcpy(c->pixels+at,c->r->mini_chrome_pixels+at,(size_t)rect[i].w);c->r->mini_restore_bytes+=rect[i].w;
 }
}
static void upload(Canvas *c,unsigned page,unsigned stamp,unsigned chrome,unsigned kind){
 L3Render *r=c->r;int force=!r->mini_stamp[page];unsigned bytes=0;
 DirtyRect rect[2];unsigned n=1;
 if(!force&&chrome&&r->mini_page_chrome[page]==chrome)n=hud_rects(c,kind,rect);
 else rect[0]=(DirtyRect){0,0,c->w,c->h};
 for(unsigned i=0;i<n;i++){
  int x0=rect[i].x&~3,x1=(rect[i].x+rect[i].w+3)&~3;
  for(int y=rect[i].y;y<rect[i].y+rect[i].h;y++){
   size_t at=(size_t)y*c->w;const uint8_t *source=r->mini_pixels+at;uint8_t *shadow=r->mini_shadow[page]+at;
   r->mini_scan_bytes+=(unsigned)(x1-x0);
   if(!force&&!memcmp(source+x0,shadow+x0,(size_t)(x1-x0)))continue;
   for(int x=x0;x<x1;x+=4){uint32_t a,b;memcpy(&a,source+x,4);memcpy(&b,shadow+x,4);if(force||a!=b){
    *(volatile uint32_t *)(r->memory+MINI_BASE+page*MINI_PAGE+at+(unsigned)x)=a;memcpy(shadow+x,&a,4);bytes+=4;
   }}
  }
 }
 r->mini_page_chrome[page]=chrome;r->mini_stamp[page]=stamp;if(bytes){r->mini_uploads++;r->mini_bytes+=bytes;}
}
int l3_mini_ui_prepare(L3Render *r,const L3Game *g,struct prodock_scene *scene){
 if(!g->activities.arcade.active)return 0;L3ArcadeView all;if(!l3_arcade_view(&g->activities.arcade,&all))return 0;
 /* Counters and completion text follow the displayed collection, while
  * engine rewards/inputs and the actual save state stay immediate. */
 if(all.kind==L3_ARCADE_MAZE&&r->maze_events.valid){
  unsigned pending,lives;if(!l3_maze_events_pending(&r->maze_events,r->presentation_seconds,&pending)||pending>all.content.grid.progress||!l3_maze_events_pending_lives(&r->maze_events,r->presentation_seconds,&lives)||lives+all.content.grid.lives>3)return 0;
  all.content.grid.progress=(uint16_t)(all.content.grid.progress-pending);
  all.content.grid.lives=(uint16_t)(all.content.grid.lives+lives);
  if(pending&&all.status==L3_MINI_WON)all.status=all.content.grid.status=L3_MINI_RUNNING;
  if(lives&&all.status==L3_MINI_LOST)all.status=all.content.grid.status=L3_MINI_RUNNING;
 }
 unsigned k=all.kind;L3MiniView v;memset(&v,0,sizeof(v));
 if(k<4)v=all.content.grid;
 else if(k==L3_ARCADE_MAZE){const L3MiniView *m=&all.content.grid;v.status=m->status;v.progress=m->progress;v.target=m->target;v.lives=m->lives;}
 else if(k==L3_ARCADE_SIMON){const L3SimonView *s=&all.content.simon;v.status=s->grid.status;v.moves=s->phase==L3_SIMON_INPUT?1:s->phase==L3_SIMON_ROUND_OK?2:0;v.cells[398].value=(s->sequence_length<<8)|s->input_index;}
 else if(k==L3_ARCADE_SHOOTER){const L3ShooterView *s=&all.content.shooter;v.status=s->status;v.score=s->score;v.progress=s->wave;v.lives=s->lives;v.moves=s->kills;v.cells[399].value=(!!s->shield_ticks)|((!!s->double_ticks)<<1);v.cells[398].value=s->boss_hp;}
 else{const L3PlatformView *p=&all.content.platform;v.status=p->status;v.progress=p->floor;v.lives=p->lives;v.moves=p->jumps;v.cells[399].value=p->checkpoint_floor;}
 Canvas c={r,r->mini_pixels,(int)r->width*2,(int)r->height*2,r->height==360?3:2,r->height==360};unsigned page=r->frame&1,stamp=hash_view(&v,k,g->activities.arcade.won,g->showcase_status,g->showcase_stage);
 unsigned chrome=k<4?0:1+k+8*all.status+32*g->showcase_status;
 if(r->mini_stamp[page]!=stamp){
  /* The CPU canvas is independent of either displayed page. A page may
   * already contain A while the latest canvas contains B; only a required
   * upload needs the requested canvas. The second page reuses that canvas. */
  if(r->mini_canvas_stamp!=stamp){
   double started=ui_seconds();
   if(k<4){r->mini_chrome_key=0;memcpy(r->mini_pixels,c.w==800?puzzle_background_800:puzzle_background_1280,(size_t)c.w*c.h);header(&c,k,v.status,g->activities.arcade.won&(1u<<k));int sx=c.w-unit(&c,244);board(&c,&v,sx);sidebar(&c,g,&v,sx);footer(&c,g);}
   else{
    if(r->mini_chrome_key!=chrome||!r->mini_canvas_stamp){
     if(k==L3_ARCADE_SHOOTER)shooter_hud(&c,g,&all.content.shooter,1);else scene_hud(&c,g,&all,1);
     memcpy(r->mini_chrome_pixels,r->mini_pixels,(size_t)c.w*c.h);r->mini_chrome_key=chrome;r->mini_chrome_rebuilds++;
    }else restore_chrome(&c,k);
    if(k==L3_ARCADE_SHOOTER)shooter_hud(&c,g,&all.content.shooter,0);else scene_hud(&c,g,&all,0);
   }
   r->mini_canvas_stamp=stamp;r->mini_rasterizations++;
   r->mini_raster_seconds+=ui_seconds()-started;
  }
  double started=ui_seconds();
  upload(&c,page,stamp,chrome,k);
  r->mini_publish_seconds+=ui_seconds()-started;
 }
 uint32_t *l=scene->layers[k==L3_ARCADE_SHOOTER?3:0];l[0]=PRODOCK_GPU_BASE+MINI_BASE+page*MINI_PAGE;l[1]=(unsigned)c.w|((unsigned)c.h<<16);l[2]=0;l[3]=l[1];l[4]=0;l[5]=(unsigned)c.w;l[6]=3;scene->layers_enabled=1;r->last_scene=*scene;return 1;
}

#include "l3_puzzle_ui.inc"
