#include "l3_festival.h"
#include "ui_clear_rows.h"
#include "festival_art.h"
#include "l3_table_progress.h"
#include "memory_progress.h"
#include "luma3d_sky_assets.h"
/* VILLAGE_SHARED_SKY_01 */
#include "festival_lighting.h"
#include "festival_hud_style.h"
#include "festival_surface_uv.h"
#include "festival_cull.h"
#include "generated.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>
#define COUNT(a) (sizeof(a)/sizeof(*(a)))
#define ATLAS (17u<<20)
#define CHROMA (ATLAS+524288u)
#define GEOMETRY (ATLAS+786432u)
#define SKY ((18u<<20)+(1u<<19))
/* Sky extent is checked by its single owning module. */
/* East stand lies outside the old ±14m collision domain: every previously
   valid garden save remains valid. It can be reached from x=14 within3m. */
static const float sites[5][2]={{-8,-8},{8,-8},{8,8},{-8,8},{16.5f,0}};
static const char *names[5]={"OTHELLO - Le jardin des contraires","SOLITAIRE - Les cartes du voyageur","CHROMA - La ronde des couleurs","PENDU - Les mots des etoiles","MEMORY - Les constellations"};
static unsigned rgb(unsigned r,unsigned g,unsigned b){return (r>>3)<<11|(g>>2)<<5|(b>>3);}
static float clamp(float v,float a,float b){return fminf(b,fmaxf(a,v));}
static float ease(float v){v=clamp(v,0,1);return v*v*(3-2*v);}
/* ---- Aggregate CPU profile (owned/l3_festival_profile.h) ----------------
 * The profile only measures. It never touches a pixel, a GPU command,
 * a rule or an animation: it opens and closes scopes around the
 * existing code and counts the bytes that already went to the GPU.
 * The clock is the same monotonic source as the renderer metrics;
 * l3_measure_now() answers NAN when it fails and the profile then
 * reports the measurement as unusable instead of a plausible value. */
static double festival_profile_clock(void *ctx){(void)ctx;return l3_measure_now();}
/* Candidate overlay hooks, defined by the candidate overlay block. */
void festival_overlay_reset(L3Festival *f);
void festival_overlay_close(L3Festival *f);
static void reset_draw(L3Festival *f){f->revision++;f->base_ready[0]=f->base_ready[1]=0;f->ui_page[0]=f->ui_page[1]=0;f->poses_n=f->old_n=0;f->page_valid[0]=f->page_valid[1]=0;festival_overlay_reset(f);}
L3Festival *l3_festival_create(int automatic){
    L3Festival *f=calloc(1,sizeof(*f));if(!f)return NULL;
    l3_profile_reset(&f->profile);
    f->automatic=!!automatic;f->kind=L3_TABLE_COUNT;f->source=255;f->baked_kind=255;f->z=13;f->camera_z=21;f->revision=1;
    for(unsigned k=0;k<L3_TABLE_COUNT;k++)if(!l3_table_init(&f->games[k],k,17+k*31)){free(f);return NULL;}
    if(!l3_memory_scene_init(&f->memory,31337,automatic)){free(f);return NULL;}
    return f;
}
void l3_festival_destroy(L3Festival *f){
    if(!f)return;
    l3_profile_report(&f->profile);
    l3_memory_scene_close(&f->memory);festival_overlay_close(f);free(f->ui);free(f->background);free(f);
}
void l3_festival_enter(L3Festival *f,unsigned game){
    if(!f)return;
    if(game==L3_FESTIVAL_MEMORY||f->kind==L3_FESTIVAL_MEMORY){
        f->assets=0;f->geometry_ready=f->mesh_count=0;l3_memory_scene_invalidate(&f->memory);
    }
    f->active=1;f->kind=game==L3_FESTIVAL_MEMORY?game:game<L3_TABLE_COUNT?game:L3_TABLE_COUNT;
    if(f->kind==L3_FESTIVAL_MEMORY){
        f->memory_visited=1;f->memory.automatic=f->automatic;f->memory.escape=f->memory.exit_requested=0;
        if(f->automatic&&f->memory.game.phase==L3_MEMORY_WON){f->memory.elapsed=f->memory.duration;l3_memory_scene_action(&f->memory,(L3MemoryAction){L3_MEMORY_NEXT,0});}
    }
    if(game<4&&f->automatic&&f->games[game].status)l3_table_init(&f->games[game],game,f->games[game].seed+1);
    f->selection=f->row=f->turns=f->escape=0;f->source=255;f->action_time=f->scene_time=0;f->transition=1;reset_draw(f);
    if(game<L3_TABLE_COUNT){f->visited|=1u<<game;l3_table_view(&f->games[game],&f->view,0);}l3_card_motion_begin(&f->motion,game,f->poses,f->poses_n,&f->view,&f->trace,1);
}
void l3_festival_leave(L3Render *r,L3Festival *f){
    if(!f)return;l3_memory_scene_invalidate(&f->memory);f->active=0;l3_card_motion_reset(&f->motion);f->assets=0;f->geometry_ready=f->mesh_count=0;r->sky_region=~0u;r->hud_stamp[0]=r->hud_stamp[1]=0;r->mini_stamp[0]=r->mini_stamp[1]=0;
    reset_draw(f);
}
static int act(L3Festival *f,L3TableAction a){
    if(f->kind>=L3_TABLE_COUNT)return 0;
    if(!l3_table_action(&f->games[f->kind],a,&f->trace))return 0;
    memcpy(f->old,f->poses,f->poses_n*sizeof(*f->old));f->old_n=f->poses_n;f->transition=0;f->action_time=0;l3_card_motion_begin(&f->motion,(unsigned)f->kind,f->old,f->old_n,&f->view,&f->trace,0);
    l3_table_view(&f->games[f->kind],&f->view,0);f->revision++;f->turns++;
    if(f->view.status==L3_TABLE_WON)f->won|=1u<<f->kind;
    return 1;
}
static unsigned nearest(const L3Festival *f){unsigned best=0;float distance=1e9f;for(unsigned k=0;k<L3_FESTIVAL_STANDS;k++){float d=hypotf(f->x-sites[k][0],f->z-sites[k][1]);if(d<distance){distance=d;best=k;}}return best;}
static int garden_blocked(float x,float z){
    if(fabsf(x)<2.65f&&fabsf(z)<2.65f)return 1;
    for(unsigned k=0;k<L3_FESTIVAL_STANDS;k++){
        float dx=x-sites[k][0],dz=z-sites[k][1];
        if(fabsf(dx)<1.2f&&fabsf(dz)<.9f)return 1;
        for(int a=-1;a<=1;a+=2)for(int b=-1;b<=1;b+=2)if(fabsf(dx-a*1.9f)<.425f&&fabsf(dz-b*1.9f)<.425f)return 1;
    }return 0;
}
int l3_festival_save(const L3Festival *f,const char *path){
    if(!f||!path)return 0;L3TableProgress p={0};memcpy(p.games,f->games,sizeof(p.games));
    p.visited=f->visited;p.won=f->won;p.kind=f->kind==L3_FESTIVAL_MEMORY?L3_FESTIVAL_GARDEN:f->kind;p.map=f->map;p.x_mm=(int32_t)lroundf(f->x*1000);p.z_mm=(int32_t)lroundf(f->z*1000);
    return l3_table_progress_save(&p,path);
}
int l3_festival_load(L3Festival *f,const char *path){
    if(!f||!path)return 0;L3TableProgress p;
    if(!l3_table_progress_load(&p,path))return 0;
    float x=p.x_mm/1000.0f,z=p.z_mm/1000.0f;if(garden_blocked(x,z))return 0;
    memcpy(f->games,p.games,sizeof(f->games));f->visited=p.visited;f->won=p.won;f->map=p.map;f->x=x;f->z=z;
    f->light_mood=p.map?1:0;
    f->vx=f->vz=f->move_x=f->move_z=f->held_until=0;f->camera_x=x;f->camera_z=z+10;f->geometry_ready=0;
    unsigned automatic=f->automatic;f->automatic=0;l3_festival_enter(f,p.kind);f->automatic=automatic;return 1;
}
int l3_festival_memory_save(const L3Festival *f,const char *path){
    if(!f)return 0;L3MemoryProgress p={.game=f->memory.game,.visited=f->memory_visited};return l3_memory_progress_save(&p,path);
}
int l3_festival_memory_load(L3Festival *f,const char *path){
    if(!f)return 0;L3MemoryProgress p;if(!l3_memory_progress_load(&p,path))return 0;
    uint8_t bytes[128];if(l3_memory_encode(&p.game,bytes,sizeof bytes)!=sizeof bytes||!l3_memory_scene_restore(&f->memory,bytes,sizeof bytes))return 0;
    f->memory_visited=p.visited;return 1;
}
void l3_festival_key(L3Render *r,L3Festival *f,int c){
    if(!f||!f->active)return;
    if(f->kind==L3_FESTIVAL_MEMORY){
        l3_memory_scene_key(&f->memory,c);f->automatic=f->memory.automatic;
        if(f->memory.exit_requested){f->automatic=0;l3_festival_enter(f,L3_FESTIVAL_GARDEN);}
        return;
    }
    if(f->automatic){f->automatic=0;f->move_x=f->move_z=0;f->escape=c==27?3:0;f->revision++;return;}
    if(c==9 || ((c=='q'||c=='Q')&&f->kind!=L3_TABLE_HANGMAN)){
        if(f->kind<4)l3_festival_enter(f,4);else l3_festival_leave(r,f);return;
    }
    if(f->escape){
        unsigned state=f->escape;
        if((state==1||state==3)&&c=='['){f->escape=state+1;return;}
        f->escape=0;
        if(state==2||state==4){
            /* Consume a complete takeover key, and never guess a letter
             * from an arrow escape sequence in the word game. */
            if(state==4||f->kind==L3_TABLE_HANGMAN)return;
            c=c=='A'?'w':c=='B'?'s':c=='C'?'d':c=='D'?'a':0;
        }
    }
    if(c==27){f->escape=1;return;}
    if(f->kind==4){
        if(c=='m'||c=='M'){f->map^=1;f->geometry_ready=0;reset_draw(f);return;}
        if(c=='e'||c=='E'||c==' '){unsigned k=nearest(f);if(hypotf(f->x-sites[k][0],f->z-sites[k][1])<3)l3_festival_enter(f,k==4?L3_FESTIVAL_MEMORY:k);return;}
        if(c=='w'||c=='a'||c=='s'||c=='d'){f->move_x=c=='a'?-1:c=='d'?1:0;f->move_z=c=='w'?-1:c=='s'?1:0;f->held_until=f->time+.18f;}return;
    }
    if(f->kind==L3_TABLE_HANGMAN){
        if(c>='a'&&c<='z')c-=32;
        if(c>='A'&&c<='Z'){act(f,(L3TableAction){.op=L3_TABLE_GUESS,.value=(uint8_t)c});return;}
    }
    if(c=='r'||c=='R'||((c==10||c==13)&&f->view.status)){
        unsigned k=f->kind;l3_table_init(&f->games[k],k,f->games[k].seed+1);l3_festival_enter(f,k);return;
    }
    if(f->view.status)return;
    if(f->kind==L3_TABLE_OTHELLO){
        if(c=='a'&&f->selection%8)f->selection--;if(c=='d'&&f->selection%8<7)f->selection++;
        if(c=='w'&&f->selection>=8)f->selection-=8;if(c=='s'&&f->selection<56)f->selection+=8;
        if(c=='e'||c==' '||c==10||c==13){if(f->view.turn==0)act(f,(L3TableAction){.op=L3_TABLE_PLACE,.index=f->selection});}
        if(c=='p'&&f->view.turn==0)act(f,(L3TableAction){.op=L3_TABLE_PASS});
    }else if(f->kind==L3_TABLE_CHROMA){
        unsigned n=f->view.data.chroma.count[0];
        if(c=='a'&&f->selection)f->selection--;if(c=='d'&&f->selection+1<n)f->selection++;
        if(c=='f')f->color=(f->color+1)%4;
        if(f->view.turn==0){
            if(c=='e'||c==' '||c==10||c==13)act(f,(L3TableAction){.op=L3_TABLE_PLAY,.index=f->selection,.value=f->color});
            if(c=='p')act(f,(L3TableAction){.op=f->view.data.chroma.drew?L3_TABLE_PASS:L3_TABLE_DRAW});
        }
        n=f->view.data.chroma.count[0];if(n&&f->selection>=n)f->selection=n-1;else if(!n)f->selection=0;
    }else if(f->kind==L3_TABLE_SOLITAIRE){
        const L3Solitaire *s=&f->view.data.solitaire;
        if(c=='a'&&f->selection)f->selection--;if(c=='d'&&f->selection<12)f->selection++;
        if(c=='w'&&f->row)f->row--;if(c=='s'&&f->row<51)f->row++;
        if(f->selection<7){if(!s->count[f->selection])f->row=0;else if(f->row>=s->count[f->selection])f->row=s->count[f->selection]-1;}
        if(c=='p')act(f,(L3TableAction){.op=L3_TABLE_DRAW});
        if(c=='f'){f->source=255;}
        if(c=='e'||c==' '||c==10||c==13){
            if(f->selection==8)act(f,(L3TableAction){.op=L3_TABLE_DRAW});
            else if(f->source==255){f->source=f->selection;f->source_row=f->row;}
            else if(act(f,(L3TableAction){.op=L3_TABLE_MOVE,.from=f->source,.to=f->selection,.index=f->source_row}))f->source=255;
        }
    }
    f->revision++;
}
void l3_festival_step(L3Festival *f,float dt){
    if(!f||!f->active||!isfinite(dt)||dt<=0)return;dt=fminf(dt,.1f);f->time+=dt;f->scene_time+=dt;f->transition=fminf(1,f->transition+dt/.32f);
    l3_card_motion_step(&f->motion,dt);f->light_mood=festival_lighting_step(f->light_mood,f->map,dt);
    if(f->kind==L3_FESTIVAL_MEMORY){
        if(f->memory_sample_limit){
            if((f->memory.actions<f->memory_sample_limit&&f->memory.game.phase!=L3_MEMORY_WON)||f->memory.elapsed<f->memory.duration)l3_memory_scene_step(&f->memory,dt);
            return; /* Finish last legal animation, retain this table for both pages. */
        }
        l3_memory_scene_step(&f->memory,dt);
        if(f->automatic&&f->memory.game.phase==L3_MEMORY_WON&&f->memory.elapsed==f->memory.duration&&f->memory.wait>=1.5f){
            f->stage=0;f->map^=1;l3_festival_enter(f,L3_FESTIVAL_GARDEN);
        }
        return;
    }
    if(f->sample_limit&&f->kind<4&&(f->turns>=f->sample_limit||f->view.status))return;
    if(f->kind==4){
        float dx=f->time<f->held_until?f->move_x:0,dz=f->time<f->held_until?f->move_z:0;
        if(f->automatic){dx=sites[f->stage%L3_FESTIVAL_STANDS][0]-f->x;dz=sites[f->stage%L3_FESTIVAL_STANDS][1]-f->z;float len=hypotf(dx,dz);
            if(len<(f->stage%L3_FESTIVAL_STANDS==4?3.0f:2.3f)){unsigned k=f->stage%L3_FESTIVAL_STANDS;l3_festival_enter(f,k==4?L3_FESTIVAL_MEMORY:k);return;}dx/=len;dz/=len;}
        f->vx+=(dx*4-f->vx)*fminf(1,dt*8);f->vz+=(dz*4-f->vz)*fminf(1,dt*8);
        float x=clamp(f->x+f->vx*dt,-14,14),z=clamp(f->z+f->vz*dt,-14,14);
        /* Central fountain collision; a circular path exists on either side. */
        if(!garden_blocked(x,f->z))f->x=x;
        if(!garden_blocked(f->x,z))f->z=z;
        if(hypotf(f->vx,f->vz)>.1f)f->yaw=atan2f(f->vx,f->vz);
        f->camera_x+=(f->x-f->camera_x)*fminf(1,dt*3);f->camera_z+=(f->z+10-f->camera_z)*fminf(1,dt*3);
        return;
    }
    f->action_time+=dt;
    int opponent=(f->kind==L3_TABLE_OTHELLO||f->kind==L3_TABLE_CHROMA)&&f->view.turn!=0;
    if((f->automatic||opponent)&&f->action_time>=.7f){
        f->action_time=0;
        if(f->view.status){if(f->automatic&&f->scene_time>4){f->stage=(f->stage+1)%L3_FESTIVAL_STANDS;if(!f->stage){f->map^=1;f->geometry_ready=0;}l3_festival_enter(f,4);}return;}
        L3TableAction action;
        if(l3_table_demo_action(&f->games[f->kind],&action)){if(!act(f,action))f->automatic=0;}
        else if(f->automatic){f->stage=(f->stage+1)%L3_FESTIVAL_STANDS;l3_festival_enter(f,4);}
        if(f->automatic&&f->turns>=96){f->stage=(f->stage+1)%L3_FESTIVAL_STANDS;l3_festival_enter(f,4);} /* bounded visit, unfinished games remain resumable */
    }
}
static int expand(uint16_t *dst,unsigned pixels,const uint32_t *src,unsigned n){unsigned at=0;for(unsigned i=0;i<n;i++){unsigned k=src[i]>>16;if(!k||k>pixels-at)return 0;for(unsigned j=0;j<k;j++)dst[at++]=(uint16_t)src[i];}return at==pixels;}
static void publish(L3Render *r,unsigned offset,const void *src,unsigned bytes){double measured=r->festival_metrics?l3_measure_now():0;for(unsigned i=0;i<bytes;i+=4){uint32_t v;memcpy(&v,(const uint8_t*)src+i,4);*(volatile uint32_t*)(r->memory+offset+i)=v;}if(r->festival_metrics)l3_measure_publish(r,offset,bytes,measured,(17u<<20)+786432u);if(r->festival_metrics&&r->festival)l3_profile_bytes(&r->festival->profile,L3_PROFILE_BYTES_PUBLISHED,bytes);}
/* The seven unused classic tiles 57..63 hold 27 antialiased 32x32
 * glyphs. Build once, before the existing atlas upload; no extra VRAM. */
static void hangman_glyphs(uint16_t *atlas){
    uint8_t glyph[32*32];
    for(unsigned ch=0;ch<27;ch++){
        memset(glyph,0,sizeof(glyph));char text[2]={(char)(ch<26?'A'+ch:'_'),0};
        l3_ui_text(glyph,32,32,0,0,2,text,78,0);
        unsigned left=32,right=0;
        for(unsigned y=0;y<32;y++)for(unsigned x=0;x<32;x++)if(glyph[y*32+x]){if(x<left)left=x;if(x>right)right=x;}
        unsigned tile=57+ch/4,u=(tile%8)*64+(ch%2)*32,v=(tile/8)*64+((ch/2)%2)*32;
        int shift=left<32?(32-(int)(right-left+1))/2-(int)left:0;
        for(unsigned y=0;y<32;y++)for(unsigned x=0;x<32;x++){
            int sx=(int)x-shift;unsigned color=sx>=0&&sx<32?glyph[y*32+(unsigned)sx]:0;
            unsigned alpha=color==78?15:color==77?10:color==73?5:0;
            atlas[(v+y)*512+u+x]=(uint16_t)(alpha?(alpha<<12)|0xfd9u:0);
        }
    }
}
static int art_inner(L3Render *r,L3Festival *f){
    if(f->assets)return 1;double measure_start=r->festival_metrics?l3_measure_now():0;uint64_t measure_bytes=r->festival_publish_bytes,measure_atlas=r->festival_atlas_bytes;double measure_atlas_seconds=r->festival_atlas_seconds;unsigned w=r->width*2,h=r->height*2;
    if(!f->ui||f->ui_w!=w||f->ui_h!=h){free(f->ui);f->ui=calloc(w,h);f->ui_w=f->ui?w:0;f->ui_h=f->ui?h:0;}
    if(!f->background||f->background_w!=w||f->background_h!=h){free(f->background);f->background=malloc(w*h*2);f->background_w=f->background?w:0;f->background_h=f->background?h:0;}
    uint16_t *work=malloc(524288);if(!work||!f->ui||!f->background){free(work);return 0;}
    int ok=expand(work,262144,festival_classic,COUNT(festival_classic));if(ok){hangman_glyphs(work);publish(r,ATLAS,work,524288);}
    ok=ok&&expand(work,131072,festival_chroma,COUNT(festival_chroma));if(ok)publish(r,CHROMA,work,262144);free(work);
    ok=ok&&(w==800?expand(f->background,w*h,festival_table_800,COUNT(festival_table_800)):expand(f->background,w*h,festival_table_1280,COUNT(festival_table_1280)));
    if(!ok)return 0;publish(r,SKY,l3_sky_assets.texture,l3_sky_assets.texture_bytes);publish(r,SKY+l3_sky_assets.texture_bytes,l3_sky_assets.vertices,l3_sky_assets.vertices_bytes);publish(r,SKY+l3_sky_assets.texture_bytes+l3_sky_assets.vertices_bytes,l3_sky_assets.faces,l3_sky_assets.faces_bytes);publish(r,6u<<20,f->background,w*h*2);gpu_v1_invalidate(&r->gpu);f->assets=1;f->baked_kind=255;reset_draw(f);l3_measure_loaded(r,f->kind,measure_start,measure_bytes,measure_atlas,measure_atlas_seconds);return 1;
}
static int art(L3Render *r,L3Festival *f){
    if(f->assets)return 1;
    l3_profile_begin(&f->profile,L3_PROFILE_ART,r->feed_seconds);
    int ok=art_inner(r,f);
    l3_profile_end(&f->profile,r->feed_seconds);
    return ok;
}
static int __attribute__((unused)) rectangle(L3Render *r,int x,int y,int w,int h,unsigned color,unsigned alpha){
    gpu_material m={.alpha=alpha,.color=color,.r=256,.g=256,.b=256};gpu_vertex q[4]={{.x=x,.y=y},{.x=x+w,.y=y},{.x=x+w,.y=y+h},{.x=x,.y=y+h}};
    return gpu_v1_material(&r->gpu,&m)&&gpu_v1_quad(&r->gpu,q);
}
static void pose(L3Festival *f,int id,int tile,int chroma,float x,float y,float w,float h,float alpha){if(f->poses_n<COUNT(f->poses))f->poses[f->poses_n++]=(L3FestivalPose){id,tile,chroma,x,y,w,h,alpha};}
static void positions(L3Festival *f){
    f->poses_n=0;
    if(f->kind==0){const L3Othello *s=&f->view.data.othello;
        for(unsigned i=0;i<64;i++)if(f->view.legal[i])pose(f,2000+i,56,0,250+i%8*40,46+i/8*40,20,20,100);
        pose(f,2200,56,0,240+f->selection%8*40,36+f->selection/8*40,40,40,160);
        for(unsigned i=0;i<64;i++)if(s->board[i])pose(f,i,52+s->board[i],0,240+(i%8)*40,36+(i/8)*40,40,40,256);}
    else if(f->kind==1){const L3Solitaire *s=&f->view.data.solitaire;
        for(unsigned i=0;i<4;i++)pose(f,1500+i,i*13,0,349+i*83,8,58,78,48);
        if(s->stock_count)pose(f,300,52,0,100,8,58,78,256);
        if(s->waste_count){unsigned id=s->waste[s->waste_count-1];pose(f,id,id,0,183,8,58,78,256);}
        for(unsigned i=0;i<4;i++)if(s->found[i]){unsigned id=i*13+s->found[i]-1;pose(f,id,id,0,349+i*83,8,58,78,256);}
        for(unsigned c=0;c<7;c++)for(unsigned j=0;j<s->count[c];j++){
            unsigned id=s->tableau[c][j];float gap=s->count[c]>1?fminf(17,208.0f/(s->count[c]-1)):17;
            pose(f,j<s->hidden[c]?(int)(400+c*52+j):(int)id,j<s->hidden[c]?52:(int)id,0,100+c*83,106+j*gap,58,78,256);
        }
    }else if(f->kind==2){const L3Chroma *s=&f->view.data.chroma;
        pose(f,300,52,0,280,100,68,92,256);
        if(s->discard_count){unsigned id=s->discard[s->discard_count-1],co=l3_table_card_color(id),v=l3_table_card_value(id);pose(f,id,(co<4?co:s->color)*16+v,1,420,100,68,92,256);}
        unsigned n=s->count[0];float gap=n>12?570.0f/fmaxf(1,(float)n-1):46;
        float start=400-((n?n-1:0)*gap+58)/2;
        for(unsigned i=0;i<n;i++){unsigned id=s->hands[0][i],co=l3_table_card_color(id),v=l3_table_card_value(id);pose(f,id,(co<4?co:f->color)*16+v,1,start+i*gap,274+(i==f->selection?-14:0),58,78,256);}
        for(unsigned p=1;p<4;p++)for(unsigned i=0;i<s->count[p]&&i<12;i++)pose(f,400+p*108+i,52,0,p==2?295+i*15:p==1?56:690,p==2?4:80+i*12,44,58,256);
    }else if(f->kind==3){
        for(unsigned i=0;i<7;i++)pose(f,2300+i,56,0,180+i*64,70+6*sinf(f->time*.3f+i),50,50,i<f->view.data.hangman.mistakes?35:220);
        /* Use only the masked public view, never the hidden word ID. */
        unsigned n=(unsigned)strlen(f->view.word);float gap=36,start=400-(n?((n-1)*gap+32):0)/2;
        for(unsigned i=0;i<n;i++){
            pose(f,2500+i,26,2,start+i*gap,226,32,32,150);
            char ch=f->view.word[i];
            if(ch>='A'&&ch<='Z')pose(f,2600+i,ch-'A',2,start+i*gap,212,32,32,256);
        }
    }
}
static int textured(L3Render *r,const L3FestivalPose *p,float scale,unsigned alpha){
    int glyph=p->chroma>=2,chroma=p->chroma==1;
    int tw=glyph||chroma?32:64,th=glyph?32:64,columns=chroma?16:8;
    gpu_texture_level t={PRODOCK_GPU_BASE+(chroma?CHROMA:ATLAS),512,chroma?256:512,1024,GPU_ARGB4444,0,0,0};
    unsigned tint=p->chroma==3?0:256;
    gpu_material m={.flags=1,.alpha=alpha,.r=tint,.g=tint,.b=tint};
    int x=(int)lroundf(p->x*scale),y=(int)lroundf(p->y*scale),w=(int)lroundf(p->w*scale),h=(int)lroundf(p->h*scale);
    if(w<1||h<1||!alpha)return 1;int u=(p->texture%columns)*tw,v=(p->texture/columns)*th;
    if(glyph){unsigned ch=(unsigned)p->texture,tile=57+ch/4;u=(tile%8)*64+(ch%2)*32;v=(tile/8)*64+((ch/2)%2)*32;}
    gpu_vertex a[4]={{x,y,u,v,0,65536,256,256,256},{x+w,y,u+tw,v,0,65536,256,256,256},{x+w,y+h,u+tw,v+th,0,65536,256,256,256},{x,y+h,u,v+th,0,65536,256,256,256}};
    return gpu_v1_texture(&r->gpu,&t)&&gpu_v1_material(&r->gpu,&m)&&gpu_v1_quad(&r->gpu,a);
}
static void bake_board(L3Render *r,L3Festival *f,unsigned x,unsigned y,float scale){
    unsigned w=r->width*2,h=r->height*2;
    if(w==800)expand(f->background,w*h,festival_table_800,COUNT(festival_table_800));
    else expand(f->background,w*h,festival_table_1280,COUNT(festival_table_1280));
    if(f->kind==0){
        int x0=(int)(x+232*scale),y0=(int)(y+28*scale),size=(int)(336*scale);
        for(int yy=0;yy<size;yy++)for(int xx=0;xx<size;xx++){
            unsigned color=rgb(122+((xx+yy)%9),87+((xx+yy)%9),46);
            float bx=xx/scale-8,by=yy/scale-8;
            if(bx>=0&&bx<320&&by>=0&&by<320){unsigned cx=(unsigned)bx/40,cy=(unsigned)by/40;int edge=(int)bx%40==0||(int)by%40==0;unsigned grain=(unsigned)(xx*13+yy*17)%4;
                color=edge?rgb(103,130,101):((cx+cy)%2)?rgb(31+grain,91+grain,76+grain):rgb(42+grain,107+grain,87+grain);}
            f->background[(y0+yy)*w+x0+xx]=(uint16_t)color;
        }
    }
    publish(r,6u<<20,f->background,w*h*2);f->baked_kind=f->kind;f->base_ready[0]=f->base_ready[1]=0;f->page_valid[0]=f->page_valid[1]=0;
}
static void bounds(const L3FestivalPose *p,float *x0,float *y0,float *x1,float *y1){
    *x0=fminf(*x0,p->x-1);*y0=fminf(*y0,p->y-1);*x1=fmaxf(*x1,p->x+p->w+5);*y1=fmaxf(*y1,p->y+p->h+7);
}
static int same_pose(const L3FestivalPose *a,const L3FestivalPose *b){return a->id==b->id&&a->texture==b->texture&&a->chroma==b->chroma&&a->x==b->x&&a->y==b->y&&a->w==b->w&&a->h==b->h&&a->alpha==b->alpha;}
/* The GPU commands of the board, extracted from board_inner() so that
   the profile scope can always be closed, even when a command fails.
   The commands and their order are exactly the ones of the original
   block, which is replaced by a single call to this function. */
static int board_commands(L3Render *r,const L3FestivalPose *poses,unsigned poses_n,
                          float x0,float y0,float x1,float y1,float scale){
    for(unsigned pass=0;pass<2;pass++)for(unsigned i=0;i<poses_n;i++){
        L3FestivalPose p=poses[i];
        if(p.x+p.w+5<x0||p.x-1>x1||p.y+p.h+7<y0||p.y-1>y1)continue;
        if(!pass){if(p.texture==56)continue;
            if(p.chroma==2){p.x+=2;p.y+=3;p.chroma=3;if(!textured(r,&p,scale,(unsigned)(p.alpha*.3f)))return 0;}
            else {p.x+=3;p.y+=5;p.texture=55;p.chroma=0;if(!textured(r,&p,scale,90))return 0;}
        }
        else if(!textured(r,&p,scale,(unsigned)p.alpha))return 0;
    }
    return 1;
}
static int board_inner(L3Render *r,L3Festival *f,struct prodock_scene *scene){
    unsigned w=r->width*2,h=r->height*2,page=r->frame&1,ww=w==800?800:960,hh=w==800?400:480,x=(w-ww)/2,y=(h-hh)/2;
    float scale=ww/800.0f;
    if(f->baked_kind!=f->kind)bake_board(r,f,x,y,scale);
    if(!f->base_ready[page]){publish(r,page*r->page_bytes,f->background,w*h*2);f->base_ready[page]=1;}
    unsigned offset=y*r->pitch+x*2;
    gpu_target t={PRODOCK_GPU_BASE+page*r->page_bytes+offset,PRODOCK_GPU_BASE+2*r->page_bytes+offset,ww,hh,r->pitch,r->pitch};
    gpu_target bg={PRODOCK_GPU_BASE+(6u<<20)+offset,t.depth,ww,hh,r->pitch,r->pitch};
    l3_profile_begin(&f->profile,L3_PROFILE_POSITIONS,r->feed_seconds);
    positions(f);
    l3_profile_end(&f->profile,r->feed_seconds);
    float e=ease(f->transition);
    if(f->kind==1||f->kind==2){
        l3_profile_begin(&f->profile,L3_PROFILE_MOTION,r->feed_seconds);
        l3_card_motion_apply(&f->motion,(unsigned)f->kind,f->poses,&f->poses_n,(unsigned)COUNT(f->poses));
        l3_profile_end(&f->profile,r->feed_seconds);
    }
    if(!(f->kind==1||f->kind==2))for(unsigned i=0;i<f->poses_n;i++){
        L3FestivalPose *p=&f->poses[i];const L3FestivalPose *old=NULL;
        for(unsigned j=0;j<f->old_n;j++)if(f->old[j].id==p->id){old=f->old+j;break;}
        if(old&&f->transition<1){p->x=old->x+(p->x-old->x)*e;p->y=old->y+(p->y-old->y)*e;
            if(f->kind==3)p->alpha=old->alpha+(p->alpha-old->alpha)*e;
            if(f->kind==0&&old->texture!=p->texture){float shrink=fabsf(cosf(3.14159265f*f->transition));p->x+=p->w*(1-shrink)/2;p->w*=shrink;if(f->transition<.5f)p->texture=old->texture;}}
        else if(!old&&f->old_n&&f->transition<1){p->alpha=f->kind==3?p->alpha*e:64+192*e;p->y+=(1-e)*12;}
    }
    float x0=800,y0=400,x1=0,y1=0;
    l3_profile_begin(&f->profile,L3_PROFILE_BOARD_DIFF,r->feed_seconds);
    if(!f->page_valid[page]){x0=y0=0;x1=800;y1=400;}
    else {
        for(unsigned i=0;i<f->poses_n;i++){
            const L3FestivalPose *p=&f->poses[i],*old=NULL;
            for(unsigned j=0;j<f->page_n[page];j++)if(f->page_poses[page][j].id==p->id){old=&f->page_poses[page][j];break;}
            if(!old||!same_pose(p,old)){bounds(p,&x0,&y0,&x1,&y1);if(old)bounds(old,&x0,&y0,&x1,&y1);}
        }
        for(unsigned j=0;j<f->page_n[page];j++){
            const L3FestivalPose *p=&f->page_poses[page][j];unsigned i=0;
            for(;i<f->poses_n;i++)if(f->poses[i].id==p->id)break;
            if(i==f->poses_n)bounds(p,&x0,&y0,&x1,&y1);
        }
    }
    l3_profile_end(&f->profile,r->feed_seconds);
    int ix=(int)floorf(clamp(x0,0,800)*scale),iy=(int)floorf(clamp(y0,0,400)*scale),ex=(int)ceilf(clamp(x1,0,800)*scale),ey=(int)ceilf(clamp(y1,0,400)*scale);
    /* 1.2f is not exact: a nominal 960-pixel bound may round to 961. */
    if(ex>(int)ww)ex=(int)ww;if(ey>(int)hh)ey=(int)hh;
    if(ex>ix&&ey>iy){
        if(!gpu_v1_target(&r->gpu,&t)||!gpu_v1_scissor(&r->gpu,ix,iy,ex-ix,ey-iy)||!gpu_v1_copy(&r->gpu,&bg,ix,iy,ix,iy,ex-ix,ey-iy))return 0;
        l3_profile_begin(&f->profile,L3_PROFILE_BOARD_COMMANDS,r->feed_seconds);
        int commands_ok=board_commands(r,f->poses,f->poses_n,x0,y0,x1,y1,scale);
        l3_profile_end(&f->profile,r->feed_seconds);
        if(!commands_ok)return 0;
    }
    memcpy(f->page_poses[page],f->poses,f->poses_n*sizeof(*f->poses));f->page_n[page]=f->poses_n;f->page_valid[page]=1;
    scene->base=PRODOCK_GPU_BASE+page*r->page_bytes;scene->stride=r->pitch;scene->format=3;return 1;
}
static int board(L3Render *r,L3Festival *f,struct prodock_scene *scene){
    l3_profile_begin(&f->profile,L3_PROFILE_BOARD,r->feed_seconds);
    int ok=board_inner(r,f,scene);
    l3_profile_end(&f->profile,r->feed_seconds);
    return ok;
}

/* Static 3D garden. Each triangle is transformed/projected by G3D1. */
typedef struct {gpu_geom_vertex v[240];gpu_geom_face f[240];unsigned nv,nf,at,texture;L3Render *r;L3Festival *owner;} Mesh;
static int mesh_flush(Mesh *m){
    if(!m->nf)return 1;if(m->owner->mesh_count>=COUNT(m->owner->meshes)||m->at+(m->nv+m->nf)*32>(18u<<20))return 0;
    unsigned va=m->at;publish(m->r,m->at,m->v,m->nv*32);m->at+=m->nv*32;unsigned fa=m->at;publish(m->r,m->at,m->f,m->nf*32);m->at+=m->nf*32;
    m->owner->mesh_texture[m->owner->mesh_count]=m->texture;
    m->owner->meshes[m->owner->mesh_count++]=(gpu_geom_mesh){PRODOCK_GPU_BASE+va,PRODOCK_GPU_BASE+fa,m->nv,m->nf};m->nv=m->nf=0;return 1;
}
static int mesh_texture(Mesh *m,unsigned texture){if(!mesh_flush(m))return 0;m->texture=texture;return 1;}
static int tri(Mesh *m,L3Vec3 a,L3Vec3 b,L3Vec3 c,unsigned red,unsigned green,unsigned blue){
    if(m->nv+3>240||m->nf==240)if(!mesh_flush(m))return 0;
    unsigned start=m->nv;L3Vec3 p[3]={a,b,c};
    for(unsigned i=0;i<3;i++){gpu_geom_vertex v={0};if(!gpu_geom_fixed(p[i].x,&v.x)||!gpu_geom_fixed(p[i].y,&v.y)||!gpu_geom_fixed(p[i].z,&v.z))return 0;m->v[m->nv++]=v;}
    gpu_geom_face f={{0}};f.words[0]=(3u<<24)|start|((start+1)<<8)|((start+2)<<16);f.words[4]=32767;f.words[6]=red|(green<<9)|(blue<<18);
    float nx=fabsf((b.y-a.y)*(c.z-a.z)-(b.z-a.z)*(c.y-a.y));
    float ny=fabsf((b.z-a.z)*(c.x-a.x)-(b.x-a.x)*(c.z-a.z));
    float nz=fabsf((b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x));
    for(unsigned i=0;i<3;i++){
        float u=nx>ny&&nx>nz?p[i].z:p[i].x,v=ny>=nx&&ny>=nz?p[i].z:-p[i].y;
        if(!festival_surface_uv(m->texture,ny>=nx&&ny>=nz,u,v,&f.words[i+1]))return 0;
    }
    m->f[m->nf++]=f;return 1;
}
static int quad3(Mesh *m,L3Vec3 a,L3Vec3 b,L3Vec3 c,L3Vec3 d,unsigned r,unsigned g,unsigned bcol){return tri(m,a,b,c,r,g,bcol)&&tri(m,a,c,d,r,g,bcol);}
static int box(Mesh *m,float x,float y,float z,float w,float h,float d,unsigned r,unsigned g,unsigned b){
    L3Vec3 a={x-w/2,y,z-d/2},bb={x+w/2,y,z-d/2},c={x+w/2,y,z+d/2},dd={x-w/2,y,z+d/2};
    L3Vec3 e=a,f=bb,gg=c,hh=dd;e.y=f.y=gg.y=hh.y=y+h;
    return quad3(m,e,f,gg,hh,r,g,b)&&quad3(m,a,bb,f,e,r*3/4,g*3/4,b*3/4)&&quad3(m,bb,c,gg,f,r*7/8,g*7/8,b*7/8)&&quad3(m,c,dd,hh,gg,r*2/3,g*2/3,b*2/3)&&quad3(m,dd,a,e,hh,r*4/5,g*4/5,b*4/5);
}
static void garden_tree(unsigned i,float *x,float *z,float *height,float *width){
    /* Three irregular groves leave a view northward towards the distant sky.
       The trunk stays outside the accessible square, including its thickness. */
    static const float centers[3]={.25f,2.25f,4.35f};
    float angle=centers[i/12]+((int)(i%12)-5.5f)*.095f+.06f*sinf(i*1.83f);
    float radius=24+4*sinf(i*2.3f)+2*cosf(i*.63f);
    *x=sinf(angle)*radius;*z=cosf(angle)*radius;
    float extent=fmaxf(fabsf(*x),fabsf(*z));
    if(extent<16.5f){*x*=16.5f/extent;*z*=16.5f/extent;}
    *height=4.2f+1.1f*(1+sinf(i*1.71f));
    *width=1.8f+.45f*(1+cosf(i*2.11f));
}
typedef struct {const char *mesh;float x,z,scale,yaw;unsigned grove;} NorthProp;
static const NorthProp north_props[]={
    {"oak_low_budget",-19.4f,-25.2f,1.12f,.35f,0},
    {"oak_low_budget",-13.8f,-31.7f,1.31f,2.2f,0},
    {"pine_far_budget",-25.6f,-32.1f,1.10f,.8f,0},
    {"pine_far_budget",-20.8f,-37.9f,.88f,2.7f,0},
    {"rock_far_budget",-16.6f,-22.8f,1.5f,1.5f,0},
    {"rock_far_budget",-23.4f,-27.3f,.9f,-.4f,0},
    {"oak_low_budget",16.4f,-27.1f,1.23f,-1.1f,1},
    {"oak_low_budget",22.9f,-34.6f,1.06f,.42f,1},
    {"pine_far_budget",10.9f,-36.2f,1.15f,1.7f,1},
    {"pine_far_budget",18.3f,-42.0f,.91f,2.4f,1},
    {"rock_far_budget",-2.9f,-29.2f,.85f,2.0f,1},
    {"rock_far_budget",7.5f,-31.1f,1.1f,-.7f,1},
    {"ruin_arch_far_budget",1.8f,-30.4f,1.18f,.18f,1}
};
static int16_t north_normal(float value){
    long n=lroundf(value);return (int16_t)(n<-32768?-32768:n>32767?32767:n);
}
/* Bake native indexed groups once. Keeping their shared vertices is required
   by the 212 vertex / 324 face budget; tri() would duplicate every corner. */
static int north_append(Mesh *m,const NorthProp *p){
    const L3AssetMesh *asset=NULL;
    for(unsigned i=0;i<l3_asset_mesh_count;i++)if(!strcmp(l3_asset_meshes[i].name,p->mesh)){asset=&l3_asset_meshes[i];break;}
    if(!asset||asset->group_count!=1||!(p->scale>0))return 0;
    const L3AssetGroup *g=asset->groups;
    if(g->material>=l3_asset_material_count||l3_asset_materials[g->material].texture_index!=8||
       !g->nv||!g->nf||m->nv+g->nv>240||m->nf+g->nf>240)return 0;
    float low=0,co=cosf(p->yaw),si=sinf(p->yaw);
    for(unsigned i=0;i<g->nv;i++){
        int32_t y;memcpy(&y,g->vertices+i*8+1,4);
        if(!i||y/65536.0f<low)low=y/65536.0f;
    }
    unsigned start=m->nv;
    for(unsigned i=0;i<g->nv;i++){
        gpu_geom_vertex v;memcpy(&v,g->vertices+i*8,sizeof(v));
        float x=v.x/65536.0f,y=v.y/65536.0f,z=v.z/65536.0f;
        L3Vec3 q={p->x+p->scale*(co*x+si*z),(y-low)*p->scale,p->z+p->scale*(-si*x+co*z)};
        /* All geometry, not only origins, remains beyond the playable square. */
        if(!(q.z<=-16&&q.y>=0&&fabsf(q.x)<80&&fabsf(q.z)<80&&q.y<40)||
           !gpu_geom_fixed(q.x,&v.x)||!gpu_geom_fixed(q.y,&v.y)||!gpu_geom_fixed(q.z,&v.z))return 0;
        m->v[m->nv++]=v;
    }
    for(unsigned i=0;i<g->nf;i++){
        gpu_geom_face face;memcpy(&face,g->faces+i*8,sizeof(face));
        unsigned indices=0;
        for(unsigned k=0;k<3;k++){
            unsigned id=(face.words[0]>>(k*8))&255;if(id>=g->nv)return 0;
            indices|=(id+start)<<(k*8);
        }
        face.words[0]=(face.words[0]&0xff000000u)|indices;
        int16_t nx=(int16_t)(face.words[4]>>16),ny=(int16_t)face.words[4],nz=(int16_t)face.words[5];
        int16_t rx=north_normal(co*nx+si*nz),rz=north_normal(-si*nx+co*nz);
        face.words[4]=((uint32_t)(uint16_t)rx<<16)|(uint16_t)ny;
        face.words[5]=(face.words[5]&0xffff0000u)|(uint16_t)rz;
        if(!strcmp(p->mesh,"ruin_arch_far_budget")){
            unsigned rgb=face.words[6],rr=rgb&511,gg=(rgb>>9)&511,bb=(rgb>>18)&511;
            face.words[6]=((rr*216+128)>>8)|(((gg*225+128)>>8)<<9)|(((bb*208+128)>>8)<<18);
        }
        m->f[m->nf++]=face;
    }
    return 1;
}
static int north_geometry(Mesh *m){
    L3Festival *f=m->owner;
    if(m->nv||m->nf||f->mesh_count>COUNT(f->meshes)-L3_FESTIVAL_STANDS-2)return 0;
    f->grove_mesh_first=f->mesh_count;f->grove_mesh_count=0;m->texture=8;
    for(unsigned grove=0;grove<2;grove++){
        for(unsigned i=0;i<COUNT(north_props);i++)if(north_props[i].grove==grove&&!north_append(m,&north_props[i]))return 0;
        if(m->nv!=(grove?120u:92u)||m->nf!=(grove?184u:140u))return 0;
        L3Vec3 lo={1e6f,1e6f,1e6f},hi={-1e6f,-1e6f,-1e6f};
        for(unsigned i=0;i<m->nv;i++){
            L3Vec3 q={m->v[i].x/65536.0f,m->v[i].y/65536.0f,m->v[i].z/65536.0f};
            lo.x=fminf(lo.x,q.x);lo.y=fminf(lo.y,q.y);lo.z=fminf(lo.z,q.z);
            hi.x=fmaxf(hi.x,q.x);hi.y=fmaxf(hi.y,q.y);hi.z=fmaxf(hi.z,q.z);
        }
        L3Vec3 center={(lo.x+hi.x)*.5f,(lo.y+hi.y)*.5f,(lo.z+hi.z)*.5f};float radius2=0;
        for(unsigned i=0;i<m->nv;i++){
            float x=m->v[i].x/65536.0f-center.x,y=m->v[i].y/65536.0f-center.y,z=m->v[i].z/65536.0f-center.z;
            radius2=fmaxf(radius2,x*x+y*y+z*z);
        }
        f->grove_center[grove]=center;
        /* Covers Q16 matrix/product truncation for these bounded vertices. */
        f->grove_radius[grove]=sqrtf(radius2)+.02f;
        if(!mesh_flush(m))return 0;f->grove_mesh_count++;
    }
    return f->grove_mesh_count==2;
}
static int garden_geometry(L3Render *r,L3Festival *f){
    f->mesh_count=0;Mesh m={.at=GEOMETRY,.r=r,.owner=f};
    /* Reach behind the panorama's forest skirt from every playable camera.
       The camera's 100 m far plane clips this unchanged two-triangle base. */
    if(!quad3(&m,(L3Vec3){-96,0,-96},(L3Vec3){96,0,-96},(L3Vec3){96,0,96},(L3Vec3){-96,0,96},140,180,110)||!mesh_texture(&m,1))return 0;
    /* Grid tiles form four courts, a central ring and multiple connecting paths. */
    for(int z=-14;z<14;z+=2)for(int x=-14;x<14;x+=2){
        float a=(float)x+1,b=(float)z+1;
        if(fabsf(a)>11||fabsf(b)>11||fabsf(a)<3||fabsf(b)<3||fabsf(fabsf(a)-7)<1.2f||fabsf(fabsf(b)-7)<1.2f){
            unsigned c=(unsigned)((x+14)*17+(z+14)*31)%5;
            float inset=0; /* Continuous world UV: no grass grid within the stone court. */
            if(!quad3(&m,(L3Vec3){x+inset,.01f,z+inset},(L3Vec3){x+2-inset,.01f,z+inset},(L3Vec3){x+2-inset,.01f,z+2-inset},(L3Vec3){x+inset,.01f,z+2-inset},160+c,151+c,124+c))return 0;
        }
    }
    if(!box(&m,0,.02f,0,4.6f,.6f,4.6f,185,218,230)||!mesh_texture(&m,6)||!box(&m,0,.64f,0,3.7f,.03f,3.7f,200,240,256)||!mesh_texture(&m,5))return 0;
    static const unsigned colors[5][3]={{200,162,88},{134,168,195},{174,87,105},{98,180,156},{154,137,214}};
    for(unsigned k=0;k<L3_FESTIVAL_STANDS;k++){
        float x=sites[k][0],z=sites[k][1];const unsigned *c=colors[k];
        if(!box(&m,x,0,z,2.8f,.2f,2.8f,195,180,142)||!box(&m,x,.2f,z,1.8f,.85f,1.2f,c[0],c[1],c[2]))return 0;
        for(int i=-1;i<=1;i+=2)for(int j=-1;j<=1;j+=2)if(!box(&m,x+i*1.9f,0,z+j*1.9f,.25f,3.64f,.25f,180,164,126))return 0;
    }
    if(!mesh_texture(&m,4))return 0;
    for(unsigned k=0;k<L3_FESTIVAL_STANDS;k++){
        float x=sites[k][0],z=sites[k][1];
        L3Vec3 a={x-2.25f,3.6f,z-2.25f},b={x+2.25f,3.6f,z-2.25f};
        L3Vec3 c={x+2.25f,3.6f,z+2.25f},d={x-2.25f,3.6f,z+2.25f};
        L3Vec3 front={x,4.25f,z-2.25f},back={x,4.25f,z+2.25f};
        /* Two roof slopes, two gables and underside: 8 rather than 10 triangles.
           The outer support edge at x=+/-2.025 lies below y=3.665. */
        if(!quad3(&m,a,front,back,d,178,117,76)||!quad3(&m,front,b,c,back,151,98,64)||
           !tri(&m,a,b,front,158,102,67)||!tri(&m,c,d,back,139,91,59)||
           !quad3(&m,a,d,c,b,112,79,53))return 0;
    }
    /* Low-poly grove and mountains beyond the playable garden; no hidden collision mismatch. */
    if(!mesh_texture(&m,5))return 0;
    for(unsigned i=0;i<36;i++){
        float x,z,h,width;garden_tree(i,&x,&z,&h,&width);
        if(!box(&m,x,0,z,.5f,h*.6f,.5f,154,104,57))return 0;
    }
    if(!mesh_texture(&m,7))return 0;
    for(unsigned i=0;i<36;i++){
        float x,z,h,width;garden_tree(i,&x,&z,&h,&width);
        L3Vec3 top={x+.4f*sinf(i*1.7f),h,z+.35f*cosf(i*1.3f)};
        L3Vec3 a={x-width,h*.3f,z-width*.85f},b={x+width,h*.3f,z-width*.85f};
        L3Vec3 c={x+width,h*.3f,z+width*.85f},d={x-width,h*.3f,z+width*.85f};
        if(!tri(&m,a,b,top,114,182+i%3*10,76)||!tri(&m,b,c,top,127,211,88)||!tri(&m,c,d,top,96,161,65)||!tri(&m,d,a,top,120,195,80))return 0;
    }
    if(!mesh_flush(&m)||!north_geometry(&m))return 0;
    f->lighting_mesh_first=f->mesh_count;f->lighting_mesh_count=0;
    if(f->mesh_count>COUNT(f->meshes)-L3_FESTIVAL_STANDS)return 0;
    /* Four world-space lamp planes face the north-facing gameplay camera.
       They reuse the validated soft halo in atlas tile56; no new texture. */
    for(unsigned k=0;k<L3_FESTIVAL_STANDS;k++){
        float x=sites[k][0],z=sites[k][1]+.45f;
        L3Vec3 a={x-.45f,2.55f,z},b={x+.45f,2.55f,z},c={x+.45f,3.45f,z},d={x-.45f,3.45f,z};
        if(!quad3(&m,a,b,c,d,256,256,256))return 0;
        /* quad3 produces (a,b,c),(a,c,d). Keep both triangles' diagonal UV
           endpoints identical, and sample inside the existing halo tile. */
        m.f[0].words[1]=(1u<<16)|510u;m.f[0].words[2]=(62u<<16)|510u;m.f[0].words[3]=(62u<<16)|449u;
        m.f[1].words[1]=(1u<<16)|510u;m.f[1].words[2]=(62u<<16)|449u;m.f[1].words[3]=(1u<<16)|449u;
        if(!mesh_flush(&m))return 0;
    }
    f->lighting_mesh_count=f->mesh_count-f->lighting_mesh_first;
    if(f->lighting_mesh_count!=L3_FESTIVAL_STANDS)return 0;
    f->geometry_ready=1;return 1;
}
static L3Vec3 sub3(L3Vec3 a,L3Vec3 b){return (L3Vec3){a.x-b.x,a.y-b.y,a.z-b.z};}
static float dot3(L3Vec3 a,L3Vec3 b){return a.x*b.x+a.y*b.y+a.z*b.z;}
static L3Vec3 unit3(L3Vec3 a){float q=sqrtf(dot3(a,a));return (L3Vec3){a.x/q,a.y/q,a.z/q};}
static L3Vec3 cross3(L3Vec3 a,L3Vec3 b){return (L3Vec3){a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
static int garden_inner(L3Render *r,L3Festival *f,struct prodock_scene *scene){
    if(!f->geometry_ready&&!garden_geometry(r,f))return 0;
    gpu_target t={PRODOCK_GPU_BASE+(r->frame&1)*r->page_bytes,PRODOCK_GPU_BASE+2*r->page_bytes,r->width,r->height,r->pitch,r->pitch};
    float mood=festival_lighting_unit(f->light_mood);
    unsigned background=rgb((unsigned)lroundf(112-87*mood),(unsigned)lroundf(163-124*mood),(unsigned)lroundf(194-121*mood));
    if(!gpu_v1_target(&r->gpu,&t)||!gpu_v1_scissor(&r->gpu,0,0,r->width,r->height)||!gpu_v1_clear(&r->gpu,3,background,65535,0,0,r->width,r->height))return 0;
    L3Vec3 eye={f->camera_x,4.5f,f->camera_z},target={f->x,1.6f,f->z-5},forward=unit3(sub3(target,eye)),right=unit3(cross3(forward,(L3Vec3){0,1,0})),down=cross3(forward,right);
    gpu_geom_camera camera={32768,100*65536,(int)(r->width*.82f*65536),(int)(r->width*.82f*65536),r->width/2,r->height/2};
    gpu_geom_transform transform;L3Vec3 rows[3]={right,down,forward};
    for(unsigned a=0;a<3;a++){if(!gpu_geom_fixed(rows[a].x,&transform.values[a*4])||!gpu_geom_fixed(rows[a].y,&transform.values[a*4+1])||!gpu_geom_fixed(rows[a].z,&transform.values[a*4+2])||!gpu_geom_fixed(-dot3(rows[a],eye),&transform.values[a*4+3]))return 0;}
    gpu_geom_light light={0,32767,0,256,0};gpu_material mat={.flags=2|4,.alpha=256,.color=65535,.r=256,.g=256,.b=256};
    if(!gpu_geom_set_camera(&r->gpu,&camera))return 0;
    gpu_geom_transform sky_transform=transform;for(unsigned a=0;a<3;a++)sky_transform.values[a*4+3]=0;
    gpu_texture_level sky={PRODOCK_GPU_BASE+SKY,512,256,1024,GPU_ARGB4444,0,0,0};
    gpu_geom_mesh sky_mesh={PRODOCK_GPU_BASE+SKY+l3_sky_assets.texture_bytes,PRODOCK_GPU_BASE+SKY+l3_sky_assets.texture_bytes+l3_sky_assets.vertices_bytes,l3_sky_assets.vertex_count,l3_sky_assets.face_count};
    gpu_material sky_mat={.flags=17,.alpha=256,.r=(unsigned)lroundf(256-91*mood),.g=(unsigned)lroundf(256-78*mood),.b=(unsigned)lroundf(256-26*mood)};
    if(!gpu_geom_set_transform(&r->gpu,&sky_transform)||!gpu_geom_set_light(&r->gpu,&light)||!gpu_v1_material(&r->gpu,&sky_mat)||!gpu_v1_texture(&r->gpu,&sky)||!gpu_geom_draw(&r->gpu,&sky_mesh,0))return 0;
    r->draws++;r->triangles+=sky_mesh.face_count;
    mat.flags=1|2|4|16;
    mat.r=(unsigned)lroundf(256-96*mood);mat.g=(unsigned)lroundf(256-66*mood);mat.b=(unsigned)lroundf(256-36*mood);
    if(!gpu_geom_set_transform(&r->gpu,&transform)||!gpu_v1_material(&r->gpu,&mat))return 0;
    for(unsigned i=0;i<f->mesh_count;i++){
        if(i>=f->lighting_mesh_first)continue;
        if(i>=f->grove_mesh_first&&i<f->grove_mesh_first+f->grove_mesh_count){
            unsigned k=i-f->grove_mesh_first;L3Vec3 rel=sub3(f->grove_center[k],eye);
            float sx=camera.center_x*65536.0f/camera.focal_x,sy=camera.center_y*65536.0f/camera.focal_y;
            if(!festival_sphere_visible(dot3(rel,right),dot3(rel,down),dot3(rel,forward),f->grove_radius[k],
                camera.near_z/65536.0f,camera.far_z/65536.0f,sx,sy)){r->culled++;continue;}
        }
        unsigned ti=f->mesh_texture[i];if(ti>=l3_asset_texture_count)return 0;
        /* This garden has one flat base and every object is above it. Draw
         * that base as the opaque background; centimetre-high paving must
         * not fight its quantized reciprocal depth. Paving/objects keep Z. */
        int ground=i==0&&ti==0&&f->meshes[i].vertex_count==6&&f->meshes[i].face_count==2;
        mat.flags=ground?1|16:1|2|4|16;
        if(!gpu_v1_material(&r->gpu,&mat))return 0;
        const L3AssetTexture *asset=&l3_asset_textures[ti];
        gpu_texture_level texture={r->textures[ti],asset->width,asset->height,asset->width*2,GPU_RGB565,1,1,0};
        if(!gpu_v1_texture(&r->gpu,&texture)||!gpu_geom_draw(&r->gpu,&f->meshes[i],0))return 0;r->draws++;r->triangles+=f->meshes[i].face_count;
    }
    /* Hero's real six-part textured mesh, translated and rotated in real time. */
    gpu_texture_level texture={r->hero_texture,256,256,512,GPU_RGB565,1,1,0};mat.flags=1|2|4|16;
    if(!gpu_v1_texture(&r->gpu,&texture)||!gpu_v1_material(&r->gpu,&mat))return 0;
    gpu_geom_transform world_transform=transform;
    float speed=hypotf(f->vx,f->vz),gait=sinf(f->time*8)*.6f*fminf(1,speed/4);
    /* Frozen leg vertices have local y>=-.760 and |z|<=.217 about a
       .760 m hip. Lift the complete rig, preserving all joint connections,
       enough for the boots to remain above the .010 m paving during gait. */
    float hero_y=.015f+fmaxf(0,.760f*cosf(gait)+.217f*fabsf(sinf(gait))-.760f);
    for(unsigned i=0;i<6;i++){
        const L3AssetPart *part=&l3_asset_hero_parts[i];
        float angle=part->kind==1||part->kind==4?gait:part->kind==2||part->kind==3?-gait:0;
        float co=cosf(f->yaw),si=sinf(f->yaw),ca=cosf(angle),sa=sinf(angle);
        L3Vec3 columns[3]={{co,0,-si},{si*sa,ca,co*sa},{si*ca,-sa,co*ca}};
        L3Vec3 pivot={f->x+co*part->pivot.x+si*part->pivot.z,part->pivot.y+hero_y,f->z-si*part->pivot.x+co*part->pivot.z};
        for(unsigned a=0;a<3;a++){
            for(unsigned b=0;b<3;b++)if(!gpu_geom_fixed(dot3(rows[a],columns[b]),&transform.values[a*4+b]))return 0;
            if(!gpu_geom_fixed(dot3(rows[a],sub3(pivot,eye)),&transform.values[a*4+3]))return 0;
        }
        if(!gpu_geom_set_transform(&r->gpu,&transform)||!gpu_geom_draw(&r->gpu,&r->hero_mesh[i],0))return 0;r->draws++;r->triangles+=r->hero_mesh[i].face_count;
    }
    if(f->lighting_mesh_count!=L3_FESTIVAL_STANDS||f->lighting_mesh_first+L3_FESTIVAL_STANDS!=f->mesh_count)return 0;
    gpu_texture_level halo={PRODOCK_GPU_BASE+ATLAS,512,512,1024,GPU_ARGB4444,0,0,0};
    /* Matrix=3 + texture=1 + four(material+draw)=8: exactly12commands.
       Test depth, never write it: roofs/hero occlude the additive halos. */
    if(!gpu_geom_set_transform(&r->gpu,&world_transform)||!gpu_v1_texture(&r->gpu,&halo))return 0;
    for(unsigned k=0;k<L3_FESTIVAL_STANDS;k++){
        FestivalLightingLamp l=festival_lighting_lamp(k%4,mood,f->time);
        gpu_material glow={.flags=1|2|16|32,.alpha=l.alpha,.color=65535,.r=l.r,.g=l.g,.b=l.b};
        const gpu_geom_mesh *mesh=&f->meshes[f->lighting_mesh_first+k];
        if(mesh->face_count!=2||!gpu_v1_material(&r->gpu,&glow)||!gpu_geom_draw(&r->gpu,mesh,0))return 0;
        r->draws++;r->triangles+=mesh->face_count;
    }
    scene->base=t.color;scene->stride=t.stride;scene->format=7;return 1;
}
static int garden(L3Render *r,L3Festival *f,struct prodock_scene *scene){
    l3_profile_begin(&f->profile,L3_PROFILE_GARDEN,r->feed_seconds);
    int ok=garden_inner(r,f,scene);
    l3_profile_end(&f->profile,r->feed_seconds);
    return ok;
}
#include "memory_ui_delta.h"
/* Festival indexed-overlay candidate: per page damage publication.
 *
 * Contract (see CONTRACT.md):
 *  - The graphics, the animation, the layout, the rules, the GPU command
 *    stream and the scene descriptor stay exactly as the original block.
 *  - Only the transport of the indexed image to the GPU changes: instead of
 *    republishing the whole physical page every frame, the candidate
 *    publishes the aligned byte spans that actually changed.
 *
 * How it works
 *  - Two CPU shadows, one per physical page (20 MiB and 21 MiB). shadow[p]
 *    holds exactly the bytes this producer has published on page p, so
 *    "canvas - shadow" is the exact damage of the current image.
 *  - The canvas (f->ui) is rasterised once per visible state change and is
 *    reused for the other page, exactly like the original code, so the
 *    pixels stay bit identical to the original block.
 *  - The first use of a page, or an invalidation, publishes the whole page:
 *    the VRAM content is unknown at that point and is never read back.
 *  - The damage scan is the algorithm of context/memory_ui_delta.h, inlined
 *    here so that no extra include path is needed: 4 byte words compared per
 *    row, one aligned span per changed row, zeros included so that erased
 *    text is really erased.
 *  - Every span is emitted through the original publish(), so the HUD
 *    counters keep describing what really reached the GPU.
 */

/* The two helpers below are copied verbatim from the original block. */
static void ui_text(L3Render *r,L3Festival *f,int x,int y,const char *s,unsigned color,unsigned width){
    int height=l3_ui_text(f->ui,r->width*2,r->height*2,x,y,0,s,color,width);
    l3_rows_mark(&f->overlay.rows,y,(int64_t)y+height);
}
static void ui_panel(L3Render *r,L3Festival *f,int x,int y,int w,int h){
    festival_hud_panel(f->ui,r->width*2,r->height*2,x,y,w,h);
    if(w>0&&h>0)l3_rows_mark(&f->overlay.rows,y,(int64_t)y+h+2);
}

/* ---- candidate state ---------------------------------------------------- */

/* The canvas belongs to the original lifecycle: it is only replaced here
   when its recorded dimensions no longer match the requested ones. The
   allocation happens before the old buffer is released, so a failure keeps
   the previous image intact and publishes nothing. */
static int overlay_canvas(L3Festival *f,unsigned w,unsigned h){
    if(f->ui&&f->ui_w==w&&f->ui_h==h)return 1;
    uint8_t *canvas=calloc((size_t)w*(size_t)h,1);
    if(!canvas)return 0;
    free(f->ui);
    f->ui=canvas;f->ui_w=w;f->ui_h=h;
    l3_rows_reset(&f->overlay.rows);
    f->overlay.key.valid=0; /* the new canvas carries no raster yet */
    f->overlay.pending_pages=3u;
    return 1;
}
/* One shadow per physical page. Same failure policy as overlay_canvas(). */
static int overlay_shadows(L3Festival *f,unsigned w,unsigned h){
    if(f->overlay.shadow[0]&&f->overlay.shadow[1]&&f->overlay.shadow_w==w&&f->overlay.shadow_h==h)return 1;
    uint8_t *a=calloc((size_t)w*(size_t)h,1);
    if(!a)return 0;
    uint8_t *b=calloc((size_t)w*(size_t)h,1);
    if(!b){free(a);return 0;}
    free(f->overlay.shadow[0]);free(f->overlay.shadow[1]);
    f->overlay.shadow[0]=a;f->overlay.shadow[1]=b;
    f->overlay.shadow_w=w;f->overlay.shadow_h=h;
    f->overlay.shadow_valid[0]=f->overlay.shadow_valid[1]=0;
    f->overlay.pending_pages=3u;
    return 1;
}

/* Exact visible state of the festival overlay. Only the fields that reach
   the screen are part of the key: the revision counter and the animation
   clock are deliberately absent, they never change a pixel. */
static void overlay_key(const L3Festival *f,L3FestivalOverlayKey *k){
    unsigned i;
    memset(k,0,sizeof(*k));
    k->kind=f->kind;k->automatic=f->automatic;
    if(f->kind<4){
        k->moves=f->view.moves;k->status=f->view.status;k->turn=f->view.turn;
    }
    if(f->kind==0){
        k->scores[0]=f->view.scores[0];k->scores[1]=f->view.scores[1];
    }else if(f->kind==1){
        k->selection=f->selection;k->row=f->row;k->source=f->source;
    }else if(f->kind==2){
        k->selection=f->selection;k->color=f->color;
    }else if(f->kind==3){
        for(i=0;i<26;i++)k->guessed[i]=f->view.data.hangman.guessed[i];
        const char *hint=f->view.hint?f->view.hint:"";
        size_t n=strlen(hint);
        /* The key stores the hint exactly while it fits. A longer hint is
           NOT truncated and NOT hashed: its bytes cannot be compared
           exactly any more, so the key only records "too long" and the
           comparison below refuses to reuse such a raster. */
        if(n>=sizeof(k->hint))k->hint_len=0xFFFFFFFFu; /* cannot be matched exactly */
        else{memcpy(k->hint,hint,n+1);k->hint_len=(unsigned)n;}
    }else if(f->kind==4){
        k->map=f->map;k->nearest=nearest(f);
        k->visited=(unsigned)__builtin_popcount(f->visited)+f->memory_visited;
    }
}
static int overlay_key_differs(const L3FestivalOverlayKey *a,const L3FestivalOverlayKey *b){
    unsigned i;
    if(a->kind!=b->kind||a->automatic!=b->automatic)return 1;
    if(a->map!=b->map||a->nearest!=b->nearest||a->visited!=b->visited)return 1;
    if(a->moves!=b->moves||a->status!=b->status||a->turn!=b->turn)return 1;
    if(a->selection!=b->selection||a->row!=b->row||a->source!=b->source||a->color!=b->color)return 1;
    if(a->scores[0]!=b->scores[0]||a->scores[1]!=b->scores[1])return 1;
    for(i=0;i<26;i++)if(a->guessed[i]!=b->guessed[i])return 1;
    if(a->hint_len!=b->hint_len)return 1;
    /* A hint that did not fit in the key (hint_len == 0xFFFFFFFF) is
       compared by nothing: two different long hints share that marker, so
       treating them as equal would keep a stale image on screen. The
       conservative answer is a forced cache miss: the raster is rebuilt
       while a long hint is displayed. The displayed text itself is never
       truncated or modified. */
    if(a->hint_len==0xFFFFFFFFu)return 1;
    if(memcmp(a->hint,b->hint,sizeof(a->hint))!=0)return 1;
    return 0;
}

/* The raster below is a byte exact copy of the original block: same panel
   geometry, same strings, same colours, same coordinates. Only the
   "memset + redraw" trigger changed (it used to be the revision counter,
   it is now the exact visible state). */
static void overlay_raster(L3Render *r,L3Festival *f,unsigned w,unsigned h){
    f->overlay.pending_pages=3u; /* both physical pages now need republication */
    l3_profile_begin(&f->profile,L3_PROFILE_OVERLAY_RASTER,r->feed_seconds);
    /* Bounded clear: erase only the rows that may still hold an old
       byte.  This must run BEFORE l3_rows_begin(), which folds the
       old footprint into the pending page masks and erases it. */
    (void)l3_ui_clear_rows(f->ui,w,h,&f->overlay.rows);
    l3_rows_begin(&f->overlay.rows,h);
    char line[160];
    /* At800 stock starts y=48 and Chroma's upper hand y=44: keep both
       panel and shadow above those bounds.
       The longest solitaire columns end432; keep footer below them. */
    ui_panel(r,f,72,5,(int)w-144,w==800?(f->kind==2?37:41):52);
    if(f->kind==1||f->kind==2)ui_panel(r,f,28,(int)h-(w==800?47:62),(int)w-56,w==800?42:55);
    else if(f->kind<4)ui_panel(r,f,72,(int)h-39,(int)w-144,32);
    else ui_panel(r,f,28,(int)h-58,(int)w-56,51);
    const char *title=f->kind<4?names[f->kind]:f->map?"LUMA - Les terrasses de lune":"LUMA - Le jardin des constellations";
    ui_text(r,f,85,12,title,78,w-170);
    if(f->kind<4){
        snprintf(line,sizeof(line),"%s  |  %u coups  |  %s",f->automatic?"VISITE AUTO":"A VOUS DE JOUER",f->view.moves,f->view.status==1?"VICTOIRE":f->view.status==2?"PARTIE TERMINEE":f->view.status==3?"EGALITE":f->view.turn?"L'adversaire reflechit":"Votre tour");
        ui_text(r,f,85,w==800?(f->kind==2?27:29):31,line,74,w-170);
        ui_text(r,f,85,h-((w==800&&(f->kind==1||f->kind==2))?21:31),f->kind==3?"A-Z : proposer une lettre  |  Tab : jardin  |  Entree : nouvelle partie":"WASD choisir / E jouer / P pioche / F option / R rejouer / Tab retour",74,w-170);
        if(f->kind==3){
            /* Word glyphs are GPU poses, independent of the indexed UI. */
            char letters[80];unsigned at=0;for(unsigned i=0;i<26;i++){letters[at++]=f->view.data.hangman.guessed[i]?'.':(char)('A'+i);letters[at++]=' ';}letters[at]=0;
            ui_text(r,f,w/5,h*2/3,letters,74,w*3/5);
            unsigned hint_margin=w*3/20; /* Inside the scaled table on both native profiles. */
            ui_text(r,f,(int)hint_margin,h/2-40,f->view.hint?f->view.hint:"",74,w-2*hint_margin);
        }
        if(f->kind==0){snprintf(line,sizeof(line),"Vous %u  /  %u",f->view.scores[0],f->view.scores[1]);ui_text(r,f,58,h/2,line,78,180);}
        if(f->kind==1){snprintf(line,sizeof(line),"Zone %u  Ligne %u  %s",f->selection+1,f->row+1,f->source==255?"Choisir une source":"Choisir destination");ui_text(r,f,40,h-(w==800?43:54),line,78,w-80);}
        if(f->kind==2){static const char *c[]={"rouge","or","vert","bleu"};snprintf(line,sizeof(line),"Carte %u  Joker : %s",f->selection+1,c[f->color]);ui_text(r,f,40,h-(w==800?43:54),line,78,w-80);}
    }else{
        unsigned k=nearest(f);snprintf(line,sizeof(line),"%s  |  %u / 5 tables decouvertes",f->automatic?"PROMENADE AUTOMATIQUE":"EXPLORATION LIBRE",(unsigned)__builtin_popcount(f->visited)+f->memory_visited);ui_text(r,f,85,w==800?29:31,line,74,w-170);
        ui_text(r,f,40,h-50,names[k],78,w-80);ui_text(r,f,40,h-28,"WASD : marcher  E : table proche  M : ambiance  Tab : retour a l'aventure",74,w-80);
    }
    l3_rows_end(&f->overlay.rows);
    l3_profile_bytes(&f->profile,L3_PROFILE_BYTES_RASTERED,(uint64_t)w*(uint64_t)h);
    l3_profile_end(&f->profile,r->feed_seconds);
}

/* Damage scan, identical to context/memory_ui_delta.h. */
typedef struct {L3Render *render;unsigned base;} FestivalOverlayWrite;
static int festival_overlay_emit(void *opaque,unsigned offset,const uint8_t *pixels,unsigned bytes){
    FestivalOverlayWrite *target=opaque;
    publish(target->render,target->base+offset,pixels,bytes);
    target->render->hud_uploads++;target->render->hud_bytes+=bytes;
    return 1;
}
/* Shared Memory helper: one aligned span per changed row, including erasure.
   The callback is the sole publication path; shadow validity follows success. */
static int overlay_delta(L3Render *r,L3Festival *f,unsigned page,unsigned w,unsigned h){
    FestivalOverlayWrite target={r,(20u<<20)+page*(1u<<20)};
    L3UiDelta traffic;
    l3_profile_begin(&f->profile,L3_PROFILE_OVERLAY_DELTA,r->feed_seconds);
    int full=!f->overlay.shadow_valid[page]||l3_rows_full(&f->overlay.rows,page,h);
    int ok=l3_ui_delta_rows(f->ui,f->overlay.shadow[page],w,h,(size_t)w*h,
                           full,festival_overlay_emit,&target,&traffic,
                           full?NULL:f->overlay.rows.dirty[page]);
    if(ok)l3_rows_consumed(&f->overlay.rows,page);
    if(ok)l3_profile_bytes(&f->profile,L3_PROFILE_BYTES_SCANNED,(uint64_t)traffic.scanned);
    l3_profile_end(&f->profile,r->feed_seconds);
    if(ok)f->overlay.shadow_valid[page]=1;
    return ok;
}


static int overlay_inner(L3Render *r,L3Festival *f,struct prodock_scene *scene){
    unsigned w,h,page;
    L3FestivalOverlayKey key;
    if(!r||!f||!scene)return 0;
    w=r->width*2;h=r->height*2;page=r->frame&1;
    if(!overlay_canvas(f,w,h))return 0;     /* no publication on failure */
    if(!overlay_shadows(f,w,h))return 0;
    l3_profile_begin(&f->profile,L3_PROFILE_OVERLAY_KEY,r->feed_seconds);
    overlay_key(f,&key);
    int key_changed=(!f->overlay.key.valid||overlay_key_differs(&f->overlay.key,&key))?1:0;
    l3_profile_end(&f->profile,r->feed_seconds);
    if(key_changed){
        /* This is the one real rasterisation trigger of the overlay:
           count it so the rebuild counter is not a dead field. */
        l3_profile_rebuild(&f->profile);
        overlay_raster(r,f,w,h);
        f->overlay.key=key;
        f->overlay.key.valid=1;
    }
    {
        unsigned overlay_page_bit=1u<<page;
        /* A page may only skip publication when the VRAM content is known
           and the cached canvas has already been published on that page. */
        if(!(f->overlay.shadow_valid[page] && !(f->overlay.pending_pages & overlay_page_bit))){
            if(!overlay_delta(r,f,page,w,h))return 0;
            f->overlay.pending_pages &= ~overlay_page_bit;
        }
    }
    uint32_t *l=scene->layers[0];l[0]=PRODOCK_GPU_BASE+(20u<<20)+page*(1u<<20);l[1]=w|(h<<16);l[2]=0;l[3]=l[1];l[5]=w;l[6]=3;scene->layers_enabled=1;return 1;
}
static int overlay(L3Render *r,L3Festival *f,struct prodock_scene *scene){
    l3_profile_begin(&f->profile,L3_PROFILE_OVERLAY,r->feed_seconds);
    int ok=overlay_inner(r,f,scene);
    l3_profile_end(&f->profile,r->feed_seconds);
    return ok;
}

/* ---- lifecycle hooks ---------------------------------------------------- */

/* The VRAM may have been touched by anybody else since the last
   publication, so the shadow of both pages becomes unknown: the next use
   republishes them completely. The buffers themselves are kept, the
   original lifecycle owns f->ui and must keep owning it. */
void festival_overlay_reset(L3Festival *f){
    if(!f)return;
    l3_rows_reset(&f->overlay.rows);
    f->overlay.shadow_valid[0]=0;f->overlay.shadow_valid[1]=0;
    f->overlay.key.valid=0;
    f->overlay.pending_pages=3u;
}
void festival_overlay_close(L3Festival *f){
    if(!f)return;
    l3_rows_reset(&f->overlay.rows);
    free(f->overlay.shadow[0]);free(f->overlay.shadow[1]);
    f->overlay.shadow[0]=0;f->overlay.shadow[1]=0;
    f->overlay.shadow_valid[0]=0;f->overlay.shadow_valid[1]=0;
    f->overlay.key.valid=0;
    f->overlay.pending_pages=0u;
}
static int festival_render_inner(L3Render *r,L3Festival *f,struct prodock_scene *scene){
    if(!r||!f||!scene||!f->active)return 0;
    if(f->kind==L3_FESTIVAL_MEMORY)return l3_memory_scene_render(r,&f->memory,scene,0);
    if(!art(r,f))return 0;
    if(f->kind<4){
        l3_profile_begin(&f->profile,L3_PROFILE_TABLE_VIEW,r->feed_seconds);
        int view_ok=l3_table_view(&f->games[f->kind],&f->view,0);
        l3_profile_end(&f->profile,r->feed_seconds);
        if(!view_ok||!board(r,f,scene))return 0;
    }
    else if(!garden(r,f,scene))return 0;
    return overlay(r,f,scene);
}
int l3_festival_render(L3Render *r,L3Festival *f,struct prodock_scene *scene){
    if(!r||!f)return 0;
    /* Both ordinary metrics and the explicit diagnostic switch are needed.
       OFF leaves the ordinary metrics intact without extra clock reads. */
    if(r->festival_metrics&&f->cpu_profile_enabled)l3_profile_enable(&f->profile,festival_profile_clock,NULL);
    else l3_profile_disable(&f->profile);
    l3_profile_begin(&f->profile,L3_PROFILE_RENDER,r->feed_seconds);
    int ok=festival_render_inner(r,f,scene);
    l3_profile_end(&f->profile,r->feed_seconds);
    return ok;
}
