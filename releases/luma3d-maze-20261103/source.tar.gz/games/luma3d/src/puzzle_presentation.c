#include "l3_puzzle_presentation.h"
#include <stdlib.h>
#include <string.h>
int l3_puzzle_presentation_open(L3Render *r)
{
    if(!r || r->puzzle_presentation)return 0;
    r->puzzle_presentation=calloc(1,sizeof(L3PuzzlePresentation));return r->puzzle_presentation!=0;
}
void l3_puzzle_presentation_close(L3Render *r)
{
    if(r && r->puzzle_presentation){free(r->puzzle_presentation->ui.number_back);free(r->puzzle_presentation);r->puzzle_presentation=0;}
}
void l3_puzzle_presentation_reset(L3Render *r)
{
    if(!r || !r->puzzle_presentation)return;
    L3PuzzlePresentation *p=r->puzzle_presentation;if(p->assets_valid)r->mini_canvas_stamp=r->mini_stamp[0]=r->mini_stamp[1]=0;l3_puzzle_motion_reset(&p->motion);p->assets_valid=0;p->page_valid[0]=p->page_valid[1]=0;
}
void l3_puzzle_presentation_observe(void *opaque,const L3ArcadeView *a,const L3ArcadeView *b,
                                  uint32_t pressed,uint32_t held,uint32_t trace,double now,uint32_t epoch)
{
    L3Render *r=opaque;if(!r || !r->puzzle_presentation)return;L3PuzzlePresentation *p=r->puzzle_presentation;(void)trace;
    if(!b || (b->kind!=L3_MINI_BLOCKS && b->kind!=L3_MINI_MERGE1024)){l3_puzzle_presentation_reset(r);return;}
    if(!a || a->kind!=b->kind || p->observed_epoch!=epoch)l3_puzzle_presentation_reset(r);
    p->observed_epoch=epoch;
    l3_puzzle_motion_observe(&p->motion,a && a->kind==b->kind?&a->content.grid:&b->content.grid,&b->content.grid,pressed,held,now,epoch);
}
static int same_frame(const L3MotionFrame *a,const L3MotionFrame *b)
{
    return a->settled==b->settled && a->count==b->count && a->logical.kind==b->logical.kind &&
           a->logical.width==b->logical.width && a->logical.height==b->logical.height &&
           !memcmp(a->logical.cells,b->logical.cells,sizeof(a->logical.cells)) &&
           !memcmp(a->poses,b->poses,a->count*sizeof(*a->poses));
}
int l3_puzzle_motion_prepare(L3Render *r,const L3Game *g,struct prodock_scene *scene,double now)
{
    if(!r || !g || !scene || !r->puzzle_presentation)return 0;
    L3ArcadeView all;if(!l3_arcade_view(&g->activities.arcade,&all) || (all.kind!=L3_MINI_BLOCKS && all.kind!=L3_MINI_MERGE1024))return 0;
    L3PuzzlePresentation *p=r->puzzle_presentation;unsigned w=r->width*2,h=r->height*2,page=r->frame&1;
    if(!p->assets_valid || p->kind!=all.kind || p->width!=w || p->height!=h){
        if(!l3_puzzle_gpu_layout(w,h,all.kind,&p->layout) || !l3_puzzle_ui_bake(r,g,&all.content.grid,&p->layout,&p->assets,&p->ui))return 0;
        p->assets_valid=1;p->kind=all.kind;p->width=w;p->height=h;p->page_valid[0]=p->page_valid[1]=0;
        gpu_v1_invalidate(&r->gpu);
    }
    if(!p->motion.valid && l3_puzzle_motion_observe(&p->motion,&all.content.grid,&all.content.grid,0,0,now,p->observed_epoch)<0)return 0;
    L3MotionFrame frame;if(!l3_puzzle_motion_sample(&p->motion,now,&frame))return 0;
    if(!l3_puzzle_ui_chrome(r,g,&frame.logical,scene,&p->ui))return 0;
    if(!p->page_valid[page] || !same_frame(&p->page_frame[page],&frame)){
        L3PuzzleGpuStats stats;
        if(!l3_puzzle_gpu_draw(&r->gpu,&p->layout,&p->assets,&frame,PRODOCK_GPU_BASE+page*r->page_bytes,
                               PRODOCK_GPU_BASE+2*r->page_bytes,r->pitch,&stats))return 0;
        p->page_frame[page]=frame;p->page_valid[page]=1;p->quads+=stats.quads;p->copy_pixels+=stats.copy_pixels;
    }else p->skipped++;
    p->frames++;scene->base=PRODOCK_GPU_BASE+page*r->page_bytes;scene->stride=r->pitch;scene->format=3;return 1;
}
