#include "l3_simon_light.h"
#include <math.h>
#include <string.h>
static int view_ok(const L3SimonView *v)
{
    if(!v || v->phase>L3_SIMON_COMPLETE || v->active_color>4 || v->phase_ms>600 || v->feedback_ms>240 ||
       !v->sequence_length || v->sequence_length>8 || v->input_index>v->sequence_length || v->grid.status>L3_MINI_LOST)return 0;
    if(v->phase==L3_SIMON_SHOW && (v->active_color>=4 || !v->phase_ms))return 0;
    if(v->feedback_ms && (v->phase!=L3_SIMON_INPUT || v->active_color>=4))return 0;
    return 1;
}
void l3_simon_light_reset(L3SimonLight *c){if(c)memset(c,0,sizeof(*c));}
static void trigger(L3SimonLight *c,unsigned color,unsigned duration,unsigned elapsed,unsigned gain,double now)
{
    c->start[color]=now-(double)elapsed*.001;c->duration[color]=duration;c->gain[color]=gain;c->triggers++;
}
int l3_simon_light_observe(L3SimonLight *c,const L3SimonView *a,const L3SimonView *b,uint32_t pressed,double now,uint32_t epoch)
{
    if(!c || !view_ok(b) || !isfinite(now) || now<0 || (c->valid && now<c->last_time))return 0;
    int fresh=!c->valid || c->epoch!=epoch || !view_ok(a);
    if(fresh){l3_simon_light_reset(c);c->valid=1;c->epoch=epoch;}
    if(c->paused)return 0;
    if(b->phase==L3_SIMON_SHOW){
        unsigned color=b->active_color,elapsed=600-b->phase_ms;
        int begins=fresh || a->phase!=L3_SIMON_SHOW || a->active_color!=color || b->phase_ms>a->phase_ms;
        /* Resuming a saved mid-flash starts at its real phase, never at zero. */
        if(begins)trigger(c,color,600,elapsed,256,now);
        else c->start[color]=now-(double)elapsed*.001;
    }else if(b->phase==L3_SIMON_INPUT && b->feedback_ms){
        unsigned color=b->active_color,elapsed=240-b->feedback_ms;
        if(fresh || a->phase!=b->phase || a->input_index!=b->input_index || b->feedback_ms>a->feedback_ms)
            trigger(c,color,240,elapsed,256,now);
        else c->start[color]=now-(double)elapsed*.001;
    }
    /* The engine clears active_color on the last correct input. Recover that
     * accepted front only from the real INPUT->ROUND_OK/COMPLETE transition. */
    if(!fresh && a->phase==L3_SIMON_INPUT && (b->phase==L3_SIMON_ROUND_OK || b->phase==L3_SIMON_COMPLETE)){
        static const uint32_t keys[4]={L3_MINI_UP,L3_MINI_RIGHT,L3_MINI_DOWN,L3_MINI_LEFT};
        unsigned count=0,color=0;for(unsigned i=0;i<4;i++)if(pressed&keys[i]){count++;color=i;}
        if(count==1)trigger(c,color,240,b->phase==L3_SIMON_ROUND_OK?600-b->phase_ms:0,256,now);
    }
    if(b->phase==L3_SIMON_ERROR && (fresh || a->phase!=L3_SIMON_ERROR) && b->active_color<4)trigger(c,b->active_color,360,0,220,now);
    /* SHOW never spills into the 250ms separation, including delayed frames. */
    if(!fresh && a->phase==L3_SIMON_SHOW && b->phase!=L3_SIMON_SHOW && a->active_color<4)c->duration[a->active_color]=0;
    c->latest=*b;c->last_time=now;return 1;
}
static unsigned smooth(double x)
{
    if(x<=0)return 0;if(x>=1)return 256;return (unsigned)(x*x*(3-2*x)*256+.5);
}
int l3_simon_light_sample(L3SimonLight *c,double now,L3SimonLightFrame *f)
{
    if(!c || !f || !c->valid || !isfinite(now) || now<c->last_time)return 0;
    double sample=c->paused?c->pause_time:now;memset(f,0,sizeof(*f));
    for(unsigned i=0;i<4;i++)f->radius_q8[i]=192;
    for(unsigned i=0;i<4;i++)if(c->duration[i]){
        double elapsed=(sample-c->start[i])*1000;unsigned attack=c->duration[i]==600?100:40;
        unsigned release=c->duration[i]==600?120:100,level=0;
        if(elapsed>=0 && elapsed<c->duration[i]){
            if(elapsed<attack)level=smooth(elapsed/attack);
            else if(elapsed>c->duration[i]-release)level=256-smooth((elapsed-(c->duration[i]-release))/release);
            else level=256;
        }
        f->level_q8[i]=level*c->gain[i]/256;
        f->radius_q8[i]=level?192+level/4:192;
        f->press_q8[i]=level;
    }
    f->phase=c->latest.phase;f->length=c->latest.sequence_length;f->index=c->latest.input_index;f->status=c->latest.grid.status;c->last_time=now;return 1;
}
int l3_simon_light_pause(L3SimonLight *c,int paused,double now)
{
    if(!c || !c->valid || !isfinite(now) || now<c->last_time)return 0;
    if(paused && !c->paused)c->pause_time=now;
    if(!paused && c->paused){double shift=now-c->pause_time;for(unsigned i=0;i<4;i++)c->start[i]+=shift;}
    c->paused=!!paused;c->last_time=now;return 1;
}
