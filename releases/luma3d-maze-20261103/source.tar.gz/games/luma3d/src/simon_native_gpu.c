#include "l3_simon_native_gpu.h"
#include <string.h>
static int quad(gpu_v1_context *g,int x,int y,int size,int u,int v,int texsize)
{
    gpu_vertex q[4]={{x,y,u,v,0,65536,256,256,256},{x+size,y,u+texsize,v,0,65536,256,256,256},
                     {x+size,y+size,u+texsize,v+texsize,0,65536,256,256,256},{x,y+size,u,v+texsize,0,65536,256,256,256}};
    return gpu_v1_quad(g,q);
}
int l3_simon_native_layout(unsigned width,unsigned height,L3SimonNativeLayout *out)
{
    if(!out)return 0;
    if(width==800 && height==480){*out=(L3SimonNativeLayout){width,height,160,24,480,448,1,1};return 1;}
    if(width==1280 && height==720){*out=(L3SimonNativeLayout){width,height,384,108,512,504,10,9};return 1;}
    return 0;
}
int l3_simon_native_assets(const L3SimonNativeLayout *l,L3SimonGpuAssets *a)
{
    L3SimonNativeLayout valid;if(!l || !a || !l3_simon_native_layout(l->width,l->height,&valid) || memcmp(&valid,l,sizeof(valid)))return 0;
    unsigned bg=0x1600000u,body=bg+l->w*l->h*2,halo=body+256*256*2,shadow=halo+128*128*2;
    if(shadow+32768>0x1700000u)return 0;
    memset(a,0,sizeof(*a));a->background=(gpu_target){bg,0,l->w,l->h,l->w*2,l->w*2};
    a->keys=(gpu_texture_level){body,256,256,512,GPU_RGB565,0,0,0};
    a->halo=(gpu_texture_level){halo,128,128,256,GPU_ARGB4444,0,0,0};a->shadow=(gpu_texture_level){shadow,128,128,256,GPU_ARGB4444,0,0,0};return 1;
}
static int texture_same(const gpu_texture_level *a,const gpu_texture_level *b)
{return a->base==b->base && a->width==b->width && a->height==b->height && a->stride==b->stride && a->format==b->format && !a->u_mode && !a->v_mode && !a->lod;}
int l3_simon_native_draw(gpu_v1_context *g,const L3SimonNativeLayout *l,const L3SimonGpuAssets *a,const L3SimonLightFrame *f,uint32_t page,uint32_t depth,unsigned *quads)
{
    L3SimonGpuAssets expected;if(!g || !g->emit || !a || !f || !quads || !l3_simon_native_assets(l,&expected))return 0;
    unsigned slot=l->width==800?1u<<20:2u<<20;
    if((page!=0x800000u && page!=0x800000u+slot) || depth!=0x800000u+slot*2)return 0;
    for(unsigned i=0;i<4;i++)if(f->level_q8[i]>256 || f->radius_q8[i]>256 || f->press_q8[i]>256)return 0;
    if(a->background.color!=expected.background.color || a->background.width!=l->w || a->background.height!=l->h || a->background.stride!=l->w*2 ||
       !texture_same(&a->keys,&expected.keys) || !texture_same(&a->halo,&expected.halo) || !texture_same(&a->shadow,&expected.shadow))return 0;
    unsigned pitch=l->width*2,offset=l->y*pitch+l->x*2;gpu_target t={page+offset,depth+offset,l->w,l->h,pitch,pitch};
    if(!gpu_v1_target(g,&t) || !gpu_v1_scissor(g,0,0,l->w,l->h) || !gpu_v1_copy(g,&a->background,0,0,0,0,l->w,l->h))return 0;
    const int ox[4]={344,464,344,224},oy[4]={66,190,314,190};
    int x[4],y[4],cell=(int)(112*l->scale_num/l->scale_den);
    for(unsigned i=0;i<4;i++){x[i]=(int)l->width/2+(ox[i]-400)*(int)l->scale_num/(int)l->scale_den-(int)l->x;y[i]=(l->width==800?244:360)+(oy[i]-244)*(int)l->scale_num/(int)l->scale_den-(int)l->y;}
    const unsigned rgb[4][3]={{256,48,24},{48,256,84},{48,100,256},{256,172,32}};*quads=0;
    for(unsigned pass=0;pass<3;pass++){
        if(!gpu_v1_texture(g,pass==0?&a->shadow:pass==1?&a->halo:&a->keys))return 0;
        for(unsigned i=0;i<4;i++){
            unsigned level=f->level_q8[i];if(pass==1 && !level)continue;
            gpu_material m={0};m.flags=pass==2?9:1;m.alpha=pass==0?110:pass==1?level*200/256:256;
            m.r=m.g=m.b=pass==2?144+level*112/256:256;
            if(pass==1){m.r=rgb[i][0];m.g=rgb[i][1];m.b=rgb[i][2];}
            if(!gpu_v1_material(g,&m))return 0;
            int size=pass==0?130:pass==1?130+(int)(f->radius_q8[i]*40/256):112-(int)(f->press_q8[i]*3/256);
            size=size*(int)l->scale_num/(int)l->scale_den;
            int dx=x[i]+(cell-size)/2,dy=y[i]+(cell-size)/2+(pass==1?0:pass==0?5:(int)(f->press_q8[i]*3/256));
            if(!quad(g,dx,dy,size,pass==2?(int)(i%2)*128:0,pass==2?(int)(i/2)*128:0,pass==2?112:128))return 0;
            (*quads)++;
        }
    }
    return 1;
}
