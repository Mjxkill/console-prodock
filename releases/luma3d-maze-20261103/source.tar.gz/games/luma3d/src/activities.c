#include "luma3d_activities.h"
#include "luma3d_garden.h"
#include "luma3d_activity_observer.h"
#include <math.h>

uint32_t l3_activity_id(unsigned k){return l3_arcade_id(k);}
const char *l3_activity_name(unsigned k){
 static const char *names[]={"Ruines des conduites","Atelier des pierres","Jardin des formes","Table de l'observatoire","Maison des lueurs","Clairière des quatre échos","Simulateur des étoiles","Tour des courroies"};
 return k<L3_ARCADE_COUNT?names[k]:"";
}
const char *l3_activity_reward(unsigned k){
 static const char *r[]={"Plan des conduites : prise ouverte + destination BASSIN","Sceau du bâtisseur : les terrasses ont deux chemins","Portillon du jardin ouvert pour toujours","Carte du ciel : souvenir de l'observatoire","Passage secret de la maison ouvert","Les quatre cristaux balisent le chemin du jardin","Balise du navigateur allumée à l'observatoire","Portillon de la tour ouvert : raccourci vers les eaux"};
 return k<L3_ARCADE_COUNT?r[k]:"";
}
L3Vec3 l3_activity_site(const L3Game *g,unsigned k){
 static const float p[][2]={{229,56},{227,40},{211,24},{258,26},{224,73},{220,32},{256,20},{231,42}};
 if(k>=L3_ARCADE_COUNT)return g->world.spawn;
 L3Vec3 r={p[k][0],0,p[k][1]};r.y=g->world.height(g->world.context,r.x,r.z);return r;
}
int l3_activity_won(const L3Game *g,unsigned k){return k<L3_ARCADE_COUNT&&!!(g->activities.arcade.won&(1u<<k));}
int l3_activity_enter(L3Game *g,unsigned k){
 L3Activities *a=&g->activities;
 if(k>=L3_ARCADE_COUNT||a->arcade.active||!g->story.region||g->story.dialogue>=0||g->story.journal)return 0;
 L3Vec3 p=l3_activity_site(g,k);
 if(k==L3_ARCADE_SIMON&&l3_garden_nearest(g)==5)p=l3_garden_site(g,5);
 if(hypotf(p.x-g->player.position.x,p.z-g->player.position.z)>2.5f||fabsf(p.y-g->player.position.y)>2)return 0;
 if(!l3_arcade_enter(&a->arcade,k,1))return 0;
 a->pending_us=0;a->revision++;
 /* E takes manual control. World pose, time and mission remain untouched. */
 g->autopilot=0;g->story.revision++;return 1;
}
void l3_activity_step(L3Game *g,const L3Input *in,float dt){
 L3Activities *a=&g->activities;if(!a->arcade.active)return;
 unsigned p=in?in->mini_pressed:0,h=in?in->mini_held:0;
 /* BACK, restart and the release gate do not accumulate hidden elapsed time. */
 unsigned us=0,ms=0;
 if(!a->arcade.release_inputs&&!(p&(L3_MINI_BACK|L3_ARCADE_RESTART))){
  if(!isfinite(dt))dt=0;
  us=(unsigned)lroundf(fminf(.1f,fmaxf(0,dt))*1000000)+a->pending_us;ms=us/1000;a->pending_us=us%1000;
 }
 L3ArcadeView before,after;int observed=l3_activity_observer_wants(g);
 int before_ok=observed&&l3_arcade_view(&a->arcade,&before);
 L3MiniTrace trace;uint32_t e=l3_arcade_step_trace(&a->arcade,p,h,ms,&trace);
 if(observed){int after_ok=l3_arcade_view(&a->arcade,&after);l3_activity_observer_emit(g,before_ok?&before:NULL,after_ok?&after:NULL,p,h,&trace);}
 if(e&L3_MINI_EVENT_EXIT||p&L3_ARCADE_RESTART)a->pending_us=0;
 if(e&(L3_MINI_EVENT_CHANGED|L3_MINI_EVENT_EXIT|L3_ARCADE_REWARD)){a->revision++;g->story.revision++;}
}
int l3_activities_valid(const L3Game *g){
 const L3Activities *a=&g->activities;
 return a->pending_us<1000&&l3_arcade_validate(&a->arcade)&&
  (!a->arcade.active||(g->story.region&&g->story.dialogue<0&&!g->story.journal));
}
