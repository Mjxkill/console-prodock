#include "luma3d_render.h"
#include "luma3d_activities.h"
#include "l3_mini_actors.h"
#include "generated.h"
#include "activity_art.h"
#include <math.h>
#include <string.h>

/* Authored MAZE grid becomes real metric walls and actors. G3D1 transforms,
 * clips, lights, projects, textures and depth-tests every visible triangle.
 * Static walls24 MiB; transient lantern/actor meshes26/27 MiB, never a live
 * scanout source. No screen-space animation coordinates or pre-rendered view. */
typedef struct {L3Render *r;uint32_t offset;gpu_geom_vertex v[256];gpu_geom_face f[384];unsigned nv,nf,n;gpu_geom_mesh *meshes;} Builder;
int l3_activity_art_open(L3Render *r){
 /*18 MiB is above the complete console bank, below HUD20/21 and geometry24+. */
 r->arcade_texture=PRODOCK_GPU_BASE+(18U<<20);
 uint32_t *dst=(uint32_t *)(r->memory+(18U<<20));const uint8_t *src=(const uint8_t *)l3_activity_texture;
 for(unsigned i=0;i<sizeof(l3_activity_texture)/4;i++){uint32_t word;memcpy(&word,src+i*4,4);dst[i]=word;}
 /* The texture cache retains physical DDR lines across texture switches and
  * does not snoop CPU writes. This one-time publication must therefore be
  * followed by an explicit invalidate, or the first MAZE request can reuse a
  * line retained from its previous owner. */
 gpu_v1_invalidate(&r->gpu);
 return 1;
}
static L3Vec3 sub(L3Vec3 a,L3Vec3 b){return (L3Vec3){a.x-b.x,a.y-b.y,a.z-b.z};}
static L3Vec3 cross(L3Vec3 a,L3Vec3 b){return (L3Vec3){a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
static float dot(L3Vec3 a,L3Vec3 b){return a.x*b.x+a.y*b.y+a.z*b.z;}
static L3Vec3 unit(L3Vec3 a){float n=sqrtf(dot(a,a));return (L3Vec3){a.x/n,a.y/n,a.z/n};}
static int seal(Builder *b){
 if(!b->nv)return 1;if(b->n>=24||b->offset>(28U<<20)||b->nv*32+b->nf*32>(28U<<20)-b->offset)return 0;
 unsigned start=b->offset;memcpy(b->r->memory+start,b->v,b->nv*32);b->offset+=b->nv*32;
 memcpy(b->r->memory+b->offset,b->f,b->nf*32);b->meshes[b->n++]=(gpu_geom_mesh){PRODOCK_GPU_BASE+start,PRODOCK_GPU_BASE+b->offset,(uint16_t)b->nv,(uint16_t)b->nf};b->offset+=b->nf*32;b->nv=b->nf=0;return 1;
}
static int quad(Builder *b,L3Vec3 a,L3Vec3 c,L3Vec3 d,L3Vec3 e,unsigned red,unsigned green,unsigned blue){
 if(b->nv+4>256&&!seal(b))return 0;L3Vec3 p[]={a,c,d,e},normal=unit(cross(sub(c,a),sub(d,a)));unsigned v=b->nv;
 for(unsigned i=0;i<4;i++){b->v[b->nv]=(gpu_geom_vertex){0};if(!gpu_geom_fixed(p[i].x,&b->v[b->nv].x)||!gpu_geom_fixed(p[i].y,&b->v[b->nv].y)||!gpu_geom_fixed(p[i].z,&b->v[b->nv].z))return 0;b->nv++;}
 const unsigned tri[2][3]={{0,1,2},{0,2,3}};
 unsigned mode=b->r->activity_mode,tile=mode==L3_MINI_MAZE+1?(normal.y>.8f&&fabsf(a.y)<.01f?2:0):mode==L3_ARCADE_PLATFORM+1?(normal.y>.8f?1:3):2;
 if(b->offset<(26U<<20)){red=green=blue=256;} /* painted albedo already supplies its colour */
 unsigned ux=(tile&1)*128+2,uy=(tile>>1)*128+2;unsigned uv[4][2]={{ux,uy},{ux+123,uy},{ux+123,uy+123},{ux,uy+123}};
 int nx=(int)lroundf(normal.x*32767),ny=(int)lroundf(normal.y*32767),nz=(int)lroundf(normal.z*32767);
 for(unsigned f=0;f<2;f++){uint32_t *w=b->f[b->nf++].words;memset(w,0,32);w[0]=(v+tri[f][0])|((v+tri[f][1])<<8)|((v+tri[f][2])<<16);for(unsigned i=0;i<3;i++)w[1+i]=uv[tri[f][i]][0]<<16|uv[tri[f][i]][1];w[4]=((uint32_t)(nx&65535)<<16)|(ny&65535);w[5]=nz&65535;w[6]=red|(green<<9)|(blue<<18);}
 return 1;
}
static int box(Builder *b,float x,float y,float z,float w,float h,float d,unsigned r,unsigned g,unsigned blue){
 float l=x-w/2,R=x+w/2,n=z-d/2,s=z+d/2,t=y+h;
 return quad(b,(L3Vec3){l,t,n},(L3Vec3){l,t,s},(L3Vec3){R,t,s},(L3Vec3){R,t,n},r,g,blue)&&
 quad(b,(L3Vec3){l,y,n},(L3Vec3){l,t,n},(L3Vec3){R,t,n},(L3Vec3){R,y,n},r,g,blue)&&
 quad(b,(L3Vec3){R,y,s},(L3Vec3){R,t,s},(L3Vec3){l,t,s},(L3Vec3){l,y,s},r,g,blue)&&
 quad(b,(L3Vec3){l,y,s},(L3Vec3){l,t,s},(L3Vec3){l,t,n},(L3Vec3){l,y,n},r,g,blue)&&
 quad(b,(L3Vec3){R,y,n},(L3Vec3){R,t,n},(L3Vec3){R,t,s},(L3Vec3){R,y,s},r,g,blue);
}
static int triangle(Builder *,L3Vec3,L3Vec3,L3Vec3,unsigned,unsigned,unsigned);
static int phantom(Builder *b,float x,float z,float time,int frightened){
 /* Bell cloak and scalloped hem:32 faces including the two readable eyes,
  * replacing the old100-face stack of boxes and four-sided eye sockets. */
 float lift=.18f+.08f*sinf(time*2.4f+x),twist=.055f*sinf(time*1.5f);
 unsigned red=frightened?105:242,green=frightened?205:222,blue=frightened?245:189;
 for(unsigned i=0;i<8;i++){
  float a=i*.78539816f+twist,c=(i+1)*.78539816f+twist;
  L3Vec3 p={x+.55f*cosf(a),lift+(i&1?.13f:0),z+.55f*sinf(a)},q={x+.55f*cosf(c),lift+(i&1?0:.13f),z+.55f*sinf(c)};
  L3Vec3 u={x+.38f*cosf(a),lift+1.05f,z+.38f*sinf(a)},v={x+.38f*cosf(c),lift+1.05f,z+.38f*sinf(c)};
  if(!quad(b,p,u,v,q,red,green,blue)||!triangle(b,u,(L3Vec3){x,lift+1.34f,z},v,red,green,blue))return 0;
 }
 for(int i=-1;i<=1;i+=2){float ex=x+i*.16f;
  if(!quad(b,(L3Vec3){ex-.055f,lift+.92f,z+.385f},(L3Vec3){ex-.055f,lift+.73f,z+.385f},(L3Vec3){ex+.055f,lift+.73f,z+.385f},(L3Vec3){ex+.055f,lift+.92f,z+.385f},20,28,46))return 0;
  if(!quad(b,(L3Vec3){ex-.019f,lift+.88f,z+.39f},(L3Vec3){ex-.019f,lift+.83f,z+.39f},(L3Vec3){ex+.019f,lift+.83f,z+.39f},(L3Vec3){ex+.019f,lift+.88f,z+.39f},240,245,232))return 0;
 }return 1;
}
static int courier(Builder *b,float x,float y,float z,float phase){
 float stride=.08f*sinf(phase),arm=.10f*sinf(phase);
 return box(b,x-.16f,y,z+stride,.21f,.46f,.3f,65,68,83)&&box(b,x+.16f,y,z-stride,.21f,.46f,.3f,65,68,83)&&
 box(b,x-.16f,y,z+stride+.06f,.25f,.15f,.4f,76,51,42)&&box(b,x+.16f,y,z-stride+.06f,.25f,.15f,.4f,76,51,42)&&
 box(b,x,y+.45f,z,.56f,.5f,.42f,45,172,167)&&box(b,x,y+.95f,z,.4f,.37f,.4f,244,200,153)&&
 box(b,x,y+1.24f,z-.02f,.44f,.15f,.43f,79,55,43)&&box(b,x-.38f,y+.5f,z-arm,.16f,.39f,.2f,58,180,175)&&
 box(b,x+.38f,y+.5f,z+arm,.16f,.39f,.2f,58,180,175);
}
static int geometry(L3Render *r,const L3MiniView *v,const L3MiniActors *actors){
 if(!r->maze_static_count){Builder b={.r=r,.offset=24U<<20,.meshes=r->maze_static};
  for(unsigned y=0;y<v->height*2;y+=4)for(unsigned x=0;x<v->width*2;x+=4){
   float x1=fminf(x+4,v->width*2),y1=fminf(y+4,v->height*2);
   if(!quad(&b,(L3Vec3){x,0,y},(L3Vec3){x,0,y1},(L3Vec3){x1,0,y1},(L3Vec3){x1,0,y},240,235,225))return 0;
  }
  for(unsigned y=0;y<v->height;y++)for(unsigned x=0;x<v->width;x++)if(v->cells[y*20+x].kind==L3_MINI_CELL_WALL)
   if(!box(&b,x*2+1,0,y*2+1,2,1.55f,2,256,256,256))return 0;
  if(!seal(&b)||b.offset>25U<<20)return 0;r->maze_static_count=b.n;
 }
 unsigned page=r->frame&1;Builder b={.r=r,.offset=(26U+page)<<20,.meshes=r->maze_dynamic};
 for(unsigned y=0;y<v->height;y++)for(unsigned x=0;x<v->width;x++){
  unsigned kind=v->cells[y*20+x].kind;if(kind!=L3_MINI_CELL_PELLET&&kind!=L3_MINI_CELL_POWER)continue;
  float size=kind==L3_MINI_CELL_POWER?.42f:.18f;
  if(!box(&b,x*2+1,.15f,y*2+1,size,kind==L3_MINI_CELL_POWER?.7f:.25f,size,256,220,90))return 0;
 }
 for(unsigned i=0;i<actors->count;i++){
  const L3MiniActor *a=&actors->actors[i];float x=a->x256/128.f,z=a->y256/128.f;
  if(i==0){
   if(!courier(&b,x,0,z,v->elapsed_ms*.018f))return 0;
   /* A thin, raised brass guide ring keeps the courier distinguishable from
    * the amber lanterns behind a wall. Same dynamic batch, 16 extra faces. */
   for(unsigned n=0;n<8;n++){
    float a=n*.78539816f,d=(n+1)*.78539816f;
    if(!quad(&b,(L3Vec3){x+.48f*cosf(a),1.68f,z+.48f*sinf(a)},
       (L3Vec3){x+.38f*cosf(a),1.68f,z+.38f*sinf(a)},
       (L3Vec3){x+.38f*cosf(d),1.68f,z+.38f*sinf(d)},
       (L3Vec3){x+.48f*cosf(d),1.68f,z+.48f*sinf(d)},256,244,171))return 0;
   }
  }
  else if(!phantom(&b,x,z,v->elapsed_ms*.001f,!!(a->flags&L3_MINI_ACTOR_FRIGHTENED)))return 0;
 }
 if(!seal(&b)||b.offset>((27U+page)<<20))return 0;r->maze_dynamic_count=b.n;return 1;
}
int l3_maze_render(L3Render *r,const L3Game *g){
 L3MiniView v;L3MiniActors actors;const L3MiniState *s=&g->activities.arcade.base[L3_MINI_MAZE];
 if(!l3_mini_view(s,&v)||!l3_mini_actors(s,&actors))return 0;
 if(!r->maze_motion.valid){if(!l3_maze_motion_observe(&r->maze_motion,&v,&actors,r->presentation_seconds,r->presentation_epoch))return 0;}
 uint8_t floor[400];
 if(!l3_mini_maze_floor(s,floor))return 0;
 if(!r->maze_events.valid && !l3_maze_events_observe(&r->maze_events,&r->maze_motion,floor,NULL,r->presentation_seconds,r->presentation_epoch))return 0;
 if(!l3_maze_events_sample(&r->maze_events,r->presentation_seconds,floor))return 0;
 for(unsigned i=0;i<400;i++)v.cells[i].kind=floor[i];
 if(!l3_maze_motion_sample(&r->maze_motion,r->presentation_seconds,&actors)||!geometry(r,&v,&actors))return 0;
 /* A stable angled view keeps the whole house navigable. All coordinates are
  * world metres and the matrix is recomputed normally for G3D1 each frame. */
 L3Vec3 eye={v.width,42,v.height+9},target={v.width,0,v.height};
 L3Vec3 f=unit(sub(target,eye)),right=unit(cross(f,(L3Vec3){0,1,0})),down=cross(f,right),rows[]={right,down,f};
 gpu_target t={PRODOCK_GPU_BASE+(r->frame&1)*r->page_bytes,PRODOCK_GPU_BASE+2*r->page_bytes,r->width,r->height,r->pitch,r->pitch};
 if(!gpu_v1_target(&r->gpu,&t)||!gpu_v1_scissor(&r->gpu,0,0,r->width,r->height)||!gpu_v1_clear(&r->gpu,3,0x0864,65535,0,0,r->width,r->height))return 0;
 gpu_geom_camera cam={65536,80*65536,(int32_t)(r->focal*65536),(int32_t)(r->focal*65536),r->width/2,r->height/2};if(!gpu_geom_set_camera(&r->gpu,&cam))return 0;
 gpu_geom_transform m;for(unsigned a=0;a<3;a++){m.values[a*4]=(int32_t)lroundf(rows[a].x*65536);m.values[a*4+1]=(int32_t)lroundf(rows[a].y*65536);m.values[a*4+2]=(int32_t)lroundf(rows[a].z*65536);m.values[a*4+3]=(int32_t)lroundf(-dot(rows[a],eye)*65536);}
 gpu_geom_light light={-12000,26000,-15000,180,76};gpu_material material={1|2|4|16,256,65535,256,256,256,0,0,0};
 gpu_texture_level texture={r->arcade_texture,256,256,512,GPU_RGB565,1,1,0};
 if(!gpu_geom_set_transform(&r->gpu,&m)||!gpu_geom_set_light(&r->gpu,&light)||!gpu_v1_material(&r->gpu,&material)||!gpu_v1_texture(&r->gpu,&texture))return 0;
 for(unsigned i=0;i<r->maze_static_count;i++){if(!gpu_geom_draw(&r->gpu,&r->maze_static[i],1))return 0;r->draws++;r->triangles+=r->maze_static[i].face_count;}
 material.flags=2|4;if(!gpu_v1_material(&r->gpu,&material))return 0;
 for(unsigned i=0;i<r->maze_dynamic_count;i++){if(!gpu_geom_draw(&r->gpu,&r->maze_dynamic[i],1))return 0;r->draws++;r->triangles+=r->maze_dynamic[i].face_count;}
 return !r->failed;
}

static int triangle(Builder *b,L3Vec3 a,L3Vec3 c,L3Vec3 d,unsigned red,unsigned green,unsigned blue){
 if(b->nv+3>256&&!seal(b))return 0;L3Vec3 p[]={a,c,d},n=unit(cross(sub(c,a),sub(d,a)));unsigned v=b->nv;
 for(unsigned i=0;i<3;i++){b->v[b->nv]=(gpu_geom_vertex){0};if(!gpu_geom_fixed(p[i].x,&b->v[b->nv].x)||!gpu_geom_fixed(p[i].y,&b->v[b->nv].y)||!gpu_geom_fixed(p[i].z,&b->v[b->nv].z))return 0;b->nv++;}
 uint32_t *w=b->f[b->nf++].words;memset(w,0,32);w[0]=v|((v+1)<<8)|((v+2)<<16);w[4]=((uint32_t)((int)lroundf(n.x*32767)&65535)<<16)|((int)lroundf(n.y*32767)&65535);w[5]=(int)lroundf(n.z*32767)&65535;w[6]=red|(green<<9)|(blue<<18);return 1;
}
static int crystal(Builder *b,float x,float z,float height,unsigned sides,unsigned r,unsigned g,unsigned blue){
 for(unsigned i=0;i<sides;i++){
  float a=i*6.2831853f/sides,c=(i+1)*6.2831853f/sides;
  L3Vec3 p={x+.51f*cosf(a),.42f,z+.51f*sinf(a)},q={x+.51f*cosf(c),.42f,z+.51f*sinf(c)};
  L3Vec3 u={x+.45f*cosf(a),height*.72f,z+.45f*sinf(a)},v={x+.45f*cosf(c),height*.72f,z+.45f*sinf(c)};
  float facet=.68f+.32f*(i%3)/2.f;
  if(!quad(b,p,u,v,q,(unsigned)(r*facet),(unsigned)(g*facet),(unsigned)(blue*facet))||
     !triangle(b,u,(L3Vec3){x+.08f,height,z-.06f},v,r,g,blue)||
     !triangle(b,p,q,(L3Vec3){x,.23f,z},r/2,g/2,blue/2))return 0;
 }return 1;
}
static int barrel(Builder *b,float x,float y,float z,float angle){
 for(unsigned i=0;i<8;i++){
  float a=angle+i*.78539816f,c=angle+(i+1)*.78539816f;float radius=.34f;
  L3Vec3 p={x+radius*cosf(a),y+radius*sinf(a),z-.32f},q={x+radius*cosf(c),y+radius*sinf(c),z-.32f},u=p,v=q;u.z=v.z=z+.32f;
  unsigned r=i&1?180:235,g=i&1?125:180,blue=i&1?75:110;
  if(!quad(b,p,u,v,q,r,g,blue)||!triangle(b,(L3Vec3){x,y,z-.32f},p,q,130,100,75)||!triangle(b,(L3Vec3){x,y,z+.32f},v,u,130,100,75))return 0;
 }return 1;
}
int l3_arcade_3d_render(L3Render *r,const L3Game *g){
 unsigned kind=g->activities.arcade.active-1,page=r->frame&1;
 L3SimonView simon;L3PlatformView tower;
 if(kind==L3_ARCADE_SIMON){if(!l3_simon_view(&g->activities.arcade.simon,&simon))return 0;}
 else if(kind==L3_ARCADE_PLATFORM){if(!l3_platform_view(&g->activities.arcade.platform,&tower))return 0;}
 else return 0;
 if(kind==L3_ARCADE_PLATFORM&&r->activity_stage!=tower.floor){r->activity_stage=tower.floor;r->maze_static_count=0;}
 if(!r->maze_static_count){Builder b={.r=r,.offset=24U<<20,.meshes=r->maze_static};
  if(kind==L3_ARCADE_SIMON){
   for(int z=-5;z<5;z+=2)for(int x=-6;x<6;x+=2)
    if(!quad(&b,(L3Vec3){x,0,z},(L3Vec3){x,0,z+2},(L3Vec3){x+2,0,z+2},(L3Vec3){x+2,0,z},256,256,256))return 0;
   for(unsigned i=0;i<4;i++){static const float x[]={0,3,0,-3},z[]={-2.3f,0,2.3f,0};if(!box(&b,x[i],0,z[i],1.7f,.25f,1.7f,190,185,170))return 0;}
  }else{
   for(unsigned side=0;side<4;side++){float x=side&1?12.4f:.4f,z=side&2?4.65f:.45f;if(!box(&b,x,-.16f,z,.24f,10.6f,.24f,90,115,135))return 0;}
   /* Every platform slab uses the exact collision rectangles from the engine.
    * Missing rectangles stay visibly empty: no decorative floor over a gap. */
   for(unsigned i=0;i<tower.surface_count;i++){const L3PlatformSurface *p=tower.surfaces+i;
    float x0=p->x0/3200.f,x1=p->x1/3200.f,z0=p->z0/3200.f,z1=p->z1/3200.f,y=p->y256/3200.f;
    if(y>tower.floor*2.56f+.05f){
     /* Upper decks are a visible cutaway frame, never an opaque ceiling
      * hiding the controlled actor. The occupied/lower decks stay complete. */
     const float t=.22f;
     if(!quad(&b,(L3Vec3){x0,y,z0},(L3Vec3){x0,y,z0+t},(L3Vec3){x1,y,z0+t},(L3Vec3){x1,y,z0},100,125,150)||
        !quad(&b,(L3Vec3){x0,y,z1-t},(L3Vec3){x0,y,z1},(L3Vec3){x1,y,z1},(L3Vec3){x1,y,z1-t},100,125,150)||
        !quad(&b,(L3Vec3){x0,y,z0},(L3Vec3){x0,y,z1},(L3Vec3){x0+t,y,z1},(L3Vec3){x0+t,y,z0},100,125,150)||
        !quad(&b,(L3Vec3){x1-t,y,z0},(L3Vec3){x1-t,y,z1},(L3Vec3){x1,y,z1},(L3Vec3){x1,y,z0},100,125,150))return 0;
    }else if(!box(&b,(x0+x1)/2,y-.16f,(z0+z1)/2,x1-x0,.16f,z1-z0,170,145,115))return 0;
   }
   for(unsigned i=0;i<tower.ladder_count;i++){const L3PlatformLadder *p=tower.ladders+i;float x=p->x256/3200.f,z=p->z256/3200.f,y0=p->y0/3200.f,y1=p->y1/3200.f;
    for(int side=-1;side<=1;side+=2)if(!box(&b,x+side*.30f,y0,z,.09f,y1-y0,.09f,240,195,90))return 0;
    for(float y=y0+.16f;y<y1;y+=.32f)if(!box(&b,x,y,z,.65f,.13f,.15f,240,195,90))return 0;
   }
  }
  if(!seal(&b)||b.offset>(25U<<20))return 0;r->maze_static_count=b.n;
 }
 Builder b={.r=r,.offset=(26U+page)<<20,.meshes=r->maze_dynamic};
 if(kind==L3_ARCADE_SIMON){
  static const float x[]={0,3,0,-3},z[]={-2.3f,0,2.3f,0};static const unsigned rgb[4][3]={{255,65,90},{60,225,125},{80,150,255},{255,220,70}};
  for(unsigned i=0;i<4;i++){float bright=simon.active_color==i?1:.45f;
   if(!crystal(&b,x[i],z[i],2.1f+i*.18f,4+i,rgb[i][0]*bright,rgb[i][1]*bright,rgb[i][2]*bright))return 0;
   /* Raised white dots give a second identity in addition to direction/color. */
   for(unsigned j=0;j<=i;j++)if(!box(&b,x[i]-.45f+j*.30f,.27f,z[i]+.67f,.12f,.07f,.12f,245,245,230))return 0;
  }
 }else{
  for(unsigned i=0;i<tower.actor_count;i++){const L3PlatformActor *a=tower.actors+i;float x=a->x256/3200.f,y=a->y256/3200.f,z=a->z256/3200.f;
   if(a->kind==2){if(!barrel(&b,x,y+.34f,z,x*2.5f))return 0;}
   else if(a->kind==1){if(!courier(&b,x,y,z,tower.elapsed_ms*.018f))return 0;}
   else if(a->kind==3){if(!box(&b,x,y,z,.8f,1,.6f,235,195,70)||!box(&b,x,y+1,z,.15f,.8f,.15f,255,245,140))return 0;}
   else if(a->kind==4){if(!box(&b,x,y,z,.8f,.14f,.8f,80,210,240))return 0;}
  }
 }
 if(!seal(&b)||b.offset>((27U+page)<<20))return 0;r->maze_dynamic_count=b.n;
 L3Vec3 eye=kind==L3_ARCADE_SIMON?(L3Vec3){0,10,12}:(L3Vec3){21,17,23};
 L3Vec3 target=kind==L3_ARCADE_SIMON?(L3Vec3){0,0,0}:(L3Vec3){6.4f,5,2.56f};
 L3Vec3 f=unit(sub(target,eye)),right=unit(cross(f,(L3Vec3){0,1,0})),down=cross(f,right),rows[]={right,down,f};
 gpu_target t={PRODOCK_GPU_BASE+(r->frame&1)*r->page_bytes,PRODOCK_GPU_BASE+2*r->page_bytes,r->width,r->height,r->pitch,r->pitch};
 if(!gpu_v1_target(&r->gpu,&t)||!gpu_v1_scissor(&r->gpu,0,0,r->width,r->height)||!gpu_v1_clear(&r->gpu,3,kind==L3_ARCADE_SIMON?0x1948:0x18e7,65535,0,0,r->width,r->height))return 0;
 gpu_geom_camera cam={65536,80*65536,(int32_t)(r->focal*65536),(int32_t)(r->focal*65536),r->width/2,r->height/2};if(!gpu_geom_set_camera(&r->gpu,&cam))return 0;
 gpu_geom_transform m;for(unsigned a=0;a<3;a++){m.values[a*4]=(int32_t)lroundf(rows[a].x*65536);m.values[a*4+1]=(int32_t)lroundf(rows[a].y*65536);m.values[a*4+2]=(int32_t)lroundf(rows[a].z*65536);m.values[a*4+3]=(int32_t)lroundf(-dot(rows[a],eye)*65536);}
 gpu_geom_light light={-12000,26000,-15000,200,56};gpu_material material={1|2|4|16,256,65535,256,256,256,0,0,0};
 gpu_texture_level texture={r->arcade_texture,256,256,512,GPU_RGB565,1,1,0};
 if(!gpu_geom_set_transform(&r->gpu,&m)||!gpu_geom_set_light(&r->gpu,&light)||!gpu_v1_material(&r->gpu,&material)||!gpu_v1_texture(&r->gpu,&texture))return 0;
 for(unsigned i=0;i<r->maze_static_count;i++){if(!gpu_geom_draw(&r->gpu,&r->maze_static[i],1))return 0;r->draws++;r->triangles+=r->maze_static[i].face_count;}
 material.flags=2|4;if(!gpu_v1_material(&r->gpu,&material))return 0;
 for(unsigned i=0;i<r->maze_dynamic_count;i++){if(!gpu_geom_draw(&r->gpu,&r->maze_dynamic[i],1))return 0;r->draws++;r->triangles+=r->maze_dynamic[i].face_count;}
 return !r->failed;
}
