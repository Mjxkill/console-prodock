#include "luma3d_amber.h"
#include "luma3d_activities.h"
#include "luma3d_render.h"
#include "luma3d_showcase.h"
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>

#define HUD_BASE (20U<<20)
#define HUD_PAGE (1U<<20)
#define TOP (r->width>400?64U:44U)
#define BOTTOM (r->width>400?384U:256U)
static unsigned native_width(const L3Render *r) {return r->width*2;}
static void rect(L3Render *r,int x,int y,int w,int h,unsigned c) {
    int width=(int)native_width(r),height=TOP+BOTTOM;
    for(int yy=y;yy<y+h;yy++)if(yy>=0&&yy<height)
        for(int xx=x;xx<x+w;xx++)if(xx>=0&&xx<width)r->hud[yy*width+xx]=(uint8_t)c;
}
static void text(L3Render *r,int x,int y,const char *string,unsigned c) {
    static const unsigned colors[]={0,64,74,78,72,81};
    if(r->width>400)y=y<(int)TOP?y*3/2:(int)TOP+(y-(int)TOP)*3/2;
    l3_ui_text(r->hud,native_width(r),TOP+BOTTOM,x,y,0,string,c<6?colors[c]:c,native_width(r)-(unsigned)x-28);
}
static void panel(L3Render *r,unsigned y,unsigned h) {
    unsigned w=native_width(r);
    rect(r,20,(int)y+5,(int)w-40,(int)h-7,64);
    rect(r,16,(int)y+9,(int)w-32,(int)h-15,64);
    rect(r,24,(int)y+3,(int)w-48,1,76);
    rect(r,28,(int)y+8,2,(int)h-18,78);
}
static uint32_t pack(unsigned r,unsigned g,unsigned b) {return (r>>2)<<12|(g>>2)<<6|(b>>2);}
int l3_hud_open(L3Render *r) {
    r->hud=calloc(native_width(r),TOP+BOTTOM);if(!r->hud)return 0;
    unsigned colors[][3]={{0,0,0},{20,32,40},{244,242,222},{245,190,86},{159,190,194},{144,220,167}};
    for(unsigned i=0;i<6;i++)r->hud_palette.rgb[i]=pack(colors[i][0],colors[i][1],colors[i][2]);
    if(!r->host&&ioctl(r->fd,PRODOCK_PALETTE,&r->hud_palette)) {perror("LUMA3D palette");r->failed=1;return 0;}
    return 1;
}
static const char *notice(unsigned id) {
    if(id==15)return "Rejoins le chemin des eaux pour reprendre la visite automatique.";
    static const char *t[]={"", "Mission reçue : le courrier du phare", "Nouvel indice : les trois pierres du relais", "Le relais répond à ton geste", "Relais réveillé : la crête attend ton courrier", "Le lien est rétabli. Merci, messager !", "Mauvais ordre : les pierres sont prêtes à recommencer", "Lieu découvert : le relais des Roseaux"};
    static const char *work[]={"Nouvelle mission : l'atelier des vents","Cuivre : les deux ailettes. Bleue : elle seule.","La roue repart, la porte est ouverte !","Cloche retrouvée : retour auprès de Maëlle","La cloche retrouve sa place au village","Iria connaît le mécanisme : lui demander conseil",
        /* Toast 14 : site 9 des terrasses encore verrouillé tant que la
         * quête de l'atelier des vents n'avance pas (amber.c, amber_phase 0). */
        "Le passage reste fermé : poursuis la quête de l'atelier des vents."};
    return id<8?t[id]:id<15?work[id-8]:"";
}
int l3_hud_prepare(L3Render *r,const L3Game *g,struct prodock_scene *scene) {
    unsigned page=r->frame&1,w=native_width(r),stamp=g->story.revision+1;
    unsigned bottom=g->story.journal?248:g->story.dialogue>=0?130:g->story.toast_time>0?64:40;
    if(r->width>400)bottom=(bottom*3+1)/2;
    stamp=(stamp*16777619u)^g->collected_count^((unsigned)g->autopilot<<8)^((unsigned)g->village_demo_active<<9)^bottom;
    if(r->hud_stamp[page]!=stamp) {
        memset(r->hud,0,w*(TOP+BOTTOM));panel(r,0,TOP);
        char line[120];snprintf(line,sizeof(line),"%s   %u/4 lettres   %s",g->story.workshop_phase==4?"LES TERRASSES D’AMBRE":g->story.phase==4?"L’ATELIER DES VENTS":"LE COURRIER DU PHARE",g->collected_count,g->village_demo_active?"DEMO LUCIOLES":g->autopilot?"VISITE AUTO":"À TOI DE JOUER");
        if(g->showcase_status)snprintf(line,sizeof(line),"DÉMO %u/%u   E : prendre la main   Q : quitter",g->showcase_stage+1,l3_showcase_stages());
        text(r,34,5,line,3);
        text(r,34,24,g->showcase_status==3?"Visite interrompue. E permet de continuer librement.":g->showcase_status?l3_showcase_title(g->showcase_stage):l3_story_objective(g),2);panel(r,TOP,bottom);
        if(g->story.journal) {
            text(r,34,TOP+5,"CARNET DU VOYAGE",3);
            text(r,34,TOP+33,l3_story_objective(g),2);
            const char *steps[]={"Rencontrer Maëlle","Rapporter deux lettres à Silo","Réveiller les trois pierres du relais","Remettre le courrier à Iria"};
            const char *worksteps[]={"Recevoir les indications d'Iria","Accorder les ailettes, ouvrir l'atelier","Entrer dans la réserve et prendre la cloche","Rapporter la cloche à Maëlle"};
            const char *ambersteps[]={"Rencontrer Nora aux terrasses","Diriger la prise vers le bassin","Rencontrer Nils par le sentier ou le pont","Rapporter les nouvelles à Nora"};
            unsigned phase=g->story.workshop_phase==4?(g->story.amber_phase?g->story.amber_phase-1:0):g->story.phase==4?g->story.workshop_phase:g->story.phase;
            for(unsigned i=0;i<4;i++){int done=g->story.workshop_phase==4?(i==0?g->story.amber_phase>=2:i==1?g->story.amber_phase>=3:i==2?g->story.amber_met_nils:g->story.amber_phase==5):phase>i;snprintf(line,sizeof(line),"%s %s",done?"[fait]":"[    ]",g->story.workshop_phase==4?ambersteps[i]:g->story.phase==4?worksteps[i]:steps[i]);text(r,34,TOP+65+i*24,line,done?5:4);}
            if(g->story.region){
                snprintf(line,sizeof(line),"Défis facultatifs : %u/8 souvenirs. Jardin %s / Maison %s",(unsigned)__builtin_popcount(g->activities.arcade.won),l3_activity_won(g,2)?"ouvert":"fermé",l3_activity_won(g,4)?"ouverte":"fermée");
                text(r,34,TOP+165,line,5);
                text(r,34,TOP+189,"Sentier ouest libre. Bassin : pont. Jardin : raccourci.\nWASD marcher / E choisir un lieu / J fermer",4);
            }else text(r,34,TOP+177,"WASD marcher / majuscules courir / espace sauter\nIUKL regarder / E parler ou activer / T visite auto\nJ fermer le carnet / Q quitter",4);
        } else if(g->story.dialogue>=0) {
            text(r,34,TOP+5,l3_story_speaker(g),3);
            text(r,34,TOP+33,l3_story_dialogue(g),2);
            text(r,34,TOP+106,(g->autopilot||g->showcase_status)?"Visite : lecture automatique. E pour prendre la main.":"E · Continuer",5);
        } else {
            text(r,34,TOP+7,l3_story_prompt(g),2);
            if(bottom>40)text(r,34,TOP+33,notice(g->story.toast),3);
        }
        /* Only the inactive display bank is written; one aligned CPU copy on
         * semantic change, no glyph DRAWs and no per-frame text upload. */
        uint32_t *dst=(uint32_t *)(r->memory+HUD_BASE+page*HUD_PAGE);
        unsigned bytes=w*(TOP+bottom);
        for(unsigned i=0;i<bytes/4;i++){uint32_t word;memcpy(&word,r->hud+i*4,4);dst[i]=word;}
        r->hud_uploads++;r->hud_bytes+=bytes;r->hud_stamp[page]=stamp;
    }
    r->hud_height=bottom;
    unsigned base=PRODOCK_GPU_BASE+HUD_BASE+page*HUD_PAGE;
    for(unsigned i=0;i<2;i++) {
        uint32_t *l=scene->layers[i];unsigned h=i?bottom:TOP,y=i?r->height*2-bottom:0;
        if(!i&&g->story.dialogue>=0&&!g->story.journal)continue;
        l[0]=base+(i?TOP*w:0);l[1]=w|(h<<16);l[2]=y<<16;l[3]=w|(h<<16);l[5]=w;l[6]=3;
    }
    scene->layers_enabled=1;r->last_scene=*scene;return 1;
}
int l3_hud_dump(L3Render *r,const char *prefix) {
    char path[1024];if(snprintf(path,sizeof(path),"%s.overlay.json",prefix)>=(int)sizeof(path))return 0;
    FILE *f=fopen(path,"w");if(!f)return 0;
    fprintf(f,"{\"width\":%u,\"height\":%u,\"palette\":[",r->width*2,r->height*2);
    for(unsigned i=0;i<256;i++)fprintf(f,"%s%u",i?",":"",r->hud_palette.rgb[i]);
    fputs("],\"layers\":[",f);
    for(unsigned i=0;i<12;i++) {fprintf(f,"%s[",i?",":"");for(unsigned j=0;j<8;j++)fprintf(f,"%s%u",j?",":"",r->last_scene.layers[i][j]);fputs("]",f);}
    fputs("],\"sprites\":[",f);for(unsigned i=0;i<64;i++){fprintf(f,"%s[",i?",":"");for(unsigned j=0;j<4;j++)fprintf(f,"%s%u",j?",":"",r->last_scene.sprites[i][j]);fputs("]",f);}
    fprintf(f,"],\"sprite_count\":%u,\"hud_uploads\":%u,\"hud_bytes\":%u}\n",r->sprite_count,r->hud_uploads,r->hud_bytes);
    return fclose(f)==0;
}
