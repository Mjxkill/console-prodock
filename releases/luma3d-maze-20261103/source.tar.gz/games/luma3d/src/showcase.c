#define _POSIX_C_SOURCE 200809L
#include "luma3d_showcase.h"
#include "luma3d_activities.h"
#include "luma3d_village.h"
/* LUMA3D VILLAGE V6: the guided tour never activates or clears the optional quest. */
#include <math.h>
#include <string.h>
#include <time.h>
static double diagnostic_clock(void){struct timespec t;if(clock_gettime(CLOCK_MONOTONIC,&t))return 0;return t.tv_sec+t.tv_nsec*1e-9;}

typedef struct {float x,z;} Point;
enum {AUTO,LOOK,TALK,PRESS1,PRESS2,ACTIVITY,RETURN,FINISH,GARDEN_SEED,GARDEN_GATE};
typedef struct {const char *title;const Point *path;unsigned count,action,kind;} Stage;
static const Point west[]={{220,58},{224,50},{224,42},{224,30},{232,24},{244,24},{250,24},{252,21.2f}};
static const Point garden[]={{250,24},{244,24},{232,24},{224,30},{218,28},{212,24}};
static const Point shortcut[]={{216,34},{216,40},{216,44},{220,48},{220,58},{224,54},{230,50}};
static const Point valve[]={{236,46},{242,43}};
static const Point water[]={{244,40},{244,28},{250,24},{252,21.2f}};
static const Point numbers[]={{250,24},{256,28},{258,27}};
static const Point blocks[]={{256,28},{250,24},{244,24},{232,24},{224,30},{224,40},{227,41}};
static const Point circuit[]={{224,42},{224,50},{224,54},{229,57}};
static const Point house[]={{224,54},{220,58},{218,62},{219,65},{219,68},{219,70.5f},{221,70.5f},{224,70.5f},{224,72}};
static const Point secret[]={{224,70.5f},{221,70.5f},{219,72},{217,72},{215,72}};
static const Point tower[]={{219,65},{220,58},{224,50},{224,42},{228,42},{231,42}};
static const Point crystals[]={{231,46},{231,48},{230,50},{224,50},{224,42},{224,30},{222.5f,30},{220,32}};
static const Point stars[]={{222.5f,30},{224,30},{232,24},{244,24},{250,24},{254,24},{256,22}};
static const Point nora[]={{254,24},{250,24},{244,28},{244,40},{242,43},{236,46},{230,50},{224,54},{220,58},{218,57.2f}};
static const Point back[]={{220,58},{214,62},{208,68},{204,70.8f}};
#define ROUTE(p) p,sizeof(p)/sizeof(*p)
#include "garden_tour_routes.h"
static const Stage stages[]={
 {"Courrier, relais, atelier : le voyage commence",NULL,0,AUTO,0},
 GARDEN_TOUR_STAGES
 {"Le sentier ouest : un autre chemin vers Nils",ROUTE(west),TALK,0},
 {"Le jardin des formes : un détour récompensé",ROUTE(garden),ACTIVITY,L3_MINI_SHAPES},
 {"Le portillon du jardin : retour par le raccourci",ROUTE(shortcut),PRESS1,0},
 {"Les eaux : orienter la vanne et lever le pont",ROUTE(valve),PRESS2,0},
 {"La passerelle : le deuxième chemin est ouvert",ROUTE(water),LOOK,0},
 {"L'observatoire : réunir les nombres jusqu'à 1024",ROUTE(numbers),ACTIVITY,L3_MINI_MERGE1024},
 {"L'atelier des blocs : compléter les lignes",ROUTE(blocks),ACTIVITY,L3_MINI_BLOCKS},
 {"Les ruines : relier le circuit de lumière",ROUTE(circuit),ACTIVITY,L3_MINI_CIRCUIT},
 {"La maison des lueurs : lanternes et fantômes",ROUTE(house),ACTIVITY,L3_MINI_MAZE},
 {"La maison révèle son passage secret",ROUTE(secret),LOOK,0},
 {"La tour des courroies : sauter, grimper, esquiver",ROUTE(tower),ACTIVITY,L3_ARCADE_PLATFORM},
 {"Les quatre échos : retenir et répéter les couleurs",ROUTE(crystals),ACTIVITY,L3_ARCADE_SIMON},
 {"Le simulateur des étoiles : le vaisseau et son boss",ROUTE(stars),ACTIVITY,L3_ARCADE_SHOOTER},
 {"Retrouver Nora : les lieux sont désormais reliés",ROUTE(nora),TALK,0},
 {"Le passage bleu : retour libre vers la vallée",ROUTE(back),RETURN,0},
 {"Huit défis découverts : le voyage peut recommencer",NULL,0,FINISH,0}
};
_Static_assert(sizeof(stages)/sizeof(*stages)<=32,"showcase completed mask capacity");
unsigned l3_showcase_stages(void){return sizeof(stages)/sizeof(*stages);}
const char *l3_showcase_title(unsigned n){return n<l3_showcase_stages()?stages[n].title:"Visite interrompue";}
static void publish(L3Showcase *s,L3Game *g){
 if(g->showcase_stage!=s->stage||g->showcase_status!=s->status){g->showcase_stage=s->stage;g->showcase_status=s->status;g->story.revision++;g->activities.revision++;}
}
static void fail(L3Showcase *s,L3Game *g){s->status=3;publish(s,g);}
static void next(L3Showcase *s,L3Game *g){s->completed|=1u<<s->stage;s->stage++;s->mode=s->point=s->presses=0;s->stage_time=s->wait=s->cooldown=0;s->action_pending=0;s->event_frame=s->frames;publish(s,g);}
void l3_showcase_init(L3Showcase *s,L3Game *g,int once){
 memset(s,0,sizeof(*s));s->initial_world=g->world;s->once=!!once;s->status=1;publish(s,g);
}
void l3_showcase_presented(L3Showcase *s){if(s)s->frames++;}
void l3_showcase_cancel(L3Showcase *s,L3Game *g){
 if(!s||!g)return;s->status=0;g->showcase_status=g->showcase_stage=0;g->autopilot=0;g->story.revision++;g->activities.revision++;
}
static void advance(L3Showcase *s,L3Game *g,const L3Input *in,float dt){
 l3_game_step(g,in,dt);
 if(g->activities.arcade.active){
  L3ArcadeView v;if(!l3_arcade_view(&g->activities.arcade,&v)){fail(s,g);return;}
  s->visited|=1u<<v.kind;s->won=g->activities.arcade.won;
  if(v.kind==L3_ARCADE_SHOOTER&&v.content.shooter.boss_hp)s->boss_seen=1;
  if(v.kind==L3_ARCADE_PLATFORM&&v.content.platform.checkpoint_floor)s->checkpoint_seen=1;
  if(v.kind==L3_ARCADE_SIMON&&v.content.simon.phase==L3_SIMON_SHOW&&v.content.simon.active_color<4)s->crystal_seen=1;
 }
}
/* Consume the fixed tick while a timed activity remains RUNNING. An adviser command
 * may end inside it (17/33ms platform commands, Simon phase boundaries).
 * Calls use positive seconds; the millisecond adapter may emit a zero-ms
 * input front while carrying its fractional time to the next step. Engine
 * fronts are immediate, even at zero ms. Terminal states intentionally freeze
 * their own clock and discard the rest of this tick. PRESENT never gates time. */
static void play_timed(L3Showcase *s,L3Game *g,float dt){
 float remaining=dt;
 for(unsigned i=0;i<32&&remaining>.000001f;i++){
  L3ArcadeView v;if(!l3_arcade_view(&g->activities.arcade,&v)){fail(s,g);return;}
  if(v.status!=L3_MINI_RUNNING)return;
  if(!s->action_pending){
   uint32_t ms=0;double started=diagnostic_clock();int advised=l3_arcade_demo_input(&g->activities.arcade,&s->action_pressed,&s->action_held,&ms);s->adviser_seconds+=diagnostic_clock()-started;s->adviser_calls++;
   if(!advised||ms>250){fail(s,g);return;}
   s->action_left=ms?ms/1000.f:1.f/60;s->action_pending=1;s->commands++;
  }
  float part=fminf(remaining,s->action_left);L3Input in={.mini_pressed=s->action_pressed,.mini_held=s->action_held};
  advance(s,g,&in,part);s->action_pressed=0;s->action_left-=part;remaining-=part;
  if(s->action_left<=.000001f){s->action_pending=0;s->event_frame=s->frames;}
 }
 if(remaining>.000001f)fail(s,g); /* no RUNNING remainder may be silently discarded */
}
static void play(L3Showcase *s,L3Game *g,float dt,unsigned kind){
 L3ArcadeView v;if(!l3_arcade_view(&g->activities.arcade,&v)||v.kind!=kind){fail(s,g);return;}
 if(v.status==L3_MINI_LOST){fail(s,g);return;}
 if(v.status==L3_MINI_WON){
  if(s->mode!=3){s->mode=3;s->wait=0;s->event_frame=s->frames;s->action_pending=0;}
  s->wait+=dt;if(s->wait>=4&&s->frames>s->event_frame){L3Input in={.mini_pressed=L3_MINI_BACK};advance(s,g,&in,dt);if(g->activities.arcade.active){fail(s,g);return;}next(s,g);}return;
 }
 s->wait=0;
 if(kind>=4){play_timed(s,g,dt);return;}
 if(s->action_pending){
  float part=fminf(dt,s->action_left);L3Input in={.mini_pressed=s->action_pressed,.mini_held=s->action_held};
  advance(s,g,&in,part);s->action_pressed=0;s->action_left-=part;
  if(s->action_left<=.000001f){s->action_pending=0;s->event_frame=s->frames;}
  return;
 }
 /* Pause this demo's simulation until its last input has actually reached
  * an image. At low FPS, commands become longer, never silently shorter. */
 if(s->frames==s->event_frame)return;
 if(s->cooldown>0){s->cooldown=fmaxf(0,s->cooldown-dt);return;}
 uint32_t ms=0;double started=diagnostic_clock();int advised=l3_arcade_demo_input(&g->activities.arcade,&s->action_pressed,&s->action_held,&ms);s->adviser_seconds+=diagnostic_clock()-started;s->adviser_calls++;if(!advised){fail(s,g);return;}
 s->action_left=ms?ms/1000.f:1.f/60;s->action_pending=1;s->commands++;
 /* Board puzzles have no timed danger. Their zero-time adviser moves are
  * executed with positive dt, then held on screen for at least400ms. */
 s->cooldown=kind<4?.4f:0;
}
void l3_showcase_step(L3Showcase *s,L3Game *g,float dt){
 if(!s||!g||s->status!=1||!isfinite(dt)||dt<=0)return;dt=fminf(dt,1.f/60);
 s->elapsed+=dt;s->stage_time+=dt;
 if(s->elapsed>1200||s->stage>=l3_showcase_stages()||s->stage_time>600){fail(s,g);return;}
 const Stage *stage=stages+s->stage;L3Input in={0};
 if(stage->action==AUTO){
  if(g->story.region&&g->story.amber_phase==2&&g->story.dialogue<0){in.pressed=L3_TOGGLE_AUTO;advance(s,g,&in,dt);next(s,g);}
  else advance(s,g,NULL,dt);return;
 }
 if(s->mode==0){
  /* Intro/braking pause is part of the visible guided tour. */
  s->wait+=dt;advance(s,g,NULL,dt);
  if(s->wait>=2&&s->frames>s->event_frame){s->mode=1;s->wait=0;}
  return;
 }
 if(s->point<stage->count){
  Point p=stage->path[s->point];float dx=p.x-g->player.position.x,dz=p.z-g->player.position.z,d=hypotf(dx,dz);
  if(d<.18f){s->point++;return;}
  float scale=fminf(1,d*1.8f)/d,c=cosf(g->camera.yaw),sn=sinf(g->camera.yaw);
  in.move_x=(-c*dx+sn*dz)*scale;in.move_z=(sn*dx+c*dz)*scale;advance(s,g,&in,dt);return;
 }
 if(stage->action==ACTIVITY){
  if(s->mode==1){s->wait+=dt;advance(s,g,NULL,dt);if(s->wait>=3&&s->frames>s->event_frame){in.pressed=L3_INTERACT;advance(s,g,&in,dt);if(g->activities.arcade.active!=stage->kind+1){fail(s,g);return;}s->mode=2;s->wait=0;s->event_frame=s->frames;}return;}
  play(s,g,dt,stage->kind);return;
 }
 if(stage->action==TALK){
  if(!s->presses||g->story.dialogue>=0){
   s->wait+=dt;if(s->wait>=(s->presses?5.f:2.f)&&s->frames>s->event_frame){in.pressed=L3_INTERACT;s->wait=0;s->presses++;s->event_frame=s->frames;}
   advance(s,g,&in,dt);
   if(stage->kind>=14&&s->presses==1&&(in.pressed&L3_INTERACT)&&g->story.dialogue!=(int)stage->kind){fail(s,g);return;}
  }else next(s,g);return;
 }
 if(stage->action==GARDEN_SEED){
  s->wait+=dt;
  if(!s->presses&&s->wait>=2&&s->frames>s->event_frame){
   in.pressed=L3_INTERACT;s->presses=1;s->wait=0;s->event_frame=s->frames;
  }
  advance(s,g,&in,dt);
  if(s->presses&&s->wait>=3&&s->frames>s->event_frame){
   if(!(g->garden_seeds&(1u<<stage->kind))){fail(s,g);return;}next(s,g);
  }return;
 }
 if(stage->action==PRESS1||stage->action==PRESS2||stage->action==RETURN){
  unsigned count=stage->action==PRESS2?2:1;s->wait+=dt;
  if(s->presses<count&&s->wait>=2&&s->frames>s->event_frame){in.pressed=L3_INTERACT;s->presses++;s->wait=0;s->event_frame=s->frames;}
  advance(s,g,&in,dt);
  if(s->presses==count&&s->wait>=3&&s->frames>s->event_frame){
   if((stage->action==RETURN&&g->story.region)||(stage->action==PRESS1&&!g->story.amber_intake)||(stage->action==PRESS2&&g->story.amber_phase<3)){fail(s,g);return;}next(s,g);
  }return;
 }
 /* Short panorama with real camera controls. The camera collision logic
  * still clips against the terrain; no precomputed image/eye coordinates. */
 s->wait+=dt;if(s->wait<1.2f&&stage->action!=GARDEN_GATE)in.look_x=.45f;advance(s,g,&in,dt);
 if(s->wait>=(stage->action==FINISH?8.f:4.f)&&s->frames>s->event_frame){
  if(stage->action==GARDEN_GATE&&(!g->garden_reward||g->player.position.x<250)){fail(s,g);return;}
  if(stage->action==FINISH){
   if(!g->garden_reward||g->garden_seeds!=7||!g->garden_invited||s->won!=255||s->visited!=255||!s->boss_seen||!s->checkpoint_seen||!s->crystal_seen||g->story.region||g->story.amber_phase!=5){fail(s,g);return;}
   s->completed|=1u<<s->stage;s->loops++;
   if(s->once){s->status=2;publish(s,g);}else{
    unsigned loops=s->loops;L3World w=s->initial_world;if(!l3_game_init(g,&w,1)){fail(s,g);return;}l3_showcase_init(s,g,0);s->loops=loops;
   }
  }else next(s,g);
 }
}
