#include "luma3d_amber.h"
#include "luma3d_activities.h"
#include "amber_data.h"
#include <math.h>
#include <stdio.h>
float l3_amber_ground(float x,float z){
 if(!isfinite(x)||!isfinite(z)||x<192||x>272||z<0||z>80)return NAN;
 float fx=(x-192)*.25f,fz=z*.25f;unsigned ix=(unsigned)fx,iz=(unsigned)fz;if(ix==20)ix=19;if(iz==20)iz=19;
 float u=fx-ix,v=fz-iz,a=amber_heights[iz][ix],b=amber_heights[iz][ix+1],c=amber_heights[iz+1][ix],d=amber_heights[iz+1][ix+1];
 return u>=v?a+(b-a)*u+(d-b)*v:a+(d-c)*u+(c-a)*v;
}
float l3_amber_floor(const L3Game *g,float x,float z,float ground){
 if(g->story.region&&g->story.amber_phase>=3&&x>=242.5f&&x<=245.5f&&z>=28&&z<=40)
  return fmaxf(ground,AMBER_DECK_SOUTH+(40-z)*(AMBER_DECK_NORTH-AMBER_DECK_SOUTH)/12-9*(1-g->story.amber_lift));
 return ground;
}
int l3_amber_blocked(const L3Game *g,float x,float y,float z,float r,float h){
 
 if(!g->story.region)return 0;
 if(!l3_activity_won(g,L3_ARCADE_PLATFORM)&&x+r>230&&x-r<232&&z+r>45.85f&&z-r<46.15f&&y+h>l3_amber_ground(231,46)&&y<l3_amber_ground(231,46)+1.7f)return 1;
 if(!l3_activity_won(g,L3_MINI_SHAPES)&&x+r>214.5f&&x-r<217.5f&&z+r>39.8f&&z-r<40.2f&&y+h>l3_amber_ground(216,40)&&y<l3_amber_ground(216,40)+2.7f)return 1;
 if(!l3_activity_won(g,L3_MINI_MAZE)&&x+r>216.8f&&x-r<217.2f&&z+r>71.1f&&z-r<72.9f&&y+h>l3_amber_ground(217,72)&&y<l3_amber_ground(217,72)+2.8f)return 1;
 if(g->story.amber_phase>=3&&x-r>=242.5f&&x+r<=245.5f&&z>=28&&z<=40)return 0;
 return x+r>232&&x-r<260&&z+r>32&&z-r<36&&y<3.2f+7*g->story.amber_lift;
}
void l3_amber_bind(L3Game *g,unsigned region){
 g->story.region=region;g->world.min_x=region?192:0;g->world.max_x=region?272:160;g->world.min_z=0;g->world.max_z=region?80:160;
 g->world.spawn=region?(L3Vec3){204,l3_amber_ground(204,68),68}:(L3Vec3){28,20,126};
}
int l3_amber_transition(L3Game *g,unsigned region){
 L3Game next=*g;l3_amber_bind(&next,region);next.story.amber_point=0;next.story.dialogue=-1;next.story.page=0;next.story.nearest=-1;
 next.player.yaw=next.camera.yaw=region?2.5f:0;next.camera.pitch=region?.16f:.30f;next.camera.distance=region?9:6.5f;next.story.revision++;next.camera_manual_seconds=0;
 if(!region){next.route_index=next.story.amber_phase<5?1:2;next.route_direction=next.story.amber_phase<5?-1:1;}
 L3Vec3 p=region?next.world.spawn:(L3Vec3){36.9f,0,114.6f};
 if(!l3_game_restore_position(&next,p))return 0;*g=next;return 1;
}
L3Vec3 l3_amber_site(const L3Game *g,unsigned site){
 static const float points[][2]={{36,115},{218,56},{231,50},{243,43},{252,23},{204,72},{252,20}};
 if(site<9||site>15)return g->world.spawn;
 L3Vec3 p={points[site-9][0],0,points[site-9][1]};p.y=g->world.height(g->world.context,p.x,p.z);return p;
}
static void talk(L3Game *g,int id){g->story.dialogue=id;g->story.page=0;g->story.dialogue_time=0;g->story.revision++;}
int l3_amber_interact(L3Game *g,int site){
 L3Story *s=&g->story;
 if(site==0&&s->workshop_phase==4&&s->amber_phase==0){talk(g,8);return 1;}
 if(site==9){if(s->amber_phase)l3_amber_transition(g,1);else {s->toast=14;s->toast_time=4;s->revision++;}return 1;}
 if(site==14){l3_amber_transition(g,0);return 1;}
 if(site==10){talk(g,s->amber_phase==1?9:s->amber_phase==4?11:12);return 1;}
 if(site==15){talk(g,!s->amber_met_nils?10:13);return 1;}
 if(site==11||site==12){
  if(s->amber_phase==2){s->amber_focus=3;if(site==11)s->amber_intake^=1;else s->amber_sluice=(s->amber_sluice+1)%3;
   if(s->amber_intake&&s->amber_sluice==2){s->amber_phase=s->amber_met_nils?4:3;s->amber_point=6;}s->revision++;}
  return 1;
 }return 0;
}
void l3_amber_dialogue_done(L3Game *g,int d){
 L3Story *s=&g->story;
 if(d==8)s->amber_phase=1;
 if(d==9)s->amber_phase=2;
 if(d==10){s->amber_met_nils=1;if(s->amber_phase==3)s->amber_phase=4;}
 if(d==11)s->amber_phase=5;
 s->revision++;
}
int l3_amber_wanted(const L3Game *g){
 const L3Story *s=&g->story;if(s->workshop_phase!=4)return -1;
 if(!s->amber_phase)return g->route_index==0||s->nearest==0?0:-1;
 if(!s->region)return s->amber_phase<5&&(g->route_index==0||s->nearest==9)?9:-1;
 if(s->amber_phase==1&&s->amber_point==2)return 10;
 if(s->amber_phase==2&&s->amber_point==(s->amber_intake?6u:4u))return s->amber_intake?12:11;
 if(s->amber_phase==3&&s->amber_point==10)return 15;
 if(s->amber_phase==4&&s->amber_point==2)return 10;
 if(s->amber_phase==5&&s->amber_point==0)return 14;
 return -1;
}
void l3_amber_tick(L3Game *g,float dt){g->story.amber_focus=fmaxf(0,g->story.amber_focus-dt);if(g->story.amber_phase>=3)g->story.amber_lift=fminf(1,g->story.amber_lift+dt*.5f);}
int l3_amber_target(L3Game *g,L3Vec3 *out){
 L3Story *s=&g->story;if(s->workshop_phase!=4)return 0;
 if(s->region&&s->amber_phase==3&&s->amber_lift<1){*out=g->player.position;return 1;}
 int wanted=l3_amber_wanted(g);
 if(wanted>=0){*out=l3_story_site(g,(unsigned)wanted);
  if(wanted==10||wanted==15)out->z+=1.2f;
  if(wanted==11||wanted==12)out->x-=1;
  return 1;}
 if(s->region){*out=amber_path[s->amber_point];return 1;}return 0;
}
int l3_amber_advance(L3Game *g){
 L3Story *s=&g->story;if(s->workshop_phase!=4)return 0;
 if((s->region&&s->amber_phase==3&&s->amber_lift<1)||l3_amber_wanted(g)>=0)return 1;
 if(!s->region)return 0;
 unsigned target=s->amber_phase==1?2:s->amber_phase==2?(s->amber_intake?6:4):s->amber_phase==3?10:s->amber_phase==4?2:0;
 if(s->amber_point<target)s->amber_point++;else if(s->amber_point>target)s->amber_point--;
 return 1;
}
int l3_amber_state_ok(const L3Game *g){
 const L3Story *s=&g->story;
 if(s->amber_met_nils>1||s->region>1||s->amber_phase>5||s->amber_intake>1||s->amber_sluice>2||s->amber_point>=AMBER_POINTS)return 0;
 if((!s->amber_phase&&s->amber_met_nils)||(s->amber_phase>=4&&!s->amber_met_nils))return 0;
 if(s->amber_phase&&s->workshop_phase!=4)return 0;
 if(!s->amber_phase&&(s->region||s->amber_intake||s->amber_sluice||s->amber_point))return 0;
 if(s->amber_phase<2&&(s->amber_intake||s->amber_sluice))return 0;
 if(s->amber_phase==2&&s->amber_intake&&s->amber_sluice==2)return 0;
 if(s->amber_phase>=3&&(!s->amber_intake||s->amber_sluice!=2))return 0;
 if(s->dialogue==8&&(s->amber_phase||s->workshop_phase!=4||s->region))return 0;
 if((s->dialogue==9&&(s->amber_phase!=1||!s->region))||(s->dialogue==10&&(!s->amber_phase||s->amber_met_nils||!s->region))||(s->dialogue==11&&(s->amber_phase!=4||!s->region)))return 0;
 if(s->dialogue>=12&&!s->region)return 0;
 return 1;
}
const char *l3_amber_objective(const L3Game *g){
 static const char *p[]={"Maëlle connaît le passage vers les Terrasses d’ambre","Franchir le passage bleu et rencontrer Nora","Ouvrir la prise, puis diriger l’eau vers le BASSIN","Retrouver Nils par le sentier ou la passerelle","Rapporter les nouvelles de Nils à Nora","Le bassin revit. Explorer ou revenir dans la vallée"};return p[g->story.amber_phase<=5?g->story.amber_phase:0];
}
unsigned l3_amber_dialogue_site(int d){return d==8?0:d==10||d==13?15:10;}
const char *l3_amber_speaker(int d){return d==8?"MAËLLE · Gardienne du courrier":d==10||d==13?"NILS · Guetteur des terrasses":"NORA · Gardienne des eaux";}
const char *l3_amber_dialogue(const L3Game *g){
 int d=g->story.dialogue,p=g->story.page;
 if(d==8)return p?"Le passage bleu s'ouvre au bord du sentier.\nNora veille sur un bassin oublié, au-delà des falaises.\nVa la rencontrer : elle attend un visiteur de la vallée.":"La cloche a retrouvé sa place ! Il existe un autre\nchemin, vers les Terrasses d'ambre. Leurs murs dorés\ngardent la chaleur longtemps après le coucher du soleil.";
 if(d==9)return p?"Ouvre la prise près du rocher, puis tourne la vanne\njusqu'au BASSIN. Le niveau relèvera la passerelle.\nNils t'attend dans l'observatoire, de l'autre côté.":"Bienvenue aux terrasses. Je suis Nora. Notre eau\nse perd dans l'ancien jardin ; le bassin reste vide.\nLe sentier ouest reste ouvert pour rejoindre Nils.";
 if(d==10)return p?"Dis à Nora que l'observatoire accueille de nouveau\nles voyageurs. Le bassin et le ciel se reflètent ici\nl'un dans l'autre. Prenez le temps de les regarder.":"Te voilà ! Regarde cette lunette :\nelle m'a permis de retrouver l'étoile des navigateurs.\nJe croyais être le dernier à connaître ce lieu.";
 if(d==11)return p?"Le passage vers la vallée reste ouvert.\nL'eau coule, Nils n'est plus seul, et les terrasses\nattendent maintenant d'autres histoires.":"Nils t'a montré sa lunette ? Je monterai le voir.\nMerci d'avoir remis le bassin en eau et relié\nnos deux maisons par tes pas.";
 if(d==12)return "La prise amène l'eau. La seconde vanne choisit\nFERMÉ, JARDIN ou BASSIN. Observe le passage :\nseul le bassin peut lever la passerelle.";
 return "Les terrasses gardent encore bien des détails.\nLa lunette, les palmiers et l'eau racontent chacun\nun morceau de ce paysage.";
}
const char *l3_amber_prompt(const L3Game *g){
 static char line[100];int n=g->story.nearest;
 if(n==11){snprintf(line,sizeof(line),"E · Prise d’eau : %s",g->story.amber_intake?"OUVERTE":"FERMÉE");return line;}
 if(n==12){static const char *m[]={"FERMÉ","JARDIN","BASSIN"};snprintf(line,sizeof(line),"E · Destination : %s",m[g->story.amber_sluice]);return line;}
 return n==9?"E · Passage vers les Terrasses d’ambre":n==14?"E · Revenir au Val des Courriers":n==10?"E · Parler à Nora":n==15?"E · Parler à Nils":"J · Carnet    WASD · Explorer    E · Interagir";
}

void l3_amber_rejoin(L3Game *g){
 if(g->story.region){
  float best=1e30f;unsigned chosen=0;
  for(unsigned i=0;i<AMBER_POINTS;i++){float d=hypotf(g->player.position.x-amber_path[i].x,g->player.position.z-amber_path[i].z);if(d<best){best=d;chosen=i;}}
  g->story.amber_point=chosen;
  /* T is a demonstration-route rejoin, not a teleport or a pathfinder.
   * A closed garden wall/house must not turn it into an endless stuck walk.
   * Refuse an unsafe direct join and retain manual exploration. */
  if(g->autopilot){
   L3Vec3 from=g->player.position,to=amber_path[chosen];unsigned n=(unsigned)ceilf(best/.15f);if(!n)n=1;
   float previous=l3_amber_floor(g,from.x,from.z,g->world.height(g->world.context,from.x,from.z));
   int safe=g->player.grounded;
   for(unsigned i=1;i<=n&&safe;i++){
    float f=(float)i/n,x=from.x+(to.x-from.x)*f,z=from.z+(to.z-from.z)*f;
    float y=l3_amber_floor(g,x,z,g->world.height(g->world.context,x,z));
    if(!isfinite(y)||y-previous>best/n*.95f+.00005f||l3_amber_blocked(g,x,y,z,.3f,1.65f)||(g->world.blocked&&g->world.blocked(g->world.context,x,y,z,.3f,1.65f)))safe=0;
    for(unsigned j=0;j<2;j++){L3Vec3 p=l3_story_site(g,j?15:10);if(hypotf(x-p.x,z-p.z)<.58f&&y<p.y+1.7f&&y+1.65f>p.y)safe=0;}
    previous=y;
   }
   if(!safe){g->autopilot=0;g->story.toast=15;g->story.toast_time=5;g->story.revision++;}
  }
 }else if(g->story.workshop_phase==4&&g->story.amber_phase<5)g->route_direction=-1;
}
