#define _POSIX_C_SOURCE 200809L
#include "luma3d_amber.h"
#include "luma3d_activities.h"
#include "luma3d_progress.h"
#include "luma3d_workshop.h"
#include "luma3d_village.h"
#include "luma3d_garden.h"
/* LUMA3D VILLAGE V6: V6 appends explicit village state, never old reserved words. */
#include <errno.h>
#include <fcntl.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

/* V1: explicit little-endian words, no native struct/pointers/padding. */
enum { HEADER=24, STATE_WORDS=20, RECORD_BYTES=8, ACTIVITY_BYTES=32+64+5*(4+L3_MINI_SAVE_BYTES) };
static const unsigned char magic[8]={'L','3','P','R','O','G','1',0};
static uint32_t word(const unsigned char *p) {
    return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;
}
static void put(unsigned char *p,uint32_t x) {
    for(unsigned i=0;i<4;i++)p[i]=(unsigned char)(x>>(8*i));
}
static uint32_t crc(const unsigned char *p,size_t n) {
    uint32_t c=~0u;
    for(size_t i=0;i<n;i++) {c^=p[i];for(unsigned b=0;b<8;b++)c=(c>>1)^(0xedb88320u&-(c&1));}
    return ~c;
}
static uint32_t bits(float x) {uint32_t n;_Static_assert(sizeof(float)==4,"float32 required");memcpy(&n,&x,4);return n;}
static float real(uint32_t n) {float x;memcpy(&x,&n,4);return x;}
static int schema_ok(const L3ProgressSchema *s,const L3Game *g) {
    if(!s||!g||!g->valid||!s->campaign_id||!s->version||s->count!=g->world.collectible_count||s->count>32||!s->collectible_ids)return 0;
    for(unsigned i=0;i<s->count;i++) {
        if(!s->collectible_ids[i])return 0;
        for(unsigned j=0;j<i;j++)if(s->collectible_ids[i]==s->collectible_ids[j])return 0;
    }
    return 1;
}
static int state_ok(const L3Game *g) {
    const L3Story *s=&g->story;
    uint32_t allowed=g->world.collectible_count==32?~0u:(1u<<g->world.collectible_count)-1;
    if((g->collected_mask&~allowed)||g->collected_count!=(unsigned)__builtin_popcount(g->collected_mask))return 0;
    if(!l3_activities_valid(g)||!l3_workshop_state_ok(g)||!l3_amber_state_ok(g))return 0;
    if(!l3_village_state_ok(g)||!l3_garden_state_ok(g))return 0;
    if(s->phase>4||s->relay_step>3||s->discovered>1||s->dialogue < -1||s->dialogue>15||s->page<0||s->page>1)return 0;
    if(g->objective_complete!=(s->phase==4)||g->route_index>=g->world.route_count||(g->route_direction!=1&&g->route_direction!=-1))return 0;
    if((s->phase<2&&s->relay_step)||(s->phase==2&&s->relay_step==3)||(s->phase>=3&&s->relay_step!=3))return 0;
    if(s->phase>=2&&g->collected_count<2)return 0;
    if(s->phase==4&&g->collected_count!=g->world.collectible_count)return 0;
    if((s->dialogue==0&&s->phase!=0)||(s->dialogue==1&&(s->phase!=1||g->collected_count<2))||
       (s->dialogue==2&&(s->phase!=3||g->collected_count!=g->world.collectible_count)))return 0;
    float f[]={g->player.position.x,g->player.position.y,g->player.position.z,g->player.yaw,g->camera.yaw,g->camera.pitch,g->time,g->distance_walked};
    for(unsigned i=0;i<sizeof(f)/sizeof(*f);i++)if(!isfinite(f[i]))return 0;
    /* These are the canonical ranges emitted by game.c's remainderf/clamp.
     * Finite alone is insufficient: opposite huge yaws overflow subtraction,
     * and huge time overflows waterfall UVs before their integer conversion. */
    const float pi=3.14159265358979323846f;
    if(fabsf(g->player.yaw)>pi||fabsf(g->camera.yaw)>pi||g->camera.pitch<.10f||g->camera.pitch>.85f)return 0;
    return g->time>=0&&g->time<=L3_PROGRESS_TIME_MAX&&g->distance_walked>=0&&g->player.position.x>=g->world.min_x&&g->player.position.x<=g->world.max_x&&
        g->player.position.z>=g->world.min_z&&g->player.position.z<=g->world.max_z;
}
/* V4 extends the fixed V1..V3 prefix; IDs, not record order, bind activities.
 * Both the outer CRC and each engine's explicit codec are checked before any
 * mutation. The paused camera/velocity are kept for an exact activity exit. */
static void pose_words(const L3Game *g,float f[16]) {
 float a[]={g->camera.eye.x,g->camera.eye.y,g->camera.eye.z,g->camera.target.x,g->camera.target.y,g->camera.target.z,g->camera.distance,
 g->player.velocity.x,g->player.velocity.y,g->player.velocity.z,g->player.speed,g->player.walk_phase,g->camera_manual_seconds,g->coyote_seconds,g->jump_buffer_seconds,g->autopilot_stuck_seconds};memcpy(f,a,sizeof(a));
}
static int pose_ok(const float f[16],unsigned grounded) {
 if(grounded>1)return 0;for(unsigned i=0;i<16;i++)if(!isfinite(f[i]))return 0;
 for(unsigned i=0;i<6;i++)if(fabsf(f[i])>10000)return 0;
 if(f[6]<1||f[6]>30)return 0;for(unsigned i=7;i<10;i++)if(fabsf(f[i])>100)return 0;
 if(f[10]<0||f[10]>10||f[11]<0||f[11]>6.283186f)return 0;
 for(unsigned i=12;i<16;i++)if(f[i]<0||f[i]>L3_PROGRESS_TIME_MAX)return 0;return 1;
}
static void restore_pose(L3Game *g,const float f[16],unsigned grounded) {
 g->camera.eye=(L3Vec3){f[0],f[1],f[2]};g->camera.target=(L3Vec3){f[3],f[4],f[5]};g->camera.distance=f[6];
 g->player.velocity=(L3Vec3){f[7],f[8],f[9]};g->player.speed=f[10];g->player.walk_phase=f[11];g->player.grounded=(int)grounded;
 g->camera_manual_seconds=f[12];g->coyote_seconds=f[13];g->jump_buffer_seconds=f[14];g->autopilot_stuck_seconds=f[15];
}
int l3_progress_encode(const L3Game *g,const L3ProgressSchema *s,unsigned char *out,size_t cap,size_t *size) {
    if(!schema_ok(s,g)||(s->version!=6&&s->version!=7)||!state_ok(g)||!out||!size)return L3_PROGRESS_INVALID;
    if(s->version==6&&(g->garden_invited||g->garden_seeds||g->garden_reward||g->story.dialogue>=14))return L3_PROGRESS_INVALID;
    size_t base=HEADER+STATE_WORDS*4+s->count*RECORD_BYTES;
    unsigned char arcade[L3_ARCADE_SAVE_MAX];size_t codec=l3_arcade_encode(&g->activities.arcade,arcade,sizeof(arcade));
    size_t n=base+96+codec+(s->version==7?12:0);if(!codec||cap<n||n>L3_PROGRESS_MAX_BYTES)return L3_PROGRESS_INVALID;
    unsigned char b[L3_PROGRESS_MAX_BYTES]={0};memcpy(b,magic,8);put(b+8,(uint32_t)n);put(b+12,s->campaign_id);put(b+16,s->version);
    uint32_t w[STATE_WORDS]={s->count,g->story.phase,g->story.relay_step,g->story.discovered,g->story.wrong_sequences,
        (uint32_t)(g->story.dialogue+1),(uint32_t)g->story.page,g->route_index,(uint32_t)(g->route_direction+1),g->completed_routes,
        bits(g->player.position.x),bits(g->player.position.y),bits(g->player.position.z),bits(g->player.yaw),
        bits(g->camera.yaw),bits(g->camera.pitch),bits(g->time),bits(g->distance_walked),
        g->story.workshop_phase|(g->story.wind_a<<3)|(g->story.wind_b<<5)|(g->story.workshop_mode<<7)|
        (g->story.region<<10)|(g->story.amber_phase<<11)|(g->story.amber_intake<<14)|(g->story.amber_sluice<<15)|(g->story.amber_met_nils<<17),g->story.workshop_point|(g->story.amber_point<<5)};
    for(unsigned i=0;i<STATE_WORDS;i++)put(b+HEADER+i*4,w[i]);
    for(unsigned i=0;i<s->count;i++) {put(b+HEADER+STATE_WORDS*4+i*8,s->collectible_ids[i]);put(b+HEADER+STATE_WORDS*4+i*8+4,(g->collected_mask>>i)&1);}
    unsigned char *ext=b+base;const L3Activities *a=&g->activities;float pose[16];pose_words(g,pose);if(!pose_ok(pose,(unsigned)g->player.grounded)||!l3_village_state_ok(g))return L3_PROGRESS_INVALID;
    uint32_t village_state=g->village_phase|(g->village_mask<<2)|(g->village_step<<5)|
        (g->village_reward<<8)|(g->village_wrong<<9);
    uint32_t village_order=(uint32_t)g->village_order[0]|((uint32_t)g->village_order[1]<<2)|
        ((uint32_t)g->village_order[2]<<4);
    uint32_t aw[]={0x36414354u,(uint32_t)codec,village_state,village_order,0x364c4956u,
        g->autopilot?2u:0u,a->pending_us,(unsigned)g->player.grounded};
    for(unsigned i=0;i<8;i++)put(ext+4*i,aw[i]);for(unsigned i=0;i<16;i++)put(ext+32+4*i,bits(pose[i]));
    memcpy(ext+96,arcade,codec);
    if(s->version==7){unsigned char *tail=ext+96+codec;put(tail,0x37445247u);put(tail+4,g->garden_invited|(g->garden_seeds<<1)|(g->garden_reward<<4));put(tail+8,0);}
    put(b+20,crc(b+HEADER,n-HEADER));memcpy(out,b,n);*size=n;return L3_PROGRESS_OK;
}
int l3_progress_decode(L3Game *g,const L3ProgressSchema *s,const unsigned char *b,size_t n) {
    if(!schema_ok(s,g)||(s->version!=6&&s->version!=7)||!b||n<HEADER||n>L3_PROGRESS_MAX_BYTES)return L3_PROGRESS_INVALID;
    unsigned version=word(b+16);if(version>s->version)return L3_PROGRESS_INVALID;size_t base=HEADER+STATE_WORDS*4+s->count*8;
    if(version<1||version>7||(version<5&&n!=base+(version==4?ACTIVITY_BYTES:0))||(version>=5&&n<base+96+128))return L3_PROGRESS_INVALID;
    if(memcmp(b,magic,8)||word(b+8)!=n||word(b+12)!=s->campaign_id||(word(b+16)<1||word(b+16)>7)||word(b+20)!=crc(b+HEADER,n-HEADER))return L3_PROGRESS_INVALID;
    uint32_t w[STATE_WORDS];for(unsigned i=0;i<STATE_WORDS;i++)w[i]=word(b+HEADER+i*4);
    if(w[0]!=s->count||w[5]>(version==7?16u:14u)||w[6]>1||(w[8]!=0&&w[8]!=2)||(w[18]&~(version>=4?262143u:131071u))||(w[19]&~511u)||(w[19]&31)>=l3_workshop_points())return L3_PROGRESS_INVALID;
    if(word(b+16)==1&&(w[18]||w[19]||w[5]>6))return L3_PROGRESS_INVALID;
    if(word(b+16)==2&&((w[18]&~1023u)||w[19]>=l3_workshop_points()||w[5]>8))return L3_PROGRESS_INVALID;
    L3Game next=*g;next.garden_invited=next.garden_seeds=next.garden_reward=0;l3_village_reset(&next);memset(&next.activities,0,sizeof(next.activities));next.collected_mask=next.collected_count=0;uint32_t seen=0;
    for(unsigned i=0;i<s->count;i++) {
        uint32_t id=word(b+HEADER+STATE_WORDS*4+i*8),got=word(b+HEADER+STATE_WORDS*4+i*8+4);unsigned j=0;
        for(;j<s->count&&s->collectible_ids[j]!=id;j++);
        if(j==s->count||got>1||(seen&(1u<<j)))return L3_PROGRESS_INVALID;
        seen|=1u<<j;next.collected_mask|=got<<j;next.collected_count+=got;
    }
    next.story.phase=w[1];next.story.relay_step=w[2];next.story.discovered=w[3];next.story.wrong_sequences=w[4];
    next.story.dialogue=(int)w[5]-1;next.story.page=(int)w[6];next.route_index=w[7];next.route_direction=(int)w[8]-1;next.completed_routes=w[9];
    next.player.position=(L3Vec3){real(w[10]),real(w[11]),real(w[12])};next.player.yaw=real(w[13]);
    next.camera.yaw=real(w[14]);next.camera.pitch=real(w[15]);next.time=real(w[16]);next.distance_walked=real(w[17]);
    next.story.workshop_phase=w[18]&7;next.story.wind_a=(w[18]>>3)&3;next.story.wind_b=(w[18]>>5)&3;
    next.story.workshop_mode=(w[18]>>7)&7;next.story.workshop_point=w[19]&31;l3_workshop_restore(&next);
    next.story.amber_phase=(w[18]>>11)&7;next.story.amber_intake=(w[18]>>14)&1;next.story.amber_sluice=(w[18]>>15)&3;next.story.amber_point=w[19]>>5;
    next.story.amber_met_nils=version>=4?(w[18]>>17)&1:next.story.amber_phase>=4;
    float pose[16]={0};unsigned grounded=0;
    if(version>=4){const unsigned char *ext=b+base;L3Activities *a=&next.activities;
      if(word(ext+20)>3)return L3_PROGRESS_INVALID;
      a->pending_us=word(ext+24);grounded=word(ext+28);next.autopilot=g->autopilot&&!!(word(ext+20)&2);
      for(unsigned i=0;i<16;i++)pose[i]=real(word(ext+32+4*i));if(!pose_ok(pose,grounded))return L3_PROGRESS_INVALID;
      if(version==4){
        if(word(ext)!=0x34414354u||word(ext+4)!=5)return L3_PROGRESS_INVALID;
        unsigned initialized=word(ext+12),won=word(ext+16),active=word(ext+8),release=word(ext+20)&1;
        L3MiniState games[5]={0};unsigned seen_activity=0;unsigned char empty[L3_MINI_SAVE_BYTES]={0};
        for(unsigned i=0;i<5;i++){const unsigned char *p=ext+96+i*(4+L3_MINI_SAVE_BYTES);unsigned k=0;for(;k<5&&l3_activity_id(k)!=word(p);k++);if(k==5||(seen_activity&(1u<<k)))return L3_PROGRESS_INVALID;seen_activity|=1u<<k;
          if(initialized&(1u<<k)){if(!l3_mini_decode(&games[k],p+4,L3_MINI_SAVE_BYTES))return L3_PROGRESS_INVALID;}else if(memcmp(p+4,empty,sizeof(empty)))return L3_PROGRESS_INVALID;
        }
        if(!l3_arcade_import_base(&a->arcade,games,initialized,won,active,release))return L3_PROGRESS_INVALID;
      }else{
        size_t codec=word(ext+4);
        if(version>=6){
          uint32_t vs=word(ext+8),vo=word(ext+12);
          if(word(ext)!=0x36414354u||word(ext+16)!=0x364c4956u||(word(ext+20)&~2u)||codec!=n-base-96-(version==7?12:0))return L3_PROGRESS_INVALID;
          if((vs&(1u<<7))||vs>>17||vo>>6)return L3_PROGRESS_INVALID;
          next.village_phase=vs&3;next.village_mask=(vs>>2)&7;next.village_step=(vs>>5)&3;
          next.village_reward=(vs>>8)&1;next.village_wrong=(vs>>9)&255;
          next.village_order[0]=(unsigned char)(vo&3);next.village_order[1]=(unsigned char)((vo>>2)&3);
          next.village_order[2]=(unsigned char)((vo>>4)&3);
        }else{
          if(word(ext)!=0x35414354u||word(ext+8)||word(ext+12)||word(ext+16)||(word(ext+20)&1)||codec!=n-base-96-(version==7?12:0))return L3_PROGRESS_INVALID;
        }
        if(!l3_arcade_decode(&a->arcade,ext+96,codec))return L3_PROGRESS_INVALID;
        if(version==7){const unsigned char *tail=ext+96+codec;unsigned gs=word(tail+4);
          if(word(tail)!=0x37445247u||word(tail+8)||(gs&~31u))return L3_PROGRESS_INVALID;
          next.garden_invited=gs&1;next.garden_seeds=(gs>>1)&7;next.garden_reward=(gs>>4)&1;
        }
      }
    }
    next.story.amber_focus=0;next.story.amber_lift=next.story.amber_phase>=3?1:0;l3_amber_bind(&next,(w[18]>>10)&1);
    next.objective_complete=next.story.phase==4;if(!state_ok(&next))return L3_PROGRESS_INVALID;
    next.story.journal=0;next.story.toast=0;next.story.toast_time=next.story.dialogue_time=0;next.story.revision++;
    int recovered=0;
    if(!l3_game_restore_position(&next,next.player.position)){
        recovered=1;next.activities.arcade.active=0;
        if(!l3_game_restore_position(&next,next.world.spawn))return L3_PROGRESS_INVALID;
        /* A recovered position starts from the safe route entrance, never
         * steers straight toward an obsolete distant waypoint or mechanism. */
        next.route_index=0;next.route_direction=1;next.story.amber_point=0;
        if(next.story.workshop_phase==1||next.story.workshop_phase==2){next.story.workshop_mode=0;next.story.workshop_point=0;}
        if(next.story.workshop_phase==3){next.story.workshop_mode=4;next.story.workshop_point=0;}
    }
    if(version>=4&&next.activities.arcade.active&&!recovered){
        L3Vec3 paused={real(w[10]),real(w[11]),real(w[12])};
        if(!l3_game_position_valid(&next,paused))return L3_PROGRESS_INVALID;
        next.player.position=paused;restore_pose(&next,pose,grounded);next.autopilot=0;next.activities.arcade.release_inputs=1;
    }
    if(!state_ok(&next))return L3_PROGRESS_INVALID;
    *g=next;return L3_PROGRESS_OK;
}
int l3_progress_read(const char *path,L3Game *g,const L3ProgressSchema *s) {
    if(!path)return L3_PROGRESS_INVALID;int fd=open(path,O_RDONLY);if(fd<0)return L3_PROGRESS_IO;
    unsigned char b[L3_PROGRESS_MAX_BYTES+1];size_t n=0;int ok=1;
    while(n<sizeof(b)) {ssize_t k=read(fd,b+n,sizeof(b)-n);if(k<0&&errno==EINTR)continue;if(k<0){ok=0;break;}if(!k)break;n+=(size_t)k;}
    if(close(fd))ok=0;return ok?l3_progress_decode(g,s,b,n):L3_PROGRESS_IO;
}
int l3_progress_write(const char *path,const L3Game *g,const L3ProgressSchema *s) {
    unsigned char b[L3_PROGRESS_MAX_BYTES];size_t n;if(!path||l3_progress_encode(g,s,b,sizeof(b),&n)!=L3_PROGRESS_OK)return L3_PROGRESS_INVALID;
    char temp[4096],parent[4096];
    if(strlen(path)>=sizeof(parent)||snprintf(temp,sizeof(temp),"%s.tmp.XXXXXX",path)>=(int)sizeof(temp))return L3_PROGRESS_INVALID;
    strcpy(parent,path);char *slash=strrchr(parent,'/');if(slash){if(slash==parent)slash[1]=0;else *slash=0;}else strcpy(parent,".");
    int dir=open(parent,O_RDONLY|O_DIRECTORY);if(dir<0)return L3_PROGRESS_IO;
    /* A stale temporary file after power loss must not block later saves,
     * even after reboot/PID reuse. mkstemp creates a new 0600/O_EXCL file. */
    int fd=mkstemp(temp);if(fd<0){close(dir);return L3_PROGRESS_IO;}
    size_t at=0;int ok=1;while(at<n){ssize_t k=write(fd,b+at,n-at);if(k<0&&errno==EINTR)continue;if(k<=0){ok=0;break;}at+=(size_t)k;}
    if(ok&&fsync(fd))ok=0;if(close(fd))ok=0;
    if(ok&&rename(temp,path))ok=0;if(ok&&fsync(dir))ok=0;if(close(dir))ok=0;
    if(!ok)unlink(temp);return ok?L3_PROGRESS_OK:L3_PROGRESS_IO;
}
