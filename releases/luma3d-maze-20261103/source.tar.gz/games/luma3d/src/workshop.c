#include "luma3d_workshop.h"
#include "workshop_route.h"
#include <math.h>
#define PI 3.14159265358979323846f
unsigned l3_workshop_points(void){return WORKSHOP_POINTS;}
static void changed(L3Story *s,unsigned toast){s->revision++;s->toast=toast;s->toast_time=4;}
static int box(float x,float y,float z,float r,float h,float x0,float x1,float z0,float z1){
    return y+h>28.05f&&y<30.25f&&x+r>x0&&x-r<x1&&z+r>z0&&z-r<z1;
}
int l3_workshop_blocked(const L3Game *g,float x,float y,float z,float r,float h){
    /* Same leaf geometry as the rendered hinge: opening latches permanently. */
    return g->story.workshop_phase<2?box(x,y,z,r,h,145.3f,146.7f,39.85f,40.15f):
        box(x,y,z,r,h,145.225f,145.425f,38.6f,40.0f);
}
int l3_workshop_interact(L3Game *g,int site){
    L3Story *s=&g->story;
    if(site==6||site==7){
        if(s->workshop_phase!=1){changed(s,s->workshop_phase?10:13);return 1;}
        s->workshop_mode=2;s->workshop_point=WORKSHOP_POINTS-1;
        if(site==6)s->wind_a=(s->wind_a+1)&3;
        s->wind_b=(s->wind_b+1)&3;s->workshop_wait=.75f;s->workshop_focus=3;changed(s,9);
        if(s->wind_a==3&&s->wind_b==2){s->workshop_phase=2;changed(s,10);}
        return 1;
    }
    if(site==8){
        if(s->workshop_phase==2&&g->player.position.z<39.4f){
            s->workshop_phase=3;s->workshop_mode=3;s->workshop_point=WORKSHOP_POINTS-1;changed(s,11);
        }
        return 1;
    }
    return 0;
}
void l3_workshop_tick(L3Game *g,float dt){
    L3Story *s=&g->story;s->workshop_wait=fmaxf(0,s->workshop_wait-dt);s->workshop_focus=fmaxf(0,s->workshop_focus-dt);
    float *v[]={&s->wind_angle_a,&s->wind_angle_b};unsigned q[]={s->wind_a,s->wind_b};
    for(unsigned i=0;i<2;i++)*v[i]=remainderf(*v[i]+remainderf(q[i]*PI*.5f-*v[i],PI*2)*fminf(1,dt*12),PI*2);
}
int l3_workshop_wanted(const L3Game *g){
    const L3Story *s=&g->story;
    if(s->phase!=4)return -1;
    if(!s->workshop_phase&&(g->route_index>=14||s->nearest==2))return 2;
    if(s->workshop_mode==2){
        if(s->workshop_phase==1)return s->wind_a!=3?6:7;
        if(s->workshop_phase==2)return 8;
    }
    if(s->workshop_phase==3&&s->workshop_mode==4&&g->route_index==0)return 0;
    return -1;
}
int l3_workshop_target(L3Game *g,L3Vec3 *target){
    L3Story *s=&g->story;
    if(s->phase!=4)return 0;
    if(s->workshop_mode==1||s->workshop_mode==3){*target=workshop_path[s->workshop_point];return 1;}
    int wanted=l3_workshop_wanted(g);
    if(wanted>=0){*target=l3_story_site(g,(unsigned)wanted);
        /* Stand in front of the mechanisms; their solid posts remain solid. */
        if(wanted==6||wanted==7)target->z+=.85f;
        return 1;}
    return 0;
}
int l3_workshop_advance(L3Game *g){
    L3Story *s=&g->story;
    if(s->phase!=4)return 0;
    if(s->workshop_mode==1){
        if(s->workshop_point+1<WORKSHOP_POINTS)s->workshop_point++;
        else s->workshop_mode=2;
        s->revision++;return 1;
    }
    if(s->workshop_mode==3){
        if(s->workshop_point)s->workshop_point--;
        else {s->workshop_mode=4;g->route_index=8;g->route_direction=-1;}
        s->revision++;return 1;
    }
    if((s->workshop_phase==1||s->workshop_phase==2)&&s->workshop_mode==0&&g->route_index==8){
        s->workshop_mode=1;s->workshop_point=0;s->revision++;return 1;
    }
    /* Stop on the actual interaction point instead of advancing main route. */
    return l3_workshop_wanted(g)>=0;
}
void l3_workshop_rejoin(L3Game *g){
    L3Story *s=&g->story;
    if(s->workshop_phase<1||s->workshop_phase>=4)return;
    float best=1e30f;unsigned index=0;
    for(unsigned i=0;i<WORKSHOP_POINTS;i++){
        float d=hypotf(g->player.position.x-workshop_path[i].x,g->player.position.z-workshop_path[i].z);
        if(d<best){best=d;index=i;}
    }
    if(best<5){s->workshop_point=index;s->workshop_mode=s->workshop_phase==3?3:1;}
}
int l3_workshop_state_ok(const L3Game *g){
    const L3Story *s=&g->story;
    if(s->workshop_phase>4||s->wind_a>3||s->wind_b>3||s->workshop_mode>5||s->workshop_point>=WORKSHOP_POINTS)return 0;
    if(s->workshop_phase&&s->phase!=4)return 0;
    if(!s->workshop_phase&&(s->wind_a||s->wind_b||s->workshop_mode||s->workshop_point))return 0;
    if(s->workshop_phase==1&&s->wind_a==3&&s->wind_b==2)return 0;
    if(s->workshop_phase==2&&s->workshop_mode>2)return 0;
    if(s->workshop_phase>=2&&(s->wind_a!=3||s->wind_b!=2))return 0;
    if(s->workshop_phase<3&&s->workshop_mode>=3)return 0;
    if(s->workshop_phase==3&&s->workshop_mode!=3&&s->workshop_mode!=4)return 0;
    if(s->workshop_phase==4&&s->workshop_mode!=5)return 0;
    if(s->dialogue==6&&(s->phase!=4||s->workshop_phase))return 0;
    if(s->dialogue==7&&s->workshop_phase!=3)return 0;
    return 1;
}
void l3_workshop_restore(L3Game *g){
    g->story.workshop_wait=g->story.workshop_focus=0;g->story.wind_angle_a=g->story.wind_a*PI*.5f;g->story.wind_angle_b=g->story.wind_b*PI*.5f;
}
