#include "luma3d_amber.h"
#include "luma3d_activities.h"
#include "luma3d_game.h"
#include "luma3d_workshop.h"
#include "luma3d_village.h"
#include "luma3d_garden.h"
/* LUMA3D VILLAGE V6: fresh optional quest beside the courier mission. */

#include <math.h>
#include <string.h>

#define PI 3.14159265358979323846f
#define RADIUS .30f
#define BODY_HEIGHT 1.65f
#define WALK_SPEED 4.5f
#define RUN_SPEED 7.0f
#define GRAVITY 16.0f

static float clampf(float v, float lo, float hi) { return fminf(hi, fmaxf(lo, v)); }
static float axis(float v) { return isfinite(v) ? clampf(v, -1, 1) : 0; }
static float length2(float x, float z) { return sqrtf(x*x + z*z); }
static float angle(float v) { return remainderf(v, 2*PI); }
static float approach(float v, float target, float amount) {
    return v + clampf(target-v, -amount, amount);
}
static float height(const L3Game *g, float x, float z) {
    /* The terrain callback is read exactly once and its sample is rejected
     * while still raw: the Amber deck combines it with fmaxf, which would
     * otherwise mask a NaN or -Inf query into a finite lifted deck height.
     * A nonfinite Amber result itself stays impassable (same sentinel). */
    float raw=g->world.height(g->world.context,x,z);
    if (!isfinite(raw)) return 100000.0f;
    float h = l3_amber_floor(g,x,z,raw);
    return isfinite(h) ? h : 100000.0f; /* malformed query is impassable */
}
static int blocked(const L3Game *g, float x, float y, float z, float r, float h) {
    if(l3_garden_blocked(g,x,y,z,r,h))return 1;
    if(l3_amber_blocked(g,x,y,z,r,h))return 1;
    if(!g->story.region&&l3_workshop_blocked(g,x,y,z,r,h))return 1;
    for(unsigned i=0;i<(g->story.region?2u:3u);i++) {
        L3Vec3 n=l3_story_site(g,g->story.region?(i?15:10):i);float dx=x-n.x,dz=z-n.z;
        if(y+h>n.y&&y<n.y+1.7f&&dx*dx+dz*dz<(r+.28f)*(r+.28f))return 1;
    }
    return x-r < g->world.min_x || x+r > g->world.max_x ||
           z-r < g->world.min_z || z+r > g->world.max_z ||
           (g->world.blocked && g->world.blocked(g->world.context,x,y,z,r,h));
}

static L3Vec3 camera_clip(const L3Game *g, L3Vec3 from, L3Vec3 to) {
    L3Vec3 delta = {to.x-from.x, to.y-from.y, to.z-from.z}, last = from;
    float dist = sqrtf(delta.x*delta.x + delta.y*delta.y + delta.z*delta.z);
    int steps = (int)ceilf(dist/.18f);
    if (steps > 160) steps = 160;
    for (int i=1; i<=steps; ++i) {
        float f = (float)i/(float)steps;
        L3Vec3 p = {from.x+delta.x*f,from.y+delta.y*f,from.z+delta.z*f};
        if (p.y < height(g,p.x,p.z)+.24f || blocked(g,p.x,p.y-.2f,p.z,.2f,.4f))
            break;
        last = p;
    }
    return last;
}

static void camera_update(L3Game *g, float dt, int immediate) {
    L3Camera *c=&g->camera;
    L3Vec3 target={g->player.position.x,g->player.position.y+1.35f,g->player.position.z};
    L3Vec3 conversation={0};int talking=g->story.dialogue>=0;
    if(talking) {
        unsigned d=(unsigned)g->story.dialogue,n=d==0||d==3||d==7?0:d==1||d==4?1:2;
        if(d>=14)n=L3_GARDEN_FIRST+d-14;
        else if(d>=8)n=l3_amber_dialogue_site((int)d);
        L3Vec3 npc=l3_story_site(g,n);float dx=npc.x-g->player.position.x,dz=npc.z-g->player.position.z;
        float length=fmaxf(.01f,length2(dx,dz));dx/=length;dz/=length;
        target=(L3Vec3){(npc.x+g->player.position.x)*.5f,(npc.y+g->player.position.y)*.5f+1.25f,(npc.z+g->player.position.z)*.5f};
        conversation=(L3Vec3){target.x-dz*5.5f-dx*2,target.y+2.1f,target.z+dx*5.5f-dz*2};
        L3Vec3 clipped=camera_clip(g,target,conversation);
        if(length2(clipped.x-target.x,clipped.z-target.z)<3)
            conversation=(L3Vec3){target.x+dz*5.5f-dx*2,target.y+2.1f,target.z-dx*5.5f-dz*2};
    }
    int puzzle=!g->story.region&&!talking&&g->camera_manual_seconds<=0&&
        ((g->autopilot&&g->story.workshop_mode==2)||g->story.workshop_focus>0);
    if(puzzle){target=(L3Vec3){145,29.5f,43};conversation=(L3Vec3){145,33.2f,54};}
    if(!talking&&g->story.region&&g->story.amber_focus>0&&g->camera_manual_seconds<=0){
        target=(L3Vec3){(g->player.position.x+244)*.5f,fmaxf(g->player.position.y,10)+1,(g->player.position.z+34)*.5f};
        conversation=(L3Vec3){target.x-7,target.y+7,target.z+11};puzzle=1;
    }
    float blend = immediate ? 1 : 1-expf(-9*dt);
    /* Immediate restoration must not inherit cancellation rounding from the
     * previous camera (for example valley versus Amber initialization). */
    if(immediate)c->target=target;
    else {
        c->target.x += (target.x-c->target.x)*blend;
        c->target.y += (target.y-c->target.y)*blend;
        c->target.z += (target.z-c->target.z)*blend;
    }
    /* Never let lag place the target inside a hill or behind a wall. */
    c->target=camera_clip(g,target,c->target);
    L3Vec3 desired={c->target.x-sinf(c->yaw)*cosf(c->pitch)*c->distance,
                   c->target.y+sinf(c->pitch)*c->distance,
                   c->target.z-cosf(c->yaw)*cosf(c->pitch)*c->distance};
    if(talking||puzzle)desired=conversation;
    desired=camera_clip(g,c->target,desired);
    L3Vec3 smooth=desired;
    if(!immediate)smooth=(L3Vec3){c->eye.x+(desired.x-c->eye.x)*blend,
                               c->eye.y+(desired.y-c->eye.y)*blend,
                               c->eye.z+(desired.z-c->eye.z)*blend};
    c->eye=camera_clip(g,c->target,smooth);
}

int l3_game_init(L3Game *g, const L3World *w, int autopilot) {
    if (!g) return 0;
    memset(g,0,sizeof(*g));
    if (!w || !w->height || !isfinite(w->min_x) || !isfinite(w->max_x) ||
        !isfinite(w->min_z) || !isfinite(w->max_z) ||
        w->max_x-w->min_x <= 2*RADIUS || w->max_z-w->min_z <= 2*RADIUS ||
        !isfinite(w->spawn.x) || !isfinite(w->spawn.z) || !isfinite(w->spawn_yaw) ||
        !isfinite(w->goal.x) || !isfinite(w->goal.y) || !isfinite(w->goal.z) ||
        w->collectible_count > 32 || (w->collectible_count && !w->collectibles) ||
        w->route_count > 1024 || (w->route_count && !w->route)) return 0;
    for (uint32_t i=0;i<w->route_count;++i)
        if (!isfinite(w->route[i].x) || !isfinite(w->route[i].z)) return 0;
    for (uint32_t i=0;i<w->collectible_count;++i)
        if (!isfinite(w->collectibles[i].x) || !isfinite(w->collectibles[i].y) ||
            !isfinite(w->collectibles[i].z)) return 0;
    g->world=*w;
    g->player.position=w->spawn;
    g->player.position.x=clampf(w->spawn.x,w->min_x+RADIUS,w->max_x-RADIUS);
    g->player.position.z=clampf(w->spawn.z,w->min_z+RADIUS,w->max_z-RADIUS);
    g->player.position.y=height(g,g->player.position.x,g->player.position.z);
    if (g->player.position.y==100000.0f || blocked(g,g->player.position.x,
        g->player.position.y,g->player.position.z,RADIUS,BODY_HEIGHT)) return 0;
    g->player.yaw=angle(w->spawn_yaw);
    g->player.grounded=1;
    g->camera.yaw=g->player.yaw;
    g->camera.pitch=.30f;
    g->camera.distance=7.8f;
    g->autopilot=autopilot && w->route_count>1;
    g->route_direction=1;
    g->valid=1;
    l3_story_init(g);l3_village_reset(g);camera_update(g,0,1);
    l3_story_after(g);
    return 1;
}

static void nearest_route(L3Game *g) {
    float best=1e30f;
    for (uint32_t i=0;i<g->world.route_count;++i) {
        float d=length2(g->world.route[i].x-g->player.position.x,
                        g->world.route[i].z-g->player.position.z);
        if (d<best) { best=d; g->route_index=i; }
    }
}

static void route_advance(L3Game *g) {
    if (g->route_direction>0) {
        if (g->route_index+1<g->world.route_count) ++g->route_index;
        else { g->route_direction=-1; --g->route_index; ++g->completed_routes; }
    } else {
        if (g->route_index>0) --g->route_index;
        else { g->route_direction=1; ++g->route_index; ++g->completed_routes; }
    }
}

static int horizontal_try(L3Game *g, float x, float z) {
    L3Player *p=&g->player;
    float floor=height(g,x,z), old_floor=height(g,p->position.x,p->position.z);
    float distance=length2(x-p->position.x,z-p->position.z);
    float feet=p->position.y;
    if (p->grounded) {
        /* Tolerance must stay below float noise: a centimetre allowance per
         * substep lets a blocked character slowly climb vertical slopes. */
        if (floor-old_floor > .00005f+distance*.95f) return 0;
        if (floor > feet-.32f) feet=floor;
    } else if (floor > feet+.08f) return 0;
    if (blocked(g,x,feet,z,RADIUS,BODY_HEIGHT)) return 0;
    p->position.x=x; p->position.z=z;
    if (p->grounded && feet>=floor && feet-floor<.32f) p->position.y=floor;
    else if (feet-floor>=.32f) p->grounded=0;
    return 1;
}

static void collect_and_interact(L3Game *g) {
    for (uint32_t i=0;i<g->world.collectible_count;++i) {
        uint32_t bit=UINT32_C(1)<<i;
        L3Vec3 a=g->world.collectibles[i], p=g->player.position;
        if (!(g->collected_mask&bit) && length2(a.x-p.x,a.z-p.z)<1.35f &&
            fabsf(a.y-p.y)<2.2f) {
            g->collected_mask|=bit;
            ++g->collected_count;g->story.revision++;
        }
    }

}

static void step(L3Game *g, L3Input in, float dt) {
    L3Player *p=&g->player;
    int was_auto=g->autopilot;
    if ((in.pressed&L3_TOGGLE_AUTO) && g->world.route_count>1) {
        g->autopilot=!g->autopilot;
        nearest_route(g);l3_workshop_rejoin(g);l3_amber_rejoin(g);
    }
    if (fabsf(in.move_x)+fabsf(in.move_z)+fabsf(in.look_x)+fabsf(in.look_y)>.02f ||
        (in.pressed&(L3_JUMP|L3_INTERACT))) g->autopilot=0;
    if(was_auto!=g->autopilot)g->story.revision++;
    g->camera_manual_seconds=fmaxf(0,g->camera_manual_seconds-dt);
    if (fabsf(in.look_x)+fabsf(in.look_y)>.01f) {
        g->camera.yaw=angle(g->camera.yaw-in.look_x*2.1f*dt);
        g->camera.pitch=clampf(g->camera.pitch+in.look_y*1.2f*dt,.10f,.85f);
        g->camera_manual_seconds=2.5f;
    }
    l3_workshop_tick(g,dt);l3_amber_tick(g,dt);
    if(l3_story_before(g,in.pressed,dt)) {
        p->velocity=(L3Vec3){0};p->speed=0;camera_update(g,dt,0);
        g->time+=dt;l3_story_after(g);return;
    }
    float dx=0,dz=0, speed=(in.held&L3_SPRINT)?RUN_SPEED:WALK_SPEED;
    if (g->autopilot) {
        L3Vec3 point=l3_story_auto_target(g);
        dx=point.x-p->position.x; dz=point.z-p->position.z;
        float dist=length2(dx,dz);
        unsigned phase=g->story.phase;
        int advance=(phase==1&&g->route_index<5)||(phase==2&&g->route_index<7)||
                    (phase==3&&g->route_index<14)||phase>=4;
        int workshop=(g->story.phase==4&&g->story.workshop_phase>0&&g->story.workshop_phase<4)||g->story.region;
        if (dist<(workshop?.15f:.60f)&&advance) {
            if(!l3_amber_advance(g)&&!l3_workshop_advance(g))route_advance(g);
            point=l3_story_auto_target(g);
            dx=point.x-p->position.x; dz=point.z-p->position.z;
            dist=length2(dx,dz);
        }
        speed=fminf(WALK_SPEED,workshop?dist*8.1f:1.8f+dist*1.5f);
        if (dist>.001f) { dx/=dist; dz/=dist; }
    } else {
        dx=-cosf(g->camera.yaw)*in.move_x+sinf(g->camera.yaw)*in.move_z;
        dz=sinf(g->camera.yaw)*in.move_x+cosf(g->camera.yaw)*in.move_z;
        float n=length2(dx,dz);
        if (n>1) { dx/=n; dz/=n; }
    }
    float accel=p->grounded ? 20.0f : 6.0f;
    p->velocity.x=approach(p->velocity.x,dx*speed,accel*dt);
    p->velocity.z=approach(p->velocity.z,dz*speed,accel*dt);
    if (length2(dx,dz)>.02f) p->yaw=angle(p->yaw+angle(atan2f(dx,dz)-p->yaw)*(1-expf(-12*dt)));
    if (p->grounded) g->coyote_seconds=.10f;
    else g->coyote_seconds=fmaxf(0,g->coyote_seconds-dt);
    if (in.pressed&L3_JUMP) g->jump_buffer_seconds=.12f;
    else g->jump_buffer_seconds=fmaxf(0,g->jump_buffer_seconds-dt);
    if (g->jump_buffer_seconds>0 && g->coyote_seconds>0) {
        p->velocity.y=6.2f; p->grounded=0;
        g->jump_buffer_seconds=0; g->coyote_seconds=0;
    }
    L3Vec3 before=p->position;
    float mx=p->velocity.x*dt, mz=p->velocity.z*dt;
    int sub=(int)ceilf(length2(mx,mz)/.12f);
    if (sub<1) sub=1;
    for (int i=0;i<sub;++i) {
        if (!horizontal_try(g,p->position.x+mx/sub,p->position.z+mz/sub)) {
            if (!horizontal_try(g,p->position.x+mx/sub,p->position.z)) p->velocity.x=0;
            if (!horizontal_try(g,p->position.x,p->position.z+mz/sub)) p->velocity.z=0;
        }
    }
    if (!p->grounded) {
        p->velocity.y-=GRAVITY*dt;
        float next_y=p->position.y+p->velocity.y*dt;
        if (blocked(g,p->position.x,next_y,p->position.z,RADIUS,BODY_HEIGHT)) p->velocity.y=0;
        else p->position.y=next_y;
    }
    float floor=height(g,p->position.x,p->position.z);
    if (p->position.y<=floor && p->velocity.y<=0) {
        p->position.y=floor; p->velocity.y=0; p->grounded=1;
    }
    float moved=length2(p->position.x-before.x,p->position.z-before.z);
    p->speed=moved/dt;
    if (p->grounded) {
        g->distance_walked+=moved;
        p->walk_phase=fmodf(p->walk_phase+moved*3.5f,2*PI);
    }
    if (g->autopilot && moved<.005f) g->autopilot_stuck_seconds+=dt;
    else g->autopilot_stuck_seconds=0;
    collect_and_interact(g);l3_story_after(g);
    if (g->camera_manual_seconds<=0 && p->speed>.2f)
        g->camera.yaw=angle(g->camera.yaw+angle(p->yaw-g->camera.yaw)*(1-expf(-2.8f*dt)));
    camera_update(g,dt,0);
    g->time+=dt;
}

void l3_game_step(L3Game *g, const L3Input *input, float dt) {
    if (!g || !g->valid || !isfinite(dt) || dt<=0) return;
    dt=fminf(dt,.1f);
    if(g->activities.arcade.active){l3_activity_step(g,input,dt);return;}
    if(input&&(input->pressed&L3_INTERACT)&&g->story.nearest>=L3_ACTIVITY_FIRST_SITE&&
       l3_activity_enter(g,(unsigned)g->story.nearest-L3_ACTIVITY_FIRST_SITE))return;
    L3Input in=input ? *input : (L3Input){0};
    in.move_x=axis(in.move_x); in.move_z=axis(in.move_z);
    in.look_x=axis(in.look_x); in.look_y=axis(in.look_y);
    int n=(int)ceilf(dt/(1.0f/60));
    for (int i=0;i<n;++i) {
        step(g,in,dt/n);
        in.pressed=0;
    }
}

int l3_game_position_valid(const L3Game *g,L3Vec3 p) {
    if(!g||!g->valid||!isfinite(p.x)||!isfinite(p.y)||!isfinite(p.z))return 0;
    float floor=height(g,p.x,p.z);
    return floor!=100000.0f&&p.y>=floor-.001f&&p.y<floor+10&&!blocked(g,p.x,p.y,p.z,RADIUS,BODY_HEIGHT);
}
int l3_game_restore_position(L3Game *g,L3Vec3 p) {
    if(!g||!g->valid||!isfinite(p.x)||!isfinite(p.z))return 0;
    p.y=height(g,p.x,p.z);
    if(p.y==100000.0f||blocked(g,p.x,p.y,p.z,RADIUS,BODY_HEIGHT))return 0;
    L3Game next=*g;next.player.position=p;next.player.velocity=(L3Vec3){0,0,0};
    next.player.speed=0;next.player.grounded=1;
    next.coyote_seconds=next.jump_buffer_seconds=next.autopilot_stuck_seconds=next.camera_manual_seconds=0;
    l3_story_after(&next);camera_update(&next,0,1);*g=next;return 1;
}
