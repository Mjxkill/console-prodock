#include "luma3d_amber.h"
#include "luma3d_render.h"
#include "generated.h"
#include "luma3d_surface.h"
#include <math.h>
#include "workshop_apron.h"
#include "amber_data.h"

static float ground(float x,float z) {return l3_surface_ground(x,z);}
static int bridge(float x,float z,float radius,float *deck) {
    return l3_surface_bridge(x,z,radius,deck);
}
static float apron(float x,float z,float floor) {
    if(z<63.5f||z>66.5f||x<108||x>121.3f||(x>111.2f&&x<121))return floor;
    for(unsigned i=0;i<sizeof(apron_triangles)/sizeof(*apron_triangles);i++){
        const L3Vec3 *v=apron_triangles[i];
        float dx=x-v[0].x,dz=z-v[0].z,ax=v[1].x-v[0].x,az=v[1].z-v[0].z,bx=v[2].x-v[0].x,bz=v[2].z-v[0].z;
        float det=ax*bz-az*bx,a=(dx*bz-dz*bx)/det,b=(ax*dz-az*dx)/det;
        if(a>=-1e-6f&&b>=-1e-6f&&a+b<=1.000001f)floor=fmaxf(floor,v[0].y+a*(v[1].y-v[0].y)+b*(v[2].y-v[0].y));
    }
    return floor;
}
static float height(void *ctx,float x,float z) {
    (void)ctx;if(x>=192)return l3_amber_ground(x,z);float y=ground(x,z),deck;
    return apron(x,z,bridge(x,z,0,&deck)?fmaxf(y,deck):y);
}
static int blocked(void *ctx,float x,float y,float z,float r,float h) {
    (void)ctx;
    for(unsigned i=x>=192?AMBER_FIRST_COLLIDER:0,end=x>=192?l3_asset_collider_count:AMBER_FIRST_COLLIDER;i<end;i++) {
        const L3AssetCollider *c=&l3_asset_colliders[i];
        if(c->kind==L3_COLLIDER_BRIDGE||y>=c->max_y||y+h<=c->min_y)continue;
        if(c->kind==L3_COLLIDER_CIRCLE&&hypotf(x-c->x,z-c->z)<r+c->radius)return 1;
        if(c->kind==L3_COLLIDER_BOX) {
            float dx=x-c->x,dz=z-c->z,co=cosf(c->yaw),s=sinf(c->yaw);
            if(fabsf(co*dx-s*dz)<c->length*.5f+r&&fabsf(s*dx+co*dz)<c->width*.5f+r)return 1;
        }
    }
    float deck;if(bridge(x,z,r,&deck)&&y>=deck-.1f)return 0;
    float floor=ground(x,z);
    for(unsigned i=0;i<l3_asset_water_count;i++) {
        const L3AssetWater *w=&l3_asset_waters[i];
        if(w->level-floor<=.65f||y>=w->level+.2f)continue;
        if(w->kind==L3_WATER_ELLIPSE) {
            float a=(x-w->x)/(w->rx+.3f),b=(z-w->z)/(w->rz+.3f);
            if(a*a+b*b<1)return 1;
        }else if(w->kind==L3_WATER_RIBBON) {
            for(unsigned j=1;j<w->point_count;j++) {
                const L3AssetPoint2 *a=&l3_asset_water_points[w->first_point+j-1],*b=a+1;
                float dx=b->x-a->x,dz=b->z-a->z,d2=dx*dx+dz*dz;
                float t=d2>0?fminf(1,fmaxf(0,((x-a->x)*dx+(z-a->z)*dz)/d2)):0;
                if(hypotf(x-a->x-t*dx,z-a->z-t*dz)<w->width*.5f+r)return 1;
            }
        }
    }return 0;
}
void l3_world_init(L3World *w) {
    *w=(L3World){.height=height,.blocked=blocked,.max_x=160,.max_z=160,
      .spawn=l3_asset_spawn,.spawn_yaw=l3_asset_spawn_yaw,
      .route=l3_asset_route,.route_count=l3_asset_route_count,
      .collectibles=l3_asset_collectibles,.collectible_count=l3_asset_collectible_count,
      .goal=l3_asset_goal,.goal_radius=l3_asset_goal_radius};
}
