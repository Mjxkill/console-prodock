#include "l3_simon_presentation.h"
#include "l3_simon_art.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#define ARRAY_COUNT(a) ((unsigned)(sizeof(a)/sizeof(*(a))))
static int expand(uint16_t *dst,unsigned pixels,const uint32_t *runs,unsigned count)
{
    unsigned at=0;for(unsigned i=0;i<count;i++){unsigned n=runs[i]>>16;if(!n || n>pixels-at)return 0;for(unsigned j=0;j<n;j++)dst[at++]=(uint16_t)runs[i];}return at==pixels;
}
static void publish(L3Render *r,unsigned offset,const uint16_t *src,unsigned bytes)
{for(unsigned i=0;i<bytes;i+=4){uint32_t v;memcpy(&v,(const uint8_t *)src+i,4);*(volatile uint32_t *)(r->memory+offset+i)=v;}}
int l3_simon_presentation_open(L3Render *r)
{if(!r || r->simon_presentation)return 0;r->simon_presentation=calloc(1,sizeof(L3SimonPresentation));return r->simon_presentation!=0;}
void l3_simon_presentation_close(L3Render *r)
{if(r){if(r->simon_presentation)free(r->simon_presentation->entry_background);free(r->simon_presentation);r->simon_presentation=0;}}
void l3_simon_presentation_reset(L3Render *r)
{
    if(!r || !r->simon_presentation)return;L3SimonPresentation *p=r->simon_presentation;
    if(p->assets_valid)r->mini_canvas_stamp=r->mini_stamp[0]=r->mini_stamp[1]=0;
    free(p->entry_background);p->entry_background=0;p->base_ready[0]=p->base_ready[1]=0;
    l3_simon_light_reset(&p->light);p->assets_valid=p->ui_valid=p->page_valid[0]=p->page_valid[1]=0;
}
void l3_simon_presentation_observe(void *opaque,const L3ArcadeView *a,const L3ArcadeView *b,uint32_t pressed,uint32_t held,uint32_t trace,double now,uint32_t epoch)
{
    L3Render *r=opaque;(void)held;(void)trace;if(!r || !r->simon_presentation)return;L3SimonPresentation *p=r->simon_presentation;
    if(!b || b->kind!=L3_ARCADE_SIMON){l3_simon_presentation_reset(r);return;}
    if(!a || a->kind!=b->kind || epoch!=p->epoch)l3_simon_presentation_reset(r);
    p->epoch=epoch;
    if(p->light.paused)l3_simon_light_pause(&p->light,0,now);
    l3_simon_light_observe(&p->light,a && a->kind==b->kind?&a->content.simon:0,&b->content.simon,pressed,now,epoch);
}
static int bake(L3Render *r,L3SimonPresentation *p)
{
    unsigned w=r->width*2,h=r->height*2,bytes=w*h*2;
    if(!r->mini_pixels || !r->mini_shadow[0] || !r->mini_shadow[1] || !r->memory || !l3_simon_native_layout(w,h,&p->layout) || !l3_simon_native_assets(&p->layout,&p->assets))return 0;
    uint16_t *work=malloc(bytes);if(!work)return 0;
    /* Decode small resources first, then retain the immutable native backdrop
     * in this same buffer until both pages have been reused. Never publish a
     * backdrop to the page still scanned out by the previous PRESENT. */
    if(!expand(work,256*256,l3_simon_keys,ARRAY_COUNT(l3_simon_keys))){free(work);return 0;}
    publish(r,p->assets.keys.base-PRODOCK_GPU_BASE,work,256*256*2);p->asset_bytes+=256*256*2;
    if(!expand(work,128*128,l3_simon_halo,ARRAY_COUNT(l3_simon_halo))){free(work);return 0;}
    publish(r,p->assets.halo.base-PRODOCK_GPU_BASE,work,32768);p->asset_bytes+=32768;
    if(!expand(work,128*128,l3_simon_shadow,ARRAY_COUNT(l3_simon_shadow))){free(work);return 0;}
    publish(r,p->assets.shadow.base-PRODOCK_GPU_BASE,work,32768);p->asset_bytes+=32768;
    int ok=w==800?expand(work,w*h,l3_simon_background_800,ARRAY_COUNT(l3_simon_background_800)):expand(work,w*h,l3_simon_background_1280,ARRAY_COUNT(l3_simon_background_1280));
    if(!ok){free(work);return 0;}
    const L3SimonNativeLayout *l=&p->layout;
    for(unsigned y=0;y<l->h;y++)publish(r,(p->assets.background.color-PRODOCK_GPU_BASE)+y*l->w*2,work+(y+l->y)*w+l->x,l->w*2);
    p->asset_bytes+=l->w*l->h*2;
    free(p->entry_background);p->entry_background=work;p->base_ready[0]=p->base_ready[1]=0;
    memset(r->mini_pixels,0,w*h);p->ui_valid=0;p->ui_page[0]=p->ui_page[1]=0;p->page_valid[0]=p->page_valid[1]=0;
    r->mini_canvas_stamp=r->mini_stamp[0]=r->mini_stamp[1]=0;p->assets_valid=1;gpu_v1_invalidate(&r->gpu);return 1;
}
static void clear_rect(L3Render *r,int x,int y,int w,int h)
{for(int yy=y;yy<y+h;yy++)memset(r->mini_pixels+(size_t)yy*r->width*2+x,0,(size_t)w);r->simon_presentation->ui_raster_pixels+=(unsigned)(w*h);}
static void text_at(L3Render *r,int x,int y,unsigned style,const char *text,unsigned color,unsigned width)
{l3_ui_text(r->mini_pixels,r->width*2,r->height*2,x,y,style,text,color,width);}
static void text_center(L3Render *r,int center,int y,const char *text,unsigned color,unsigned width)
{
    unsigned stride=r->width*2;int x=center-(int)width/2;
    int height=l3_ui_text(r->mini_pixels,stride,r->height*2,x,y,0,text,color,0),left=(int)width,right=-1;
    for(int yy=0;yy<height;yy++)for(unsigned xx=0;xx<width;xx++)if(r->mini_pixels[(size_t)(y+yy)*stride+x+xx]){if((int)xx<left)left=(int)xx;if((int)xx>right)right=(int)xx;}
    if(right<left)return;
    uint8_t row[1280];int target=((int)width-(right-left+1))/2;
    for(int yy=0;yy<height;yy++){
        uint8_t *dst=r->mini_pixels+(size_t)(y+yy)*stride+x;memcpy(row,dst,width);memset(dst,0,width);memcpy(dst+target,row+left,(size_t)(right-left+1));
    }
}
static void chrome(L3Render *r,const L3Game *g,const L3SimonView *v)
{
    L3SimonPresentation *p=r->simon_presentation;unsigned key[]={v->phase,v->sequence_length,v->input_index,v->grid.status,v->grid.progress,g->showcase_status,g->showcase_stage};
    if(p->ui_valid && !memcmp(key,p->ui_key,sizeof(key)))return;
    int wide=r->width==640,w=(int)r->width*2,h=(int)r->height*2,left=wide?100:32,top=wide?238:136;
    clear_rect(r,left,top,wide?210:150,wide?180:126);
    text_at(r,left,top,0,"LUMA",78,150);text_at(r,left,top+(wide?36:27),1,"Mémoire",75,200);
    char line[64];snprintf(line,sizeof(line),"Manche %u / 8",v->sequence_length);text_at(r,left,top+(wide?78:57),0,line,74,wide?210:150);
    int dots=top+(wide?128:91),rad=wide?4:3,spacing=wide?22:15;
    for(unsigned i=0;i<8;i++)for(int dy=-rad;dy<=rad;dy++)for(int dx=-rad;dx<=rad;dx++)if(dx*dx+dy*dy<=rad*rad)r->mini_pixels[(size_t)(dots+dy)*w+left+rad+(int)i*spacing+dx]=(uint8_t)(i<v->grid.progress?78:76);
    int center=w/2,cy=wide?360:244,cw=wide?130:108;
    clear_rect(r,center-cw/2,cy-(wide?34:29),cw,wide?76:62);
    const char *phase=v->phase==L3_SIMON_INPUT?"À VOUS":v->phase==L3_SIMON_ROUND_OK?"BRAVO":v->phase==L3_SIMON_ERROR?"ESSAYEZ":v->phase==L3_SIMON_COMPLETE?"SOUVENIR":"OBSERVEZ";
    text_center(r,center,cy-(wide?29:26),phase,79,(unsigned)cw);
    if(v->phase==L3_SIMON_INPUT)snprintf(line,sizeof(line),"%u / %u",v->input_index,v->sequence_length);else snprintf(line,sizeof(line),"%u note%s",v->sequence_length,v->sequence_length>1?"s":"");
    text_center(r,center,cy+(wide?7:1),line,74,(unsigned)cw);
    int right=wide?970:650,ry=wide?255:157,rw=wide?240:132;clear_rect(r,right,ry,rw,wide?200:150);
    text_at(r,right,ry,0,"QUATRE CRISTAUX",78,rw);
    const char *hint=v->grid.status==L3_MINI_WON?"Souvenir acquis. Q pour retrouver l'aventure.":v->grid.status==L3_MINI_LOST?"Nouvel essai ? R pour recommencer.":v->phase==L3_SIMON_INPUT?"Répétez les couleurs dans l'ordre.":"Observez les cristaux. Puis répétez.";
    text_at(r,right,ry+(wide?70:60),0,hint,74,rw);
    clear_rect(r,20,h-(wide?54:38),w-40,wide?48:32);
    const char *controls=g->showcase_status?"DÉMO - E pour jouer - Q pour revenir":"W : rouge · D : vert · S : bleu · A : or · R rejouer · Q retour";
    text_center(r,w/2,h-(wide?46:30),controls,74,(unsigned)(w-(wide?180:64)));
    memcpy(p->ui_key,key,sizeof(key));p->ui_valid=1;p->ui_revision++;if(!p->ui_revision){p->ui_revision=1;p->ui_page[0]=p->ui_page[1]=0;}
}
static void upload_rect(L3Render *r,unsigned page,int x,int y,int width,int height,int force)
{
    L3SimonPresentation *p=r->simon_presentation;int end=(x+width+3)&~3;x&=~3;width=end-x;unsigned stride=r->width*2;
    for(int yy=y;yy<y+height;yy++){
        size_t at=(size_t)yy*stride+x;const uint8_t *src=r->mini_pixels+at;uint8_t *old=r->mini_shadow[page]+at;p->ui_scan_bytes+=(unsigned)width;
        for(int xx=0;xx<width;xx+=4){uint32_t a,b;memcpy(&a,src+xx,4);memcpy(&b,old+xx,4);if(force||a!=b){*(volatile uint32_t *)(r->memory+(22u<<20)+page*(1u<<20)+at+xx)=a;memcpy(old+xx,&a,4);p->ui_published_bytes+=4;r->mini_bytes+=4;}}
    }
}
int l3_simon_presentation_prepare(L3Render *r,const L3Game *g,struct prodock_scene *scene,double now)
{
    if(!r || !g || !scene || !r->simon_presentation)return 0;L3ArcadeView all;
    if(!l3_arcade_view(&g->activities.arcade,&all) || all.kind!=L3_ARCADE_SIMON)return 0;
    L3SimonPresentation *p=r->simon_presentation;const L3SimonView *v=&all.content.simon;
    if(!p->assets_valid && !bake(r,p))return 0;
    if(!p->light.valid && !l3_simon_light_observe(&p->light,0,v,0,now,p->epoch))return 0;
    if(!l3_simon_light_pause(&p->light,g->showcase_status==3,now))return 0;
    L3SimonLightFrame frame;if(!l3_simon_light_sample(&p->light,now,&frame))return 0;
    unsigned page=r->frame&1;
    if(!p->base_ready[page]){
        if(!p->entry_background)return 0;
        unsigned bytes=r->width*2*r->height*2*2;publish(r,page*r->page_bytes,p->entry_background,bytes);p->base_bytes+=bytes;p->base_ready[page]=1;
        if(p->base_ready[0] && p->base_ready[1]){free(p->entry_background);p->entry_background=0;}
    }
    if(!p->page_valid[page] || memcmp(&p->page_light[page],&frame,3*sizeof(frame.level_q8))){
        unsigned quads;if(!l3_simon_native_draw(&r->gpu,&p->layout,&p->assets,&frame,PRODOCK_GPU_BASE+page*r->page_bytes,PRODOCK_GPU_BASE+2*r->page_bytes,&quads))return 0;
        p->page_light[page]=frame;p->page_valid[page]=1;p->quads+=quads;
    }else p->skipped++;
    chrome(r,g,v);unsigned w=r->width*2,h=r->height*2;
    if(p->ui_page[page]!=p->ui_revision){
        if(!p->ui_page[page])upload_rect(r,page,0,0,w,h,1);
        else if(w==800){upload_rect(r,page,32,136,150,126,0);upload_rect(r,page,346,215,108,62,0);upload_rect(r,page,650,157,132,150,0);upload_rect(r,page,20,442,760,32,0);}
        else{upload_rect(r,page,100,238,210,180,0);upload_rect(r,page,575,326,130,76,0);upload_rect(r,page,970,255,240,200,0);upload_rect(r,page,20,666,1240,48,0);}
        p->ui_page[page]=p->ui_revision;r->mini_uploads++;
    }
    uint32_t *layer=scene->layers[0];layer[0]=PRODOCK_GPU_BASE+(22u<<20)+page*(1u<<20);layer[1]=w|(h<<16);layer[2]=0;layer[3]=layer[1];layer[4]=0;layer[5]=w;layer[6]=3;scene->layers_enabled=1;scene->format=3;scene->base=PRODOCK_GPU_BASE+page*r->page_bytes;scene->stride=w*2;p->frames++;return 1;
}
