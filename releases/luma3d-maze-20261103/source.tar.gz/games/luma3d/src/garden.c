#include "luma3d_garden.h"
#include "luma3d_activities.h"
#include <math.h>
/* Single owner of interaction positions. Renderers obtain ground from here. */
const float l3_garden_posts[4][2]={{241,49},{247,49},{241,55},{247,55}};
static const float sites[L3_GARDEN_SITES][2]={
 {244,58},{254,62},{242,67},{255,51},{260,70},{254,58}
};
L3Vec3 l3_garden_site(const L3Game *g,unsigned i){
 if(!g||i>=L3_GARDEN_SITES||!g->world.height)return (L3Vec3){NAN,NAN,NAN};
 L3Vec3 p={sites[i][0],0,sites[i][1]};p.y=g->world.height(g->world.context,p.x,p.z);return p;
}
int l3_garden_in_zone(const L3Game *g){return g&&g->story.region==1&&
 g->player.position.x>=238&&g->player.position.x<=264&&g->player.position.z>=48&&g->player.position.z<=74;}
static int close_to(const L3Game *g,unsigned i){
 if(!g||!g->valid||g->story.region!=1)return 0;
 L3Vec3 p=l3_garden_site(g,i),a=g->player.position;
 return isfinite(a.x)&&isfinite(a.y)&&isfinite(a.z)&&isfinite(p.y)&&
 hypotf(a.x-p.x,a.z-p.z)<2.3f&&fabsf(a.y-p.y)<1.9f;
}
int l3_garden_nearest(const L3Game *g){
 int best=-1;float d=2.3f;
 for(unsigned i=0;i<L3_GARDEN_SITES;i++)if(close_to(g,i)){
  L3Vec3 p=l3_garden_site(g,i);float next=hypotf(p.x-g->player.position.x,p.z-g->player.position.z);
  if(next<d){d=next;best=(int)i;}
 }return best;
}
int l3_garden_state_ok(const L3Game *g){
 if(!g||g->garden_invited>1||g->garden_seeds>7||g->garden_reward>1)return 0;
 return !g->garden_reward||(g->garden_invited&&g->garden_seeds==7&&l3_activity_won(g,L3_ARCADE_SIMON));
}
int l3_garden_interact(L3Game *g,unsigned i){
 if(!close_to(g,i)||!l3_garden_state_ok(g)||g->activities.arcade.active||g->story.dialogue>=0||g->story.journal)return 0;
 if(i==5){
  /* Reuse the complete existing engine, release gate and renderer. The
   * alternative entrance is authorized in l3_activity_enter, not teleporting. */
  return l3_activity_enter(g,L3_ARCADE_SIMON);
 }
 if(i>=2){unsigned old=g->garden_seeds;g->garden_seeds|=1u<<(i-2);
  if(old!=g->garden_seeds)g->story.revision++;return 1;}
 if(i==0){g->garden_invited=1;
  if(g->garden_seeds==7&&l3_activity_won(g,L3_ARCADE_SIMON))g->garden_reward=1;
 }
 g->story.dialogue=14+(int)i;g->story.page=0;g->story.dialogue_time=0;g->story.revision++;return 1;
}
int l3_garden_blocked(const L3Game *g,float x,float y,float z,float r,float h){
 if(!g||g->story.region!=1)return 0;
 for(unsigned i=0;i<2;i++){L3Vec3 p=l3_garden_site(g,i);
  if(y+h>p.y&&y<p.y+1.7f&&hypotf(x-p.x,z-p.z)<r+.28f)return 1;}
 for(unsigned i=0;i<4;i++){
  float px=l3_garden_posts[i][0],pz=l3_garden_posts[i][1],floor=g->world.height(g->world.context,px,pz);
  if(fabsf(x-px)<r+.15f&&fabsf(z-pz)<r+.15f&&y+h>floor&&y<floor+2.8f)return 1;
 }
 /* Hedge and gate share their rendered dimensions. Both end routes always
  * remain open; completing the optional quest shortens only the middle path. */
 if(fabsf(x-L3_GARDEN_GATE_X)<r+.35f&&z+r>55&&z-r<67){
  int gap=z-r>59.6f&&z+r<62.4f;
  float floor=g->world.height(g->world.context,x,z);
  if((!gap||!g->garden_reward)&&y<floor+1.8f&&y+h>floor)return 1;
 }return 0;
}
const char *l3_garden_objective(const L3Game *g){
 if(g->garden_reward)return "Serres de Sélène · le passage du verger est ouvert";
 if(!g->garden_invited)return "Serres de Sélène · rencontrer la botaniste";
 if(g->garden_seeds!=7)return "Herbier lunaire · retrouver les trois semences";
 if(!l3_activity_won(g,L3_ARCADE_SIMON))return "Oren attend · jouer le carillon des quatre couleurs";
 return "Herbier complet · rapporter les semences à Sélène";
}
const char *l3_garden_prompt(const L3Game *g,unsigned i){
 if(i==0)return "E · Sélène, botaniste des serres";
 if(i==1)return "E · Oren, gardien du carillon";
 if(i==5)return "E · Carillon des couleurs · défi Simon";
 static const char *const names[]={"E · Semence de rosée · sentier bas","E · Semence solaire · belvédère","E · Semence de nuit · verger"};
 if(i<2||i>4)return "Serres de Sélène";
 return g->garden_seeds&(1u<<(i-2))?"Semence conservée dans l’herbier":names[i-2];
}
const char *l3_garden_dialogue(const L3Game *g){
 if(g->story.dialogue==15)return l3_activity_won(g,L3_ARCADE_SIMON)?
  "Tu connais déjà les quatre couleurs ! Ton ancien\nsuccès compte ici. Sélène attend les trois semences.\nLe chemin du haut et celui du verger restent ouverts.":
  "Les fleurs répondent au carillon. Approche de son\npupitre, derrière moi : observe, puis répète les\nquatre couleurs. Tu peux quitter et revenir librement.";
 if(g->garden_reward)return "L'herbier est vivant ! Le portillon s'ouvre entre\nles haies. Garde ce raccourci pour tes prochaines\nvisites : les serres seront toujours ta maison.";
 if(g->garden_seeds==7)return l3_activity_won(g,L3_ARCADE_SIMON)?
  "Les trois semences et le carillon sont réunis.":
  "Rosée, soleil et nuit : toutes les semences sont là.\nIl manque leur mélodie. Oren garde le carillon,\nde l'autre côté de la haie ; aucun chemin n'est imposé.";
 return "Je suis Sélène. Trois semences manquent à l'herbier :\nla rosée en bas, le soleil au belvédère et la nuit\nau verger. Choisis ton chemin, puis retrouve Oren.";
}
