#include "luma3d_arcade_core.h"
#include "l3_mini_trace.h"
#include <string.h>

static uint32_t get32(const unsigned char *p){return p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static void put32(unsigned char *p,uint32_t v){for(unsigned i=0;i<4;i++)p[i]=(unsigned char)(v>>(8*i));}
static uint32_t crc(const unsigned char *p,size_t n){uint32_t c=~0u;while(n--){c^=*p++;for(unsigned i=0;i<8;i++)c=(c>>1)^(0xedb88320u&-(c&1));}return ~c;}
static const uint32_t ids[8]={0x43495231u,0x424c4b31u,0x53485031u,0x4d524731u,0x4d415a31u,0x53494d31u,0x53485431u,0x544f5731u};
uint32_t l3_arcade_id(unsigned k){return k<8?ids[k]:0;}
void l3_arcade_init(L3ArcadeState *s){if(s)memset(s,0,sizeof(*s));}
static int engine_init(L3ArcadeState *s,unsigned k,uint32_t seed){
 if(k<5)return l3_mini_init(&s->base[k],(L3MiniKind)k,seed);
 if(k==5)return l3_simon_init(&s->simon,seed);
 if(k==6)return l3_shooter_init(&s->shooter,seed);
 return k==7&&l3_platform_init(&s->platform,seed);
}
static int engine_view(const L3ArcadeState *s,unsigned k,L3ArcadeView *v){
 memset(v,0,sizeof(*v));v->kind=k;int ok=0;
 if(k<5){ok=l3_mini_view(&s->base[k],&v->content.grid);v->status=v->content.grid.status;}
 else if(k==5){ok=l3_simon_view(&s->simon,&v->content.simon);v->status=v->content.simon.grid.status;}
 else if(k==6){ok=l3_shooter_view(&s->shooter,&v->content.shooter);v->status=v->content.shooter.status;}
 else if(k==7){ok=l3_platform_view(&s->platform,&v->content.platform);v->status=v->content.platform.status;}
 return ok;
}
static int metadata_ok(const L3ArcadeState *s){
 if(!s||s->active>8||s->initialized>255||s->won>255||(s->won&~s->initialized)||s->release_inputs>1)return 0;
 if(s->active&&!(s->initialized&(1u<<(s->active-1))))return 0;
 return 1;
}
int l3_arcade_validate(const L3ArcadeState *s){
 if(!metadata_ok(s))return 0;
 for(unsigned k=0;k<8;k++)if(s->initialized&(1u<<k)){
  int ok=k<5?l3_mini_validate(&s->base[k]):k==5?l3_simon_validate(&s->simon):k==6?l3_shooter_validate(&s->shooter):l3_platform_validate(&s->platform);
  L3ArcadeView v;if(!ok||!engine_view(s,k,&v)||(v.status==L3_MINI_WON&&!(s->won&(1u<<k))))return 0;
 }else if(s->seed[k])return 0;
 return 1;
}
int l3_arcade_import_base(L3ArcadeState *s,const L3MiniState games[5],unsigned initialized,unsigned won,unsigned active,unsigned release_inputs){
 if(!s||!games||initialized>31||won>31||active>5||release_inputs>1)return 0;
 L3ArcadeState next;l3_arcade_init(&next);memcpy(next.base,games,sizeof(next.base));next.initialized=initialized;next.won=won;next.active=active;next.release_inputs=release_inputs;
 for(unsigned k=0;k<5;k++)if(initialized&(1u<<k))next.seed[k]=1; /* r4's authored seeds */
 if(!l3_arcade_validate(&next))return 0;*s=next;return 1;
}
int l3_arcade_enter(L3ArcadeState *s,unsigned k,uint32_t seed){
 if(!l3_arcade_validate(s)||s->active||k>=8)return 0;
 if(!(s->initialized&(1u<<k))){if(!engine_init(s,k,seed))return 0;s->seed[k]=seed;s->initialized|=1u<<k;}
 s->active=k+1;s->release_inputs=1;return 1;
}
uint32_t l3_arcade_step_trace(L3ArcadeState *s,uint32_t pressed,uint32_t held,uint32_t ms,L3MiniTrace *trace){
 if(trace)memset(trace,0,sizeof *trace);
 /* Each engine validates its own active state. Revalidating the seven
  * paused engines and building all their views every tick is unnecessary. */
 if(!metadata_ok(s)||!s->active)return L3_MINI_EVENT_INVALID;
 unsigned k=s->active-1;
 if(pressed&L3_MINI_BACK){s->active=0;s->release_inputs=1;return L3_MINI_EVENT_EXIT;}
 if(s->release_inputs){if(!pressed&&!held)s->release_inputs=0;return 0;}
 if(pressed&L3_ARCADE_RESTART){if(!engine_init(s,k,s->seed[k]))return L3_MINI_EVENT_INVALID;s->release_inputs=1;return L3_MINI_EVENT_CHANGED;}
 if(ms>250)ms=250;pressed&=127;held&=127;uint32_t e;
 if(k<5)e=l3_mini_step_trace(&s->base[k],pressed,held,ms,trace);
 else if(k==5)e=l3_simon_step(&s->simon,pressed,held,ms);
 else if(k==6)e=l3_shooter_step(&s->shooter,pressed,held,ms);
 else e=l3_platform_step(&s->platform,pressed,held,ms);
 if(e&L3_MINI_EVENT_WON){if(!(s->won&(1u<<k)))e|=L3_ARCADE_REWARD;s->won|=1u<<k;}
 return e;
}
uint32_t l3_arcade_step(L3ArcadeState *s,uint32_t pressed,uint32_t held,uint32_t ms){
 return l3_arcade_step_trace(s,pressed,held,ms,NULL);
}
int l3_arcade_view(const L3ArcadeState *s,L3ArcadeView *v){return v&&metadata_ok(s)&&s->active&&engine_view(s,s->active-1,v);}
int l3_arcade_demo_input(const L3ArcadeState *s,uint32_t *p,uint32_t *h,uint32_t *ms){
 if(!p||!h||!ms||!metadata_ok(s)||!s->active)return 0;
 if(s->release_inputs){*p=*h=*ms=0;return 1;}unsigned k=s->active-1;
 if(k<5)return l3_mini_demo_input(&s->base[k],p,h,ms);
 if(k==5)return l3_simon_demo_input(&s->simon,p,h,ms);
 if(k==6)return l3_shooter_demo_input(&s->shooter,p,h,ms);
 return l3_platform_demo_input(&s->platform,p,h,ms);
}
static size_t payload_size(unsigned k){return k<5?L3_MINI_SAVE_BYTES:k==5?L3_SIMON_SAVE_BYTES:k==6?L3_SHOOTER_SAVE_BYTES:L3_PLATFORM_SAVE_BYTES;}
size_t l3_arcade_encode(const L3ArcadeState *s,void *output,size_t cap){
 if(!output||!l3_arcade_validate(s))return 0;size_t bytes=32+8*12;
 for(unsigned k=0;k<8;k++)if(s->initialized&(1u<<k))bytes+=payload_size(k);
 if(bytes>cap||bytes>L3_ARCADE_SAVE_MAX)return 0;unsigned char *b=output;memset(b,0,bytes);
 put32(b,0x31435241u);put32(b+4,(uint32_t)bytes);put32(b+8,1);put32(b+16,s->active);put32(b+20,s->initialized);put32(b+24,s->won);put32(b+28,s->release_inputs);
 size_t at=32;
 for(unsigned k=0;k<8;k++){
  size_t n=s->initialized&(1u<<k)?payload_size(k):0;put32(b+at,ids[k]);put32(b+at+4,s->seed[k]);put32(b+at+8,(uint32_t)n);at+=12;
  if(n){size_t actual=k<5?l3_mini_encode(&s->base[k],b+at,n):k==5?l3_simon_encode(&s->simon,b+at,n):k==6?l3_shooter_encode(&s->shooter,b+at,n):l3_platform_encode(&s->platform,b+at,n);if(actual!=n)return 0;at+=n;}
 }
 put32(b+12,crc(b+16,bytes-16));return bytes;
}
int l3_arcade_decode(L3ArcadeState *s,const void *input,size_t bytes){
 if(!s||!input||bytes<128||bytes>L3_ARCADE_SAVE_MAX)return 0;const unsigned char *b=input;
 if(get32(b)!=0x31435241u||get32(b+4)!=bytes||get32(b+8)!=1||get32(b+12)!=crc(b+16,bytes-16))return 0;
 L3ArcadeState next;l3_arcade_init(&next);next.active=get32(b+16);next.initialized=get32(b+20);next.won=get32(b+24);next.release_inputs=get32(b+28);
 if(next.active>8||next.initialized>255||next.won>255||next.release_inputs>1)return 0;
 size_t at=32;unsigned seen=0;
 for(unsigned i=0;i<8;i++){
  if(bytes-at<12)return 0;unsigned k=0;for(;k<8&&ids[k]!=get32(b+at);k++);if(k==8||(seen&(1u<<k)))return 0;seen|=1u<<k;
  next.seed[k]=get32(b+at+4);size_t n=get32(b+at+8);at+=12;
  if(n!=(next.initialized&(1u<<k)?payload_size(k):0)||n>bytes-at)return 0;
  if(n){int ok=k<5?l3_mini_decode(&next.base[k],b+at,n):k==5?l3_simon_decode(&next.simon,b+at,n):k==6?l3_shooter_decode(&next.shooter,b+at,n):l3_platform_decode(&next.platform,b+at,n);if(!ok)return 0;}at+=n;
 }
 if(at!=bytes||!l3_arcade_validate(&next))return 0;*s=next;return 1;
}
