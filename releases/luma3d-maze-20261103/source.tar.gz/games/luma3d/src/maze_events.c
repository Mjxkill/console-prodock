#include "l3_maze_events.h"
#include <math.h>
#include <string.h>
void l3_maze_events_reset(L3MazeEvents *e){if(e)memset(e,0,sizeof *e);}
int l3_maze_events_observe(L3MazeEvents *e,const L3MazeMotion *m,const uint8_t floor[400],const L3MiniTrace *trace,double now,uint32_t epoch){
 if(!e||!m||!floor||!isfinite(now)||now<0||!m->valid)return 0;
 if(e->valid&&e->epoch==epoch&&now<e->time)return 0;
 if(trace&&(trace->event_count>L3_MAZE_TRACE_EVENTS||trace->event_overflow))return 0;
 for(unsigned q=0;q<400;q++)if(floor[q]!=L3_MINI_CELL_EMPTY&&floor[q]!=L3_MINI_CELL_WALL&&floor[q]!=L3_MINI_CELL_PELLET&&floor[q]!=L3_MINI_CELL_POWER)return 0;
 if(trace)for(unsigned i=0;i<trace->event_count;i++){
  const L3MazeEvent *v=trace->events+i;
  if(v->x>=20||v->y>=20||v->kind<L3_MAZE_COLLECT||v->kind>L3_MAZE_CONTACT_LOST)return 0;
  if(v->kind==L3_MAZE_COLLECT&&(v->detail<2||v->detail>3||floor[v->y*20+v->x]!=L3_MINI_CELL_EMPTY))return 0;
 }
 if(!e->valid||e->epoch!=epoch){l3_maze_events_reset(e);e->valid=1;e->epoch=epoch;}
 memcpy(e->floor,floor,sizeof e->floor);e->time=now;
 for(unsigned q=0;q<400;q++)if(e->until[q]<=now)e->pending[q]=0;
 if(trace)for(unsigned i=0;i<trace->event_count;i++){
  const L3MazeEvent *v=trace->events+i;
  if(v->kind!=L3_MAZE_COLLECT&&v->kind!=L3_MAZE_CONTACT_DEATH&&v->kind!=L3_MAZE_CONTACT_LOST)continue;
  unsigned q=v->y*20+v->x;double arrival=now;const L3MazeTrack *t=&m->actor[0];
  for(unsigned n=0;n<t->count;n++){
   const L3MazeSegment *s=&t->segments[(t->head+n)%L3_MAZE_SEGMENTS];
   if(s->x1==v->x*256u+128&&s->y1==v->y*256u+128&&s->end>arrival)arrival=s->end;
  }
  if(v->kind!=L3_MAZE_COLLECT){
   if(arrival>now)for(unsigned n=0;n<3;n++)if(e->life_until[n]<=now){e->life_until[n]=arrival;break;}
   continue;
  }
  e->collections++;
  if(arrival>now){e->pending[q]=(uint8_t)(v->detail==3?L3_MINI_CELL_POWER:L3_MINI_CELL_PELLET);e->until[q]=arrival;e->deferred++;}
  else e->fallbacks++; /* A reset/multi-move discontinuity has no traversed segment. */
 }
 return 1;
}
int l3_maze_events_sample(const L3MazeEvents *e,double now,uint8_t floor[400]){
 if(!e||!e->valid||!floor||!isfinite(now)||now<e->time)return 0;
 memcpy(floor,e->floor,sizeof e->floor);
 for(unsigned q=0;q<400;q++)if(e->pending[q]&&now<e->until[q])floor[q]=e->pending[q];
 return 1;
}
int l3_maze_events_pending(const L3MazeEvents *e,double now,unsigned *count){
 if(!e||!e->valid||!count||!isfinite(now)||now<e->time)return 0;
 unsigned n=0;for(unsigned q=0;q<400;q++)n+=e->pending[q]&&now<e->until[q];
 *count=n;return 1;
}
int l3_maze_events_pending_lives(const L3MazeEvents *e,double now,unsigned *count){
 if(!e||!e->valid||!count||!isfinite(now)||now<e->time)return 0;
 unsigned n=0;for(unsigned i=0;i<3;i++)n+=now<e->life_until[i];*count=n;return 1;
}
