#include "luma3d_sky_assets.h"
#include "sky_art.h"
/* sky_art.h is an unchanged, traced resource archive. This translation unit
 * is its sole owner, avoiding a 264 KiB duplicate in each consumer. */
_Static_assert(sizeof sky_texture + sizeof sky_vertices + sizeof sky_faces <
               (1u << 19), "Sky reservation overlaps hero atlas");
_Static_assert(sizeof sky_texture == 512u * 256u * 2u, "Sky ARGB4444 extent");
_Static_assert(sizeof sky_vertices == SKY_VERTEX_COUNT * 32u, "Sky vertices");
_Static_assert(sizeof sky_faces == SKY_FACE_COUNT * 32u, "Sky faces");
const L3SkyAssets l3_sky_assets = {
    sky_texture, sky_vertices, sky_faces,
    sizeof sky_texture, sizeof sky_vertices, sizeof sky_faces,
    SKY_VERTEX_COUNT, SKY_FACE_COUNT
};
