#define _POSIX_C_SOURCE 200809L
#include "l3_table_progress.h"
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
static uint32_t get32(const uint8_t *p){return p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static void put32(uint8_t *p,uint32_t v){for(unsigned i=0;i<4;i++)p[i]=(uint8_t)(v>>(i*8));}
static int32_t gets32(const uint8_t *p){uint32_t v=get32(p);return (int32_t)(v<0x80000000u?(int64_t)v:(int64_t)v-4294967296LL);}
static uint32_t crc(const uint8_t *p,size_t n){uint32_t c=~0u;while(n--){c^=*p++;for(unsigned i=0;i<8;i++)c=(c>>1)^(0xedb88320u&-(c&1));}return ~c;}
int l3_table_progress_validate(const L3TableProgress *p){
    if(!p||p->visited>15||p->won>15||(p->won&~p->visited)||p->kind>4||p->map>1||p->x_mm< -14000||p->x_mm>14000||p->z_mm< -14000||p->z_mm>14000)return 0;
    if(p->kind<4&&!(p->visited&(1u<<p->kind)))return 0;
    for(unsigned i=0;i<4;i++)if(p->games[i].kind!=i||!l3_table_validate(&p->games[i])||(p->games[i].status==L3_TABLE_WON&&!(p->won&(1u<<i))))return 0;
    return 1;
}
int l3_table_progress_init(L3TableProgress *p,uint32_t seed){
    if(!p)return 0;L3TableProgress n;memset(&n,0,sizeof n);n.kind=4;n.z_mm=13000;
    for(unsigned i=0;i<4;i++)if(!l3_table_init(&n.games[i],i,seed+31u*i))return 0;
    *p=n;return 1;
}
size_t l3_table_progress_encode(const L3TableProgress *p,void *output,size_t capacity){
    if(!l3_table_progress_validate(p))return 0;
    size_t n=40;for(unsigned i=0;i<4;i++)n+=8+l3_table_encode(&p->games[i],0,0);
    if(n>L3_TABLE_PROGRESS_MAX)return 0;if(!output)return n;if(capacity<n)return 0;
    uint8_t *b=output;memset(b,0,n);put32(b,0x3150544cu);put32(b+4,1);put32(b+8,(uint32_t)n);
    put32(b+16,p->visited);put32(b+20,p->won);put32(b+24,p->kind);put32(b+28,p->map);put32(b+32,(uint32_t)p->x_mm);put32(b+36,(uint32_t)p->z_mm);
    size_t at=40;for(unsigned i=0;i<4;i++){size_t len=l3_table_encode(&p->games[i],b+at+8,n-at-8);if(!len)return 0;put32(b+at,i);put32(b+at+4,(uint32_t)len);at+=8+len;}
    put32(b+12,crc(b+16,n-16));return n;
}
int l3_table_progress_decode(L3TableProgress *p,const void *input,size_t bytes){
    if(!p||!input||bytes<40||bytes>L3_TABLE_PROGRESS_MAX)return 0;const uint8_t *b=input;
    if(get32(b)!=0x3150544cu||get32(b+4)!=1||get32(b+8)!=bytes||get32(b+12)!=crc(b+16,bytes-16))return 0;
    L3TableProgress n;memset(&n,0,sizeof n);n.visited=get32(b+16);n.won=get32(b+20);n.kind=get32(b+24);n.map=get32(b+28);n.x_mm=gets32(b+32);n.z_mm=gets32(b+36);
    size_t at=40;for(unsigned i=0;i<4;i++){
        if(bytes-at<8||get32(b+at)!=i)return 0;size_t len=get32(b+at+4);at+=8;
        if(len>bytes-at||!l3_table_decode(&n.games[i],b+at,len))return 0;at+=len;
    }
    if(at!=bytes||!l3_table_progress_validate(&n))return 0;*p=n;return 1;
}
static int read_all(int fd,uint8_t *b,size_t n){
    while(n){ssize_t k=read(fd,b,n);if(k<0&&errno==EINTR)continue;if(k<=0)return 0;b+=k;n-=(size_t)k;}return 1;
}
int l3_table_progress_load(L3TableProgress *p,const char *path){
    if(!p||!path||!*path){errno=EINVAL;return 0;}
    int fd=open(path,O_RDONLY|O_CLOEXEC|O_NOFOLLOW|O_NONBLOCK);if(fd<0)return 0;
    struct stat st;uint8_t b[L3_TABLE_PROGRESS_MAX],extra;int ok=0;
    if(fstat(fd,&st)==0&&S_ISREG(st.st_mode)&&st.st_size>=40&&st.st_size<=L3_TABLE_PROGRESS_MAX){
        if(read_all(fd,b,(size_t)st.st_size)){
            ssize_t tail;do{tail=read(fd,&extra,1);}while(tail<0&&errno==EINTR);
            if(tail==0)ok=l3_table_progress_decode(p,b,(size_t)st.st_size);
        }
    }
    int saved_errno=errno;close(fd);errno=ok?0:saved_errno?saved_errno:EINVAL;return ok;
}
int l3_table_progress_save(const L3TableProgress *p,const char *path){
    uint8_t b[L3_TABLE_PROGRESS_MAX];size_t n=l3_table_progress_encode(p,b,sizeof b);
    if(!n||!path||!*path||strlen(path)>4000){errno=EINVAL;return 0;}
    struct stat st;
    if(lstat(path,&st)==0){L3TableProgress old;if(!S_ISREG(st.st_mode)||!l3_table_progress_load(&old,path)){errno=EINVAL;return 0;}}
    else if(errno!=ENOENT)return 0;
    size_t len=strlen(path);char *tmp=malloc(len+12),*dir=malloc(len+2);if(!tmp||!dir){free(tmp);free(dir);errno=ENOMEM;return 0;}
    memcpy(tmp,path,len);memcpy(tmp+len,".tmp.XXXXXX",12);strcpy(dir,path);
    char *slash=strrchr(dir,'/');if(!slash)strcpy(dir,".");else if(slash==dir)slash[1]=0;else *slash=0;
    int fd=mkstemp(tmp),ok=0,dirfd=-1;if(fd<0)goto done;
    size_t at=0;while(at<n){ssize_t k=write(fd,b+at,n-at);if(k<0&&errno==EINTR)continue;if(k<=0)goto done;at+=(size_t)k;}
    if(fsync(fd))goto done;if(close(fd)){fd=-1;goto done;}fd=-1;
    dirfd=open(dir,O_RDONLY|O_DIRECTORY|O_CLOEXEC);if(dirfd<0)goto done;
    if(rename(tmp,path))goto done;if(fsync(dirfd))goto done;ok=1;
done:;
    int saved_errno=errno;if(fd>=0)close(fd);if(dirfd>=0)close(dirfd);if(!ok)unlink(tmp);free(tmp);free(dir);errno=ok?0:saved_errno;return ok;
}
