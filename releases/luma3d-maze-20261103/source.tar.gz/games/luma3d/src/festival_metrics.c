#define _POSIX_C_SOURCE 200809L
#include "luma3d_render.h"
#include <time.h>
#include <math.h>
double l3_measure_now(void){struct timespec t;if(clock_gettime(CLOCK_MONOTONIC,&t))return NAN;return t.tv_sec+t.tv_nsec*1e-9;}
void l3_measure_publish(L3Render *r,unsigned offset,unsigned bytes,double start,unsigned atlas_end){
    if(!r->festival_metrics)return;double elapsed=l3_measure_now()-start;
    if(!isfinite(elapsed)||elapsed<0){r->festival_measure_error=1;return;}
    r->festival_publish_bytes+=bytes;r->festival_publish_seconds+=elapsed;
    if(offset>=(17u<<20)&&offset<=atlas_end&&bytes<=atlas_end-offset){r->festival_atlas_bytes+=bytes;r->festival_atlas_seconds+=elapsed;}
}
void l3_measure_loaded(L3Render *r,unsigned mode,double start,uint64_t previous_bytes,uint64_t previous_atlas,double previous_atlas_seconds){
    if(!r->festival_metrics)return;double elapsed=l3_measure_now()-start;
    if(!isfinite(elapsed)||elapsed<0){r->festival_measure_error=1;return;}
    if(r->festival_asset_generation>=16){r->festival_measure_error=1;return;}
    unsigned i=r->festival_asset_generation++;
    r->festival_asset_events[i].mode=mode;r->festival_asset_events[i].frame=r->frame;
    r->festival_asset_events[i].seconds=elapsed;r->festival_asset_events[i].bytes=r->festival_publish_bytes-previous_bytes;
    r->festival_asset_events[i].atlas_bytes=r->festival_atlas_bytes-previous_atlas;r->festival_asset_events[i].atlas_seconds=r->festival_atlas_seconds-previous_atlas_seconds;
}
