#include "luma3d_render.h"
#include "luma3d_activity_observer.h"
#include "l3_puzzle_presentation.h"
#include "l3_simon_presentation.h"
static int puzzle_view(const L3ArcadeView *v){return v&&(v->kind==L3_MINI_BLOCKS||v->kind==L3_MINI_MERGE1024);}
static void observed(void *context,const L3ArcadeView *before,const L3ArcadeView *after,uint32_t pressed,uint32_t held,const L3MiniTrace *trace,double time,uint32_t epoch){
 L3Render *r=context;(void)held;unsigned warp=trace?trace->maze_warp_mask:0;
 if(pressed&L3_ARCADE_RESTART){
  l3_maze_motion_reset(&r->maze_motion);l3_maze_events_reset(&r->maze_events);
  l3_puzzle_presentation_reset(r);l3_simon_presentation_reset(r);
  before=NULL;
 }
 if(after&&after->kind==L3_MINI_MAZE){
  L3MiniActors actors;
  if(!l3_mini_actors(&r->presentation_game->activities.arcade.base[L3_MINI_MAZE],&actors)||
     !l3_maze_motion_observe_events(&r->maze_motion,&after->content.grid,&actors,time,epoch,trace))r->failed=1;
  uint8_t floor[400];
  if(!r->failed&&(!l3_mini_maze_floor(&r->presentation_game->activities.arcade.base[L3_MINI_MAZE],floor)||!l3_maze_events_observe(&r->maze_events,&r->maze_motion,floor,trace,time,epoch)))r->failed=1;
 }else if(before&&before->kind==L3_MINI_MAZE){l3_maze_motion_reset(&r->maze_motion);l3_maze_events_reset(&r->maze_events);}
 if(puzzle_view(before)||puzzle_view(after))l3_puzzle_presentation_observe(r,before,after,pressed,held,warp,time,epoch);
 if((before&&before->kind==L3_ARCADE_SIMON)||(after&&after->kind==L3_ARCADE_SIMON))l3_simon_presentation_observe(r,before,after,pressed,held,warp,time,epoch);
}
void l3_presentation_bind(L3Render *r,const L3Game *g){
 l3_puzzle_presentation_reset(r);l3_simon_presentation_reset(r);l3_maze_motion_reset(&r->maze_motion);l3_maze_events_reset(&r->maze_events);
 r->presentation_game=g;l3_activity_observer_bind(g,255,observed,r);
}
int l3_presentation_clock(L3Render *r,double seconds,uint32_t epoch){
 if(!l3_activity_observer_clock(seconds,epoch)){r->failed=1;return 0;}
 r->presentation_seconds=seconds;r->presentation_epoch=epoch;return 1;
}
/* activity_enter may be followed by a render before the first engine step.
 * Establish its real view/epoch before baking, without discarding a queue
 * already observed during this frame's simulation steps. */
int l3_presentation_prepare(L3Render *r,const L3Game *g){
 unsigned active=g->activities.arcade.active;
 int puzzle=active==L3_MINI_BLOCKS+1||active==L3_MINI_MERGE1024+1;
 int simon=active==L3_ARCADE_SIMON+1;
 if((puzzle&&!r->puzzle_presentation)||(simon&&!r->simon_presentation))return 0;
 if(puzzle&&r->puzzle_presentation->motion.valid&&r->puzzle_presentation->motion.latest.kind==active-1&&r->puzzle_presentation->observed_epoch==r->presentation_epoch)return 1;
 if(simon&&r->simon_presentation&&r->simon_presentation->light.valid&&r->simon_presentation->epoch==r->presentation_epoch)return 1;
 if(!puzzle&&!simon)return 1;
 L3ArcadeView view;if(!l3_arcade_view(&g->activities.arcade,&view))return 0;
 if(puzzle)l3_puzzle_presentation_observe(r,NULL,&view,0,0,0,r->presentation_seconds,r->presentation_epoch);
 else l3_simon_presentation_observe(r,NULL,&view,0,0,0,r->presentation_seconds,r->presentation_epoch);
 return puzzle?r->puzzle_presentation->motion.valid:r->simon_presentation->light.valid;
}
void l3_presentation_unbind(L3Render *r){l3_activity_observer_bind(NULL,0,NULL,NULL);r->presentation_game=NULL;}
