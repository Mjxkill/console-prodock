#define _POSIX_C_SOURCE 200809L
#include "luma3d_render.h"
#include "l3_festival.h"
#include "luma3d_progress.h"
#include "luma3d_activities.h"
#include "luma3d_showcase.h"
#include "luma3d_village.h"
/* LUMA3D VILLAGE V6: --village-demo only changes this fresh run. */
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <time.h>
#include "sample_stats.h"
#include "festival_metrics.h"
#include <unistd.h>

/* Stable content identity: VAL1 / letter_01..letter_04. Bump the semantic
 * version before reinterpreting mission phases or route indices. */
static const uint32_t letter_ids[]={0x4c455431,0x4c455432,0x4c455433,0x4c455434};
static const L3ProgressSchema progress_schema={0x56414c31,7,4,letter_ids};
static volatile sig_atomic_t stop;
static void signal_stop(int n) {(void)n;stop=1;}
static double seconds(void) {struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec*1e-9;}
static int number(const char *s,unsigned *out) {char *end;errno=0;unsigned long x=strtoul(s,&end,10);if(errno||!*s||*end||x>1000000)return 0;*out=(unsigned)x;return 1;}
/* Feed real movement/input to l3_game_step; never move or mutate a site. */
static void village_demo_advance(L3VillageDemo *d,L3Game *g,float dt) {
    g->village_demo_active=d->active;
    if(!d->active){l3_game_step(g,NULL,dt);return;}
    if(l3_village_demo_done(g,d)) {
        L3Input resume={0};
        if(!g->autopilot)resume.pressed=L3_TOGGLE_AUTO;
        l3_game_step(g,&resume,dt);d->active=0;g->village_demo_active=0;return;
    }
    L3Input in={0};
    if(l3_village_demo_input(g,d,&in,dt))l3_game_step(g,&in,dt);
}
int main(int argc,char **argv) {
    int host=0,wide=0,automatic=1,benchmark=0,warmup_set=0,showcase=0,showcase_once=0,village_demo_enabled=0;
    unsigned festival_start=0,festival_game=4,sample_actions=0,memory_actions=0,festival_metrics=0,cpu_profile=0,cpu_profile_set=0;
    L3FestivalSample sample={0};L3FestivalMetrics metrics={0};
    unsigned frames=0,advance=0,warmup=3;const char *capture=NULL,*save_path=NULL,*festival_save=NULL,*memory_save=NULL;
    for(int i=1;i<argc;i++) {
        if(!strcmp(argv[i],"--host"))host=1;
        else if(!strcmp(argv[i],"--festival-metrics"))festival_metrics=1;
        else if(!strcmp(argv[i],"--festival-cpu-profile")&&i+1<argc){
            if(cpu_profile_set||!number(argv[++i],&cpu_profile)||cpu_profile>1)return 2;
            cpu_profile_set=1;
        }
        else if(!strcmp(argv[i],"--memory-sample-actions")&&i+1<argc){if(!number(argv[++i],&memory_actions)||memory_actions<1||memory_actions>128)return 2;}
        else if(!strcmp(argv[i],"--festival-save")&&i+1<argc){festival_save=argv[++i];if(!*festival_save)return 2;}
        else if(!strcmp(argv[i],"--720p"))wide=1;
        else if(!strcmp(argv[i],"--festival"))festival_start=1;
        else if(!strcmp(argv[i],"--festival-memory")){festival_start=1;festival_game=L3_FESTIVAL_MEMORY;}
        else if(!strcmp(argv[i],"--memory-save")&&i+1<argc){memory_save=argv[++i];if(!*memory_save)return 2;}
        else if(!strcmp(argv[i],"--festival-sample-actions")&&i+1<argc){if(!number(argv[++i],&sample_actions)||sample_actions<1||sample_actions>32)return 2;}
        else if(!strcmp(argv[i],"--festival-game")&&i+1<argc){festival_start=1;if(!number(argv[++i],&festival_game)||festival_game>=4)return 2;}
        else if(!strcmp(argv[i],"--village-demo"))village_demo_enabled=1;
        else if(!strcmp(argv[i],"--showcase"))showcase=1;
        else if(!strcmp(argv[i],"--showcase-once")){showcase=1;showcase_once=1;}
        else if(!strcmp(argv[i],"--manual"))automatic=0;
        else if(!strcmp(argv[i],"--benchmark"))benchmark=1;
        else if(!strcmp(argv[i],"--save")&&i+1<argc) {save_path=argv[++i];if(!*save_path)return 2;}
        else if(!strcmp(argv[i],"--warmup")&&i+1<argc) {warmup_set=1;if(!number(argv[++i],&warmup)||warmup<2)return 2;}
        else if(!strcmp(argv[i],"--frames")&&i+1<argc) {if(!number(argv[++i],&frames))return 2;}
        else if(!strcmp(argv[i],"--advance")&&i+1<argc) {if(!number(argv[++i],&advance))return 2;}
        else if(!strcmp(argv[i],"--capture")&&i+1<argc)capture=argv[++i];
        else {fprintf(stderr,"Usage: %s [--host] [--720p] [--manual] [--frames N] [--advance simulation_steps] [--capture prefix] [--benchmark --warmup N] [--save path] [--showcase | --showcase-once] [--festival | --festival-game 0..3] [--festival-save separate-path] [--festival-memory] [--memory-save independent-path] [--festival-sample-actions 1..32] [--festival-metrics] [--festival-cpu-profile 0|1] [--memory-sample-actions 1..128] [--village-demo]\n",argv[0]);return 2;}
    }
    if(memory_save&&((save_path&&!strcmp(memory_save,save_path))||(festival_save&&!strcmp(memory_save,festival_save)))){fputs("Memory requires a distinct save path\n",stderr);return 2;}
    if(festival_start&&(showcase||benchmark)){fputs("Festival requires its own non-benchmark tour\n",stderr);return 2;}
    if(village_demo_enabled&&(festival_start||showcase||benchmark||!automatic||save_path||festival_save||memory_save)){fputs("Village demo requires a fresh automatic tour without festival, showcase, save, manual or benchmark\n",stderr);return 2;}
    if(showcase&&(save_path||benchmark||!automatic||(!host&&advance))) {fputs("Showcase starts a separate fresh game, without save, benchmark, manual or hardware fast-forward\n",stderr);return 2;}
    if(benchmark&&save_path) {fputs("Save is unavailable in benchmark mode\n",stderr);return 2;}
    if((benchmark&&!frames)||(warmup_set&&!benchmark)||(benchmark&&capture)) {fputs("Benchmark requires --frames N; --warmup requires benchmark, without capture\n",stderr);return 2;}
    if(sample_actions&&(!festival_start||festival_game>=4||!automatic||showcase||benchmark||advance||capture||save_path||festival_save||memory_save)) {fputs("Animation sample requires an automatic fresh --festival-game, without save/capture/advance/benchmark\n",stderr);return 2;}
    if(memory_actions&&(!festival_start||festival_game!=L3_FESTIVAL_MEMORY||!automatic||sample_actions||showcase||benchmark||advance||capture||save_path||festival_save||memory_save)){fputs("Memory sample requires fresh automatic --festival-memory without save/capture/advance/benchmark\n",stderr);return 2;}
    if(festival_metrics&&(!festival_start||showcase||benchmark||advance||capture||save_path||festival_save||memory_save)){fputs("Festival metrics require fresh scene without save/capture/advance/benchmark\n",stderr);return 2;}
    if((sample_actions||memory_actions)&&!frames)frames=3600;
    festival_metrics=festival_metrics||memory_actions||sample_actions;
    if(cpu_profile_set&&(!festival_start||!festival_metrics)){
        fputs("CPU profile requires a fresh festival metrics run\n",stderr);return 2;
    }
    if(host&&!frames)frames=1;
    if(capture&&(!host||frames!=1)) {fputs("Capture requires --host --frames 1\n",stderr);return 2;}
    L3World world;L3Game game;L3Render renderer;l3_world_init(&world);
    if(!l3_game_init(&game,&world,automatic)) {fputs("Invalid world\n",stderr);return 1;}
    if(save_path) {
        errno=0;int loaded=l3_progress_read(save_path,&game,&progress_schema);
        if(loaded==L3_PROGRESS_OK) {puts("LUMA3D_SAVE loaded");fflush(stdout);}
        else if(loaded==L3_PROGRESS_IO&&errno==ENOENT) {
            if(l3_progress_write(save_path,&game,&progress_schema)!=L3_PROGRESS_OK) {perror("Cannot create save");return 1;}
            puts("LUMA3D_SAVE created");fflush(stdout);
        } else {fputs("Save invalid, incompatible or unreadable; file preserved\n",stderr);return 1;}
    }
    double festival_last_save=0,memory_last_save=0;
    L3Festival *festival=l3_festival_create(automatic);if(!festival)return 1;
    festival->cpu_profile_enabled=cpu_profile;
    festival->sample_limit=sample_actions;festival->memory_sample_limit=memory_actions;
    if(festival_start)l3_festival_enter(festival,festival_game);
    if(festival_save){
        if(save_path&&!strcmp(save_path,festival_save)){fputs("Separate save paths required\n",stderr);l3_festival_destroy(festival);return 2;}
        int active=festival->active;errno=0;
        if(!l3_festival_load(festival,festival_save)){
            if(errno!=ENOENT||!l3_festival_save(festival,festival_save)){fputs("Festival save invalid or unavailable; file preserved\n",stderr);l3_festival_destroy(festival);return 1;}
        }
        festival->active=active;
    }
    if(memory_save){
        errno=0;if(!l3_festival_memory_load(festival,memory_save)){
            if(errno!=ENOENT||!l3_festival_memory_save(festival,memory_save)){fputs("Memory save invalid or unavailable; file preserved\n",stderr);l3_festival_destroy(festival);return 1;}
        }
    }
    if(festival_start&&festival_game==L3_FESTIVAL_MEMORY)l3_festival_enter(festival,L3_FESTIVAL_MEMORY);
    L3Showcase tour={0};L3VillageDemo village_demo={0};
    if(village_demo_enabled){l3_village_demo_init(&village_demo);game.village_demo_active=1;}
    if(showcase)l3_showcase_init(&tour,&game,showcase_once);
    for(unsigned i=0;i<advance;i++) {
        if(festival->active)l3_festival_step(festival,1.0f/60);
        else if(showcase) {l3_showcase_step(&tour,&game,1.0f/60);if(!(i%10))l3_showcase_presented(&tour);}
        else if(village_demo_enabled)village_demo_advance(&village_demo,&game,1.0f/60);
        else l3_game_step(&game,NULL,1.0f/60);
    }
    if(showcase&&advance)printf("LUMA3D_SHOWCASE_FIXTURE advance=%u simulated_present_every=10 actual_rendering=0\n",advance);
    if(showcase) {printf("LUMA3D_SHOWCASE_START stage=%u simulated=%.3f once=%d saves=disabled\n",tour.stage,tour.elapsed,showcase_once);fflush(stdout);}
    double graphics_start=seconds();
    if(!l3_render_open(&renderer,host,wide)) {fputs("GPU initialization failed; G3D1 Linux candidate required\n",stderr);l3_render_close(&renderer);return 1;}
    renderer.festival=festival;renderer.festival_metrics=festival_metrics;
    l3_presentation_bind(&renderer,&game);
    if(!l3_presentation_clock(&renderer,0,1)){l3_render_close(&renderer);return 1;}
    double simulation_clock=0;
    printf("LUMA3D_GRAPHICS_READY seconds=%.6f base_art_loaded=1 scene_resources_pending=%u hardware=%d\n",seconds()-graphics_start,festival_start,!host);fflush(stdout);
    char path[1024];
    if(capture) {
        if(snprintf(path,sizeof(path),"%s.commands",capture)>=(int)sizeof(path)) {l3_render_close(&renderer);return 1;}
        renderer.capture=fopen(path,"wb");if(!renderer.capture) {perror(path);l3_render_close(&renderer);return 1;}
    }
    signal(SIGINT,signal_stop);signal(SIGTERM,signal_stop);
    struct termios saved,raw;int terminal=!host&&!benchmark&&isatty(STDIN_FILENO)&&!tcgetattr(STDIN_FILENO,&saved);
    int stdin_flags=-1;
    if(terminal) {raw=saved;raw.c_lflag&=~(ICANON|ECHO);raw.c_cc[VMIN]=raw.c_cc[VTIME]=0;
        if(tcsetattr(STDIN_FILENO,TCSANOW,&raw))terminal=0;
        else {stdin_flags=fcntl(STDIN_FILENO,F_GETFL);if(stdin_flags>=0)fcntl(STDIN_FILENO,F_SETFL,stdin_flags|O_NONBLOCK);}}
    puts("LUMA3D — Le Val des Courriers. WASD move, IUKL camera, J journal, space jump, E interact, T auto, N new garden, Q quit.");fflush(stdout);
    double start=seconds(),previous=start,accumulator=0,held_until=0,look_until=0,mini_until=0,report=start;
    double tour_started=start;unsigned tour_stage=tour.stage,tour_status=tour.status,tour_loops=tour.loops;
    double last_save=start;unsigned saved_revision=game.story.revision;
    unsigned report_frames=0,report_commands=0;int escape_state=0;L3Input input={0};int ok=1;
    struct prodock_geometry_info previous_gpu=renderer.initial_geometry;
    struct prodock_display_info previous_display=renderer.initial;
    struct prodock_geometry_info benchmark_gpu=renderer.initial_geometry;
    struct prodock_display_info benchmark_display=renderer.initial;
    uint64_t geometry_cycles_total=0;
    unsigned measured_frame=0,measured_commands=0,measured_batches=0;
    double measured_feed=0,measured_present=0;
    struct {unsigned frames,slow_frames,histogram[256],max_sprites,max_layers,max_draws;unsigned long long bytes,commands,batches,triangles;
        double sim,prepare,feed,present,adviser,max_frame,frame_sum,ui_raster,ui_publish;unsigned long long ui_scan,ui_restore;unsigned ui_updates,ui_chrome;} activity_cost[9]={{0}};
    double last_frame_done=start;
    if(benchmark) {printf("LUMA3D_BENCHMARK pose=%u warmup=%u measured_frames=%u fixed_pose=1 hardware=%d\n",advance,warmup,frames,!host);fflush(stdout);}
    while(!stop&&(!frames||renderer.frame<frames+(benchmark?warmup:0))) {
        if(benchmark&&renderer.frame==warmup) {
            /* Both pages and the sky cache have been exercised. Start the
             * measurement after counter reads; keep this exact pose frozen. */
            if(!host&&(ioctl(renderer.fd,PRODOCK_GEOMETRY_INFO,&previous_gpu)||ioctl(renderer.display,PRODOCK_DISPLAY_INFO,&previous_display))) {perror("LUMA3D benchmark counters");ok=0;break;}
            benchmark_gpu=previous_gpu;benchmark_display=previous_display;
            measured_frame=report_frames=renderer.frame;
            measured_commands=report_commands=renderer.total_commands;
            measured_batches=renderer.total_flushes;
            measured_feed=renderer.feed_seconds;measured_present=renderer.present_seconds;
            geometry_cycles_total=0;
            memset(activity_cost,0,sizeof(activity_cost));
            start=previous=report=last_frame_done=seconds();
        }
        double now=seconds(),dt=now-previous;previous=now;
        if(terminal) {
            unsigned char bytes[64];ssize_t n=read(STDIN_FILENO,bytes,sizeof(bytes));
            for(ssize_t j=0;j<n;j++) {
                int c=bytes[j];
                if(sample_actions||memory_actions)continue; /* Diagnostic remains deterministic; signals still stop it. */
                if(festival->active){l3_festival_key(&renderer,festival,c);memset(&input,0,sizeof(input));continue;}
                if((c=='n'||c=='N')&&!game.activities.arcade.active){
                    if(tour.status)l3_showcase_cancel(&tour,&game);
                    festival->automatic=0;l3_festival_enter(festival,4);memset(&input,0,sizeof(input));continue;
                }
                if(tour.status) {
                    /* The first recognized key takes control without also
                     * answering a puzzle or rotating a mechanism. */
                    if(c=='q'||c=='Q'){stop=1;continue;}
                    if(c==27||strchr("eEwWaAsSdDiIuUkKlLjJtTfFrR ",c)) {
                        l3_showcase_cancel(&tour,&game);memset(&input,0,sizeof(input));escape_state=0;
                        puts("LUMA3D_SHOWCASE_MANUAL control_returned=1 saves=disabled");fflush(stdout);
                        break;
                    }
                }
                if(game.activities.arcade.active){
                    unsigned button=0;
                    if(c==27){escape_state=1;continue;}
                    if(escape_state==1&&c=='['){escape_state=2;continue;}
                    if(escape_state==2){button=c=='A'?L3_MINI_UP:c=='B'?L3_MINI_DOWN:c=='C'?L3_MINI_RIGHT:c=='D'?L3_MINI_LEFT:0;escape_state=0;}
                    else button=c=='w'||c=='W'?L3_MINI_UP:c=='s'||c=='S'?L3_MINI_DOWN:c=='a'||c=='A'?L3_MINI_LEFT:c=='d'||c=='D'?L3_MINI_RIGHT:c=='e'||c=='E'||c==' '?L3_MINI_ACT:c=='f'||c=='F'?L3_MINI_ROTATE:c=='r'||c=='R'?L3_MINI_RESTART:c=='q'||c=='Q'?L3_MINI_BACK:0;
                    input.mini_pressed|=button;
                    if(game.activities.arcade.active>=L3_ARCADE_SHOOTER+1&&(button&(L3_MINI_UP|L3_MINI_DOWN|L3_MINI_LEFT|L3_MINI_RIGHT|L3_MINI_ACT))){
                        unsigned axis=(button&(L3_MINI_UP|L3_MINI_DOWN))?(L3_MINI_UP|L3_MINI_DOWN):(button&(L3_MINI_LEFT|L3_MINI_RIGHT))?(L3_MINI_LEFT|L3_MINI_RIGHT):L3_MINI_ACT;
                        input.mini_held=(input.mini_held&~axis)|button;mini_until=now+.16;
                    }
                    continue;
                }
                if(c=='q'||c=='Q')stop=1;
                else if(c=='t'||c=='T')input.pressed|=L3_TOGGLE_AUTO;
                else if(c==' ')input.pressed|=L3_JUMP;
                else if(c=='e'||c=='E')input.pressed|=L3_INTERACT;
                else if(c=='j'||c=='J')input.pressed|=L3_JOURNAL;
                else if(c=='i'||c=='u'||c=='k'||c=='l') {
                    input.look_x=c=='u'?-1:c=='l'?1:0;
                    input.look_y=c=='i'?-1:c=='k'?1:0;look_until=now+.16;
                }
                else if(c=='w'||c=='W'||c=='s'||c=='S'||c=='a'||c=='A'||c=='d'||c=='D') {
                    input.move_x=(c=='a'||c=='A')?-1:(c=='d'||c=='D')?1:0;
                    input.move_z=(c=='w'||c=='W')?1:(c=='s'||c=='S')?-1:0;held_until=now+.16;
                    input.held=c>='A'&&c<='Z'?L3_SPRINT:0;
                }
            }
            if(now>mini_until||!game.activities.arcade.active)input.mini_held=0;
            if(now>held_until) {input.move_x=input.move_z=0;input.held=0;}
            if(now>look_until)input.look_x=input.look_y=0;
        }
        double sim_started=seconds(),adviser_started=tour.adviser_seconds;
        if(benchmark) { /* Deliberately no game/camera/animation advancement. */ }
        else if(tour.status&&renderer.frame==0) { /* Publish the exact initial state before accepting elapsed time. */ }
        else if(host) {if(renderer.frame){simulation_clock+=1.0/60;if(!l3_presentation_clock(&renderer,simulation_clock,1)){ok=0;break;}if(festival->active)l3_festival_step(festival,1.0f/60);else if(tour.status)l3_showcase_step(&tour,&game,1.0f/60);else if(village_demo_enabled)village_demo_advance(&village_demo,&game,1.0f/60);else l3_game_step(&game,&input,1.0f/60);}}
        else {
            if(dt>.25)dt=.25;accumulator+=dt;
            while(accumulator>=1.0/60) {simulation_clock+=1.0/60;if(!l3_presentation_clock(&renderer,simulation_clock,1)){ok=0;break;}if(festival->active)l3_festival_step(festival,1.0f/60);else if(tour.status)l3_showcase_step(&tour,&game,1.0f/60);else if(village_demo_enabled)village_demo_advance(&village_demo,&game,1.0f/60);else l3_game_step(&game,&input,1.0f/60);input.pressed=0;input.mini_pressed=0;accumulator-=1.0/60;}
        }
        if(!ok||!l3_presentation_clock(&renderer,simulation_clock+accumulator,1)){ok=0;break;}
        if(memory_save&&festival->active&&festival->kind==L3_FESTIVAL_MEMORY&&now-memory_last_save>=5){if(!l3_festival_memory_save(festival,memory_save)){ok=0;break;}memory_last_save=now;}
        if(festival_save&&festival->active&&now-festival_last_save>=5){if(!l3_festival_save(festival,festival_save)){ok=0;break;}festival_last_save=now;}
        if(save_path&&((game.story.revision!=saved_revision&&now-last_save>=2)||now-last_save>=15)) {
            if(l3_progress_write(save_path,&game,&progress_schema)!=L3_PROGRESS_OK) {fputs("Save failed; previous file preserved if replacement did not complete\n",stderr);ok=0;break;}
            last_save=now;saved_revision=game.story.revision;
        }
        if(tour.status==1&&now-tour_started>3600) {
            tour.status=game.showcase_status=3;game.story.revision++;game.activities.revision++;
            fputs("LUMA3D_SHOWCASE_TIMEOUT wall_limit=3600\n",stderr);
        }
        double sim_elapsed=seconds()-sim_started,render_started=seconds();
        double feed_before=renderer.feed_seconds,present_before=renderer.present_seconds;
        unsigned bytes_before=renderer.mini_bytes,mode_cost=game.activities.arcade.active;
        double raster_before=renderer.mini_raster_seconds,publish_before=renderer.mini_publish_seconds;
        uint64_t scan_before=renderer.mini_scan_bytes,restore_before=renderer.mini_restore_bytes;
        unsigned raster_updates=renderer.mini_rasterizations,chrome_before=renderer.mini_chrome_rebuilds;
        unsigned commands_before=renderer.total_commands,batches_before=renderer.total_flushes;
        unsigned metrics_phase=festival_metrics?l3_metrics_phase(festival,renderer.frame&1):0,metrics_page=renderer.frame&1,metrics_frame=renderer.frame;
        uint64_t metrics_bytes=renderer.festival_publish_bytes;double metrics_publish=renderer.festival_publish_seconds;
        if(!l3_render_frame(&renderer,&game)) {ok=0;break;}
        double frame_done=seconds(),feed_delta=renderer.feed_seconds-feed_before,present_delta=renderer.present_seconds-present_before;
        if(mode_cost<9){
            activity_cost[mode_cost].frames++;
            activity_cost[mode_cost].ui_raster+=renderer.mini_raster_seconds-raster_before;
            activity_cost[mode_cost].ui_publish+=renderer.mini_publish_seconds-publish_before;
            activity_cost[mode_cost].ui_scan+=renderer.mini_scan_bytes-scan_before;
            activity_cost[mode_cost].ui_restore+=renderer.mini_restore_bytes-restore_before;
            activity_cost[mode_cost].ui_updates+=renderer.mini_rasterizations-raster_updates;
            activity_cost[mode_cost].ui_chrome+=renderer.mini_chrome_rebuilds-chrome_before;
            activity_cost[mode_cost].sim+=sim_elapsed;
            activity_cost[mode_cost].adviser+=tour.adviser_seconds>=adviser_started?tour.adviser_seconds-adviser_started:0;
            activity_cost[mode_cost].prepare+=frame_done-render_started-feed_delta-present_delta;
            activity_cost[mode_cost].feed+=feed_delta;activity_cost[mode_cost].present+=present_delta;
            activity_cost[mode_cost].bytes+=(uint32_t)(renderer.mini_bytes-bytes_before);
            activity_cost[mode_cost].commands+=renderer.total_commands-commands_before;
            activity_cost[mode_cost].batches+=renderer.total_flushes-batches_before;
            activity_cost[mode_cost].triangles+=renderer.triangles;
            if(renderer.sprite_count>activity_cost[mode_cost].max_sprites)activity_cost[mode_cost].max_sprites=renderer.sprite_count;
            if(renderer.draws>activity_cost[mode_cost].max_draws)activity_cost[mode_cost].max_draws=renderer.draws;
            unsigned layers=0;for(unsigned layer=0;layer<12;layer++)layers+=!!(renderer.last_scene.layers[layer][6]&1);
            if(layers>activity_cost[mode_cost].max_layers)activity_cost[mode_cost].max_layers=layers;
            /* Completion-to-completion intervals include normal log/input work.
             * Histogram bins are4ms; final bin is overflow, reported explicitly.
             * All static artwork was loaded separately before the first frame. */
            double frame=frame_done-last_frame_done;
            unsigned bin=frame>=1.02?255:(unsigned)(frame*250);
            activity_cost[mode_cost].histogram[bin]++;activity_cost[mode_cost].frame_sum+=frame;
            if(frame>1.0/30)activity_cost[mode_cost].slow_frames++;
            if(frame>activity_cost[mode_cost].max_frame)activity_cost[mode_cost].max_frame=frame;
        }
        if(sample_actions)l3_sample_observe(&sample,festival,frame_done-last_frame_done,renderer.total_commands-commands_before);
        if(festival_metrics)l3_metrics_observe(&metrics,festival,metrics_phase,metrics_frame,metrics_page,frame_done-last_frame_done,sim_elapsed,frame_done-render_started-feed_delta-present_delta,feed_delta,present_delta,renderer.total_commands-commands_before,renderer.total_flushes-batches_before,renderer.festival_publish_bytes-metrics_bytes,renderer.festival_publish_seconds-metrics_publish);
        last_frame_done=frame_done;
        if(memory_actions&&(metrics.complete||seconds()-start>60))break;
        if(sample_actions&&(sample.complete||seconds()-start>60))break;
        if(tour.status)l3_showcase_presented(&tour);
        if(tour.stage!=tour_stage||tour.status!=tour_status||tour.loops!=tour_loops) {
            printf("LUMA3D_SHOWCASE stage=%u status=%u loops=%u simulated=%.3f wall=%.3f visited=%02x won=%02x commands=%u title=%s\n",tour.stage,tour.status,tour.loops,tour.elapsed,seconds()-tour_started,tour.visited,tour.won,tour.commands,l3_showcase_title(tour.stage));fflush(stdout);
            if(tour.loops!=tour_loops&&tour.status==1)tour_started=seconds();
            tour_stage=tour.stage;tour_status=tour.status;tour_loops=tour.loops;
        }
        if(showcase_once&&(tour.status==2||tour.status==3)){if(tour.status==3)ok=0;break;}
        double finished=seconds();
        if(!host&&(!benchmark||measured_frame)&&finished-report>=5) {
            printf("LUMA3D_PERF fps=%.2f cmd_s=%.0f draws=%u triangles_in=%u objects=%u collected=%u/4 auto=%d sim=%.2f\n",(renderer.frame-report_frames)/(finished-report),(renderer.total_commands-report_commands)/(finished-report),renderer.draws,renderer.triangles,renderer.instances,game.collected_count,game.autopilot,game.time);fflush(stdout);
            report_frames=renderer.frame;report_commands=renderer.total_commands;report=finished;
            struct prodock_geometry_info gpu;struct prodock_display_info display;
            if(ioctl(renderer.fd,PRODOCK_GEOMETRY_INFO,&gpu)||ioctl(renderer.display,PRODOCK_DISPLAY_INFO,&display)) {perror("LUMA3D counters");ok=0;break;}
            uint32_t cycles=gpu.cycles-previous_gpu.cycles;geometry_cycles_total+=cycles;
            printf("LUMA3D_WINDOW cycles=%u cycles_accumulated=%llu vertices=%u raster_triangles=%u culled=%u intersections=%u slivers=%u feed_us=%u wait_us=%u cache_us=%u present_us=%u\n",cycles,(unsigned long long)geometry_cycles_total,gpu.vertices-previous_gpu.vertices,gpu.triangles-previous_gpu.triangles,gpu.culled-previous_gpu.culled,gpu.intersections-previous_gpu.intersections,gpu.slivers-previous_gpu.slivers,display.feed_us-previous_display.feed_us,display.wait_us-previous_display.wait_us,display.cache_us-previous_display.cache_us,display.present_us-previous_display.present_us);fflush(stdout);
            previous_gpu=gpu;previous_display=display;
        }
    }
    for(unsigned k=0;k<9;k++)if(activity_cost[k].frames){
        unsigned p95=0,p99=0,total=0;
        for(unsigned bin=0;bin<256;bin++){total+=activity_cost[k].histogram[bin];
            if(!p95&&(uint64_t)total*100>=(uint64_t)activity_cost[k].frames*95)p95=(bin+1)*4;
            if(!p99&&(uint64_t)total*100>=(uint64_t)activity_cost[k].frames*99)p99=(bin+1)*4;
        }
        printf("LUMA3D_UI_COST mode=%u raster=%.6f compare_publish=%.6f scan_bytes=%llu restore_bytes=%llu canvas_updates=%u chrome_rebuilds=%u hardware=%d\n",k,activity_cost[k].ui_raster,activity_cost[k].ui_publish,activity_cost[k].ui_scan,activity_cost[k].ui_restore,activity_cost[k].ui_updates,activity_cost[k].ui_chrome,!host);
        printf("LUMA3D_ACTIVITY_COST mode=%u frames=%u simulation=%.6f adviser=%.6f preparation=%.6f submit=%.6f present=%.6f ui_bytes=%llu commands=%llu batches=%llu triangles=%llu max_sprites=%u max_layers=%u max_draws=%u frame_sum=%.6f p95_upper_ms=%u p99_upper_ms=%u p95_overflow=%u p99_overflow=%u over_1020ms=%u over_33ms=%u max_frame=%.6f hardware=%d\n",k,activity_cost[k].frames,activity_cost[k].sim,activity_cost[k].adviser,activity_cost[k].prepare,activity_cost[k].feed,activity_cost[k].present,activity_cost[k].bytes,activity_cost[k].commands,activity_cost[k].batches,activity_cost[k].triangles,activity_cost[k].max_sprites,activity_cost[k].max_layers,activity_cost[k].max_draws,activity_cost[k].frame_sum,p95==1024?0:p95,p99==1024?0:p99,p95==1024,p99==1024,activity_cost[k].histogram[255],activity_cost[k].slow_frames,activity_cost[k].max_frame,!host);
    }
    if(showcase)printf("LUMA3D_SHOWCASE_RESULT status=%u stage=%u loops=%u simulated=%.3f wall=%.3f visited=%02x won=%02x commands=%u boss=%u checkpoint=%u crystals=%u hardware=%d\n",tour.status,tour.stage,tour.loops,tour.elapsed,seconds()-tour_started,tour.visited,tour.won,tour.commands,tour.boss_seen,tour.checkpoint_seen,tour.crystal_seen,!host);
    double elapsed=seconds()-start;
    if(benchmark&&!host&&measured_frame) {
        struct prodock_geometry_info gpu;struct prodock_display_info display;
        if(ioctl(renderer.fd,PRODOCK_GEOMETRY_INFO,&gpu)||ioctl(renderer.display,PRODOCK_DISPLAY_INFO,&display)) {perror("LUMA3D final benchmark counters");ok=0;}
        else {
            geometry_cycles_total+=(uint32_t)(gpu.cycles-previous_gpu.cycles);
            printf("LUMA3D_BENCHMARK_COUNTERS cycles=%llu vertices=%u raster_triangles=%u culled=%u intersections=%u slivers=%u feed_us=%u wait_us=%u cache_us=%u present_us=%u\n",(unsigned long long)geometry_cycles_total,gpu.vertices-benchmark_gpu.vertices,gpu.triangles-benchmark_gpu.triangles,gpu.culled-benchmark_gpu.culled,gpu.intersections-benchmark_gpu.intersections,gpu.slivers-benchmark_gpu.slivers,display.feed_us-benchmark_display.feed_us,display.wait_us-benchmark_display.wait_us,display.cache_us-benchmark_display.cache_us,display.present_us-benchmark_display.present_us);
        }
    }
    if(capture) {if(fclose(renderer.capture))ok=0;renderer.capture=NULL;if(!l3_render_dump(&renderer,capture))ok=0;}
    unsigned completed=renderer.frame-measured_frame;
    if(benchmark&&(!measured_frame||completed!=frames))ok=0;
    printf("LUMA3D_STORY phase=%u relay=%u discovered=%u collected=%u complete=%d sim=%.2f auto=%d\n",game.story.phase,game.story.relay_step,game.story.discovered,game.collected_count,game.objective_complete,game.time,game.autopilot);
    printf("LUMA3D_AMBER region=%u phase=%u point=%u intake=%u sluice=%u\n",game.story.region,game.story.amber_phase,game.story.amber_point,game.story.amber_intake,game.story.amber_sluice);
    printf("LUMA3D_WORKSHOP phase=%u mode=%u point=%u copper=%u blue=%u\n",game.story.workshop_phase,game.story.workshop_mode,game.story.workshop_point,game.story.wind_a,game.story.wind_b);
    printf("LUMA3D_GARDEN invited=%u seeds=%u reward=%u simon=%u\n",game.garden_invited,game.garden_seeds,game.garden_reward,l3_activity_won(&game,L3_ARCADE_SIMON));
    printf("LUMA3D_VILLAGE phase=%u mask=%u step=%u reward=%u demo=%d\n",game.village_phase,game.village_mask,game.village_step,game.village_reward,village_demo_enabled);
    printf("LUMA3D_RESULT frames=%u elapsed=%.3f fps=%.2f commands=%u batches=%u feed_seconds=%.3f present_seconds=%.3f draws_last=%u triangles_last=%u benchmark=%d hardware=%d warmup=%u\n",completed,elapsed,elapsed>0?completed/elapsed:0,renderer.total_commands-measured_commands,renderer.total_flushes-measured_batches,renderer.feed_seconds-measured_feed,renderer.present_seconds-measured_present,renderer.draws,renderer.triangles,benchmark,!host,benchmark?warmup:0);fflush(stdout);
    if(terminal) {tcsetattr(STDIN_FILENO,TCSANOW,&saved);if(stdin_flags>=0)fcntl(STDIN_FILENO,F_SETFL,stdin_flags);}
    if(save_path) {
        if(l3_progress_write(save_path,&game,&progress_schema)!=L3_PROGRESS_OK) {fputs("Final save failed\n",stderr);ok=0;}
        else {puts("LUMA3D_SAVE saved");fflush(stdout);}
    }
    if(sample_actions){l3_sample_report(&sample,festival,!host);if(!l3_sample_valid(&sample,festival,festival_game))ok=0;}
    if(festival_metrics){l3_metrics_report(&metrics,festival,&renderer);if(metrics.invalid||renderer.festival_measure_error)ok=0;}
    if(memory_actions&&!l3_metrics_memory_valid(&metrics,festival))ok=0;
    if(cpu_profile&&festival->profile.invalid)ok=0; /* Invalid timings are not a successful diagnostic. */
    if(festival_start)printf("LUMA3D_FESTIVAL active=%u mode=%u visited=%x won=%x time=%.3f hardware=%d\n",festival->active,festival->kind,festival->visited,festival->won,festival->time,!host);
    if(festival_save&&!l3_festival_save(festival,festival_save))ok=0;
    if(memory_save&&!l3_festival_memory_save(festival,memory_save))ok=0;
    l3_festival_destroy(festival);renderer.festival=NULL;
    if(!l3_render_close(&renderer))ok=0;return !ok;
}
