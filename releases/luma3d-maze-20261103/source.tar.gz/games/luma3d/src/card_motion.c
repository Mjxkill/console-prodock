/* Card-flight presentation: a real presentation module on the FC1 tables.
 *
 * Demonstrated problem on the frozen producer base: rules engines are
 * correct, but the old presentation only faded a newly drawn id (+12 px)
 * and enter() displayed every hand at once. This module owns the flights
 * for solitaire (kind 1) and chroma (kind 2), driven by public data only:
 *
 *   reset()  zero presentation state (called by festival reset_draw).
 *   begin()  runs on the single accepted event: it copies the really
 *            displayed poses, the previous public view and the needed
 *            trace events, then plans one flight per animated event.
 *            In deal mode no event is interpreted: the deal falls out of
 *            the first sanitized target, every departing card leaves the
 *            stock pile with departures staggered >= 15 ms.
 *   step()   advances the module age in seconds. NaN/inf/non-positive dt
 *            is ignored and leaves the module bit-identical state.
 *   apply()  receives the target positions the board computed with
 *            positions(f) and replaces them with the current flight
 *            poses. It never exceeds the caller capacity, calls without
 *            time progression are idempotent, and a settled flight
 *            leaves the target pose byte-exact (damage tests and cached
 *            rasters converge, resting frames change nothing).
 *
 * Flights: straight interpolation from.a to.b during 300 ms (contract
 * range 250-450 ms) with a light arc of 10 px (4..12) subtracted from y,
 * zero at both endpoints, so endpoints land exactly. A public flight
 * whose face changes (texture or chroma differs) turns the card on its
 * vertical axis: the width closes to 0 at the half turn and opens again
 * to the target width, so the face substitution happens on the invisible
 * edge instead of on a full-width card. The geometric center (x + w/2)
 * keeps following the same continuous travel as before, the width stays
 * nonnegative and its profile is flat in slope at both ends. Public
 * same-face moves and secret-back draws keep the plain slide (no turn).
 * A hidden flight keeps texture 52, chroma 0 and the back placeholder id
 * for the whole travel.
 *
 * Never touched from here: f->games, allocation, save format, overlay
 * damage/cache, VRAM publication, textures/GPU acceleration, logic.
 */
#include "l3_card_motion.h"
#include <math.h>
#include <string.h>

#define L3CM_DURATION .30f /* every flight: contract range is 250-450 ms */
#define L3CM_STAGGER .03f  /* deal departures: >= 15 ms apart */
#define L3CM_LIFT 10.f     /* light arc height in logical pixels */
#define L3CM_FLIP .5f      /* public flights show the arrival face here */
#define L3CM_MIN_MOVE .5f  /* below this displacement a pose is at rest */
#define L3CM_PILE_MISS .25f
#define L3CM_BACK 52       /* back-card tile shared by both engines */
#define L3CM_MAX_BACKS 12  /* positions() shows at most 12 opponent backs */
#define L3CM_ORNAMENT 1500 /* decorative markers start at this id, never fly */
#define L3CM_PI 3.14159265f /* only for the arc and the turn profile */

static unsigned cm_kind(unsigned k){return (k==1u||k==2u)?k:0u;}

/* Foundation outlines and other decorative ids (1500+) are ornaments: they
 * must stay exactly where positions() put them while real cards are dealt. */
static int cm_ornament(int id){return id>=L3CM_ORNAMENT;}

static unsigned cm_flight(const L3CardMotion *m,int id){
    for(unsigned i=0;i<m->flight_n;i++)
        if(m->flights[i].id==id)return i;
    return L3CM_FLIGHTS; /* not planned */
}

static const L3FestivalPose *cm_byid(const L3FestivalPose *v,unsigned n,int id){
    for(unsigned i=0;i<n;i++)
        if(v[i].id==id)return &v[i];
    return 0;
}

static const L3FestivalPose *cm_at(const L3FestivalPose *v,unsigned n,float x,float y){
    for(unsigned i=0;i<n;i++)
        if(fabsf(v[i].x-x)<L3CM_PILE_MISS&&fabsf(v[i].y-y)<L3CM_PILE_MISS)return &v[i];
    return 0;
}

/* Pile anchor, used only when the really displayed copy is missing (so the
 * flight still has a public, secret-free origin instead of teleporting). */
static L3FestivalPose cm_anchor(const L3CardMotion *m,float x,float y){
    L3FestivalPose p;memset(&p,0,sizeof p);
    p.texture=L3CM_BACK;p.x=x;p.y=y;
    p.w=m->kind==1?58.f:68.f; /* waste tile vs seat tile */
    p.h=m->kind==1?78.f:92.f;
    p.alpha=256.f;
    return p;
}

/* Visible back slot of a hidden seat. positions() draws only the first
 * min(count,12) backs, so an accepted move whose hand index is beyond that
 * span (e.g. index 18 in a 20-card hand) departs from the last visible back
 * rather than from the discard destination. Only the public count captured
 * in before_view is read; hidden face values are never touched. */
static unsigned cm_visible_slot(const L3CardMotion *m,unsigned player,unsigned index){
    unsigned visible=L3CM_MAX_BACKS;
    if(m->before.kind==2u&&player<4u){
        unsigned count=m->before.data.chroma.count[player];
        if(count<visible)visible=count;
    }
    if(!visible)visible=1;
    return index<visible?index:visible-1u;
}

/* Plan a flight; returns its index or L3CM_FLIGHTS when full/duplicate.
 * Ornaments never become flights, so a deal cannot move a foundation mark. */
static unsigned cm_spawn(L3CardMotion *m,int id,const L3FestivalPose *from,float delay,unsigned hidden){
    if(cm_ornament(id))return L3CM_FLIGHTS;
    if(m->flight_n>=L3CM_FLIGHTS||cm_flight(m,id)<L3CM_FLIGHTS)return L3CM_FLIGHTS;
    {
        L3CardFlight *f=&m->flights[m->flight_n++];
        memset(f,0,sizeof *f);
        f->id=id;f->from=*from;f->delay=delay;f->hidden=hidden;
        return m->flight_n-1;
    }
}

static float cm_progress(const L3CardMotion *m,const L3CardFlight *f){
    float k=(m->age-f->delay)/L3CM_DURATION;
    return k<0?0:(k>1?1:k);
}

/* Turn ramp: cm_ramp maps a turn phase u in [0,1] to a smooth 0..1 ramp.
 * R(0)=0 and R(1)=1 are exact, the slope is zero at both ends (the card
 * starts and lands without a step) and flat topped in between: the peak
 * slope is 7/6, only 17% above the mean slope 1. A steeper ramp opens
 * the card faster than the center travels, which would push the left
 * edge backwards during the opening half of the turn. */
static float cm_ramp(float u){
    float s;
    if(u<=0.f)return 0.f;
    if(u>=1.f)return 1.f;
    s=2.f*u-1.f;
    return (7.f/12.f)*(s-s*s*s*s*s*s*s/7.f+6.f/7.f);
}

/* Width of a turning card: from.w closes to 0 at the half turn (k=0.5)
 * and opens to to.w again. k is the normalized flight time in [0,1].
 * The result is never negative and never exceeds the wider endpoint. */
static float cm_turn_width(const L3CardFlight *f,float k){
    if(k<=.5f)return f->from.w*(1.f-cm_ramp(2.f*k));
    return f->to.w*cm_ramp(2.f*k-1.f);
}

/* A public flight turns only when the visible face really changes
 * (texture or chroma). Hidden flights keep the public back for the whole
 * travel, so they never turn and never read a secret value. */
static int cm_turn_face(const L3CardFlight *f){
    if(f->hidden)return 0;
    return f->from.texture!=f->to.texture||f->from.chroma!=f->to.chroma;
}

static L3FestivalPose cm_pose(const L3CardMotion *m,unsigned idx){
    const L3CardFlight *f=&m->flights[idx];
    L3FestivalPose p=f->from;
    float k=cm_progress(m,f);
    if(f->seen){
        int turn=cm_turn_face(f);
        float w=f->from.w+(f->to.w-f->from.w)*k;
        if(turn){
            w=cm_turn_width(f,k);
            /* Keep the geometric center (x + w/2) on the CM1 travel path:
             * the narrowing is symmetric around that center, so the card
             * turns about its middle while the center keeps travelling. */
            p.x=f->from.x+(f->to.x-f->from.x)*k
                +.5f*(f->from.w-w)*(1.f-k)+.5f*(f->to.w-w)*k;
        }else{
            p.x=f->from.x+(f->to.x-f->from.x)*k;
        }
        p.y=f->from.y+(f->to.y-f->from.y)*k;
        p.w=w;
        p.h=f->from.h+(f->to.h-f->from.h)*k;
        p.alpha=f->from.alpha+(f->to.alpha-f->from.alpha)*k;
        if(f->hidden){p.texture=L3CM_BACK;p.chroma=0;} /* value stays sealed */
        else if(k>=L3CM_FLIP){p.texture=f->to.texture;p.chroma=f->to.chroma;}
    }
    p.id=f->id; /* the flying pose answers for the destination id */
    p.y-=L3CM_LIFT*sinf(L3CM_PI*k); /* arc, exact at both endpoints */
    return p;
}

/* One flight per animated event of an accepted action. Event vocabulary
 * (frozen engines):
 *   solitaire: DRAW 8->7 (stock->waste, value=id drawn), waste recycle is
 *   MOVE 7->8 (value = new stock size, never a card id, hidden arrival),
 *   MOVE cols/foundations (value=id, public), REVEAL from=col index=old
 *   back row value=new face (old back id 400+col*52+row).
 *   chroma: DRAW 4->player (value=hidden card id for seats 1..3: never
 *   read; public own draw to seat 0), MOVE player->5 (discard is public,
 *   value is the visible id). */
static void cm_plan(L3CardMotion *m,const L3TableTrace *t){
    L3FestivalPose back;
    for(unsigned e=0;t&&e<t->count&&e<L3_TABLE_TRACE_MAX;e++){
        const L3TableEvent *ev=&t->events[e];
        const L3FestivalPose *o;
        int id=0,hidden=0;
        if(m->kind==1){
            if(ev->kind==L3_TABLE_EVENT_DRAW){
                if(ev->from!=8)continue;
                /* The stock card has public id 300. During a recycle it can
                 * itself be displayed mid-flight off the nominal pile spot,
                 * so its current displayed pose is found by id first. */
                o=cm_byid(m->shown,m->shown_n,300);
                if(!o)o=cm_at(m->shown,m->shown_n,100,8);
                back=cm_anchor(m,100,8);if(!o)o=&back;
                id=ev->value; /* waste is public from now on */
            }else if(ev->kind==L3_TABLE_EVENT_MOVE){
                if(ev->from==7&&ev->to==8){
                    /* A rapid recycle can interrupt the last drawn card.
                     * The top waste id is public; use its displayed position
                     * before falling back to the nominal empty pile anchor. */
                    const L3Solitaire *s=&m->before.data.solitaire;
                    o=(m->before.kind==1&&s->waste_count&&s->waste_count<=24)
                        ?cm_byid(m->shown,m->shown_n,s->waste[s->waste_count-1]):0;
                    if(!o)o=cm_at(m->shown,m->shown_n,183,8);
                    back=cm_anchor(m,183,8);if(!o)o=&back;
                    id=300;hidden=1;
                }else{
                    id=ev->value;
                    o=cm_byid(m->shown,m->shown_n,id);
                    back=cm_anchor(m,100,8);if(!o)o=&back;
                }
            }else if(ev->kind==L3_TABLE_EVENT_REVEAL){
                o=cm_byid(m->shown,m->shown_n,(int)(400+(unsigned)ev->from*52u+ev->index));
                back=cm_anchor(m,100,8);if(!o)o=&back;
                id=ev->value;
            }else continue;
        }else{
            if(ev->kind==L3_TABLE_EVENT_DRAW){
                if(ev->from!=4)continue;
                if(ev->to==0){id=ev->value;} /* own hand is public */
                else{id=(int)(400+(unsigned)ev->to*108u+ev->index);hidden=1;}
                back=cm_anchor(m,280,100);o=cm_at(m->shown,m->shown_n,280,100);
                if(!o)o=&back;
            }else if(ev->kind==L3_TABLE_EVENT_MOVE){
                if(ev->to!=5)continue;
                id=ev->value; /* discard is public: value is the visible id */
                if(ev->from==0)o=cm_byid(m->shown,m->shown_n,id);
                else{
                    unsigned slot=cm_visible_slot(m,(unsigned)ev->from,ev->index);
                    o=cm_byid(m->shown,m->shown_n,(int)(400+(unsigned)ev->from*108u+slot));
                }
                back=cm_anchor(m,420,100);if(!o)o=&back;
            }else continue;
        }
        cm_spawn(m,id,o,0,(unsigned)hidden);
    }
    m->pending=m->flight_n;
}

/* Deal mode: everything visible in the first sanitized target that is not
 * already sitting on the stock pile departs from the stock pose, departures
 * staggered by encounter order (>= 15 ms). The stock pose itself is read in
 * the sanitized target: no secret and no allocation, ids and pixels derive
 * from public data only. Foundation/ornament markers are stationary. */
static void cm_spawn_deals(L3CardMotion *m,const L3FestivalPose *t,unsigned n){
    L3FestivalPose anchor=cm_anchor(m,m->kind==1?100:280,m->kind==1?8:100);
    const L3FestivalPose *pile=cm_at(t,n,anchor.x,anchor.y);
    L3FestivalPose from=pile?*pile:anchor;
    unsigned slot=0;
    for(unsigned i=0;i<n;i++){
        if(cm_ornament(t[i].id))continue;
        if(fabsf(t[i].x-from.x)+fabsf(t[i].y-from.y)<L3CM_MIN_MOVE)continue;
        if(cm_spawn(m,t[i].id,&from,slot*L3CM_STAGGER,(unsigned)(t[i].texture==L3CM_BACK&&t[i].chroma==0))>=L3CM_FLIGHTS)return;
        slot++;
    }
}

/* One-shot diff of the previous display against the target: cards that were
 * really displayed and now sit elsewhere glide too (hand reorganizations,
 * compacting piles). Runs once per begin so a later selection shuffle can
 * never cancel or restart a running flight. */
static void cm_spawn_diff(L3CardMotion *m,const L3FestivalPose *t,unsigned n){
    for(unsigned i=0;i<m->shown_n&&m->flight_n<L3CM_FLIGHTS;i++){
        const L3FestivalPose *d;
        if(cm_ornament(m->shown[i].id))continue;
        d=cm_byid(t,n,m->shown[i].id);
        if(!d)continue;
        if(fabsf(d->x-m->shown[i].x)+fabsf(d->y-m->shown[i].y)<L3CM_MIN_MOVE)continue;
        cm_spawn(m,d->id,&m->shown[i],0,(unsigned)(d->texture==L3CM_BACK&&d->chroma==0));
    }
}

void l3_card_motion_reset(L3CardMotion *m){
    if(m)memset(m,0,sizeof *m); /* zero presentation state */
}

void l3_card_motion_begin(L3CardMotion *m,unsigned kind,const L3FestivalPose *shown,unsigned shown_n,const L3TableView *view,const L3TableTrace *trace,int deal){
    if(!m)return;
    memset(m,0,sizeof *m);
    m->kind=cm_kind(kind);
    if(!m->kind)return; /* presentation lives on card tables only */
    m->deal=deal?1u:0u;
    if(view)memcpy(&m->before,view,sizeof m->before); /* previous public view */
    m->shown_n=(shown&&shown_n<L3CM_SHOWN)?shown_n:(shown?L3CM_SHOWN:0u);
    for(unsigned i=0;i<m->shown_n;i++)m->shown[i]=shown[i];
    if(!m->deal)cm_plan(m,trace);
    m->pending=m->flight_n;
}

void l3_card_motion_step(L3CardMotion *m,float dt){
    unsigned keep;
    /* Ignored dt must not write a single byte of the module state. */
    if(!m||!(dt>0)||!isfinite(dt))return;
    m->age+=dt;
    keep=0;
    for(unsigned i=0;i<m->flight_n;i++){
        if(m->age-m->flights[i].delay>=L3CM_DURATION)continue; /* settled */
        m->flights[keep++]=m->flights[i];
    }
    m->flight_n=keep;
    m->pending=keep;
}

void l3_card_motion_apply(L3CardMotion *m,unsigned kind,L3FestivalPose *target,unsigned *count,unsigned capacity){
    unsigned i;
    if(!m||!target||!count)return;
    if(*count>capacity)*count=capacity; /* never exceed the caller array */
    if(cm_kind(kind)!=m->kind)return;
    /* At rest: no flight and no deal spawn pending, the target must stay
     * bit-identical so poses/textures/command counts change nothing. */
    if(!m->flight_n&&!m->deal)return;
    if(!m->spawned){ /* one-shot target-based spawn, idempotent */
        m->spawned=1;
        if(m->deal)cm_spawn_deals(m,target,*count);
        else cm_spawn_diff(m,target,*count);
        m->pending=m->flight_n;
    }
    for(i=0;i<m->flight_n;i++){ /* fill unseen destinations from the target */
        L3CardFlight *f=&m->flights[i];
        const L3FestivalPose *d;
        if(f->seen)continue;
        d=cm_byid(target,*count,f->id);
        if(d){f->to=*d;f->seen=1;f->hidden|=(unsigned)(d->texture==L3CM_BACK&&d->chroma==0);}
    }
    for(i=0;i<*count;i++){ /* overwrite target slots with current flight poses */
        unsigned j=cm_flight(m,target[i].id);
        const L3CardFlight *f;
        if(j>=L3CM_FLIGHTS)continue;
        f=&m->flights[j];
        if(!f->seen)continue;
        if(cm_progress(m,f)>=1)continue; /* settled flight: exact target */
        target[i]=cm_pose(m,j);
    }
}
