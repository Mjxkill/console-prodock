#include "luma3d_village.h"

#include <math.h>
#include <stdio.h>

/* Authored positions from ZONE.md. Y is never authored: it comes from the
 * same physical height callback the engine uses for walking and collision. */
static const float site_xz[L3_VILLAGE_SITE_COUNT][2] = {
    {33.390625f, 117.65625f},
    {39.125f, 113.1953125f},
    {46.5f, 110.5234375f},
    {50.0f, 109.0f}
};

/* The three short clues imply B (first breath), C (answers the first), then A
 * (the last light). Discovery order is deliberately free. */
static const unsigned correct_sequence[3] = {
    L3_VILLAGE_SITE_B, L3_VILLAGE_SITE_C, L3_VILLAGE_SITE_A
};
static const unsigned demo_discovery[3] = {
    L3_VILLAGE_SITE_C, L3_VILLAGE_SITE_A, L3_VILLAGE_SITE_B
};

static int site_pos(const L3Game *g, unsigned site, L3Vec3 *out) {
    if (!g || !out || site >= L3_VILLAGE_SITE_COUNT || !g->world.height) return 0;
    out->x = site_xz[site][0];
    out->z = site_xz[site][1];
    out->y = g->world.height(g->world.context, out->x, out->z);
    return isfinite(out->y);
}

static unsigned popcount3(unsigned mask) {
    unsigned n = 0;
    while (mask) { n += mask & 1u; mask >>= 1; }
    return n;
}

L3Vec3 l3_village_site(const L3Game *g, unsigned site) {
    L3Vec3 p = {0, 0, 0};
    if (!site_pos(g, site, &p)) p = (L3Vec3){0, 0, 0};
    return p;
}

float l3_village_reach(void) { return 2.5f; }

int l3_village_nearest(const L3Game *g, float *distance) {
    if (distance) *distance = 0;
    if (!g || !g->valid || g->story.region != 0) return -1;
    const L3Vec3 p = g->player.position;
    if (!isfinite(p.x) || !isfinite(p.y) || !isfinite(p.z)) return -1;
    int found = -1;
    float best = l3_village_reach();
    for (unsigned i = 0; i < L3_VILLAGE_SITE_COUNT; ++i) {
        L3Vec3 s;
        if (!site_pos(g, i, &s)) continue;
        const float dx = s.x - p.x, dz = s.z - p.z;
        const float d = sqrtf(dx * dx + dz * dz);
        if (!isfinite(d) || d > best) continue;
        if (fabsf(s.y - p.y) > 2.5f) continue;
        best = d;
        found = (int)i;
    }
    if (distance && found >= 0) *distance = best;
    return found;
}

int l3_village_interact(L3Game *g, unsigned site) {
    if (!g || site >= L3_VILLAGE_SITE_COUNT || g->story.region != 0) return 0;
    if (!l3_village_state_ok(g)) return 0;
    L3Vec3 p;
    if (!site_pos(g, site, &p)) return 0;
    const L3Vec3 at = g->player.position;
    const float dx = p.x - at.x, dz = p.z - at.z;
    const float reach = l3_village_reach();
    if (dx * dx + dz * dz > reach * reach) return 0;
    if (fabsf(p.y - at.y) > 2.5f) return 0;

    const unsigned phase = g->village_phase;
    if (phase == L3_VILLAGE_PHASE_DONE) return 1; /* reward already unique */

    if (site < L3_VILLAGE_SITE_D) {
        const unsigned bit = 1u << site;
        if (phase == L3_VILLAGE_PHASE_DORMANT ||
            phase == L3_VILLAGE_PHASE_EXPLORING) {
            if (g->village_mask & bit) return 1; /* duplicate: no mutation */
            g->village_phase = L3_VILLAGE_PHASE_EXPLORING;
            g->village_mask |= bit;
            if ((g->village_mask & 7u) == 7u) {
                g->village_phase = L3_VILLAGE_PHASE_AWAKE;
                g->village_step = 0;
                g->village_order[0] = g->village_order[1] =
                    g->village_order[2] = 0;
            }
            g->story.revision++;
            return 1;
        }
        if (phase == L3_VILLAGE_PHASE_AWAKE) {
            if (g->village_step >= 3) return 1; /* already unlocked */
            if (site == correct_sequence[g->village_step]) {
                g->village_order[g->village_step] = (unsigned char)site;
                g->village_step++;
                g->story.revision++;
            } else {
                g->village_step = 0;
                g->village_order[0] = g->village_order[1] =
                    g->village_order[2] = 0;
                if (g->village_wrong < L3_VILLAGE_MAX_WRONG)
                    g->village_wrong++;
                g->story.revision++;
            }
            return 1;
        }
        return 1;
    }

    /* Sanctuary: only a complete, correct sequence yields the one reward. */
    if (phase == L3_VILLAGE_PHASE_AWAKE && g->village_step == 3 &&
        !g->village_reward) {
        g->village_reward = 1;
        g->village_phase = L3_VILLAGE_PHASE_DONE;
        g->story.revision++;
    }
    return 1;
}

int l3_village_state_ok(const L3Game *g) {
    if (!g || !g->valid) return 0;
    const L3Vec3 p = g->player.position;
    if (!isfinite(p.x) || !isfinite(p.y) || !isfinite(p.z)) return 0;
    if (g->village_phase > L3_VILLAGE_PHASE_DONE) return 0;
    if (g->village_mask & ~7u) return 0;
    if (g->village_step > 3) return 0;
    if (g->village_wrong > L3_VILLAGE_MAX_WRONG) return 0;
    if (g->village_reward > 1) return 0;
    for (unsigned i = 0; i < 3; ++i)
        if (g->village_order[i] >= L3_VILLAGE_SITE_COUNT) return 0;

    switch (g->village_phase) {
    case L3_VILLAGE_PHASE_DORMANT:
        return g->village_mask == 0 && g->village_step == 0 &&
               g->village_wrong == 0 && g->village_reward == 0 &&
               g->village_order[0] == 0 && g->village_order[1] == 0 &&
               g->village_order[2] == 0;
    case L3_VILLAGE_PHASE_EXPLORING:
        if (g->village_mask == 0 || g->village_mask == 7u) return 0;
        if (g->village_step || g->village_wrong || g->village_reward) return 0;
        return g->village_order[0] == 0 && g->village_order[1] == 0 &&
               g->village_order[2] == 0;
    case L3_VILLAGE_PHASE_AWAKE:
        if (g->village_mask != 7u || g->village_reward) return 0;
        for (unsigned i = 0; i < 3; ++i) {
            const unsigned want = i < g->village_step ? correct_sequence[i] : 0;
            if (g->village_order[i] != want) return 0;
        }
        return 1;
    default: /* DONE */
        if (g->village_mask != 7u || g->village_step != 3 ||
            !g->village_reward) return 0;
        for (unsigned i = 0; i < 3; ++i)
            if (g->village_order[i] != correct_sequence[i]) return 0;
        return 1;
    }
}

int l3_village_view(const L3Game *g, L3VillageView *out) {
    if (!out || !l3_village_state_ok(g)) return 0;
    out->phase = g->village_phase;
    out->mask = g->village_mask;
    out->step = g->village_step;
    out->wrong = g->village_wrong;
    out->reward = g->village_reward;
    for (unsigned i = 0; i < 3; ++i) out->order[i] = g->village_order[i];
    return 1;
}

int l3_village_reward_available(const L3Game *g) {
    return l3_village_state_ok(g) &&
           g->village_phase == L3_VILLAGE_PHASE_AWAKE &&
           g->village_step == 3 && !g->village_reward;
}

void l3_village_reset(L3Game *g) {
    if (!g) return;
    g->village_phase = L3_VILLAGE_PHASE_DORMANT;
    g->village_mask = 0;
    g->village_step = 0;
    g->village_wrong = 0;
    g->village_reward = 0;
    g->village_order[0] = g->village_order[1] = g->village_order[2] = 0;
}

int l3_village_in_zone(const L3Game *g) {
    if (!g || g->story.region != 0) return 0;
    const L3Vec3 p = g->player.position;
    return isfinite(p.x) && isfinite(p.z) &&
           p.x >= 33.0f && p.x <= 50.0f && p.z >= 109.0f && p.z <= 118.0f;
}

const char *l3_village_objective(const L3Game *g) {
    static char text[128];
    if (!g) return "Sentier des lucioles";
    switch (g->village_phase) {
    case L3_VILLAGE_PHASE_EXPLORING:
        snprintf(text, sizeof(text), "Sentier des lucioles · échos %u/3",
                 popcount3(g->village_mask & 7u));
        return text;
    case L3_VILLAGE_PHASE_AWAKE:
        return g->village_step >= 3
                   ? "Sanctuaire prêt · E au sanctuaire"
                   : "Sentier des lucioles · suivre l'ordre des trois échos";
    case L3_VILLAGE_PHASE_DONE:
        return "Sentier des lucioles · récompense obtenue";
    default:
        return "Sentier des lucioles · explorer les trois bornes d'échos";
    }
}

const char *l3_village_prompt(const L3Game *g, unsigned site) {
    static char text[128];
    static const char *name[L3_VILLAGE_SITE_COUNT] = {"A", "B", "C", "D"};
    if (!g || site >= L3_VILLAGE_SITE_COUNT) return "E · Sentier des lucioles";
    if (site == L3_VILLAGE_SITE_D) {
        if (g->village_phase == L3_VILLAGE_PHASE_DONE)
            return "E · Sanctuaire apaisé · récompense obtenue";
        if (l3_village_reward_available(g))
            return "E · Recevoir la lumière du sanctuaire";
        return "E · Le sanctuaire attend la séquence des échos";
    }
    if (g->village_phase == L3_VILLAGE_PHASE_DONE) {
        snprintf(text, sizeof(text), "E · Écho %s · apaisé", name[site]);
    } else if (g->village_mask & (1u << site)) {
        if (g->village_phase == L3_VILLAGE_PHASE_AWAKE)
            snprintf(text, sizeof(text), "E · Écho %s · entrer dans la séquence",
                     name[site]);
        else
            snprintf(text, sizeof(text), "E · Écho %s · déjà entendu",
                     name[site]);
    } else {
        snprintf(text, sizeof(text), "E · Écouter l'écho %s", name[site]);
    }
    return text;
}

const char *l3_village_clue(unsigned site) {
    static const char *clues[L3_VILLAGE_SITE_COUNT] = {
        "Écho A · Je suis la dernière lumière : après le vent vient le repos.",
        "Écho B · J'ouvre la marche : le premier souffle sort du silence.",
        "Écho C · Je réponds au premier, avant la dernière lumière.",
        "Sanctuaire D · L'ordre se lit dans les trois bornes, pas dans tes pas."
    };
    return site < L3_VILLAGE_SITE_COUNT ? clues[site]
                                        : "Sentier des lucioles";
}

const char *l3_village_speaker(void) { return "LES ÉCHOS DU SENTIER"; }

/* Physical demo waypoints. The hamlet collider around Maelle and the two
 * gate posts near z=115 force a short detour and a pass through the gate:
 * everything is still normal L3Input movement handled by l3_game_step. */
static const float demo_detour[2] = {31.0f, 122.5f};
static const float demo_north_hub[2] = {36.0f, 115.0f};
static const float demo_gate[2] = {36.0f, 113.5f};

static int demo_steer(const L3Game *g, L3Input *in, float tx, float tz) {
    const L3Vec3 p = g->player.position;
    const float dx = tx - p.x, dz = tz - p.z;
    const float dist = sqrtf(dx * dx + dz * dz);
    if (!isfinite(dist) || dist <= 0.60f) return 1;
    const float scale = fminf(1.0f, dist / 1.5f) / dist;
    const float c = cosf(g->camera.yaw), s = sinf(g->camera.yaw);
    in->move_x = (-c * dx + s * dz) * scale;
    in->move_z = (s * dx + c * dz) * scale;
    return 0;
}

void l3_village_demo_init(L3VillageDemo *d) {
    if (!d) return;
    *d = (L3VillageDemo){0};
    d->active = 1;
}

int l3_village_demo_done(const L3Game *g, const L3VillageDemo *d) {
    return g && d && d->active && d->stage >= 4 &&
           g->village_phase == L3_VILLAGE_PHASE_DONE && g->village_reward;
}

int l3_village_demo_input(const L3Game *g, L3VillageDemo *d, L3Input *in,
                          float dt) {
    if (!g || !d || !in || !isfinite(dt) || dt <= 0) return 0;
    if (!d->active) return 0;
    *in = (L3Input){0};
    if (d->stage >= 4) return 0;
    if (d->cooldown > 0) {
        d->cooldown = fmaxf(0, d->cooldown - dt);
        return 1;
    }
    if (g->village_phase == L3_VILLAGE_PHASE_DONE) {
        /* Return through the same real gate before handing back to the
         * courier autopilot. Switching at D would aim straight through a
         * gate post toward Maelle and leave the main story stuck. */
        static const float back[][2]={{36,113.5f},{36,115},{31,122.5f},{28,126}};
        if(d->stage!=3){d->stage=3;d->leg=0;}
        if(d->leg<4){
            if(demo_steer(g,in,back[d->leg][0],back[d->leg][1]))d->leg++;
            return 1;
        }
        d->stage=4;return 0;
    }

    unsigned target = L3_VILLAGE_SITE_D;
    if (d->stage == 0) {
        if ((g->village_mask & 7u) == 7u) { d->stage = 1; return 1; }
        int next = -1;
        for (unsigned i = 0; i < 3; ++i) {
            const unsigned s = demo_discovery[i];
            if (!(g->village_mask & (1u << s))) { next = (int)s; break; }
        }
        if (next < 0) { d->stage = 1; return 1; }
        target = (unsigned)next;
    } else if (d->stage == 1) {
        if (g->village_step >= 3) { d->stage = 2; return 1; }
        target = correct_sequence[g->village_step];
    }

    if (d->target != target) { d->target = target; d->leg = 0; }
    const L3Vec3 p = g->player.position;

    /* Spawn faces Maelle's solid collider. A short north-east detour keeps
     * the demo on real terrain without touching the NPC or the quest state. */
    if (!d->passed_detour) {
        float sx = 28.0f, sz = 126.0f;
        if (g->world.route_count) { sx = g->world.route[0].x; sz = g->world.route[0].z; }
        if (hypotf(p.x - sx, p.z - sz) > 8.0f) {
            d->passed_detour = 1;
        } else {
            if (!demo_steer(g, in, demo_detour[0], demo_detour[1])) return 1;
            d->passed_detour = 1;
        }
    }

    L3Vec3 site;
    if (!site_pos(g, target, &site)) return 1;

    if (target == L3_VILLAGE_SITE_A) {
        if (d->leg == 0 && p.z < 114.2f) {
            if (demo_steer(g, in, demo_gate[0], demo_gate[1])) d->leg = 1;
        } else {
            demo_steer(g, in, site.x, site.z);
        }
    } else if (p.z < 114.2f) {
        /* Already south of the gate posts: direct approach is clear. */
        demo_steer(g, in, site.x, site.z);
    } else if (d->leg == 0) {
        if (demo_steer(g, in, demo_north_hub[0], demo_north_hub[1])) d->leg = 1;
    } else if (d->leg == 1) {
        if (demo_steer(g, in, demo_gate[0], demo_gate[1])) d->leg = 2;
    } else {
        demo_steer(g, in, site.x, site.z);
    }

    const float dx = site.x - p.x, dz = site.z - p.z;
    const float dist = sqrtf(dx * dx + dz * dz);
    if (l3_village_nearest(g, NULL) == (int)target &&
        dist <= l3_village_reach() * 0.80f) {
        d->visits |= 1u << target;
        in->pressed |= L3_INTERACT;
        d->presses++;
        d->cooldown = 0.42f;
    }
    return 1;
}
