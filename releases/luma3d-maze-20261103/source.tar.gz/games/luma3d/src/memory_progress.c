#define _POSIX_C_SOURCE 200809L
#include "memory_progress.h"
#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
static uint32_t get(const uint8_t *p){return p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static void put(uint8_t *p,uint32_t x){for(unsigned i=0;i<4;i++)p[i]=x>>(8*i);}
static uint32_t crc(const uint8_t *p,unsigned n){uint32_t c=~0u;while(n--){c^=*p++;for(unsigned i=0;i<8;i++)c=(c>>1)^(0xedb88320u&-(c&1));}return ~c;}
static int valid(const L3MemoryProgress *p){return p&&p->visited<=1&&l3_memory_validate(&p->game)&&(p->visited||(!p->game.turns&&!p->game.wins[0]&&p->game.phase==L3_MEMORY_READY));}
static int decode(L3MemoryProgress *p,const uint8_t b[152]){
 if(get(b)!=0x31504d4du||get(b+4)!=1||get(b+8)!=152||get(b+12)!=crc(b+16,136)||get(b+20))return 0;
 L3MemoryProgress n={0};n.visited=get(b+16);if(!l3_memory_decode(&n.game,b+24,128)||!valid(&n))return 0;*p=n;return 1;
}
static int io(int writing,int fd,void *data,size_t count){uint8_t *p=data;while(count){ssize_t n=writing?write(fd,p,count):read(fd,p,count);if(n<0&&errno==EINTR)continue;if(n<=0)return 0;p+=n;count-=(size_t)n;}return 1;}
int l3_memory_progress_load(L3MemoryProgress *p,const char *path){
 if(!p||!path||!*path){errno=EINVAL;return 0;}int fd=open(path,O_RDONLY|O_CLOEXEC|O_NOFOLLOW|O_NONBLOCK);if(fd<0)return 0;
 struct stat st;uint8_t b[152],extra;int ok=0;errno=0;
 if(!fstat(fd,&st)&&S_ISREG(st.st_mode)&&st.st_size==152&&io(0,fd,b,sizeof b)){
  ssize_t tail;do{tail=read(fd,&extra,1);}while(tail<0&&errno==EINTR);if(tail==0)ok=decode(p,b);
 }
 int e=errno;close(fd);errno=ok?0:e?e:EINVAL;return ok;
}
int l3_memory_progress_save(const L3MemoryProgress *p,const char *path){
 if(!valid(p)||!path||!*path||strlen(path)>4000){errno=EINVAL;return 0;}
 struct stat st;if(!lstat(path,&st)){L3MemoryProgress old;if(!S_ISREG(st.st_mode)||!l3_memory_progress_load(&old,path)){errno=EINVAL;return 0;}}else if(errno!=ENOENT)return 0;
 uint8_t b[152]={0};put(b,0x31504d4du);put(b+4,1);put(b+8,152);put(b+16,p->visited);if(l3_memory_encode(&p->game,b+24,128)!=128){errno=EINVAL;return 0;}put(b+12,crc(b+16,136));
 size_t n=strlen(path);char *tmp=malloc(n+12),*dir=malloc(n+2);if(!tmp||!dir){free(tmp);free(dir);errno=ENOMEM;return 0;}
 memcpy(tmp,path,n);memcpy(tmp+n,".tmp.XXXXXX",12);strcpy(dir,path);char *slash=strrchr(dir,'/');if(!slash)strcpy(dir,".");else if(slash==dir)slash[1]=0;else *slash=0;
 int fd=mkstemp(tmp),dfd=-1,ok=0;if(fd<0)goto done;
 if(!io(1,fd,b,sizeof b)||fsync(fd))goto done;if(close(fd)){fd=-1;goto done;}fd=-1;
 dfd=open(dir,O_RDONLY|O_DIRECTORY|O_CLOEXEC);if(dfd<0||rename(tmp,path)||fsync(dfd))goto done;ok=1;
done:;
 int e=errno;if(fd>=0)close(fd);if(dfd>=0)close(dfd);if(!ok)unlink(tmp);free(tmp);free(dir);errno=ok?0:e?e:EIO;return ok;
}
