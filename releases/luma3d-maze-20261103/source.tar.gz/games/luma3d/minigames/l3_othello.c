#include "l3_table_internal.h"
static const int dirs[8][2]={{-1,-1},{0,-1},{1,-1},{-1,0},{1,0},{-1,1},{0,1},{1,1}};
unsigned l3t_othello_flips(const L3Othello *o,unsigned turn,unsigned square,uint8_t *flips){
    if(turn>1||square>=64||o->board[square])return 0;
    unsigned total=0,own=turn+1,other=2-turn;
    for(unsigned d=0;d<8;d++){
        int x=(int)(square%8)+dirs[d][0],y=(int)(square/8)+dirs[d][1];
        uint8_t line[7];unsigned n=0;
        while(x>=0&&x<8&&y>=0&&y<8&&o->board[y*8+x]==other){line[n++]=(uint8_t)(y*8+x);x+=dirs[d][0];y+=dirs[d][1];}
        if(n&&x>=0&&x<8&&y>=0&&y<8&&o->board[y*8+x]==own){
            if(flips)memcpy(flips+total,line,n);total+=n;
        }
    }
    return total;
}
static int can_play(const L3Othello *o,unsigned turn){for(unsigned i=0;i<64;i++)if(l3t_othello_flips(o,turn,i,0))return 1;return 0;}
static unsigned winner(const L3Othello *o){unsigned a=0,b=0;for(unsigned i=0;i<64;i++){a+=o->board[i]==1;b+=o->board[i]==2;}return a>b?0:b>a?1:L3_TABLE_NONE;}
static void finish(L3TableState *s,L3TableTrace *trace){
    s->winner=winner(&s->data.othello);
    s->status=s->winner==L3_TABLE_NONE?L3_TABLE_DRAWN:s->winner==0?L3_TABLE_WON:L3_TABLE_LOST;
    l3t_event(trace,L3_TABLE_EVENT_FINISH,0,0,0,s->winner);
}
int l3t_othello_validate(const L3TableState *s){
    const L3Othello *o=&s->data.othello;unsigned occupied=0;
    if(s->turn>1||o->passes>1)return 0;
    for(unsigned i=0;i<64;i++){if(o->board[i]>2)return 0;occupied+=o->board[i]!=0;}
    if(occupied<4)return 0;
    if(o->passes&&can_play(o,s->turn^1))return 0;
    int end=!can_play(o,0)&&!can_play(o,1);
    if(!end)return s->status==L3_TABLE_RUNNING&&s->winner==L3_TABLE_NONE;
    unsigned w=winner(o),status=w==L3_TABLE_NONE?L3_TABLE_DRAWN:w==0?L3_TABLE_WON:L3_TABLE_LOST;
    return s->status==status&&s->winner==w;
}
int l3t_othello_action(L3TableState *s,L3TableAction a,L3TableTrace *trace){
    L3Othello *o=&s->data.othello;
    if(a.op==L3_TABLE_PASS){
        if(can_play(o,s->turn))return 0;
        o->passes=1;s->turn^=1;l3t_event(trace,L3_TABLE_EVENT_PASS,0,0,0,s->turn);
    }else if(a.op==L3_TABLE_PLACE){
        uint8_t flips[64];unsigned n=l3t_othello_flips(o,s->turn,a.index,flips);if(!n)return 0;
        o->board[a.index]=(uint8_t)(s->turn+1);o->passes=0;
        l3t_event(trace,L3_TABLE_EVENT_MOVE,255,a.index,0,s->turn+1);
        for(unsigned i=0;i<n;i++){o->board[flips[i]]=(uint8_t)(s->turn+1);l3t_event(trace,L3_TABLE_EVENT_FLIP,flips[i],flips[i],0,s->turn+1);}
        s->turn^=1;
    }else return 0;
    if(!can_play(o,0)&&!can_play(o,1))finish(s,trace);
    return 1;
}
int l3t_othello_advice(const L3TableState *s,L3TableAction *a){
    int best=-100000;unsigned at=64;const L3Othello *o=&s->data.othello;
    for(unsigned p=0;p<64;p++){
        unsigned n=l3t_othello_flips(o,s->turn,p,0);if(!n)continue;
        int x=(int)(p%8),y=(int)(p/8),score=(int)n*3;
        if((x==0||x==7)&&(y==0||y==7))score+=1000;
        else if(x==0||x==7||y==0||y==7)score+=25;
        const unsigned corners[4]={0,7,56,63};
        for(unsigned c=0;c<4;c++){
            int cx=(int)(corners[c]%8),cy=(int)(corners[c]/8),dx=x-cx,dy=y-cy;
            if(!o->board[corners[c]]&&dx>=-1&&dx<=1&&dy>=-1&&dy<=1)score-=120;
        }
        L3Othello next=*o;uint8_t flips[64];n=l3t_othello_flips(o,s->turn,p,flips);
        next.board[p]=(uint8_t)(s->turn+1);for(unsigned i=0;i<n;i++)next.board[flips[i]]=(uint8_t)(s->turn+1);
        unsigned mobility=0;for(unsigned q=0;q<64;q++)mobility+=l3t_othello_flips(&next,s->turn^1,q,0)!=0;
        score-=(int)mobility*4;if(score>best){best=score;at=p;}
    }
    memset(a,0,sizeof *a);a->op=at==64?L3_TABLE_PASS:L3_TABLE_PLACE;a->index=(uint8_t)(at==64?0:at);return 1;
}
