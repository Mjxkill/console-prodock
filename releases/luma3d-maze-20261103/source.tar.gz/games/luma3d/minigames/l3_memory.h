#ifndef L3_MEMORY_H
#define L3_MEMORY_H
#include <stdint.h>
#include <stddef.h>
#define L3_MEMORY_MAX 30u
#define L3_MEMORY_NONE 255u
#define L3_MEMORY_SAVE_BYTES 128u
enum {L3_MEMORY_READY,L3_MEMORY_ONE,L3_MEMORY_TWO,L3_MEMORY_WON};
enum {L3_MEMORY_FLIP=1,L3_MEMORY_RESOLVE,L3_MEMORY_NEXT};
enum {L3_MEMORY_REVEAL=1,L3_MEMORY_HIDE,L3_MEMORY_PAIR,L3_MEMORY_DEAL,L3_MEMORY_VICTORY};
typedef struct {
 uint32_t seed,rng,turns,matched,wins[3],best[3];
 uint8_t difficulty,phase,first,second,cards[30],known[30];
} L3Memory;
typedef struct {uint8_t op,index;} L3MemoryAction;
typedef struct {uint8_t kind,a,b;} L3MemoryEvent;
typedef struct {unsigned count;L3MemoryEvent events[4];} L3MemoryTrace;
typedef struct {
 unsigned count,difficulty,phase,turns,pairs,stars,unlocked;
 uint32_t matched;
 uint8_t first,second,face[30],known[30];
} L3MemoryView;
/* Pure deterministic rules. RESOLVE is explicit; the presenter owns delays.
 * The public view masks hidden faces. known[] is previously revealed memory.
 * NEXT is legal only after a completed round: 12 ->20 ->30 ->30 fresh cards.
 * Every rejected operation leaves the state byte-for-byte unchanged. */
unsigned l3_memory_count(unsigned difficulty);
int l3_memory_init(L3Memory *,uint32_t seed);
int l3_memory_validate(const L3Memory *);
int l3_memory_action(L3Memory *,L3MemoryAction,L3MemoryTrace *);
int l3_memory_view(const L3Memory *,L3MemoryView *);
int l3_memory_advice(const L3Memory *,L3MemoryAction *);
size_t l3_memory_encode(const L3Memory *,void *,size_t);
int l3_memory_decode(L3Memory *,const void *,size_t);
#endif
