#include "l3_table_internal.h"
unsigned l3_table_card_color(unsigned id){return id<100?id/25:L3_TABLE_NONE;}
unsigned l3_table_card_value(unsigned id){
    if(id>=108)return L3_TABLE_NONE;if(id>=104)return 14;if(id>=100)return 13;
    unsigned r=id%25;return r==0?0:r<=18?1+(r-1)/2:r<=20?10:r<=22?11:12;
}
static unsigned advance(const L3TableState *s,unsigned steps){return (s->turn+(s->data.chroma.direction?4-(steps%4):steps))%4;}
static void shuffle(L3TableState *s,uint8_t *cards,unsigned n){
    for(unsigned i=n;i>1;i--){unsigned j=l3t_random(s)%i;uint8_t t=cards[i-1];cards[i-1]=cards[j];cards[j]=t;}
}
void l3t_chroma_init(L3TableState *s){
    L3Chroma *p=&s->data.chroma;memset(p->hands,255,sizeof p->hands);memset(p->discard,255,108);
    for(unsigned i=0;i<108;i++)p->deck[i]=(uint8_t)i;shuffle(s,p->deck,108);p->draw_count=108;p->drawn_id=255;
    for(unsigned r=0;r<7;r++)for(unsigned player=0;player<4;player++){
        p->hands[player][p->count[player]++]=p->deck[--p->draw_count];p->deck[p->draw_count]=255;
    }
    unsigned at=0;while(l3_table_card_value(p->deck[at])>9)at++;
    unsigned last=p->draw_count-1;uint8_t top=p->deck[at];p->deck[at]=p->deck[last];p->deck[last]=255;p->draw_count--;
    p->discard[0]=top;p->discard_count=1;p->color=(uint8_t)l3_table_card_color(top);
}
static int playable(const L3Chroma *p,unsigned player,unsigned index){
    if(player>=4||index>=p->count[player])return 0;
    unsigned c=p->hands[player][index],value=l3_table_card_value(c);
    if(value==14){ /* Draw4 is legal only without another card of active color. */
        for(unsigned i=0;i<p->count[player];i++)if(l3_table_card_color(p->hands[player][i])==p->color)return 0;
        return 1;
    }
    return value==13||l3_table_card_color(c)==p->color||value==l3_table_card_value(p->discard[p->discard_count-1]);
}
static int any_play(const L3Chroma *p,unsigned player){for(unsigned i=0;i<p->count[player];i++)if(playable(p,player,i))return 1;return 0;}
static unsigned draw_card(L3TableState *s,unsigned player,L3TableTrace *trace){
    L3Chroma *p=&s->data.chroma;
    if(!p->draw_count&&p->discard_count>1){
        unsigned n=p->discard_count-1;uint8_t top=p->discard[n];memcpy(p->deck,p->discard,n);shuffle(s,p->deck,n);p->draw_count=(uint8_t)n;
        memset(p->discard,255,108);p->discard[0]=top;p->discard_count=1;
    }
    if(!p->draw_count)return 255;
    unsigned c=p->deck[--p->draw_count];p->deck[p->draw_count]=255;
    unsigned at=p->count[player]++;p->hands[player][at]=(uint8_t)c;
    l3t_event(trace,L3_TABLE_EVENT_DRAW,4,player,at,c);return c;
}
int l3t_chroma_validate(const L3TableState *s){
    const L3Chroma *p=&s->data.chroma;unsigned total=0;uint8_t seen[108]={0};
    if(s->turn>3||p->draw_count>108||p->discard_count<1||p->discard_count>108||p->color>3||p->direction>1||p->drew>1||p->passes>4)return 0;
    for(unsigned player=0;player<4;player++){
        if(p->count[player]>108)return 0;
        for(unsigned i=0;i<108;i++){
            unsigned c=p->hands[player][i];if(i>=p->count[player]){if(c!=255)return 0;continue;}
            if(c>=108||seen[c])return 0;seen[c]=1;total++;
        }
    }
    for(unsigned i=0;i<108;i++){
        unsigned c=p->deck[i];if(i<p->draw_count){if(c>=108||seen[c])return 0;seen[c]=1;total++;}else if(c!=255)return 0;
        c=p->discard[i];if(i<p->discard_count){if(c>=108||seen[c])return 0;seen[c]=1;total++;}else if(c!=255)return 0;
    }
    if(total!=108)return 0;
    unsigned top=p->discard[p->discard_count-1];if(top<100&&l3_table_card_color(top)!=p->color)return 0;
    if(!p->drew&&p->drawn_id!=255)return 0;
    if(p->drew&&p->drawn_id!=255&&(p->count[s->turn]<2||p->hands[s->turn][p->count[s->turn]-1]!=p->drawn_id))return 0;
    if(p->drew&&p->drawn_id==255&&(p->draw_count||p->discard_count!=1))return 0;
    unsigned empty=0,w=255;for(unsigned i=0;i<4;i++)if(!p->count[i]){empty++;w=i;}
    if(empty){
        unsigned v=l3_table_card_value(top),step=v==10||v==12||v==14?2:1;
        unsigned next=(w+(p->direction?4-step:step))%4;
        return empty==1&&!p->drew&&!p->passes&&s->turn==next&&s->winner==w&&s->status==(w==0?L3_TABLE_WON:L3_TABLE_LOST);
    }
    if(s->status==L3_TABLE_DRAWN){
        if(s->winner!=255||p->passes!=4||p->draw_count||p->discard_count!=1||p->drew)return 0;
        for(unsigned i=0;i<4;i++)if(any_play(p,i))return 0;return 1;
    }
    return p->passes<4&&s->status==L3_TABLE_RUNNING&&s->winner==255;
}
int l3t_chroma_action(L3TableState *s,L3TableAction a,L3TableTrace *trace){
    L3Chroma *p=&s->data.chroma;
    if(a.op==L3_TABLE_DRAW){
        if(p->drew)return 0;p->drawn_id=(uint8_t)draw_card(s,s->turn,trace);p->drew=1;return 1;
    }
    if(a.op==L3_TABLE_PASS){
        if(!p->drew)return 0;
        if(p->drawn_id==255&&!any_play(p,s->turn)){if(p->passes<4)p->passes++;}else p->passes=0;
        p->drew=0;p->drawn_id=255;s->turn=advance(s,1);l3t_event(trace,L3_TABLE_EVENT_PASS,0,0,0,s->turn);
        if(p->passes==4){int blocked=1;for(unsigned i=0;i<4;i++)blocked&=!any_play(p,i);
            if(blocked&&!p->draw_count&&p->discard_count==1){s->status=L3_TABLE_DRAWN;l3t_event(trace,L3_TABLE_EVENT_FINISH,0,0,0,255);}}
        return 1;
    }
    if(a.op!=L3_TABLE_PLAY||!playable(p,s->turn,a.index))return 0;
    unsigned c=p->hands[s->turn][a.index],value=l3_table_card_value(c),player=s->turn;
    if(p->drew&&c!=p->drawn_id)return 0;
    if(value>=13&&a.value>3)return 0;
    memmove(p->hands[player]+a.index,p->hands[player]+a.index+1,p->count[player]-a.index-1);
    p->hands[player][--p->count[player]]=255;
    p->discard[p->discard_count++]=(uint8_t)c;p->color=(uint8_t)(value>=13?a.value:l3_table_card_color(c));
    p->drew=0;p->drawn_id=255;p->passes=0;l3t_event(trace,L3_TABLE_EVENT_MOVE,player,5,a.index,c);
    if(value==11)p->direction^=1;
    unsigned next=advance(s,1);
    if(value==12||value==14){unsigned penalty=value==12?2:4;for(unsigned i=0;i<penalty;i++)draw_card(s,next,trace);}
    s->turn=advance(s,value==10||value==12||value==14?2:1);
    if(!p->count[player]){s->winner=player;s->status=player==0?L3_TABLE_WON:L3_TABLE_LOST;l3t_event(trace,L3_TABLE_EVENT_FINISH,0,0,0,player);}
    return 1;
}
int l3t_chroma_advice(const L3TableState *s,L3TableAction *a){
    const L3Chroma *p=&s->data.chroma;int best=-1;unsigned selected=0,colors[4]={0};
    for(unsigned i=0;i<p->count[s->turn];i++){unsigned color=l3_table_card_color(p->hands[s->turn][i]);if(color<4)colors[color]++;}
    for(unsigned i=0;i<p->count[s->turn];i++){
        unsigned c=p->hands[s->turn][i],v=l3_table_card_value(c);if(!playable(p,s->turn,i)||(p->drew&&c!=p->drawn_id))continue;
        int score=v>=13?5:v>=10?30:(int)v+10;
        if(c<100)score+=(int)colors[l3_table_card_color(c)]*2;
        if(score>best){best=score;selected=i;}
    }
    memset(a,0,sizeof *a);
    if(best<0){a->op=p->drew?L3_TABLE_PASS:L3_TABLE_DRAW;return 1;}
    a->op=L3_TABLE_PLAY;a->index=(uint8_t)selected;unsigned color=0;
    for(unsigned i=1;i<4;i++)if(colors[i]>colors[color])color=i;a->value=(uint8_t)color;return 1;
}
