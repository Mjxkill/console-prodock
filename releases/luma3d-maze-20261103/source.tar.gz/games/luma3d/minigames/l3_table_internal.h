#ifndef L3_TABLE_INTERNAL_H
#define L3_TABLE_INTERNAL_H
#include "l3_table.h"
#include <string.h>
uint32_t l3t_random(L3TableState *s);
void l3t_event(L3TableTrace *,unsigned kind,unsigned from,unsigned to,unsigned index,unsigned value);
int l3t_othello_validate(const L3TableState *);
int l3t_othello_action(L3TableState *,L3TableAction,L3TableTrace *);
int l3t_othello_advice(const L3TableState *,L3TableAction *);
unsigned l3t_othello_flips(const L3Othello *,unsigned turn,unsigned square,uint8_t *flips);
void l3t_solitaire_init(L3TableState *);
int l3t_solitaire_validate(const L3TableState *);
int l3t_solitaire_action(L3TableState *,L3TableAction,L3TableTrace *);
int l3t_solitaire_advice(const L3TableState *,L3TableAction *);
void l3t_chroma_init(L3TableState *);
int l3t_chroma_validate(const L3TableState *);
int l3t_chroma_action(L3TableState *,L3TableAction,L3TableTrace *);
int l3t_chroma_advice(const L3TableState *,L3TableAction *);
void l3t_hangman_init(L3TableState *);
int l3t_hangman_validate(const L3TableState *);
int l3t_hangman_action(L3TableState *,L3TableAction,L3TableTrace *);
int l3t_hangman_advice(const L3TableState *,L3TableAction *);
void l3t_hangman_view(const L3TableState *,L3TableView *);
#endif
