#include "l3_memory.h"
#include <string.h>
#include <limits.h>
unsigned l3_memory_count(unsigned level){static const unsigned counts[]={12,20,30};return level<3?counts[level]:0;}
static uint32_t random32(L3Memory *s){uint32_t x=s->rng;x^=x<<13;x^=x>>17;x^=x<<5;s->rng=x;return x;}
static unsigned bounded(L3Memory *s,unsigned n){uint32_t x,limit=(0u-n)%n;do{x=random32(s);}while(x<limit);return x%n;}
static void deal(L3Memory *s){
 unsigned n=l3_memory_count(s->difficulty);memset(s->cards,255,sizeof(s->cards));memset(s->known,255,sizeof(s->known));
 for(unsigned i=0;i<n;i++)s->cards[i]=(uint8_t)(i/2);
 for(unsigned i=n-1;i>0;i--){unsigned j=bounded(s,i+1);uint8_t t=s->cards[i];s->cards[i]=s->cards[j];s->cards[j]=t;}
 s->turns=s->matched=0;s->phase=L3_MEMORY_READY;s->first=s->second=255;
}
int l3_memory_validate(const L3Memory *s){
 if(!s||s->difficulty>2||s->phase>L3_MEMORY_WON||!s->rng)return 0;
 unsigned n=l3_memory_count(s->difficulty),counts[15]={0},matches[15]={0},pairs=0,known=0;
 if(s->matched&~((1u<<n)-1))return 0;
 for(unsigned i=0;i<30;i++){
  if(i>=n){if(s->cards[i]!=255||s->known[i]!=255)return 0;continue;}
  if(s->cards[i]>=n/2||!(s->known[i]==255||s->known[i]==s->cards[i]))return 0;
  counts[s->cards[i]]++;
  known+=s->known[i]!=255;
  if(s->matched&(1u<<i)){if(s->known[i]==255)return 0;matches[s->cards[i]]++;}
 }
 for(unsigned i=0;i<n/2;i++){if(counts[i]!=2||matches[i]==1)return 0;pairs+=matches[i]/2;}
 for(unsigned k=0;k<3;k++){
  if((s->wins[k]==0)!=(s->best[k]==0))return 0;
  if(s->wins[k]&&s->best[k]<l3_memory_count(k)/2)return 0;
  if(k>s->difficulty&&s->wins[k])return 0;
  if(k<s->difficulty&&!s->wins[k])return 0;
 }
 if(s->turns<pairs+(s->phase==L3_MEMORY_TWO))return 0;
 if((s->turns&&known<2)||(s->turns<n/2&&known>2*s->turns+(s->phase==L3_MEMORY_ONE)))return 0;
 if(s->phase==L3_MEMORY_ONE||s->phase==L3_MEMORY_TWO){
  if(s->first>=n||(s->matched&(1u<<s->first))||s->known[s->first]==255)return 0;
 }else if(s->first!=255)return 0;
 if(s->phase==L3_MEMORY_TWO){
  if(s->second>=n||s->second==s->first||(s->matched&(1u<<s->second))||s->known[s->second]==255)return 0;
 }else if(s->second!=255)return 0;
 if((pairs==n/2)!=(s->phase==L3_MEMORY_WON))return 0;
 if(s->phase==L3_MEMORY_WON&&(!s->wins[s->difficulty]||s->best[s->difficulty]>s->turns))return 0;
 return 1;
}
int l3_memory_init(L3Memory *s,uint32_t seed){
 if(!s)return 0;L3Memory n;memset(&n,0,sizeof(n));n.seed=seed;n.rng=seed^0x9e3779b9u;if(!n.rng)n.rng=1;deal(&n);if(!l3_memory_validate(&n))return 0;*s=n;return 1;
}
static void event(L3MemoryTrace *t,unsigned kind,unsigned a,unsigned b){if(t->count<4)t->events[t->count++]=(L3MemoryEvent){kind,a,b};}
int l3_memory_action(L3Memory *s,L3MemoryAction action,L3MemoryTrace *trace){
 if(trace)memset(trace,0,sizeof(*trace));if(!l3_memory_validate(s))return 0;
 L3Memory n=*s;L3MemoryTrace t={0};unsigned count=l3_memory_count(n.difficulty);
 if(action.op==L3_MEMORY_FLIP){
  unsigned i=action.index;if(i>=count||n.phase>L3_MEMORY_ONE||(n.matched&(1u<<i))||i==n.first)return 0;
  n.known[i]=n.cards[i];event(&t,L3_MEMORY_REVEAL,i,n.cards[i]);
  if(n.phase==L3_MEMORY_READY){n.first=i;n.phase=L3_MEMORY_ONE;}
  else {n.second=i;n.phase=L3_MEMORY_TWO;if(n.turns<UINT32_MAX)n.turns++;}
 }else if(action.op==L3_MEMORY_RESOLVE){
  if(n.phase!=L3_MEMORY_TWO||action.index)return 0;
  if(n.cards[n.first]==n.cards[n.second]){
   n.matched|=(1u<<n.first)|(1u<<n.second);event(&t,L3_MEMORY_PAIR,n.first,n.second);
  }else {event(&t,L3_MEMORY_HIDE,n.first,n.second);}
  n.first=n.second=255;n.phase=L3_MEMORY_READY;
  if(n.matched==((1u<<count)-1)){
   n.phase=L3_MEMORY_WON;if(n.wins[n.difficulty]<UINT32_MAX)n.wins[n.difficulty]++;
   if(!n.best[n.difficulty]||n.turns<n.best[n.difficulty])n.best[n.difficulty]=n.turns;
   event(&t,L3_MEMORY_VICTORY,n.difficulty,0);
  }
 }else if(action.op==L3_MEMORY_NEXT){
  if(n.phase!=L3_MEMORY_WON||action.index)return 0;
  if(n.difficulty<2)n.difficulty++;deal(&n);event(&t,L3_MEMORY_DEAL,n.difficulty,0);
 }else return 0;
 if(!l3_memory_validate(&n))return 0;*s=n;if(trace)*trace=t;return 1;
}
int l3_memory_view(const L3Memory *s,L3MemoryView *v){
 if(!v||!l3_memory_validate(s))return 0;memset(v,0,sizeof(*v));memset(v->face,255,sizeof(v->face));
 v->count=l3_memory_count(s->difficulty);v->difficulty=s->difficulty;v->phase=s->phase;v->turns=s->turns;v->matched=s->matched;v->first=s->first;v->second=s->second;
 memcpy(v->known,s->known,30);v->unlocked=1u|((s->wins[0]>0)<<1)|((s->wins[1]>0)<<2);
 for(unsigned i=0;i<v->count;i++)if((s->matched&(1u<<i))||i==s->first||i==s->second){v->face[i]=s->cards[i];v->pairs+=(s->matched>>i)&1u;}
 v->pairs/=2;if(s->phase==L3_MEMORY_WON)v->stars=s->turns<=v->count/2+v->count/6?3:s->turns<=v->count?2:1;
 return 1;
}
int l3_memory_advice(const L3Memory *s,L3MemoryAction *a){
 if(!a||!l3_memory_validate(s))return 0;unsigned n=l3_memory_count(s->difficulty),chosen=255;
 if(s->phase==L3_MEMORY_WON){*a=(L3MemoryAction){L3_MEMORY_NEXT,0};return 1;}
 if(s->phase==L3_MEMORY_TWO){*a=(L3MemoryAction){L3_MEMORY_RESOLVE,0};return 1;}
 /* Only previously observed information drives the adviser. No cards[] read. */
 if(s->phase==L3_MEMORY_READY){
  for(unsigned i=0;i<n&&chosen==255;i++)if(!(s->matched&(1u<<i))&&s->known[i]!=255)
   for(unsigned j=i+1;j<n;j++)if(!(s->matched&(1u<<j))&&s->known[i]==s->known[j]){chosen=i;break;}
 }else for(unsigned i=0;i<n;i++)if(i!=s->first&&!(s->matched&(1u<<i))&&s->known[i]==s->known[s->first]){chosen=i;break;}
 for(unsigned i=0;i<n&&chosen==255;i++)if(i!=s->first&&!(s->matched&(1u<<i))&&s->known[i]==255)chosen=i;
 for(unsigned i=0;i<n&&chosen==255;i++)if(i!=s->first&&!(s->matched&(1u<<i)))chosen=i;
 if(chosen==255)return 0;*a=(L3MemoryAction){L3_MEMORY_FLIP,chosen};return 1;
}
static uint32_t get32(const uint8_t *p){return p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static void put32(uint8_t *p,uint32_t v){for(unsigned i=0;i<4;i++)p[i]=(uint8_t)(v>>(i*8));}
static uint32_t crc(const uint8_t *p,size_t n){uint32_t c=~0u;while(n--){c^=*p++;for(unsigned j=0;j<8;j++)c=(c>>1)^(0xedb88320u&-(c&1));}return ~c;}
size_t l3_memory_encode(const L3Memory *s,void *dst,size_t cap){
 if(!l3_memory_validate(s))return 0;if(!dst)return 128;if(cap<128)return 0;uint8_t *b=dst;memset(b,0,128);
 put32(b,0x3159524du);put32(b+4,1);put32(b+8,128);put32(b+16,s->seed);put32(b+20,s->rng);put32(b+24,s->turns);put32(b+28,s->matched);
 for(unsigned k=0;k<3;k++){put32(b+32+k*4,s->wins[k]);put32(b+44+k*4,s->best[k]);}
 b[56]=s->difficulty;b[57]=s->phase;b[58]=s->first;b[59]=s->second;memcpy(b+60,s->cards,30);memcpy(b+90,s->known,30);put32(b+12,crc(b+16,112));return 128;
}
int l3_memory_decode(L3Memory *s,const void *src,size_t bytes){
 if(!s||!src||bytes!=128)return 0;const uint8_t *b=src;
 if(get32(b)!=0x3159524du||get32(b+4)!=1||get32(b+8)!=128||get32(b+12)!=crc(b+16,112))return 0;
 for(unsigned i=120;i<128;i++)if(b[i])return 0;
 L3Memory n;memset(&n,0,sizeof(n));n.seed=get32(b+16);n.rng=get32(b+20);n.turns=get32(b+24);n.matched=get32(b+28);
 for(unsigned k=0;k<3;k++){n.wins[k]=get32(b+32+k*4);n.best[k]=get32(b+44+k*4);}
 n.difficulty=b[56];n.phase=b[57];n.first=b[58];n.second=b[59];memcpy(n.cards,b+60,30);memcpy(n.known,b+90,30);
 if(!l3_memory_validate(&n))return 0;*s=n;return 1;
}
