#ifndef L3_TABLE_H
#define L3_TABLE_H
#include <stddef.h>
#include <stdint.h>

/* Pure deterministic rule engines. No GPU, clock, input device or allocation.
 * A turn/action is explicit. No hidden automatic AI turn in action(). */
enum { L3_TABLE_OTHELLO, L3_TABLE_SOLITAIRE, L3_TABLE_CHROMA,
       L3_TABLE_HANGMAN, L3_TABLE_COUNT };
enum { L3_TABLE_RUNNING, L3_TABLE_WON, L3_TABLE_LOST, L3_TABLE_DRAWN };
enum { L3_TABLE_PLACE=1, L3_TABLE_PASS, L3_TABLE_DRAW, L3_TABLE_MOVE,
       L3_TABLE_PLAY, L3_TABLE_GUESS };
enum { L3_TABLE_EVENT_MOVE=1, L3_TABLE_EVENT_FLIP, L3_TABLE_EVENT_DRAW,
       L3_TABLE_EVENT_REVEAL, L3_TABLE_EVENT_PASS, L3_TABLE_EVENT_FINISH };
#define L3_TABLE_NONE 255u
#define L3_TABLE_TRACE_MAX 68u
#define L3_TABLE_SAVE_MAX 1024u
typedef struct { uint8_t op,from,to,index,value; } L3TableAction;
typedef struct { uint8_t kind,from,to,index,value; } L3TableEvent;
typedef struct { unsigned count; L3TableEvent events[L3_TABLE_TRACE_MAX]; } L3TableTrace;
typedef struct { uint8_t board[64],passes; } L3Othello;
/* IDs 0..51: suit=id/13 (clubs,diamonds,spades,hearts), rank=id%13+1.
 * Empty slots are 255. Tableau slots >= hidden[] are face up.
 * Move zones: 0..6 tableau,7 waste,9..12 foundations. index is first source
 * tableau row (ignored for waste/foundation). Stock draw/recycle is DRAW. */
typedef struct {
    uint8_t tableau[7][52],count[7],hidden[7];
    uint8_t stock[24],stock_count,waste[24],waste_count,found[4];
} L3Solitaire;
/* Chroma IDs 0..107: use card_color/card_value. Values0..9 numbers,
 *10 skip,11 reverse,12 draw2,13 wildcard,14 draw4. Four players, no stacking.
 * PLAY index is current hand slot, value is desired color for a wildcard.
 * DRAW ends choice of old cards: only the newly drawn card can be played;
 * otherwise PASS ends the turn. Hands in a view hide opponents with255. */
typedef struct {
    uint8_t hands[4][108],count[4],deck[108],draw_count;
    uint8_t discard[108],discard_count,color,direction,drew,drawn_id,passes;
} L3Chroma;
typedef struct { uint8_t word,guessed[26],mistakes; } L3Hangman;
typedef union { L3Othello othello; L3Solitaire solitaire; L3Chroma chroma; L3Hangman hangman; } L3TableData;
/* State is not a wire format; callers use actions, never mutate state. */
typedef struct {
    uint32_t kind,status,turn,winner,moves,seed,rng; /* moves saturates at UINT32_MAX */
    L3TableData data;
} L3TableState;
typedef struct {
    uint32_t kind,status,turn,winner,moves;
    const char *title,*help,*hint;
    L3TableData data; /* Sanitized presentation copy. */
    uint8_t legal[64]; /* Othello legal squares; otherwise zero. */
    char word[24]; /* Pendu revealed letters / underscores, secret hidden. */
    unsigned scores[4];
} L3TableView;

int l3_table_init(L3TableState *,unsigned kind,uint32_t seed);
/* Rejected action leaves state unchanged; trace is cleared on every call. */
int l3_table_action(L3TableState *,L3TableAction,L3TableTrace *);
int l3_table_view(const L3TableState *,L3TableView *,unsigned viewer);
int l3_table_validate(const L3TableState *);
/* Adviser does not change state or peek at hidden cards/word. Solitaire
 * advice is heuristic, not a guarantee that a random deal is solvable. */
int l3_table_demo_action(const L3TableState *,L3TableAction *);
/* Exact-length LE+CRC format, semantic validation, transactional decode. */
size_t l3_table_encode(const L3TableState *,void *,size_t);
int l3_table_decode(L3TableState *,const void *,size_t);
unsigned l3_table_card_color(unsigned id);
unsigned l3_table_card_value(unsigned id);
#endif
