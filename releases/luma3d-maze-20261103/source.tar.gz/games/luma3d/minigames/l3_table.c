#include "l3_table_internal.h"
#include <limits.h>
uint32_t l3t_random(L3TableState *s){uint32_t x=s->rng;x^=x<<13;x^=x>>17;x^=x<<5;s->rng=x;return x;}
void l3t_event(L3TableTrace *t,unsigned kind,unsigned from,unsigned to,unsigned index,unsigned value){
    if(t&&t->count<L3_TABLE_TRACE_MAX)t->events[t->count++]=(L3TableEvent){(uint8_t)kind,(uint8_t)from,(uint8_t)to,(uint8_t)index,(uint8_t)value};
}
static size_t data_size(unsigned kind){
    static const size_t sizes[]={sizeof(L3Othello),sizeof(L3Solitaire),sizeof(L3Chroma),sizeof(L3Hangman)};
    return kind<L3_TABLE_COUNT?sizes[kind]:0;
}
int l3_table_validate(const L3TableState *s){
    if(!s||s->kind>=L3_TABLE_COUNT||s->status>L3_TABLE_DRAWN||!s->rng||!(s->winner<4||s->winner==255))return 0;
    switch(s->kind){
    case L3_TABLE_OTHELLO:return l3t_othello_validate(s);
    case L3_TABLE_SOLITAIRE:return l3t_solitaire_validate(s);
    case L3_TABLE_CHROMA:return l3t_chroma_validate(s);
    default:return l3t_hangman_validate(s);
    }
}
int l3_table_init(L3TableState *s,unsigned kind,uint32_t seed){
    if(!s||kind>=L3_TABLE_COUNT)return 0;
    L3TableState n;memset(&n,0,sizeof n);n.kind=kind;n.seed=seed;n.rng=seed^0x9e3779b9u;if(!n.rng)n.rng=1;n.winner=255;
    switch(kind){
    case L3_TABLE_OTHELLO:n.data.othello.board[27]=2;n.data.othello.board[28]=1;n.data.othello.board[35]=1;n.data.othello.board[36]=2;break;
    case L3_TABLE_SOLITAIRE:l3t_solitaire_init(&n);break;
    case L3_TABLE_CHROMA:l3t_chroma_init(&n);break;
    default:l3t_hangman_init(&n);break;
    }
    if(!l3_table_validate(&n))return 0;*s=n;return 1;
}
int l3_table_action(L3TableState *s,L3TableAction a,L3TableTrace *trace){
    if(trace)memset(trace,0,sizeof *trace);
    if(!l3_table_validate(s)||s->status!=L3_TABLE_RUNNING)return 0;
    L3TableState n=*s;L3TableTrace tr;memset(&tr,0,sizeof tr);int ok;
    switch(s->kind){
    case L3_TABLE_OTHELLO:ok=l3t_othello_action(&n,a,&tr);break;
    case L3_TABLE_SOLITAIRE:ok=l3t_solitaire_action(&n,a,&tr);break;
    case L3_TABLE_CHROMA:ok=l3t_chroma_action(&n,a,&tr);break;
    default:ok=l3t_hangman_action(&n,a,&tr);break;
    }
    if(!ok)return 0;if(n.moves<UINT32_MAX)n.moves++;
    if(!l3_table_validate(&n))return 0;*s=n;if(trace)*trace=tr;return 1;
}
int l3_table_view(const L3TableState *s,L3TableView *v,unsigned viewer){
    if(!v||viewer>3||!l3_table_validate(s))return 0;memset(v,0,sizeof *v);
    v->kind=s->kind;v->status=s->status;v->turn=s->turn;v->winner=s->winner;v->moves=s->moves;v->data=s->data;
    static const char *titles[]={"Othello - Jardin des deux lunes","Solitaire - L'auberge des voyageurs","Chroma - La table des couleurs","Pendu - Les mots de la foret"};
    static const char *helps[]={"Placer un pion pour encadrer et retourner les autres","Alterner rouge/noir en descendant ; As vers fondations","Meme couleur ou valeur ; joker pour choisir une couleur","Choisir une lettre. Sept erreurs au maximum"};
    v->title=titles[s->kind];v->help=helps[s->kind];v->hint="";
    if(s->kind==L3_TABLE_OTHELLO){
        for(unsigned i=0;i<64;i++){v->legal[i]=(uint8_t)(s->status==L3_TABLE_RUNNING&&l3t_othello_flips(&s->data.othello,s->turn,i,0)!=0);unsigned c=s->data.othello.board[i];if(c)v->scores[c-1]++;}
    }else if(s->kind==L3_TABLE_SOLITAIRE){
        for(unsigned i=0;i<7;i++)memset(v->data.solitaire.tableau[i],255,v->data.solitaire.hidden[i]);
        memset(v->data.solitaire.stock,255,24);
        for(unsigned i=0;i<4;i++)v->scores[0]+=v->data.solitaire.found[i];
    }else if(s->kind==L3_TABLE_CHROMA){
        memset(v->data.chroma.deck,255,108);
        for(unsigned i=0;i<4;i++){v->scores[i]=s->data.chroma.count[i];if(i!=viewer)memset(v->data.chroma.hands[i],255,108);}
        if(s->turn!=viewer)v->data.chroma.drawn_id=255;
    }else l3t_hangman_view(s,v);
    return 1;
}
int l3_table_demo_action(const L3TableState *s,L3TableAction *a){
    if(!a||!l3_table_validate(s)||s->status!=L3_TABLE_RUNNING)return 0;
    switch(s->kind){
    case L3_TABLE_OTHELLO:return l3t_othello_advice(s,a);
    case L3_TABLE_SOLITAIRE:return s->moves<512&&l3t_solitaire_advice(s,a);
    case L3_TABLE_CHROMA:return s->moves<4096&&l3t_chroma_advice(s,a);
    default:return l3t_hangman_advice(s,a);
    }
}
static uint32_t get32(const uint8_t *p){return p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static void put32(uint8_t *p,uint32_t v){for(unsigned i=0;i<4;i++)p[i]=(uint8_t)(v>>(i*8));}
static uint32_t crc(const uint8_t *p,size_t n){uint32_t c=~0u;while(n--){c^=*p++;for(unsigned i=0;i<8;i++)c=(c>>1)^(0xedb88320u&-(c&1));}return ~c;}
size_t l3_table_encode(const L3TableState *s,void *dst,size_t cap){
    if(!l3_table_validate(s))return 0;size_t bytes=44+data_size(s->kind);if(!dst)return bytes;if(cap<bytes)return 0;
    uint8_t *b=dst;memset(b,0,bytes);put32(b,0x3142544cu);put32(b+4,1);put32(b+8,(uint32_t)bytes);
    put32(b+16,s->kind);put32(b+20,s->status);put32(b+24,s->turn);put32(b+28,s->winner);put32(b+32,s->moves);put32(b+36,s->seed);put32(b+40,s->rng);
    /* All payload members are uint8_t, no implicit padding/endianness. */
    memcpy(b+44,&s->data,data_size(s->kind));put32(b+12,crc(b+16,bytes-16));return bytes;
}
int l3_table_decode(L3TableState *s,const void *src,size_t bytes){
    if(!s||!src||bytes<44||bytes>L3_TABLE_SAVE_MAX)return 0;const uint8_t *b=src;
    if(get32(b)!=0x3142544cu||get32(b+4)!=1||get32(b+8)!=bytes||get32(b+12)!=crc(b+16,bytes-16))return 0;
    unsigned kind=get32(b+16);if(kind>=L3_TABLE_COUNT||bytes!=44+data_size(kind))return 0;
    L3TableState n;memset(&n,0,sizeof n);n.kind=kind;n.status=get32(b+20);n.turn=get32(b+24);n.winner=get32(b+28);n.moves=get32(b+32);n.seed=get32(b+36);n.rng=get32(b+40);
    memcpy(&n.data,b+44,data_size(kind));if(!l3_table_validate(&n))return 0;*s=n;return 1;
}
_Static_assert(sizeof(L3Othello)==65,"wire payload padding");
_Static_assert(sizeof(L3Solitaire)==432,"wire payload padding");
_Static_assert(sizeof(L3Chroma)==659,"wire payload padding");
_Static_assert(sizeof(L3Hangman)==28,"wire payload padding");
_Static_assert(sizeof(L3TableData)+44<=L3_TABLE_SAVE_MAX,"save budget");
