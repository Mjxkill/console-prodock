#include "l3_table_internal.h"
typedef struct { const char *word,*hint; } Word;
static const Word words[]={
 {"LUCIOLE","Une petite lumiere dans la foret"},{"CRISTAL","Un tresor qui renvoie la lumiere"},
 {"PAPILLON","Un visiteur colore des fleurs"},{"MONTAGNE","Le paysage touche les nuages"},
 {"CASCADE","Une riviere qui tombe"},{"GALAXIE","Un immense jardin d'etoiles"},
 {"BOUSSOLE","Elle t'aide a trouver le nord"},{"PARACHUTE","Pour redescendre en douceur"},
 {"CHOUETTE","Une gardienne de la nuit"},{"BOULANGER","Il prepare le pain du village"},
 {"NENUPHAR","Une fleur qui flotte"},{"LIBELLULE","Elle danse au bord de l'eau"},
 {"LABYRINTHE","Il faut y retrouver son chemin"},{"CONSTELLATION","Un dessin parmi les etoiles"},
 {"MONTGOLFIERE","Un ballon emporte des voyageurs"},{"BIBLIOTHEQUE","Une maison remplie d'histoires"},
 {"HORIZON","La ou le ciel rencontre la terre"},{"ECUREUIL","Il cache des noisettes"},
 {"FOUGERE","Une plante aux feuilles decoupees"},{"AMETHYSTE","Une pierre de couleur violette"},
 {"CERF","Un habitant majestueux de la foret"},{"HIBOU","Il observe le monde dans le noir"},
 {"OASIS","Une halte verte dans le desert"},{"PHARE","Il guide les bateaux dans la nuit"},
 {"VOILIER","Le vent lui sert de moteur"},{"ORCHESTRE","Beaucoup d'instruments reunis"},
 {"TRESOR","Une belle recompense a decouvrir"},{"PLANETE","Un monde autour d'une etoile"},
 {"AVENTURE","Un voyage plein de surprises"},{"SOUVENIR","Un petit morceau de ton histoire"},
 {"CITROUILLE","Une grande courge orange"},{"ARBALETE","Elle lance un carreau"}
};
#define WORD_COUNT ((unsigned)(sizeof words/sizeof words[0]))
void l3t_hangman_init(L3TableState *s){s->data.hangman.word=(uint8_t)(l3t_random(s)%WORD_COUNT);}
static void score(const L3Hangman *p,unsigned *wrong,unsigned *missing){
    const char *w=words[p->word].word;*wrong=*missing=0;
    for(unsigned i=0;i<26;i++)if(p->guessed[i]&&!strchr(w,(int)('A'+i)))(*wrong)++;
    for(const char *q=w;*q;q++)if(!p->guessed[(unsigned)(*q-'A')])(*missing)++;
}
int l3t_hangman_validate(const L3TableState *s){
    const L3Hangman *p=&s->data.hangman;if(s->turn||p->word>=WORD_COUNT||p->mistakes>7)return 0;
    unsigned guesses=0;for(unsigned i=0;i<26;i++){if(p->guessed[i]>1)return 0;guesses+=p->guessed[i];}
    if(guesses!=s->moves)return 0;
    unsigned wrong,missing;score(p,&wrong,&missing);if(wrong!=p->mistakes||(!missing&&wrong==7))return 0;
    unsigned status=!missing?L3_TABLE_WON:wrong==7?L3_TABLE_LOST:L3_TABLE_RUNNING;
    return s->status==status&&s->winner==(status==L3_TABLE_WON?0u:255u);
}
int l3t_hangman_action(L3TableState *s,L3TableAction a,L3TableTrace *trace){
    if(a.op!=L3_TABLE_GUESS||a.value<'A'||a.value>'Z')return 0;
    L3Hangman *p=&s->data.hangman;unsigned letter=a.value-'A';if(p->guessed[letter])return 0;p->guessed[letter]=1;
    unsigned wrong,missing;score(p,&wrong,&missing);p->mistakes=(uint8_t)wrong;
    l3t_event(trace,L3_TABLE_EVENT_REVEAL,0,0,letter,wrong);
    if(!missing){s->status=L3_TABLE_WON;s->winner=0;}else if(wrong==7)s->status=L3_TABLE_LOST;
    if(s->status!=L3_TABLE_RUNNING)l3t_event(trace,L3_TABLE_EVENT_FINISH,0,0,0,s->winner);
    return 1;
}
void l3t_hangman_view(const L3TableState *s,L3TableView *v){
    const L3Hangman *p=&s->data.hangman;const char *w=words[p->word].word;
    v->hint=words[p->word].hint;v->data.hangman.word=255;
    for(unsigned i=0;w[i];i++)v->word[i]=p->guessed[(unsigned)(w[i]-'A')]||s->status!=L3_TABLE_RUNNING?w[i]:'_';
    v->scores[0]=7-p->mistakes;
}
int l3t_hangman_advice(const L3TableState *s,L3TableAction *a){
    /* Use only the masked pattern and known wrong letters, never the word ID
     * or hint. Dictionary filtering is the same information a player sees. */
    L3TableView v;memset(&v,0,sizeof v);l3t_hangman_view(s,&v);unsigned freq[26]={0};size_t n=strlen(v.word);
    for(unsigned k=0;k<WORD_COUNT;k++){
        const char *w=words[k].word;if(strlen(w)!=n)continue;int possible=1;
        for(unsigned i=0;i<n;i++){
            unsigned c=(unsigned)(w[i]-'A');if(v.word[i]!='_'&&v.word[i]!=w[i])possible=0;
            if(v.word[i]=='_'&&s->data.hangman.guessed[c])possible=0;
        }
        if(!possible)continue;unsigned mask=0;
        for(unsigned i=0;i<n;i++)mask|=1u<<(unsigned)(w[i]-'A');
        for(unsigned c=0;c<26;c++)if(mask&(1u<<c))freq[c]++;
    }
    unsigned selected=26,best=0;
    for(unsigned c=0;c<26;c++)if(!s->data.hangman.guessed[c]&&(selected==26||freq[c]>best)){best=freq[c];selected=c;}
    if(selected==26)return 0;memset(a,0,sizeof *a);a->op=L3_TABLE_GUESS;a->value=(uint8_t)('A'+selected);return 1;
}
