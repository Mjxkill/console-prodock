#include "l3_table_internal.h"
static unsigned rank(unsigned c){return c%13+1;}
static unsigned color(unsigned c){return (c/13)&1;}
void l3t_solitaire_init(L3TableState *s){
    L3Solitaire *p=&s->data.solitaire;uint8_t deck[52];
    memset(p->tableau,255,sizeof p->tableau);memset(p->stock,255,24);memset(p->waste,255,24);
    for(unsigned i=0;i<52;i++)deck[i]=(uint8_t)i;
    for(unsigned i=51;i;i--){unsigned j=l3t_random(s)%(i+1);uint8_t t=deck[i];deck[i]=deck[j];deck[j]=t;}
    unsigned at=0;
    for(unsigned row=0;row<7;row++)for(unsigned col=row;col<7;col++)p->tableau[col][p->count[col]++]=deck[at++];
    for(unsigned i=0;i<7;i++)p->hidden[i]=(uint8_t)i;
    p->stock_count=24;memcpy(p->stock,deck+28,24);
}
static int seen_card(unsigned c,uint8_t seen[52]){if(c>=52||seen[c])return 0;seen[c]=1;return 1;}
int l3t_solitaire_validate(const L3TableState *s){
    const L3Solitaire *p=&s->data.solitaire;uint8_t seen[52]={0};unsigned total=0,done=0;
    if(s->turn||p->stock_count>24||p->waste_count>24||p->stock_count+p->waste_count>24)return 0;
    for(unsigned i=0;i<7;i++){
        if(p->count[i]>52||p->hidden[i]>i||p->hidden[i]>p->count[i]||(p->count[i]&&p->hidden[i]==p->count[i]))return 0;
        for(unsigned j=0;j<52;j++){
            unsigned c=p->tableau[i][j];
            if(j>=p->count[i]){if(c!=255)return 0;continue;}
            if(!seen_card(c,seen))return 0;total++;
            if(j>p->hidden[i]){unsigned before=p->tableau[i][j-1];if(rank(before)!=rank(c)+1||color(before)==color(c))return 0;}
        }
    }
    for(unsigned i=0;i<24;i++){
        if(i<p->stock_count){if(!seen_card(p->stock[i],seen))return 0;total++;}else if(p->stock[i]!=255)return 0;
        if(i<p->waste_count){if(!seen_card(p->waste[i],seen))return 0;total++;}else if(p->waste[i]!=255)return 0;
    }
    for(unsigned suit=0;suit<4;suit++){
        if(p->found[suit]>13)return 0;done+=p->found[suit];
        for(unsigned r=0;r<p->found[suit];r++){if(!seen_card(suit*13+r,seen))return 0;total++;}
    }
    if(total!=52)return 0;
    return done==52?s->status==L3_TABLE_WON&&s->winner==0:s->status==L3_TABLE_RUNNING&&s->winner==255;
}
int l3t_solitaire_action(L3TableState *s,L3TableAction a,L3TableTrace *trace){
    L3Solitaire *p=&s->data.solitaire;
    if(a.op==L3_TABLE_DRAW){
        if(p->stock_count){
            unsigned card=p->stock[--p->stock_count];p->stock[p->stock_count]=255;
            p->waste[p->waste_count++]=(uint8_t)card;l3t_event(trace,L3_TABLE_EVENT_DRAW,8,7,0,card);
        }else{
            if(!p->waste_count)return 0;
            while(p->waste_count){unsigned card=p->waste[--p->waste_count];p->waste[p->waste_count]=255;p->stock[p->stock_count++]=(uint8_t)card;}
            l3t_event(trace,L3_TABLE_EVENT_MOVE,7,8,0,p->stock_count);
        }
        return 1;
    }
    if(a.op!=L3_TABLE_MOVE||a.from==a.to)return 0;
    uint8_t moving[52];unsigned n=0;
    if(a.from<7){
        if(a.index<p->hidden[a.from]||a.index>=p->count[a.from])return 0;
        n=p->count[a.from]-a.index;memcpy(moving,p->tableau[a.from]+a.index,n);
    }else if(a.from==7){if(!p->waste_count)return 0;moving[n++]=p->waste[p->waste_count-1];}
    else if(a.from>=9&&a.from<13){unsigned suit=a.from-9;if(!p->found[suit])return 0;moving[n++]=(uint8_t)(suit*13+p->found[suit]-1);}
    else return 0;
    if(a.to<7){
        unsigned count=p->count[a.to];if(count+n>52)return 0;
        if(count){unsigned top=p->tableau[a.to][count-1];if(rank(top)!=rank(moving[0])+1||color(top)==color(moving[0]))return 0;}
        else if(rank(moving[0])!=13)return 0;
    }else if(a.to>=9&&a.to<13){unsigned suit=a.to-9;if(n!=1||moving[0]/13!=suit||rank(moving[0])!=(unsigned)p->found[suit]+1u)return 0;}
    else return 0;
    if(a.from<7){
        p->count[a.from]=(uint8_t)a.index;memset(p->tableau[a.from]+a.index,255,n);
        if(p->count[a.from]&&p->hidden[a.from]==p->count[a.from]){
            p->hidden[a.from]--;l3t_event(trace,L3_TABLE_EVENT_REVEAL,a.from,a.from,p->hidden[a.from],p->tableau[a.from][p->hidden[a.from]]);
        }
    }else if(a.from==7){p->waste[--p->waste_count]=255;}
    else p->found[a.from-9]--;
    if(a.to<7){memcpy(p->tableau[a.to]+p->count[a.to],moving,n);p->count[a.to]=(uint8_t)(p->count[a.to]+n);}
    else p->found[a.to-9]++;
    unsigned row=a.from<7?a.index:0;
    for(unsigned i=0;i<n;i++)l3t_event(trace,L3_TABLE_EVENT_MOVE,a.from,a.to,row+i,moving[i]);
    if(p->found[0]+p->found[1]+p->found[2]+p->found[3]==52){s->status=L3_TABLE_WON;s->winner=0;l3t_event(trace,L3_TABLE_EVENT_FINISH,0,0,0,0);}
    return 1;
}
int l3t_solitaire_advice(const L3TableState *s,L3TableAction *out){
    const L3Solitaire *p=&s->data.solitaire;int best=-10000;L3TableAction selected={0};
    for(unsigned from=0;from<8;from++){
        unsigned start=from<7?p->hidden[from]:0,end=from<7?p->count[from]:p->waste_count?1:0;
        for(unsigned i=start;i<end;i++)for(unsigned to=0;to<13;to++){
            if(to==7||to==8||to==from)continue;
            L3TableAction a={L3_TABLE_MOVE,(uint8_t)from,(uint8_t)to,(uint8_t)i,0};L3TableState next=*s;
            if(!l3t_solitaire_action(&next,a,0))continue;
            int score=to>=9?120:from==7?40:0;
            /* Rearrangement without revealing anything can ping-pong forever.
             * Prefer an observable gain; otherwise advance the stock. */
            if(from<7&&to<7&&i==p->hidden[from]&&i)score=110;
            if(score>best){best=score;selected=a;}
        }
    }
    if(best>0){*out=selected;return 1;}
    if(p->stock_count||p->waste_count){memset(out,0,sizeof *out);out->op=L3_TABLE_DRAW;return 1;}
    return 0;
}
