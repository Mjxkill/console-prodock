#ifndef L3_SIMON_GPU_H
#define L3_SIMON_GPU_H
#include "l3_simon_light.h"
#include "gpu_v1.h"
typedef struct {gpu_target background;gpu_texture_level keys,halo,shadow;} L3SimonGpuAssets;
/* Diagnostic native800 layout shared with the approved composition. */
int l3_simon_gpu_draw(gpu_v1_context *,const L3SimonGpuAssets *,const L3SimonLightFrame *,uint32_t page,uint32_t depth,unsigned *quads);
#endif
