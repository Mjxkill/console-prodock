#ifndef LUMA_GARDEN_TOUR_ROUTES_H
#define LUMA_GARDEN_TOUR_ROUTES_H
/* Private route data for the existing showcase scheduler. Point coordinates
 * are metres on the unchanged physical terrain; no position setter is used.
 * Endpoints stop beside solid NPCs. North/south legs bypass the closed gate. */
static const Point serre_arrival[]={{220,58},{224,54},{235,54},{241,60},{242.5f,58}};
static const Point serre_dew[]={{242,65.5f}};
static const Point serre_night[]={{244,68},{251,68},{260,71.4f}};
static const Point serre_oren[]={{258,67},{254,63.7f}};
static const Point serre_sun[]={{257,60},{255,52.4f}};
static const Point serre_music[]={{254,56.5f}};
static const Point serre_reward[]={{252,53},{240,53},{241,60},{242.5f,58}};
static const Point serre_gate[]={{245,61},{251,61}};
static const Point serre_leave[]={{251,68},{244,68},{242,65.5f},{241,60},{235,54},{224,54},{220,58}};

/* kind identifies dialogue 14/15, seed index 0..2 or existing Simon kind.
 * Entries are expanded inside the single Stage table, not a parallel runner. */
#define GARDEN_TOUR_STAGES \
 {"Serres de Sélène : rencontrer la botaniste",ROUTE(serre_arrival),TALK,14}, \
 {"La rosée : découvrir le sentier des fleurs",ROUTE(serre_dew),GARDEN_SEED,0}, \
 {"Le verger de nuit : contourner librement les serres",ROUTE(serre_night),GARDEN_SEED,2}, \
 {"Oren : écouter le gardien du carillon",ROUTE(serre_oren),TALK,15}, \
 {"Le belvédère doré : retrouver la dernière semence",ROUTE(serre_sun),GARDEN_SEED,1}, \
 {"Le carillon des serres : répéter les quatre couleurs",ROUTE(serre_music),ACTIVITY,L3_ARCADE_SIMON}, \
 {"L'herbier de Sélène : rapporter les trois découvertes",ROUTE(serre_reward),TALK,14}, \
 {"Le portillon : traverser le nouveau raccourci",ROUTE(serre_gate),GARDEN_GATE,0}, \
 {"Retour par le sentier bas : poursuivre l'aventure",ROUTE(serre_leave),LOOK,0},
#endif
