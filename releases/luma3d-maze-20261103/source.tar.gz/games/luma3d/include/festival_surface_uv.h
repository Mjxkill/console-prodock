#ifndef FESTIVAL_SURFACE_UV_H
#define FESTIVAL_SURFACE_UV_H

#include <stdint.h>
#include <stddef.h>
#include <math.h>

static inline int festival_surface_uv(unsigned texture, int horizontal,
                                    float u, float v, uint32_t *packed)
{
    double du;
    double dv;
    long ru;
    long rv;

    if (packed == NULL) return 0;
    if (!isfinite(u) || !isfinite(v)) return 0;

    if (texture == 0U && horizontal != 0) {
        const double x = (double)u;
        const double y = (double)v;
        du = 32.0 * (0.6 * x + 0.8 * y);
        dv = 32.0 * (-0.8 * x + 0.6 * y);
    } else if (texture == 1U && horizontal != 0) {
        du = 32.0 * (double)u;
        dv = 32.0 * (double)v;
    } else {
        du = 32.0 * (double)u;
        dv = 32.0 * (double)v;
    }

    if (!isfinite(du) || !isfinite(dv)) return 0;
    if (du < -32768.5 || du > 32767.5) return 0;
    if (dv < -32768.5 || dv > 32767.5) return 0;

    ru = lround(du);
    rv = lround(dv);
    if (ru < -32768 || ru > 32767 || rv < -32768 || rv > 32767) return 0;

    *packed = ((uint32_t)(uint16_t)ru << 16) | (uint32_t)(uint16_t)rv;
    return 1;
}

#endif
