#ifndef LUMA3D_ARCADE_CORE_H
#define LUMA3D_ARCADE_CORE_H
#include "l3_minigames.h"
#include "l3_simon.h"
#include "l3_shooter.h"
#include "l3_platform.h"

/* Isolated next-lot adapter. No world/renderer dependency; r4 is unchanged. */
enum {L3_ARCADE_CIRCUIT,L3_ARCADE_BLOCKS,L3_ARCADE_SHAPES,L3_ARCADE_MERGE,
      L3_ARCADE_MAZE,L3_ARCADE_SIMON,L3_ARCADE_SHOOTER,L3_ARCADE_PLATFORM,L3_ARCADE_COUNT};
#define L3_ARCADE_RESTART (1u<<16)
#define L3_ARCADE_REWARD (1u<<20)
#define L3_ARCADE_SAVE_MAX 7248u
typedef struct {
 L3MiniState base[5];
 L3SimonState simon;
 L3ShooterState shooter;
 L3PlatformState platform;
 uint32_t seed[8],initialized,won,active,release_inputs;
} L3ArcadeState;
typedef struct {
 unsigned kind,status;
 union {L3MiniView grid;L3SimonView simon;L3ShooterView shooter;L3PlatformView platform;} content;
} L3ArcadeView;
void l3_arcade_init(L3ArcadeState *state);
int l3_arcade_import_base(L3ArcadeState *state,const L3MiniState games[5],unsigned initialized,unsigned won,unsigned active,unsigned release_inputs);
int l3_arcade_enter(L3ArcadeState *state,unsigned kind,uint32_t seed);
uint32_t l3_arcade_step(L3ArcadeState *state,uint32_t pressed,uint32_t held,uint32_t dt_ms);
int l3_arcade_view(const L3ArcadeState *state,L3ArcadeView *view);
int l3_arcade_validate(const L3ArcadeState *state);
uint32_t l3_arcade_id(unsigned kind);
int l3_arcade_demo_input(const L3ArcadeState *state,uint32_t *pressed,uint32_t *held,uint32_t *dt_ms);
size_t l3_arcade_encode(const L3ArcadeState *state,void *output,size_t capacity);
int l3_arcade_decode(L3ArcadeState *state,const void *input,size_t bytes);
/* Enter preserves an existing run. Restart uses its original seed and keeps
 * the reward bit. BACK exits before any engine step. Release gating prevents
 * the world E key from becoming a puzzle action. WORLD pose restoration is
 * intentionally outside this adapter and remains to integrate in lot V5. */
#endif
