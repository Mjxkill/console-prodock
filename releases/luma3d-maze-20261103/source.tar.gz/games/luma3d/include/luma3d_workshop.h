#ifndef LUMA3D_WORKSHOP_H
#define LUMA3D_WORKSHOP_H
#include "luma3d_game.h"
int l3_workshop_blocked(const L3Game *,float,float,float,float,float);
int l3_workshop_interact(L3Game *,int);
int l3_workshop_target(L3Game *,L3Vec3 *);
int l3_workshop_advance(L3Game *);
int l3_workshop_wanted(const L3Game *);
void l3_workshop_tick(L3Game *,float);
void l3_workshop_rejoin(L3Game *);
int l3_workshop_state_ok(const L3Game *);
void l3_workshop_restore(L3Game *);
unsigned l3_workshop_points(void);
#endif
