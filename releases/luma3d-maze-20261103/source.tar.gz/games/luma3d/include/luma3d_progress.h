#ifndef LUMA3D_PROGRESS_H
#define LUMA3D_PROGRESS_H
#include "luma3d_game.h"
#include <stddef.h>
#include <float.h>
/* The current renderer's largest time multiplier is 18 (waterfall UVs).
 * Leave headroom for that product and subsequent additions. This is a numeric
 * safety bound, not a play-duration cap or a change to the V1 file layout. */
#define L3_PROGRESS_TIME_MAX (FLT_MAX/32.0f)
/* Stable IDs are supplied by content. Reject zero/duplicate IDs. A semantic
 * change of story/route must bump version; never interpret unknown versions. */
typedef struct {
    uint32_t campaign_id, version, count;
    const uint32_t *collectible_ids;
} L3ProgressSchema;
enum { L3_PROGRESS_OK=1, L3_PROGRESS_INVALID=0, L3_PROGRESS_IO=-1 };
enum { L3_PROGRESS_MAX_BYTES=8192 };
int l3_progress_encode(const L3Game *,const L3ProgressSchema *,unsigned char *,size_t,size_t *);
/* Transactional: every rejection leaves the complete L3Game unchanged.
 * Restore at a safe grounded position, with zero velocity; preserve the
 * caller's manual override. V4 also preserves a saved manual mode; legacy
 * versions retain the caller's mode. Dialogue resumes from its current page. */
int l3_progress_decode(L3Game *,const L3ProgressSchema *,const unsigned char *,size_t);
/* No implicit/default path or autosave. Caller explicitly chooses storage.
 * Save uses same-directory temporary file + fsync + atomic rename. */
int l3_progress_write(const char *,const L3Game *,const L3ProgressSchema *);
int l3_progress_read(const char *,L3Game *,const L3ProgressSchema *);
#endif
