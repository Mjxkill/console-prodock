#ifndef L3_TABLE_PROGRESS_H
#define L3_TABLE_PROGRESS_H
#include "l3_table.h"
#define L3_TABLE_PROGRESS_MAX 4096u
typedef struct {
    L3TableState games[L3_TABLE_COUNT];
    uint32_t visited,won,kind,map; /* kind0..3 table,4 garden; map0..1 */
    int32_t x_mm,z_mm; /* Exact millimetres; permitted garden domain±14000. */
} L3TableProgress;
int l3_table_progress_init(L3TableProgress *,uint32_t seed);
int l3_table_progress_validate(const L3TableProgress *);
size_t l3_table_progress_encode(const L3TableProgress *,void *,size_t);
int l3_table_progress_decode(L3TableProgress *,const void *,size_t);
/* Files are separate from existing LUMA saves. Existing foreign-format files
 * and symlinks are refused. 0 means failure; errno is available for I/O errors.
 * load() leaves destination intact on every failure. save() uses a same-dir
 * temporary file, fsync, rename, directory fsync. A directory-fsync failure
 * after rename returns0 even though the complete new file may already exist.
 * Frontend checks physical collision of loaded position and restores motion,
 * input latches and animation to rest; those transient values are not saved. */
int l3_table_progress_load(L3TableProgress *,const char *path);
int l3_table_progress_save(const L3TableProgress *,const char *path);
#endif
