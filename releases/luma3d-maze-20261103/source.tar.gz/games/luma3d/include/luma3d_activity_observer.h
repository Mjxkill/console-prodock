#ifndef L3_ACTIVITY_OBSERVER_H
#define L3_ACTIVITY_OBSERVER_H
#include "luma3d_game.h"
#include "l3_mini_trace.h"
/* Presentation telemetry only. A single frontend owns the binding; an exact
 * game-address filter prevents speculative/test game copies from reporting.
 * Nothing is added to L3Game, engine state or save codecs. NULL views denote
 * entry/exit/reset. Callback must not mutate gameplay or reenter this module. */
typedef void (*L3ActivityObserver)(void *,const L3ArcadeView *,const L3ArcadeView *,
                                 uint32_t,uint32_t,const L3MiniTrace *,double,uint32_t);
void l3_activity_observer_bind(const L3Game *,unsigned kind_mask,L3ActivityObserver,void *);
int l3_activity_observer_clock(double monotone_seconds,uint32_t epoch);
int l3_activity_observer_wants(const L3Game *);
void l3_activity_observer_emit(const L3Game *,const L3ArcadeView *,const L3ArcadeView *,uint32_t,uint32_t,const L3MiniTrace *);
uint32_t l3_arcade_step_trace(L3ArcadeState *,uint32_t,uint32_t,uint32_t,L3MiniTrace *);
#endif
