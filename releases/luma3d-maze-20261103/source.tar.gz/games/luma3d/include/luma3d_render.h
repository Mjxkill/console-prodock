#ifndef LUMA3D_RENDER_H
#define LUMA3D_RENDER_H
#include "luma3d_game.h"
#include "l3_maze_motion.h"
#include "l3_maze_events.h"
#include "gpu_geometry.h"
#include "prodock-uapi.h"
#include "submit_diag.h"
#include <stdio.h>

/* Same command producer for native GPU and independent model capture. */
#define L3_MAP_BYTES (32U*1024*1024)
#define L3_ASSET_OFFSET (8U*1024*1024)
typedef struct {
    int fd, display, host, failed;
    const L3Game *presentation_game;
    double presentation_seconds;
    uint32_t presentation_epoch;
    L3MazeMotion maze_motion;
    L3MazeEvents maze_events;
    struct L3PuzzlePresentation *puzzle_presentation;
    struct L3SimonPresentation *simon_presentation;
    unsigned width, height, pitch, page_bytes, frame;
    unsigned commands, draws, triangles, instances, culled, uploaded;
    unsigned total_commands, total_flushes;
    double feed_seconds, present_seconds;
    uint8_t *memory;
    struct L3Festival *festival;
    unsigned festival_metrics,festival_measure_error,festival_asset_generation;
    uint64_t festival_publish_bytes,festival_atlas_bytes;
    double festival_publish_seconds,festival_atlas_seconds;
    struct {unsigned mode,frame;uint64_t bytes,atlas_bytes;double seconds,atlas_seconds;} festival_asset_events[16];
    struct prodock_batch batch;
    gpu_command state_cache[6]; /* matrix rows, light, material, texture */
    unsigned state_valid;
    struct prodock_display_info initial;
    struct prodock_geometry_info initial_geometry;
    gpu_v1_context gpu;
    gpu_geom_mesh *meshes;
    uint32_t *textures;
    uint8_t *water_kind;
    uint32_t *water_faces[2];
    unsigned static_end,water_texture,animated_bytes,sky_region;
    unsigned arcade_texture;
    gpu_geom_mesh bird_mesh[2];
    int ambient_active;
    L3Vec3 bird_position;
    unsigned tint[3];
    gpu_geom_mesh npc_mesh[3][7];
    gpu_geom_mesh hero_mesh[6];
    unsigned hero_texture;
    int hero_part;
    int npc_character,npc_part;
    uint8_t *hud;
    gpu_geom_mesh maze_static[24], maze_dynamic[24];
    unsigned maze_static_count, maze_dynamic_count;
    uint8_t *mini_pixels;
    uint8_t *mini_chrome_pixels; /* immutable HUD chrome for the current mode */
    unsigned mini_chrome_key, mini_page_chrome[2], mini_chrome_rebuilds;
    uint64_t mini_scan_bytes, mini_restore_bytes;
/* VILLAGE_VISUAL_ROOT_03 */
    unsigned garden_ready,garden_mesh[4],garden_halo_texture;
    gpu_geom_mesh garden_geometry[11];
    unsigned village_ready,village_mesh[3],village_texture,village_sky_texture;
    gpu_geom_mesh village_sky_mesh,village_halo_mesh;
    L3Vec3 village_ground[9];
    double mini_raster_seconds, mini_publish_seconds;
    uint8_t *mini_shadow[2]; /* cached CPU copies of the two displayed UI pages */
    unsigned activity_mode, activity_stage, shooter_ready, sprite_count, sprite_limit;
    unsigned shooter_upload_bytes;
    L3ShooterView shooter_previous;
    struct {int32_t x256,y256;uint32_t started;unsigned active;} shooter_bursts[8];
    unsigned cosmetic_dropped;
    unsigned mini_stamp[2], mini_uploads, mini_bytes;
    unsigned mini_canvas_stamp, mini_rasterizations;
    unsigned hud_stamp[2],hud_height,hud_uploads,hud_bytes;
    struct prodock_palette hud_palette;
    struct prodock_scene last_scene;
    FILE *capture;
    L3Vec3 right, down, forward;
    float focal, near_z, far_z;
    L3SubmitDiag submit_diag;
    int submit_diag_enabled;
} L3Render;
double l3_measure_now(void);
void l3_measure_publish(L3Render *,unsigned,unsigned,double,unsigned);
void l3_measure_loaded(L3Render *,unsigned,double,uint64_t,uint64_t,double);
void l3_presentation_bind(L3Render *,const L3Game *);
int l3_presentation_clock(L3Render *,double seconds,uint32_t epoch);
int l3_presentation_prepare(L3Render *,const L3Game *);
void l3_presentation_unbind(L3Render *);
int l3_render_open(L3Render *, int host, int wide);
int l3_render_frame(L3Render *, const L3Game *);
int l3_render_dump(L3Render *, const char *prefix);
int l3_render_close(L3Render *);
void l3_world_init(L3World *world);
int l3_hud_open(L3Render *r);
int l3_hud_prepare(L3Render *r,const L3Game *g,struct prodock_scene *scene);
int l3_hud_dump(L3Render *r,const char *prefix);
int l3_arcade_3d_render(L3Render *,const L3Game *);
int l3_shooter_render(L3Render *,const L3Game *,struct prodock_scene *);
int l3_shooter_art_open(L3Render *);
int l3_maze_render(L3Render *,const L3Game *);
int l3_mini_ui_open(L3Render *);
int l3_mini_ui_prepare(L3Render *,const L3Game *,struct prodock_scene *);
void l3_mini_ui_close(L3Render *);
int l3_activity_art_open(L3Render *);
int l3_ui_text(uint8_t *,unsigned,unsigned,int,int,unsigned,const char *,unsigned,unsigned);
#endif
