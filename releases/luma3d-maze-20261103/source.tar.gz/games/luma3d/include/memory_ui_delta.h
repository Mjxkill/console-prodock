#ifndef L3_MEMORY_UI_DELTA_H
#define L3_MEMORY_UI_DELTA_H
#include <stddef.h>
#include <stdint.h>
#include <string.h>
typedef struct {size_t scanned,published,spans;} L3UiDelta;
typedef int (*L3UiEmit)(void *,unsigned,const uint8_t *,unsigned);
/* Indexed 8-bit UI. Four pixels per compared/published word. Independent
 * shadow per physical page. No GPU mapping is read by this operation. */
static inline int l3_ui_delta_rows(const uint8_t *src,uint8_t *shadow,unsigned width,unsigned height,size_t capacity,
                      int force,L3UiEmit emit,void *opaque,L3UiDelta *out,const uint8_t *rows){
    if(!out)return 0;memset(out,0,sizeof(*out));
    if(!src||!shadow||!emit||!width||!height||(width&3)||height>capacity/width)return 0;
    size_t bytes=(size_t)width*height;if(bytes>(1u<<20))return 0;
    uintptr_t a=(uintptr_t)src,b=(uintptr_t)shadow;
    if(a>UINTPTR_MAX-bytes||b>UINTPTR_MAX-bytes||(a<b+bytes&&b<a+bytes))return 0;
    if(force){if(!emit(opaque,0,src,(unsigned)bytes))return 0;memcpy(shadow,src,bytes);out->published=bytes;out->spans=1;return 1;}
    for(unsigned y=0;y<height;y++){
        if(rows&&!rows[y])continue;
        size_t row=(size_t)y*width;unsigned first=width,last=0;
        for(unsigned x=0;x<width;x+=4){
            uint32_t current,old;
            /* calloc/malloc canvases and four-byte pitches normally take this
             * path. Prove alignment before telling GCC: on RV32 a plain
             * memcpy from uint8_t* uses four lbu, four sb, then a stack lw.
             * memcpy retains aliasing safety; the fallback preserves support
             * for deliberately unaligned caller buffers. */
#if defined(__GNUC__)
            if(((a|b)&3u)==0){
                memcpy(&current,__builtin_assume_aligned(src+row+x,4),4);
                memcpy(&old,__builtin_assume_aligned(shadow+row+x,4),4);
            }else
#endif
            {memcpy(&current,src+row+x,4);memcpy(&old,shadow+row+x,4);}
            out->scanned+=4;
            if(current!=old){if(first==width)first=x;last=x+4;}
        }
        if(first==width)continue;
        unsigned offset=(unsigned)row+first,length=last-first;
        if(!emit(opaque,offset,src+offset,length))return 0;
        memcpy(shadow+offset,src+offset,length);out->published+=length;out->spans++;
    }
    return 1;
}
/* Optional rows has height entries, conservative for this physical page and
 * disjoint from src/shadow. NULL retains the original full comparison.
 * force always publishes the complete page, regardless of the mask. */
static inline int l3_ui_delta(const uint8_t *src,uint8_t *shadow,unsigned width,unsigned height,size_t capacity,
                             int force,L3UiEmit emit,void *opaque,L3UiDelta *out){
    return l3_ui_delta_rows(src,shadow,width,height,capacity,force,emit,opaque,out,NULL);
}
#endif
