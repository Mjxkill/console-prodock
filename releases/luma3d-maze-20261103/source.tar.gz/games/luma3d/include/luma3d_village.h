#ifndef LUMA3D_VILLAGE_H
#define LUMA3D_VILLAGE_H

#include "luma3d_game.h"
#include <stdint.h>

/* Optional "Sentier des lucioles" (region 0, x 33..50, z 109..118).
 * A/B/C are echo markers on the existing path; D is the small reward
 * sanctuary. The module owns state, validation and short HUD strings but
 * never moves the player: every action requires a real proximity check and
 * the terrain height supplied by L3World.height. No graphics dependency. */

enum {
    L3_VILLAGE_SITE_A = 0,
    L3_VILLAGE_SITE_B = 1,
    L3_VILLAGE_SITE_C = 2,
    L3_VILLAGE_SITE_D = 3,
    L3_VILLAGE_SITE_COUNT = 4,
    /* Story.nearest values 30..33 map to the four village sites. */
    L3_VILLAGE_FIRST_NEAREST = 30,
    L3_VILLAGE_PHASE_DORMANT = 0,
    L3_VILLAGE_PHASE_EXPLORING = 1,
    L3_VILLAGE_PHASE_AWAKE = 2,
    L3_VILLAGE_PHASE_DONE = 3,
    /* Bounded so older saves cannot overflow the packed V6 field. */
    L3_VILLAGE_MAX_WRONG = 255
};

typedef struct {
    unsigned phase;   /* dormant, exploring, awake, done */
    unsigned mask;    /* bit 0..2 discovered echoes */
    unsigned step;    /* recorded prefix length, 0..3 */
    unsigned wrong;   /* failed sequence attempts, bounded for saves */
    unsigned reward;  /* 0/1, unique */
    unsigned char order[3];
} L3VillageView;

/* Demo state lives in main only; it never touches L3Game directly and is
 * therefore absent from saves. target/leg/passed_detour are navigation
 * bookkeeping for the physical walk, never a teleport or state shortcut. */
typedef struct {
    unsigned active, stage, visits, presses;
    unsigned target, leg, passed_detour;
    float cooldown;
} L3VillageDemo;

/* Positions are (x,z) from ZONE.md; y always comes from world.height. */
L3Vec3 l3_village_site(const L3Game *g, unsigned site);
float l3_village_reach(void);
/* Closest site when the player is physically near and in region 0. Returns
 * -1 when none is in range. distance may be NULL. */
int l3_village_nearest(const L3Game *g, float *distance);
/* E interaction. Returns 1 when the site handled the press, 0 when the
 * player is out of range, in another region, or the game/state is invalid.
 * Refused calls never mutate the game. */
int l3_village_interact(L3Game *g, unsigned site);
int l3_village_view(const L3Game *g, L3VillageView *out);
/* Full invariant check used by saves; rejects tampered or non-finite state. */
int l3_village_state_ok(const L3Game *g);
int l3_village_reward_available(const L3Game *g);
/* Fresh optional quest, without touching the main story or position. */
void l3_village_reset(L3Game *g);
/* True only inside the authored region-0 rectangle, used for contextual HUD. */
int l3_village_in_zone(const L3Game *g);
const char *l3_village_objective(const L3Game *g);
const char *l3_village_prompt(const L3Game *g, unsigned site);
const char *l3_village_clue(unsigned site);
const char *l3_village_speaker(void);

/* Optional --village-demo support: produces the next real movement/input
 * command. main feeds it to l3_game_step, so walking, inertia and collision
 * stay in the existing engine; there is no teleport and no state shortcut. */
void l3_village_demo_init(L3VillageDemo *d);
int l3_village_demo_input(const L3Game *g, L3VillageDemo *d, L3Input *in,
                          float dt);
int l3_village_demo_done(const L3Game *g, const L3VillageDemo *d);

#endif
