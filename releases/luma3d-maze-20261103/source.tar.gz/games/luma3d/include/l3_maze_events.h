#ifndef L3_MAZE_EVENTS_H
#define L3_MAZE_EVENTS_H
#include "l3_maze_motion.h"
#include "l3_mini_trace.h"
/* Presentation only. Logical floor/rewards remain immediate and untouched. */
typedef struct {
 uint8_t floor[400],pending[400];double until[400],time;
 double life_until[3];
 uint32_t epoch;unsigned valid,collections,deferred,fallbacks;
} L3MazeEvents;
void l3_maze_events_reset(L3MazeEvents *);
int l3_maze_events_observe(L3MazeEvents *,const L3MazeMotion *,const uint8_t floor[400],const L3MiniTrace *,double,uint32_t);
int l3_maze_events_sample(const L3MazeEvents *,double,uint8_t floor[400]);
int l3_maze_events_pending(const L3MazeEvents *,double,unsigned *count);
int l3_maze_events_pending_lives(const L3MazeEvents *,double,unsigned *count);
#endif
