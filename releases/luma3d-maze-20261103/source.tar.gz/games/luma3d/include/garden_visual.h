#ifndef LUMA_GARDEN_VISUAL_H
#define LUMA_GARDEN_VISUAL_H
#include "luma3d_garden.h"
/* Private native renderer extension. Immutable meshes uploaded once into the
 * checked existing arena. Camera/animation remain live G3D1 transformations.
 * Mesh positions and UVs are geometry, never pre-rendered scene imagery. */
static const float garden_trees[][4]={
 {240,51,.65f,.2f},{250,49,.75f,1.2f},{261,53,.65f,.4f},
 {241,71,.80f,.6f},{252,72,.65f,2.2f},{261,73,.60f,-.6f}
};
typedef struct {gpu_geom_vertex v[256];gpu_geom_face f[512];unsigned nv,nf,overflow;} GardenMesh;
static int garden_vertex(GardenMesh *m,float x,float y,float z){
 if(m->nv>=256){m->overflow=1;return 0;}gpu_geom_vertex *v=&m->v[m->nv++];
 return gpu_geom_fixed(x,&v->x)&&gpu_geom_fixed(y,&v->y)&&gpu_geom_fixed(z,&v->z);
}
static void garden_face(GardenMesh *m,unsigned a,unsigned b,unsigned c,unsigned color){
 if(m->nf>=512){m->overflow=1;return;}gpu_geom_face *f=&m->f[m->nf++];
 f->words[0]=(3u<<24)|a|(b<<8)|(c<<16);
 f->words[1]=0;f->words[2]=127u<<16;f->words[3]=(127u<<16)|127u;
 L3Vec3 pa={m->v[a].x/65536.f,m->v[a].y/65536.f,m->v[a].z/65536.f};
 L3Vec3 pb={m->v[b].x/65536.f,m->v[b].y/65536.f,m->v[b].z/65536.f};
 L3Vec3 pc={m->v[c].x/65536.f,m->v[c].y/65536.f,m->v[c].z/65536.f};
 L3Vec3 normal=unit(cross(sub(pb,pa),sub(pc,pa)));
 /* All horizontal botanical sheets are viewed from above; wall winding
  * below points outward. Proper normals give masonry depth with one pass. */
 if(normal.y<-.5f)normal=(L3Vec3){-normal.x,-normal.y,-normal.z};
 int16_t nx=(int16_t)(normal.x*32767),ny=(int16_t)(normal.y*32767),nz=(int16_t)(normal.z*32767);
 f->words[4]=((uint32_t)(uint16_t)nx<<16)|(uint16_t)ny;f->words[5]=(uint16_t)nz;f->words[6]=color;
}
static void garden_quad(GardenMesh *m,L3Vec3 a,L3Vec3 b,L3Vec3 c,L3Vec3 d,unsigned color){
 unsigned n=m->nv;if(n+4>256||m->nf+2>512){m->overflow=1;return;}
 if(!garden_vertex(m,a.x,a.y,a.z)||!garden_vertex(m,b.x,b.y,b.z)||
 !garden_vertex(m,c.x,c.y,c.z)||!garden_vertex(m,d.x,d.y,d.z))return;
 garden_face(m,n,n+1,n+2,color);garden_face(m,n,n+2,n+3,color);
 m->f[m->nf-1].words[2]=(127u<<16)|127u;m->f[m->nf-1].words[3]=127u;
}
/* Axis-aligned structural boxes use precisely the local collision extents. */
static void garden_box(GardenMesh *m,float x0,float x1,float y0,float y1,float z0,float z1){
 L3Vec3 v[8]={{x0,y0,z0},{x1,y0,z0},{x1,y0,z1},{x0,y0,z1},
 {x0,y1,z0},{x1,y1,z0},{x1,y1,z1},{x0,y1,z1}};
 static const unsigned q[5][4]={{0,1,5,4},{1,2,6,5},{2,3,7,6},{3,0,4,7},{4,5,6,7}};
 for(unsigned i=0;i<5;i++)garden_quad(m,v[q[i][3]],v[q[i][2]],v[q[i][1]],v[q[i][0]],176u|(161u<<9)|(132u<<18));
}
static int garden_upload(L3Render *r,GardenMesh *m,unsigned slot){
 if(!m->nv||!m->nf||m->overflow)return 0;
 r->garden_geometry[slot]=(gpu_geom_mesh){upload(r,m->v,m->nv*sizeof(*m->v)),
 upload(r,m->f,m->nf*sizeof(*m->f)),m->nv,m->nf};return !r->failed;
}
static unsigned garden_color(unsigned r,unsigned g,unsigned b){return r|(g<<9)|(b<<18);}
static int garden_resources(L3Render *r,const L3Game *g){
 if(r->garden_ready)return 1;
 static const char *names[]={"blossom_low_budget","oak_low_budget","rock_far_budget","ruin_arch_low_budget"};
 for(unsigned k=0;k<4;k++){unsigned i;for(i=0;i<l3_asset_mesh_count;i++)if(!strcmp(names[k],l3_asset_meshes[i].name))break;
  if(i==l3_asset_mesh_count)return 0;r->garden_mesh[k]=i;}
 /* Texture the existing terrain instead of adding coplanar polygons.
  * The last Amber atlas maps [232,272]x[40,80] to [0,255]^2. Validate
  * every active face's UV mapping before touching the private GPU copy. */
 unsigned ti=~0u;
 for(unsigned i=0;i<l3_asset_texture_count;i++)if(!strcmp(l3_asset_textures[i].name,"amber_ground_1_1"))ti=i;
 if(ti==~0u||l3_asset_textures[ti].width!=256||l3_asset_textures[ti].height!=256)return 0;
 unsigned checked=0;
 for(unsigned k=0;k<l3_asset_group_count;k++){
  const L3AssetGroup *a=&l3_asset_groups[k];if(l3_asset_materials[a->material].texture_index!=ti)continue;
  for(unsigned f=0;f<a->nf;f++)for(unsigned j=0;j<3;j++){
   unsigned v=(a->faces[f*8]>>(j*8))&255;float x=(int32_t)a->vertices[v*8]/65536.f,z=(int32_t)a->vertices[v*8+2]/65536.f;
   int u=(int16_t)(a->faces[f*8+j+1]>>16),vv=(int16_t)a->faces[f*8+j+1];
   if(fabsf(u-(x-232)*255/40)>1.01f||fabsf(vv-(z-40)*255/40)>1.01f)return 0;checked++;
  }
 }if(!checked)return 0;
 uint16_t *dest=(uint16_t *)(r->memory+r->textures[ti]-PRODOCK_GPU_BASE);
 const uint16_t *original=l3_asset_textures[ti].pixels,*grass=l3_asset_textures[0].pixels;
 for(unsigned v=0;v<256;v++)for(unsigned u=0;u<256;u++){
  float x=232+u*(40.f/255),z=40+v*(40.f/255);
  float e1=(x-244)*(x-244)/81+(z-55)*(z-55)/81,e2=(x-254)*(x-254)/100+(z-66)*(z-66)/81;
  float a=fminf(1,fmaxf(0,(1-fminf(e1,e2))*5));
  float path=fminf(fabsf(z-53),fabsf(z-68));
  if(x>242&&x<246)path=fminf(path,fabsf(x-244));
  if(z>53&&z<68)path=fminf(path,fabsf(x-254));
  a*=fminf(1,fmaxf(0,(path-.55f)*1.4f));
  unsigned old=original[v*256+u];
  if(a<=0){dest[v*256+u]=(uint16_t)old;continue;} /* preserve every outside byte exactly */
  unsigned leaf=grass[((unsigned)(z*13)&127)*128+((unsigned)(x*13)&127)];
  unsigned rr=(old>>11)*255/31,gg=((old>>5)&63)*255/63,bb=(old&31)*255/31;
  unsigned gr=(unsigned)((leaf>>11)*255/31*.48f),ge=(unsigned)(((leaf>>5)&63)*255/63*.72f),bl=(unsigned)((leaf&31)*255/31*.48f);
  dest[v*256+u]=(uint16_t)rgb((unsigned)(rr*(1-a)+gr*a),(unsigned)(gg*(1-a)+ge*a),(unsigned)(bb*(1-a)+bl*a));
 }
 /* Raised stepping stones show the upper/lower loops without baking paths
  * into terrain or mutating the collision height. They are only 3cm thick. */
 GardenMesh m={0};
 for(unsigned side=0;side<2;side++)for(unsigned k=0;k<18;k++){
  float x=240+k*1.2f,z=side?68:53,h=g->world.height(g->world.context,x,z)+.055f;
  garden_quad(&m,(L3Vec3){x-.42f,h,z-.55f},(L3Vec3){x+.42f,h,z-.55f},
   (L3Vec3){x+.42f,h,z+.55f},(L3Vec3){x-.42f,h,z+.55f},garden_color(172,164,139));
 }if(!garden_upload(r,&m,4))return 0;
 /* Serre roof and side panes: transparent pass, depth tested, no Z writes.
  * Open sides maintain free walking; structural posts are solid in game.c. */
 m=(GardenMesh){0};float y=g->world.height(g->world.context,244,52)+2.8f;
 garden_quad(&m,(L3Vec3){241,y,49},(L3Vec3){244,y+1.3f,49},(L3Vec3){244,y+1.3f,55},(L3Vec3){241,y,55},garden_color(165,245,256));
 garden_quad(&m,(L3Vec3){244,y+1.3f,49},(L3Vec3){247,y,49},(L3Vec3){247,y,55},(L3Vec3){244,y+1.3f,55},garden_color(200,240,256));
 if(!garden_upload(r,&m,5))return 0;
 /* Individual luminous seed pools, same named gameplay sites. */
 m=(GardenMesh){0};for(unsigned i=2;i<5;i++){
  L3Vec3 p=l3_garden_site(g,i);float y0=p.y+.08f;
  garden_quad(&m,(L3Vec3){p.x-.7f,y0,p.z-.7f},(L3Vec3){p.x+.7f,y0,p.z-.7f},
   (L3Vec3){p.x+.7f,y0,p.z+.7f},(L3Vec3){p.x-.7f,y0,p.z+.7f},garden_color(230,210,256));
 }if(!garden_upload(r,&m,6))return 0;
 uint16_t halo[32*32];for(unsigned yy=0;yy<32;yy++)for(unsigned xx=0;xx<32;xx++){
  float dx=(xx-15.5f)/15.5f,dz=(yy-15.5f)/15.5f,a=fmaxf(0,1-dx*dx-dz*dz);
  halo[yy*32+xx]=(uint16_t)(((unsigned)(15*a*a)<<12)|0xcdf);}
 r->garden_halo_texture=upload(r,halo,sizeof halo);
 /* Correct halo UVs for the 32px texture, unlike terrain's 128px UVs. */
 for(unsigned i=0;i<m.nf;i++)for(unsigned j=1;j<4;j++){
  unsigned uv=m.f[i].words[j];m.f[i].words[j]=((uv>>16)?31u<<16:0)|(uv&65535?31:0);}
 /* Rewrite only this not-yet-submitted initial face bank; never per frame. */
 memcpy(r->memory+r->garden_geometry[6].faces-PRODOCK_GPU_BASE,m.f,m.nf*sizeof(*m.f));
 /* A continuous wall and separate reward gate, not a visual pile of
  * rocks with a different collision silhouette. Terrain height varies slowly. */
 m=(GardenMesh){0};
 for(unsigned i=0;i<2;i++){
  float z0=i?62.4f:55,z1=i?67:59.6f;
  /* Split along terrain grid boundaries so the wall is grounded throughout. */
  for(float z=z0;z<z1;z+=1){float end=fminf(z+1,z1),floor=g->world.height(g->world.context,248,(z+end)*.5f);
   garden_box(&m,247.65f,248.35f,floor-.3f,floor+1.8f,z,end);}
 }
 if(!garden_upload(r,&m,7))return 0;
 m=(GardenMesh){0};float floor=g->world.height(g->world.context,248,61);
 garden_box(&m,247.65f,248.35f,floor-.5f,floor+1.8f,59.6f,62.4f);
 if(!garden_upload(r,&m,8))return 0;
 m=(GardenMesh){0};for(unsigned i=0;i<4;i++){
  float x=l3_garden_posts[i][0],z=l3_garden_posts[i][1],floor=g->world.height(g->world.context,x,z);
  garden_box(&m,x-.15f,x+.15f,floor,floor+2.8f,z-.15f,z+.15f);
 }if(!garden_upload(r,&m,9))return 0;
 /* Twelve five-petal flowers, batched into one native mesh (192 faces
  * would be unnecessary here). Distinct coral/lavender/gold flower beds. */
 m=(GardenMesh){0};
 for(unsigned k=0;k<12;k++){
  unsigned bed=k/4;L3Vec3 center=l3_garden_site(g,bed+2);
  float x=center.x+((k&1)?1.0f:-1.0f),z=center.z+((k&2)?.6f:-.6f);
  float y0=g->world.height(g->world.context,x,z)+.85f;
  unsigned n=m.nv;garden_vertex(&m,x,y0,z);
  for(unsigned j=0;j<10;j++){float angle=j*.62831853f,rad=(j&1)?.21f:.60f;
   garden_vertex(&m,x+rad*cosf(angle),y0+((j&1)?-.08f:.08f),z+rad*sinf(angle));}
  unsigned color=bed==0?garden_color(245,130,165):bed==1?garden_color(256,216,100):garden_color(170,145,256);
  for(unsigned j=0;j<10;j++)garden_face(&m,n,n+1+j,n+1+(j+1)%10,color);
  garden_quad(&m,(L3Vec3){x-.035f,y0-.85f,z},(L3Vec3){x+.035f,y0-.85f,z},
   (L3Vec3){x+.035f,y0,z},(L3Vec3){x-.035f,y0,z},garden_color(60,155,70));
  garden_quad(&m,(L3Vec3){x-.42f,y0-.35f,z-.06f},(L3Vec3){x,y0-.25f,z-.13f},
   (L3Vec3){x+.42f,y0-.35f,z+.06f},(L3Vec3){x,y0-.25f,z+.13f},garden_color(70,185,88));
 }
 if(!garden_upload(r,&m,10))return 0;
 r->garden_ready=1;return !r->failed;
}
static int garden_native(L3Render *r,const L3Game *g,unsigned slot,unsigned texture,unsigned alpha,int blend){
 L3Vec3 rows[]={r->right,r->down,r->forward};gpu_geom_transform t;
 for(unsigned a=0;a<3;a++){
  if(!gpu_geom_fixed(rows[a].x,&t.values[a*4])||!gpu_geom_fixed(rows[a].y,&t.values[a*4+1])||
  !gpu_geom_fixed(rows[a].z,&t.values[a*4+2])||!gpu_geom_fixed(-dot(rows[a],g->camera.eye),&t.values[a*4+3]))return 0;
 }
 unsigned ambient=slot>=7&&slot<=9?160:256;
 L3Vec3 direction=l3_asset_light_direction;
 gpu_geom_light light={(int16_t)(direction.x*32767),(int16_t)(direction.y*32767),(int16_t)(direction.z*32767),ambient,256-ambient};
 gpu_material mat={.flags=1|2|16|(blend==1?32:blend==2?0:4),.alpha=alpha,.r=256,.g=256,.b=256};
 gpu_texture_level tex={texture,slot==6?32:128,slot==6?32:128,slot==6?64:256,slot==6?GPU_ARGB4444:GPU_RGB565,1,1,0};
 if(!gpu_geom_set_transform(&r->gpu,&t)||!gpu_geom_set_light(&r->gpu,&light)||!gpu_v1_material(&r->gpu,&mat)||
 !gpu_v1_texture(&r->gpu,&tex)||!gpu_geom_draw(&r->gpu,&r->garden_geometry[slot],0))return 0;
 r->draws++;r->triangles+=r->garden_geometry[slot].face_count;return !r->failed;
}
static int garden_environment(L3Render *r,const L3Game *g){
 if(g->story.region!=1)return 1;
 if(!garden_resources(r,g))return 0;
 if(hypotf(g->camera.eye.x-250,g->camera.eye.z-61)>65)return 1;
 if(!garden_native(r,g,4,r->textures[1],256,0)||!garden_native(r,g,10,r->textures[3],256,0))return 0;
 for(unsigned k=0;k<6;k++){
  L3Vec3 p={garden_trees[k][0],0,garden_trees[k][1]};p.y=g->world.height(g->world.context,p.x,p.z);
  float s=garden_trees[k][2],sway=.009f*sinf(g->time+k);
  if(!draw_ex(r,g,r->garden_mesh[k&1],p,(L3Vec3){s,s,s},garden_trees[k][3],0,sway,1))return 0;
 }
 if(!garden_native(r,g,7,r->textures[1],256,0))return 0;
 if(!g->garden_reward&&!garden_native(r,g,8,r->textures[5],256,0))return 0;
 if(!garden_native(r,g,9,r->textures[1],256,0))return 0;
 L3Vec3 arch={248,0,61};arch.y=g->world.height(g->world.context,248,61);
 if(!draw(r,g,r->garden_mesh[3],arch,(L3Vec3){.55f,.55f,.55f},1.5707963f,1))return 0;
 for(unsigned n=0;n<2;n++){
  L3Vec3 p=l3_garden_site(g,n);float yaw=atan2f(g->player.position.x-p.x,g->player.position.z-p.z);
  r->npc_character=n?1:0;r->tint[0]=n?230:200;r->tint[1]=n?210:256;r->tint[2]=256;
  if(hypotf(p.x-g->camera.eye.x,p.z-g->camera.eye.z)>22){r->npc_part=6;
   if(!draw(r,g,l3_asset_hero_mesh,p,(L3Vec3){1,1,1},yaw,1))return 0;
  }else for(unsigned i=0;i<l3_asset_hero_part_count;i++){
   const L3AssetPart *part=l3_asset_hero_parts+i;r->npc_part=(int)i;
   L3Vec3 pivot=object_point(part->pivot,(L3Vec3){1,1,1},yaw,p);
   if(!draw_ex(r,g,part->mesh_id,pivot,(L3Vec3){1,1,1},yaw,part->kind==3?.12f*sinf(g->time):0,0,1))return 0;
  }
 }
 r->npc_character=-1;r->tint[0]=r->tint[1]=r->tint[2]=256;
 for(unsigned i=2;i<6;i++){
  L3Vec3 p=l3_garden_site(g,i);p.y+=.8f+.10f*sinf(g->time*1.4f+i);
  float s=i==5?1.5f:.75f;
  if(i<5&&(g->garden_seeds&(1u<<(i-2))))continue;
  if(!draw(r,g,l3_asset_letter_mesh,p,(L3Vec3){s,s,s},g->time*.4f+i,1))return 0;
 }return !r->failed;
}
static int garden_transparent(L3Render *r,const L3Game *g){
 if(g->story.region!=1||!r->garden_ready||hypotf(g->camera.eye.x-250,g->camera.eye.z-61)>65)return 1;
 return garden_native(r,g,5,r->textures[6],75,2)&&garden_native(r,g,6,r->garden_halo_texture,
 (unsigned)(110+25*sinf(g->time*1.3f)),1);
}
#endif
