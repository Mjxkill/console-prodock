#ifndef L3_FESTIVAL_METRICS_H
#define L3_FESTIVAL_METRICS_H
#include "l3_festival.h"
#include <math.h>
#include <string.h>
enum {L3_ME_ENTRY,L3_ME_DEAL,L3_ME_REVEAL,L3_ME_HIDE,L3_ME_PAIR,L3_ME_WAIT,
      L3_ME_TABLE_ACTIVE,L3_ME_TABLE_WAIT,L3_ME_GARDEN,L3_ME_INVALID,L3_ME_PHASES};
typedef struct {
    unsigned frames,commands,batches;uint64_t bytes;
    double seconds,publish,simulation,prepare,submit,present,max_seconds;
} L3MeasureBucket;
typedef struct {
    L3MeasureBucket phase[L3_ME_PHASES];unsigned frames,invalid,seen,skipped;
    unsigned transition_seen[4],settled_seen[4],tail,tail_pages,tail_action,complete;
    unsigned last_frame;double seconds;
} L3FestivalMetrics;
static unsigned l3_metrics_phase(const L3Festival *f,unsigned page){
    if(!f||!f->active||page>1)return L3_ME_INVALID;
    if(f->kind==L3_FESTIVAL_MEMORY){
        const L3MemoryScene *m=&f->memory;
        if(!isfinite(m->elapsed)||!isfinite(m->duration)||m->duration<=0||m->elapsed<0||m->elapsed>m->duration||m->trace.count>4)return L3_ME_INVALID;
        if(!m->assets||!m->base_ready[page])return L3_ME_ENTRY;
        if(m->elapsed>=m->duration)return L3_ME_WAIT;
        unsigned p=L3_ME_INVALID;
        for(unsigned i=0;i<m->trace.count;i++)switch(m->trace.events[i].kind){
            case L3_MEMORY_DEAL:p=L3_ME_DEAL;break;
            case L3_MEMORY_REVEAL:p=L3_ME_REVEAL;break;
            case L3_MEMORY_HIDE:p=L3_ME_HIDE;break;
            case L3_MEMORY_PAIR:p=L3_ME_PAIR;break;
            /* VICTORY accompanies PAIR: do not hide the collection animation. */
            default:break;
        }
        return p;
    }
    if(!f->assets||(f->kind<4&&(!f->base_ready[page]||f->baked_kind!=f->kind))||(f->kind==4&&!f->geometry_ready))return L3_ME_ENTRY;
    if(f->kind==4)return L3_ME_GARDEN;
    return f->turns&&f->transition<1?L3_ME_TABLE_ACTIVE:L3_ME_TABLE_WAIT;
}
static unsigned l3_metrics_bits(const unsigned *v){unsigned n=0;for(unsigned i=0;i<4;i++){unsigned x=v[i];while(x){x&=x-1;n++;}}return n;}
static int l3_metrics_time(double t){return isfinite(t)&&t>=0;}
static void l3_metrics_observe(L3FestivalMetrics *s,const L3Festival *f,unsigned phase,unsigned frame,unsigned page,
    double elapsed,double sim,double prepare,double submit,double present,unsigned commands,unsigned batches,uint64_t bytes,double publish){
    if(!s||!f)return;
    if(phase>=L3_ME_INVALID||page>1||(s->frames&&frame!=s->last_frame+1)||
       !l3_metrics_time(elapsed)||elapsed<=0||!l3_metrics_time(sim)||!l3_metrics_time(prepare)||
       !l3_metrics_time(submit)||!l3_metrics_time(present)||!l3_metrics_time(publish)||publish>elapsed+.000001){s->invalid=1;return;}
    s->last_frame=frame;s->frames++;s->seconds+=elapsed;
    L3MeasureBucket *b=&s->phase[phase];b->frames++;b->seconds+=elapsed;b->commands+=commands;b->batches+=batches;b->bytes+=bytes;b->publish+=publish;
    b->simulation+=sim;b->prepare+=prepare;b->submit+=submit;b->present+=present;if(elapsed>b->max_seconds)b->max_seconds=elapsed;
    if(f->kind!=L3_FESTIVAL_MEMORY||!f->memory_sample_limit)return;
    const L3MemoryScene *m=&f->memory;
    if(m->actions>128||m->actions<s->seen||!isfinite(m->elapsed)||!isfinite(m->duration)||m->duration<=0){s->invalid=1;return;}
    if(m->actions>s->seen){s->skipped+=m->actions-s->seen-1;s->seen=m->actions;}
    if(m->actions){unsigned a=m->actions-1;if(m->elapsed<m->duration)s->transition_seen[a/32]|=1u<<(a%32);else s->settled_seen[a/32]|=1u<<(a%32);}
    unsigned done=(m->actions>=f->memory_sample_limit||m->view.phase==L3_MEMORY_WON)&&m->elapsed>=m->duration;
    if(done&&phase!=L3_ME_ENTRY){
        if(s->tail&&s->tail_action!=m->actions){s->tail=s->tail_pages=0;}
        s->tail_action=m->actions;s->tail++;s->tail_pages|=1u<<page;
    }else s->tail=s->tail_pages=0;
    s->complete=s->tail>=2&&s->tail_pages==3;
}
static int l3_metrics_memory_valid(const L3FestivalMetrics *s,const L3Festival *f){
    return !s->invalid&&s->complete&&f->active&&f->kind==L3_FESTIVAL_MEMORY&&f->automatic&&
      s->seen&&s->seen==f->memory.actions&&!s->skipped&&
      l3_metrics_bits(s->transition_seen)==s->seen&&l3_metrics_bits(s->settled_seen)==s->seen&&
      f->memory.page_valid[0]&&f->memory.page_valid[1]&&
      s->phase[L3_ME_REVEAL].commands+s->phase[L3_ME_HIDE].commands+s->phase[L3_ME_PAIR].commands>0;
}
static void l3_metrics_report(const L3FestivalMetrics *s,const L3Festival *f,const L3Render *r){
    static const char *names[]={"entry","deal","reveal","hide","pair","wait","table_active","table_wait","garden","invalid"};
    int rate_valid=!r->host&&!s->invalid&&!r->festival_measure_error;
    for(unsigned i=0;i<r->festival_asset_generation&&i<16;i++)printf("LUMA3D_SCENE_ASSETS mode=%u frame=%u asset_generation=%u preparation_seconds=%.9f published_bytes=%llu atlas_bytes=%llu atlas_publish_seconds=%.9f hardware=%d\n",
      r->festival_asset_events[i].mode,r->festival_asset_events[i].frame,i+1,r->festival_asset_events[i].seconds,
      (unsigned long long)r->festival_asset_events[i].bytes,(unsigned long long)r->festival_asset_events[i].atlas_bytes,r->festival_asset_events[i].atlas_seconds,!r->host);
    for(unsigned i=0;i<L3_ME_PHASES;i++){const L3MeasureBucket *b=&s->phase[i];if(!b->frames)continue;
        printf("LUMA3D_FESTIVAL_PHASE phase=%s frames=%u commands=%u batches=%u cpu_bytes=%llu cpu_publish_seconds=%.9f completion_seconds=%.9f simulation_seconds=%.9f preparation_seconds=%.9f submit_seconds=%.9f present_seconds=%.9f max_interval_ms=%.6f rate_valid=%d rate=%.6f hardware=%d\n",
          names[i],b->frames,b->commands,b->batches,(unsigned long long)b->bytes,b->publish,b->seconds,b->simulation,b->prepare,b->submit,b->present,b->max_seconds*1000,rate_valid,rate_valid&&b->seconds>0?b->frames/b->seconds:0,!r->host);
    }
    printf("LUMA3D_FESTIVAL_METRICS frames=%u invalid=%u publication_invalid=%u cpu_bytes=%llu hardware=%d\n",s->frames,s->invalid,r->festival_measure_error,(unsigned long long)r->festival_publish_bytes,!r->host);
    if(!f->memory_sample_limit)return;
    printf("LUMA3D_MEMORY_SAMPLE requested_actions=%u actions=%u transition_actions=%u settled_actions=%u skipped_actions=%u frames=%u tail=%u tail_pages=%u complete=%u invalid=%u publication_invalid=%u hardware=%d\n",
      f->memory_sample_limit,s->seen,l3_metrics_bits(s->transition_seen),l3_metrics_bits(s->settled_seen),s->skipped,s->frames,s->tail,s->tail_pages,s->complete,s->invalid,r->festival_measure_error,!r->host);
}
#endif
