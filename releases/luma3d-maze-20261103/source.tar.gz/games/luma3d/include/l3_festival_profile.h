#ifndef L3_FESTIVAL_PROFILE_H
#define L3_FESTIVAL_PROFILE_H
/* Aggregated CPU instrumentation for the festival render path.
 *
 * This module only measures. It never changes a pixel, a GPU command, a
 * rule or an animation. It is included by l3_festival.h and used by
 * games/luma3d/src/festival.c only.
 *
 * Rules implemented here (see CONTRACT.md):
 *  - the clock is read only while the profile is enabled. The renderer
 *    enables it only when ordinary metrics and cpu_profile_enabled are
 *    both set, so an explicitly OFF run performs no profiling clocks at
 *    all and leaves no trace;
 *  - every scope is exclusive: the own time of a scope is its wall time
 *    minus the wall time of the scopes it contains. The sum of the own
 *    times of the sections is therefore the wall time of the whole render
 *    and nothing is counted twice;
 *  - the feed time (the GPU submission) integrated in a scope is read from
 *    the renderer feed counter and subtracted, so the submission is never
 *    counted twice with the renderer buckets (prepare/submit/present);
 *  - a clock that returns a non finite value, a clock that goes backwards
 *    and a feed counter that goes backwards all mark the measurement as
 *    invalid: the summary then prints "nan" instead of a value that would
 *    look plausible.
 */
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

/* The measured sections, in the order of the render path. */
enum {
    L3_PROFILE_RENDER = 0,        /* the whole festival render */
    L3_PROFILE_ART,               /* atlas, chroma and background publication */
    L3_PROFILE_TABLE_VIEW,        /* the table view rebuilt for the frame */
    L3_PROFILE_POSITIONS,         /* the pose list of the table */
    L3_PROFILE_MOTION,            /* the card flight poses */
    L3_PROFILE_BOARD,             /* the whole board composition */
    L3_PROFILE_BOARD_DIFF,        /* the pose comparison and the damage bounds */
    L3_PROFILE_BOARD_COMMANDS,    /* the GPU command construction of the board */
    L3_PROFILE_GARDEN,            /* the 3D garden scene */
    L3_PROFILE_OVERLAY,           /* the whole indexed overlay */
    L3_PROFILE_OVERLAY_KEY,       /* the visible state key */
    L3_PROFILE_OVERLAY_RASTER,    /* the rasterisation of the overlay image */
    L3_PROFILE_OVERLAY_DELTA,     /* the damage scan and the span publication */
    L3_PROFILE_SECTIONS
};

/* The kinds of bytes that are counted. */
enum {
    L3_PROFILE_BYTES_SCANNED = 0, /* bytes compared by the damage scan */
    L3_PROFILE_BYTES_RASTERED,    /* bytes of the rasterised overlay image */
    L3_PROFILE_BYTES_PUBLISHED,   /* bytes written into the GPU memory */
    L3_PROFILE_BYTES_KINDS
};

/* Maximum number of scopes that may be open at the same time. */
#define L3_PROFILE_MAX_DEPTH 8
/* The stack also holds the refused scopes, so it is a little larger. */
#define L3_PROFILE_STACK_MAX 32
#define L3_PROFILE_NO_PARENT 0xFFFFFFFFu

typedef double (*L3ProfileClock)(void *ctx);

typedef struct {
    uint64_t calls;              /* number of measured calls */
    double gross_seconds;        /* wall time, children included */
    double seconds;              /* own wall time, children excluded */
    double feed_seconds;         /* own feed (submission) time */
    double gross_feed_seconds;   /* feed time, children included */
    uint64_t bytes_scanned, bytes_rastered, bytes_published, rebuilds;
    uint64_t invalid;            /* unusable measurements of this section */
} L3ProfileSection;

typedef struct {
    unsigned section;
    unsigned refused;            /* the scope was refused: it only pops */
    unsigned parent;             /* index of the enclosing scope */
    int clock_ok;                /* the clock gave a usable value */
    int invalid;                 /* a child scope was unusable */
    double start, feed_start;
    double child_seconds, child_feed;
    uint64_t bytes_scanned, bytes_rastered, bytes_published, rebuilds;
} L3ProfileFrame;

typedef struct {
    int enabled;                 /* the clock may be read */
    int requested;               /* the metrics were asked for at least once */
    L3ProfileClock clock;
    void *clock_ctx;
    unsigned top;                /* entries used in the stack */
    unsigned depth;              /* scopes that are really open */
    unsigned last_real;          /* index of the innermost open scope */
    unsigned pending;            /* refused scopes that did not fit the stack */
    unsigned invalid;            /* a measurement problem was seen */
    unsigned clock_errors;       /* unusable or backwards clock readings */
    unsigned range_errors;       /* refused scopes or unbalanced scopes */
    uint64_t frames;             /* measured frames */
    L3ProfileSection section[L3_PROFILE_SECTIONS];
    L3ProfileFrame stack[L3_PROFILE_STACK_MAX];
    uint64_t bytes_scanned, bytes_rastered, bytes_published, rebuilds;
    double seconds;              /* wall time of the frames */
    double feed_seconds;         /* feed time integrated in the frames */
} L3FestivalProfile;

/* ------------------------------------------------------------------ setup */

static inline void l3_profile_reset(L3FestivalProfile *p){
    if(!p)return;
    memset(p,0,sizeof(*p));
    p->last_real=L3_PROFILE_NO_PARENT;
}

static inline void l3_profile_enable(L3FestivalProfile *p,L3ProfileClock clock,void *ctx){
    if(!p)return;
    if(p->depth||p->top||p->pending){ /* a frame was left open: the accounting is broken */
        p->invalid=1;p->range_errors++;
        p->top=0;p->depth=0;p->pending=0;p->last_real=L3_PROFILE_NO_PARENT;
    }
    p->requested=1;p->enabled=1;p->clock=clock;p->clock_ctx=ctx;
}

static inline void l3_profile_disable(L3FestivalProfile *p){
    if(!p)return;
    p->enabled=0;
}

static inline int l3_profile_enabled(const L3FestivalProfile *p){
    return p&&p->enabled&&p->clock!=0;
}

/* ----------------------------------------------------------------- scopes */

static inline void l3_profile_begin(L3FestivalProfile *p,unsigned section,double feed_now){
    if(!p||!p->enabled||!p->clock)return;
    if(section>=L3_PROFILE_SECTIONS||p->depth>=L3_PROFILE_MAX_DEPTH){
        /* Refused: the scope is not measured, but the matching end stays
           harmless, so the stack of the caller stays balanced. */
        p->invalid=1;p->range_errors++;
        if(p->top<L3_PROFILE_STACK_MAX){
            L3ProfileFrame *fr=&p->stack[p->top++];
            memset(fr,0,sizeof(*fr));
            fr->section=section;fr->refused=1;fr->parent=L3_PROFILE_NO_PARENT;
        }else p->pending++;
        return;
    }
    if(p->top>=L3_PROFILE_STACK_MAX){p->invalid=1;p->range_errors++;p->pending++;return;}
    double t=p->clock(p->clock_ctx);
    int ok=isfinite(t)?1:0;
    if(!ok){p->clock_errors++;p->invalid=1;}
    L3ProfileFrame *fr=&p->stack[p->top];
    memset(fr,0,sizeof(*fr));
    fr->section=section;fr->refused=0;fr->clock_ok=ok;
    fr->start=ok?t:0;fr->feed_start=feed_now;
    fr->parent=p->last_real;
    p->top++;p->depth++;p->last_real=p->top-1;
}

static inline void l3_profile_end(L3FestivalProfile *p,double feed_now){
    if(!p||!p->enabled)return;
    /* A scope that did not fit the stack was only recorded as pending.
       Scopes are strictly LIFO, so such a scope is always more recent than
       every entry still on the stack: the matching end must consume it
       first. Popping a stack entry here would close an outer scope and
       unbalance the depth for the rest of the frame. */
    if(p->pending){p->pending--;return;}
    if(!p->top){
        /* Nothing left to close: an unbalanced call. */
        p->invalid=1;p->range_errors++;return;
    }
    L3ProfileFrame fr=p->stack[--p->top];
    if(fr.refused)return;
    p->depth--;
    p->last_real=fr.parent;
    L3ProfileSection *s=&p->section[fr.section];
    s->calls++;
    s->bytes_scanned+=fr.bytes_scanned;s->bytes_rastered+=fr.bytes_rastered;
    s->bytes_published+=fr.bytes_published;s->rebuilds+=fr.rebuilds;
    int ok=fr.clock_ok&&!fr.invalid;
    double t=0,gross=0,feed_gross=0,own=0,own_feed=0;
    if(ok){
        t=p->clock(p->clock_ctx);
        if(!isfinite(t)){ok=0;p->clock_errors++;}
    }
    if(ok){gross=t-fr.start;if(!(gross>=0)){ok=0;p->clock_errors++;}}
    if(ok){feed_gross=feed_now-fr.feed_start;if(!(feed_gross>=0)){ok=0;p->clock_errors++;}}
    if(ok){own=gross-fr.child_seconds;if(!(own>=0)){ok=0;p->clock_errors++;}}
    if(ok){own_feed=feed_gross-fr.child_feed;if(!(own_feed>=0)){ok=0;p->clock_errors++;}}
    if(ok&&own_feed>own+1e-6){ok=0;p->clock_errors++;}
    if(!ok){
        /* Nothing plausible is kept: the section stays unusable and the
           enclosing scopes are marked unusable too. */
        p->invalid=1;s->invalid++;
        if(fr.parent!=L3_PROFILE_NO_PARENT)p->stack[fr.parent].invalid=1;
        return;
    }
    s->gross_seconds+=gross;s->seconds+=own;
    s->gross_feed_seconds+=feed_gross;s->feed_seconds+=own_feed;
    if(fr.parent!=L3_PROFILE_NO_PARENT){
        L3ProfileFrame *parent=&p->stack[fr.parent];
        parent->child_seconds+=gross;parent->child_feed+=feed_gross;
    }else{
        p->frames++;
        p->seconds+=gross;p->feed_seconds+=feed_gross;
    }
}

/* --------------------------------------------------------------- counters */

static inline void l3_profile_bytes(L3FestivalProfile *p,unsigned kind,uint64_t bytes){
    if(!p||!p->enabled)return;
    if(kind>=L3_PROFILE_BYTES_KINDS){p->invalid=1;p->range_errors++;return;}
    if(p->last_real!=L3_PROFILE_NO_PARENT){
        L3ProfileFrame *fr=&p->stack[p->last_real];
        if(kind==L3_PROFILE_BYTES_SCANNED)fr->bytes_scanned+=bytes;
        else if(kind==L3_PROFILE_BYTES_RASTERED)fr->bytes_rastered+=bytes;
        else fr->bytes_published+=bytes;
    }
    if(kind==L3_PROFILE_BYTES_SCANNED)p->bytes_scanned+=bytes;
    else if(kind==L3_PROFILE_BYTES_RASTERED)p->bytes_rastered+=bytes;
    else p->bytes_published+=bytes;
}

static inline void l3_profile_rebuild(L3FestivalProfile *p){
    if(!p||!p->enabled)return;
    if(p->last_real!=L3_PROFILE_NO_PARENT)p->stack[p->last_real].rebuilds++;
    p->rebuilds++;
}

/* ---------------------------------------------------------------- report */

static inline const char *l3_profile_section_name(unsigned section){
    static const char *const names[L3_PROFILE_SECTIONS]={
        "render","art","table_view","positions","motion","board","board_diff",
        "board_commands","garden","overlay","overlay_key","overlay_raster","overlay_delta"};
    return section<L3_PROFILE_SECTIONS?names[section]:"unknown";
}

static inline void l3_profile_print_seconds(FILE *out,double value,int valid){
    if(!out)return;
    if(!valid||!isfinite(value)||value<0) fputs("nan",out);
    else fprintf(out,"%.9f",value);
}

static inline void l3_profile_report_to(const L3FestivalProfile *p,FILE *out){
    if(!p||!out||!p->requested)return;
    int total_valid=!p->invalid;
    uint64_t calls=0;
    for(unsigned i=0;i<L3_PROFILE_SECTIONS;i++){
        const L3ProfileSection *s=&p->section[i];
        calls+=s->calls;
        if(!s->calls)continue;
        int ok=s->invalid==0;
        double cpu=s->seconds-s->feed_seconds;
        if(cpu<0&&cpu>-1e-6)cpu=0;
        fprintf(out,"LUMA3D_FESTIVAL_PROFILE section=%s calls=%llu gross_seconds=",
                l3_profile_section_name(i),(unsigned long long)s->calls);
        l3_profile_print_seconds(out,s->gross_seconds,ok);
        fputs(" own_seconds=",out);
        l3_profile_print_seconds(out,s->seconds,ok);
        fputs(" feed_seconds=",out);
        l3_profile_print_seconds(out,s->feed_seconds,ok);
        fputs(" cpu_seconds=",out);
        l3_profile_print_seconds(out,cpu,ok);
        fprintf(out," bytes_scanned=%llu bytes_rastered=%llu bytes_published=%llu rebuilds=%llu invalid=%llu\n",
                (unsigned long long)s->bytes_scanned,(unsigned long long)s->bytes_rastered,
                (unsigned long long)s->bytes_published,(unsigned long long)s->rebuilds,
                (unsigned long long)s->invalid);
    }
    double cpu=p->seconds-p->feed_seconds;
    if(cpu<0&&cpu>-1e-6)cpu=0;
    fprintf(out,"LUMA3D_FESTIVAL_PROFILE_TOTAL frames=%llu calls=%llu seconds=",
            (unsigned long long)p->frames,(unsigned long long)calls);
    l3_profile_print_seconds(out,p->seconds,total_valid);
    fputs(" feed_seconds=",out);
    l3_profile_print_seconds(out,p->feed_seconds,total_valid);
    fputs(" cpu_seconds=",out);
    l3_profile_print_seconds(out,cpu,total_valid);
    fprintf(out," bytes_scanned=%llu bytes_rastered=%llu bytes_published=%llu rebuilds=%llu invalid=%u clock_errors=%u range_errors=%u\n",
            (unsigned long long)p->bytes_scanned,(unsigned long long)p->bytes_rastered,
            (unsigned long long)p->bytes_published,(unsigned long long)p->rebuilds,
            p->invalid,p->clock_errors,p->range_errors);
}

static inline void l3_profile_report(const L3FestivalProfile *p){
    l3_profile_report_to(p,stdout);
}

#endif
