#ifndef L3_FESTIVAL_SAMPLE_STATS_H
#define L3_FESTIVAL_SAMPLE_STATS_H
/* Optional diagnostic only. All durations are presentation completion intervals,
 * not the 60 Hz simulation clock. Pose deltas are not pixel-equivalence proofs. */
typedef struct {
    unsigned frames,active_frames,idle_frames,settled_frames,stable_tail;
    unsigned seen_actions,completed_actions,unseen_actions,commands,active_commands;
    unsigned pose_changes,active_pose_changes,old_n,complete;
    double seconds,active_seconds,max_active;
    L3FestivalPose old[256];
} L3FestivalSample;
static void l3_sample_observe(L3FestivalSample *s,const L3Festival *f,double seconds,unsigned commands){
    unsigned animated=f->turns&&f->transition<1;
    if(f->turns>s->seen_actions){s->unseen_actions+=f->turns-s->seen_actions-1;s->seen_actions=f->turns;}
    if(f->turns&&f->transition>=1)s->completed_actions=f->turns;
    unsigned changes=0;
    for(unsigned i=0;i<f->poses_n;i++)for(unsigned j=0;j<s->old_n;j++)if(f->poses[i].id==s->old[j].id){
        const L3FestivalPose *a=&f->poses[i],*b=&s->old[j];
        if(a->x!=b->x||a->y!=b->y||a->w!=b->w||a->h!=b->h||a->texture!=b->texture||a->alpha!=b->alpha)changes++;
        break;
    }
    s->pose_changes+=changes;s->frames++;s->seconds+=seconds;s->commands+=commands;
    if(animated){s->active_frames++;s->active_seconds+=seconds;s->active_commands+=commands;s->active_pose_changes+=changes;if(seconds>s->max_active)s->max_active=seconds;}
    else if(f->turns)s->settled_frames++;else s->idle_frames++;
    memcpy(s->old,f->poses,f->poses_n*sizeof(*f->poses));s->old_n=f->poses_n;
    if((f->turns>=f->sample_limit||f->view.status)&&f->transition>=1)s->stable_tail++;else s->stable_tail=0;
    s->complete=s->stable_tail>=2;
}
static int l3_sample_valid(const L3FestivalSample *s,const L3Festival *f,unsigned kind){
    return s->complete&&f->active&&f->kind==kind&&f->automatic&&s->seen_actions&&
        s->completed_actions==s->seen_actions&&!s->unseen_actions&&s->active_frames&&s->active_commands;
}
static void l3_sample_report(const L3FestivalSample *s,const L3Festival *f,int hardware){
    printf("LUMA3D_FESTIVAL_SAMPLE kind=%u requested_actions=%u actions=%u completed_actions=%u unseen_actions=%u frames=%u active_frames=%u idle_frames=%u settled_frames=%u stable_tail=%u seconds=%.6f active_seconds=%.6f active_fps=%.3f max_active_ms=%.3f commands=%u active_commands=%u pose_changes=%u active_pose_changes=%u complete=%u status=%u hardware=%d\n",
        f->kind,f->sample_limit,s->seen_actions,s->completed_actions,s->unseen_actions,s->frames,s->active_frames,s->idle_frames,s->settled_frames,s->stable_tail,s->seconds,s->active_seconds,s->active_seconds?s->active_frames/s->active_seconds:0,s->max_active*1000,s->commands,s->active_commands,s->pose_changes,s->active_pose_changes,s->complete,f->view.status,hardware);
}
#endif
