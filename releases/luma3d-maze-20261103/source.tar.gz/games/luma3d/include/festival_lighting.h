#ifndef FESTIVAL_LIGHTING_H
#define FESTIVAL_LIGHTING_H
#include <math.h>
#include <stdint.h>

/* Derived from Beam's isolated implementation proposal; audited integration.
   Pure coefficients, no allocation, no GPU access or new texture. */
typedef struct { uint16_t r,g,b,alpha; } FestivalLightingLamp;
static inline float festival_lighting_unit(float x){
    return isfinite(x)?fminf(1,fmaxf(0,x)):0;
}
static inline float festival_lighting_step(float current,unsigned night,float dt){
    current=festival_lighting_unit(current);
    if(!isfinite(dt)||dt<=0)return current;
    float weight=1-expf(-1.5f*fminf(dt,.1f));
    return festival_lighting_unit(current+((night?1.0f:0)-current)*weight);
}
static inline FestivalLightingLamp festival_lighting_lamp(unsigned lamp,float mood,float time){
    mood=festival_lighting_unit(mood);
    float t=isfinite(time)&&time>=0?time:0;
    float phase=fmodf(t*.31f,6.283185307f)+.31f*(lamp%4+1)+1.37f*(lamp%4);
    float amp=.94f+.06f*sinf(phase),energy=(.35f+.65f*mood)*amp;
    return (FestivalLightingLamp){(uint16_t)lroundf((212+43*mood)*amp),
        (uint16_t)lroundf((176+8*mood)*amp),(uint16_t)lroundf((136-44*mood)*amp),
        (uint16_t)lroundf(70+170*energy)};
}
#endif
