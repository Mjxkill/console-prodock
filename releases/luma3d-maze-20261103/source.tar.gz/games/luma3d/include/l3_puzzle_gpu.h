#ifndef L3_PUZZLE_GPU_H
#define L3_PUZZLE_GPU_H
#include "l3_puzzle_motion.h"
#include "gpu_v1.h"
typedef struct {
    unsigned native_width,native_height,cell,board_x,board_y,board_width,board_height;
    unsigned window_x,window_y,window_width,window_height;
} L3PuzzleLayout;
typedef struct {
    gpu_target background; /* immutable RGB565 window, aligned, COPY source */
    gpu_texture_level bodies,shadow; /* RGB565 key0 / ARGB4444 */
    unsigned uv_x[16],uv_y[16],body_width,body_height;
} L3PuzzleGpuAssets;
typedef struct {unsigned quads,body_quads,shadow_quads,copy_pixels,cpu_uploaded_bytes;} L3PuzzleGpuStats;
/* Exact R6 board layout plus an eight-pixel effect margin and x aligned16.
 * Width may exceed512; V1 target/COPY limit is1024x512, textures512x512. */
int l3_puzzle_gpu_layout(unsigned native_width,unsigned native_height,unsigned kind,L3PuzzleLayout *);
/* Emit only actual V1 commands. No framebuffer painting or asset upload.
 * page/depth are full native-page addresses, pitch is native byte stride.
 * The caller supplies scene.format=3 and a transparent indexed window.
 * This path stays RGB565 at rest; its palette quantization must be reported. */
int l3_puzzle_gpu_draw(gpu_v1_context *,const L3PuzzleLayout *,const L3PuzzleGpuAssets *,
                       const L3MotionFrame *,uint32_t page,uint32_t depth,
                       unsigned pitch,L3PuzzleGpuStats *);
#endif
