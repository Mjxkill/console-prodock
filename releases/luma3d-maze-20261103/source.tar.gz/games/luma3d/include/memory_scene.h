#ifndef L3_MEMORY_SCENE_H
#define L3_MEMORY_SCENE_H
#include "l3_memory.h"
#include "luma3d_render.h"
typedef struct {int id,tile,atlas;float x,y,w,h,alpha;} L3MemoryPose;
typedef struct {
 L3Memory game;L3MemoryView view;L3MemoryTrace trace;
 L3MemoryPose old[31],poses[31],pages[2][31];
 unsigned old_n,poses_n,page_n[2],page_valid[2],base_ready[2];
 unsigned assets,asset_w,asset_h,revision,ui_revision[2],cursor,automatic,escape,exit_requested;
 unsigned actions,reveals,pairs,mismatches,rounds;
 float elapsed,duration,wait;uint8_t *ui;uint16_t *background;
} L3MemoryScene;
int l3_memory_scene_init(L3MemoryScene *,uint32_t seed,int automatic);
void l3_memory_scene_close(L3MemoryScene *);
/* Call after another mode has overwritten the reserved GPU regions. Does not
 * modify the game. The next draw republishes textures/background and pages. */
void l3_memory_scene_invalidate(L3MemoryScene *);
/* Every accepted action goes through the same rules; animation/hold rejects
 * impatient actions. Navigation does not alter the rules or remembered cards. */
int l3_memory_scene_action(L3MemoryScene *,L3MemoryAction);
void l3_memory_scene_step(L3MemoryScene *,float dt);
void l3_memory_scene_key(L3MemoryScene *,int key);
void l3_memory_scene_poses(L3MemoryScene *);
/* Restore uses the separate MRY1 codec, commits only on success, and starts
 * from a settled public state. It never changes any Festival/GM1 save. */
int l3_memory_scene_restore(L3MemoryScene *,const void *,size_t);
/* Uses a caller-owned L3Render mapping/palette and frame counter. No IO or
 * present ioctl here. Full restore is an oracle/debug mode, not a second
 * rendering implementation. Caller must wait for GPU completion before reuse. */
int l3_memory_scene_render(L3Render *,L3MemoryScene *,struct prodock_scene *,int full_restore);
#endif
