#ifndef L3_MEMORY_PROGRESS_H
#define L3_MEMORY_PROGRESS_H
#include "l3_memory.h"
/* Separate MMP1 envelope (152 bytes) around unchanged MRY1 game state. */
typedef struct {L3Memory game;unsigned visited;} L3MemoryProgress;
int l3_memory_progress_load(L3MemoryProgress *,const char *);
int l3_memory_progress_save(const L3MemoryProgress *,const char *);
#endif
