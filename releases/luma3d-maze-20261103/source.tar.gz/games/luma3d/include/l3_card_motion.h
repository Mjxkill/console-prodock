#ifndef L3_CARD_MOTION_H
#define L3_CARD_MOTION_H
#include "l3_table.h"
/* L3FestivalPose moved out of l3_festival.h into this owned header so the
 * festival and the card-flight module share exactly one definition. */
typedef struct {int id,texture,chroma;float x,y,w,h,alpha;} L3FestivalPose;

/* Card-flight presentation (candidate-owned) for FC1 card tables:
 * kind 1 = solitaire, kind 2 = chroma. All coordinates are logical 800x400
 * pixels; the renderer scales per profile. Presentation only: the module
 * reads public view/trace and the sanitized target, never state storage,
 * never allocates, keeps no pointer into the caller.
 * Secrecy: a draw into a hidden seat (chroma player != 0) always travels as
 * the public back placeholder 400+player*108+slot with texture 52 and
 * chroma 0; the trace value of such an event is never read, so poisoning
 * those secret ids produces strictly identical poses and pixels. */
/* SHOWN is the existing displayed-pose bound (256). Flights are bounded by
 * the same number, so a full public hand (chroma allows 90 cards) can reflow
 * continuously without malloc and without dropping the tail. */
enum {L3CM_FLIGHTS=256,L3CM_SHOWN=256};

typedef struct {
    int id;              /* id under which the target view shows the card */
    L3FestivalPose from; /* copy of the really displayed pose */
    L3FestivalPose to;   /* exact destination pose, filled from a target */
    unsigned seen;       /* destination pose already observed in a target */
    unsigned hidden;     /* seat is hidden: stay a back card, never reveal */
    float delay;         /* departure offset from begin, in seconds */
} L3CardFlight;

typedef struct {
    unsigned pending;    /* flights still in the air after the last step */
    unsigned kind;       /* 1 solitaire, 2 chroma, 0 idle/non card table */
    unsigned deal;       /* begin() ran in deal mode (enter) */
    unsigned spawned;    /* one-shot target-based spawn already ran */
    float age;           /* seconds since begin */
    L3TableView before;  /* copy of the previous public view (sanitized) */
    L3FestivalPose shown[L3CM_SHOWN]; /* copies of really displayed poses */
    unsigned shown_n;
    L3CardFlight flights[L3CM_FLIGHTS];
    unsigned flight_n;
} L3CardMotion;

void l3_card_motion_reset(L3CardMotion *);
void l3_card_motion_begin(L3CardMotion *, unsigned kind, const L3FestivalPose *, unsigned, const L3TableView *, const L3TableTrace *, int deal);
void l3_card_motion_step(L3CardMotion *, float dt);
void l3_card_motion_apply(L3CardMotion *, unsigned kind, L3FestivalPose *, unsigned *count, unsigned capacity);
#endif
