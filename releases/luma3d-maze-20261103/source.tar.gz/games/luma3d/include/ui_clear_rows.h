#ifndef L3_UI_CLEAR_ROWS_H
#define L3_UI_CLEAR_ROWS_H

/* The includer owns ui_damage_rows.h: it must be included first. */
#ifndef L3_UI_DAMAGE_ROWS_H
#error "ui_clear_rows.h requires ui_damage_rows.h to be included first"
#endif

/* ---- bounded canvas clear (candidate) ----------------------------------
 *
 * Why this exists
 *   The festival overlay raster used to erase the whole CPU canvas with
 *   memset(canvas, 0, width * height) although ui_damage_rows.h already
 *   records the conservative set of rows that may still hold an old byte
 *   (L3UiDamageRows.footprint).  Every raster operation of the overlay
 *   marks the rows it touches, so all bytes outside that footprint are
 *   already zero.  Erasing only the footprint therefore produces exactly
 *   the same canvas as the full memset, with far fewer bytes written.
 *   The CPU canvas is not VRAM: no GPU state is touched here.
 *
 * Include contract
 *   The includer must include ui_damage_rows.h before this header; the
 *   type L3UiDamageRows and the constant L3_UI_DAMAGE_ROWS_MAX come from
 *   there and are deliberately not included again (the producer owns that
 *   header and its include path).
 *
 * Caller preconditions
 *   - canvas points to at least width * height writable bytes.  It is the
 *     indexed CPU canvas of the overlay: row pitch is exactly width, row
 *     y starts at canvas + y * width.  The helper never allocates, never
 *     resizes, never frees and never reads the canvas.
 *   - the footprint of the given rows describes every row that may still
 *     contain a nonzero old byte, i.e. bytes outside the footprint are
 *     already zero.  This is the invariant of the raster producer.
 *   - rows is a live, quiescent state: it is not being built (building is
 *     cleared) and its height matches the canvas height.
 *
 * Behaviour
 *   - Fallback (full clear): rows == NULL, !rows->valid, rows->building,
 *     rows->height != height, or height > L3_UI_DAMAGE_ROWS_MAX.  In these
 *     cases the complete canvas is cleared, because an unknown or in
 *     flight footprint must never leave stale bytes behind.  The helper
 *     returns width * height in that case.
 *   - Bounded clear: only the marked rows are cleared.  Adjacent marked
 *     rows are merged into one memset; disjoint runs are cleared one by
 *     one.  Rows outside the footprint are never written, so bytes that
 *     are already zero stay untouched and the result is identical to the
 *     full memset under the caller precondition above.
 *   - The rows state is read only: footprint, dirty masks, full flags and
 *     the valid/building/height fields are never modified.  In particular
 *     the helper does not erase the footprint and does not touch the
 *     pending per page masks: the caller decides what happens next.
 *
 * Zero size
 *   width == 0 or height == 0 means the canvas has no byte at all.  The
 *   helper returns 0 and issues no memset, so a null canvas pointer is
 *   harmless in that case.  A canvas whose byte count is not representable
 *   in size_t is refused as well (nothing is cleared, 0 is returned); the
 *   caller precondition excludes that case.
 *
 * Return value
 *   The exact number of bytes cleared, as size_t: width * height for a
 *   full clear, and the sum of the cleared rows times width otherwise.
 *
 * The helper performs no I/O, no allocation and no timing.
 */

#include <stddef.h>
#include <stdint.h>
#include <string.h>

static inline size_t l3_ui_clear_rows(uint8_t *canvas, unsigned width,
                                      unsigned height,
                                      const L3UiDamageRows *rows)
{
    if (!width || !height) return 0;              /* nothing to clear */
    if ((size_t)height > SIZE_MAX / (size_t)width) return 0; /* impossible canvas */
    const size_t total = (size_t)width * (size_t)height;
    if (!canvas) return 0;                        /* defensive: no buffer */
    if (!rows || !rows->valid || rows->building ||
        rows->height != height || height > L3_UI_DAMAGE_ROWS_MAX) {
        memset(canvas, 0, total);                 /* unknown footprint */
        return total;
    }
    size_t cleared = 0;
    unsigned y = 0;
    while (y < height) {
        if (!rows->footprint[y]) { y++; continue; }
        unsigned first = y;
        while (y < height && rows->footprint[y]) y++;
        const size_t bytes = (size_t)(y - first) * (size_t)width;
        memset(canvas + (size_t)first * (size_t)width, 0, bytes);
        cleared += bytes;
    }
    return cleared;
}

#endif /* L3_UI_CLEAR_ROWS_H */
