#ifndef LUMA3D_GARDEN_H
#define LUMA3D_GARDEN_H
#include "luma3d_game.h"
/* Sites are metres in region1. State is explicit, independent of the courier
 * and firefly missions. Existing Simon victory is accepted, never erased. */
enum { L3_GARDEN_FIRST=80, L3_GARDEN_SITES=6 };
extern const float l3_garden_posts[4][2];
L3Vec3 l3_garden_site(const L3Game *,unsigned);
int l3_garden_nearest(const L3Game *);
int l3_garden_interact(L3Game *,unsigned);
int l3_garden_state_ok(const L3Game *);
int l3_garden_blocked(const L3Game *,float,float,float,float,float);
int l3_garden_in_zone(const L3Game *);
const char *l3_garden_objective(const L3Game *);
const char *l3_garden_prompt(const L3Game *,unsigned);
const char *l3_garden_dialogue(const L3Game *);
/* The shortcut has exactly this physical/visual extent. */
#define L3_GARDEN_GATE_X 248.0f
#define L3_GARDEN_GATE_Z 61.0f
#endif
