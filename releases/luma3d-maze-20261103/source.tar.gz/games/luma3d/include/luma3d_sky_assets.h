#ifndef LUMA3D_SKY_ASSETS_H
#define LUMA3D_SKY_ASSETS_H
#include <stddef.h>
/* One immutable CPU copy shared by festival and world. Each renderer still
 * owns its existing GPU reservation and upload lifetime. Sizes are bytes;
 * mesh counts are native GPU vertices/faces. The archived generated asset
 * header is included only by sky_assets.c, never by a renderer. */
typedef struct {
    const void *texture, *vertices, *faces;
    size_t texture_bytes, vertices_bytes, faces_bytes;
    unsigned vertex_count, face_count;
} L3SkyAssets;
extern const L3SkyAssets l3_sky_assets;
#endif
