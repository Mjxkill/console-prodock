#ifndef LUMA3D_ACTIVITIES_H
#define LUMA3D_ACTIVITIES_H
#include "luma3d_game.h"
#define L3_MINI_RESTART L3_ARCADE_RESTART
#define L3_ACTIVITY_FIRST_SITE 16
L3Vec3 l3_activity_site(const L3Game *, unsigned kind);
int l3_activity_enter(L3Game *, unsigned kind);
void l3_activity_step(L3Game *, const L3Input *, float dt);
int l3_activities_valid(const L3Game *);
const char *l3_activity_name(unsigned kind);
const char *l3_activity_reward(unsigned kind);
int l3_activity_won(const L3Game *, unsigned kind);
uint32_t l3_activity_id(unsigned kind);
#endif
