#ifndef FESTIVAL_HUD_PANEL_H
#define FESTIVAL_HUD_PANEL_H
#include <stddef.h>
#include <stdint.h>
#include <string.h>

/* Same palette, clipping, cut corners and precedence as the original panel.
 * Bounds remain int64_t for x/y near INT_MIN/MAX. Once a row is clipped,
 * memset handles its contiguous interior; no wide arithmetic per pixel.
 * This private helper receives cut=1..3 and bounds derived from int x/y plus
 * at most 16384 pixels. All additions/subtractions below therefore fit int64.
 */
static inline void festival_hud_panel_shape(
    uint8_t *pixels, unsigned width, unsigned height,
    int64_t left, int64_t top, int64_t right, int64_t bottom,
    int64_t cut, uint8_t base, uint8_t top_color, uint8_t bottom_color)
{
    if (!pixels || right <= left || bottom <= top) return;
    int64_t y0=top<0?0:top, y1=bottom>(int64_t)height?height:bottom;
    for (int64_t y=y0;y<y1;y++) {
        int64_t inset=0,dt=y-top,db=bottom-1-y;
        if(dt<cut)inset=cut-dt;
        if(db<cut && cut-db>inset)inset=cut-db;
        int64_t lo=left+inset,hi=right-inset;
        if(lo<0)lo=0;
        if(hi>(int64_t)width)hi=width;
        if(lo>=hi)continue;
        uint8_t *row=pixels+(size_t)y*width;
        uint8_t color=y==top?top_color:y==bottom-1?bottom_color:base;
        memset(row+(size_t)lo,color,(size_t)(hi-lo));
        /* Top/left wins over bottom/right, including one-pixel rectangles. */
        if(left>=lo && left<hi)row[(size_t)left]=top_color;
        if(y!=top && right-1!=left && right-1>=lo && right-1<hi)
            row[(size_t)(right-1)]=bottom_color;
    }
}

static inline void festival_hud_panel(
    uint8_t *pixels,unsigned width,unsigned height,int x,int y,int w,int h)
{
    if(!pixels || w<=0 || h<=0 || w>16384 || h>16384 ||
       !((width==800u && height==480u)||(width==1280u && height==720u)))return;
    int64_t left=x,top=y,right=left+w,bottom=top+h;
    festival_hud_panel_shape(pixels,width,height,left+2,top+2,right+2,bottom+2,3,65,65,65);
    festival_hud_panel_shape(pixels,width,height,left,top,right,bottom,3,77,78,76);
    festival_hud_panel_shape(pixels,width,height,left+1,top+1,right-1,bottom-1,2,67,68,67);
    festival_hud_panel_shape(pixels,width,height,left+2,top+2,right-2,bottom-2,1,66,66,66);
}
#endif
