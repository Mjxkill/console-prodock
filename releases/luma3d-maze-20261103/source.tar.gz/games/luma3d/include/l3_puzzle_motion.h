#ifndef L3_PUZZLE_MOTION_H
#define L3_PUZZLE_MOTION_H
#include "l3_minigames.h"

/* Presentation only; never encoded with game saves. All coordinates are in
 * Q16 board cells and alpha/scale in Q8 (256=opaque/unit). Each event follows
 * one real engine step, including no-render steps. No engine data is changed.
 * The integration owns this context and must invalidate on enter/exit/load. */
#define L3_MOTION_QUEUE 8u
#define L3_MOTION_TRACKS 128u
#define L3_MOTION_POSES 160u
enum { L3_MOTION_KEEP, L3_MOTION_SLIDE, L3_MOTION_MERGE,
       L3_MOTION_SPAWN, L3_MOTION_CLEAR, L3_MOTION_GHOST };
enum { L3_MOTION_EVENT_MERGE, L3_MOTION_EVENT_PIECE, L3_MOTION_EVENT_LOCK };
enum { L3_MOTION_INVALID=-1, L3_MOTION_UNCHANGED=0,
       L3_MOTION_ANIMATED=1, L3_MOTION_SNAPPED=2 };
typedef struct {
    int16_t from_x,from_y,via_x,via_y,to_x,to_y;
    uint16_t value,result_value;
    uint8_t color,result_color,kind,active;
} L3MotionTrack;
typedef struct {
    L3MiniView before,after;
    L3MotionTrack tracks[L3_MOTION_TRACKS];
    unsigned count,kind,duration_ms;
    double start;
} L3MotionEvent;
typedef struct {
    L3MotionEvent queue[L3_MOTION_QUEUE];
    L3MiniView latest,settled;
    double last_time;
    uint32_t epoch;
    unsigned head,count,valid;
    unsigned observations,events,overflows,discontinuities,unsupported;
} L3PuzzleMotion;
typedef struct {
    int32_t x_q16,y_q16;
    uint16_t value,alpha_q8,scale_q8;
    uint8_t color,kind,active,reserved;
} L3MotionPose;
typedef struct {
    /* Render immutable board wells and HUD from logical, then these poses.
     * At rest, settled=1: compose cached original R6 tile/cell patches for
     * exact pixels. Never call the full R6 raster at every completed move.
     * During motion, erase moving pieces from the cached background once;
     * the GPU restores dirty rectangles, blends shadows/ghosts, draws bodies.
     * No claim that an indexed layer provides fractional alpha. */
    L3MiniView logical;
    L3MotionPose poses[L3_MOTION_POSES];
    unsigned count,settled,event_kind,progress_q16;
} L3MotionFrame;

void l3_puzzle_motion_reset(L3PuzzleMotion *context);
/* Time must be finite, nonnegative and monotone across observe/sample.
 * Epoch or view discontinuity snaps to the actual after view. A full queue
 * also snaps and counts overflow: visual history may drop, game inputs never.
 * Other game kinds snap for now; this first lot covers 1024 and blocks only.
 * The caller supplies the same pressed/held used by the real engine step. */
int l3_puzzle_motion_observe(L3PuzzleMotion *,const L3MiniView *before,
                            const L3MiniView *after,uint32_t pressed,
                            uint32_t held,double monotone_seconds,uint32_t epoch);
int l3_puzzle_motion_sample(L3PuzzleMotion *,double monotone_seconds,L3MotionFrame *);
#endif
