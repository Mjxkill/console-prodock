#ifndef LUMA3D_SURFACE_H
#define LUMA3D_SURFACE_H
/* Canonical walk surface: actual packed LOD0 triangles, with a conservative
 * 2 m spatial index. No GPU uploads or additional mesh geometry. */
float l3_surface_ground(float x,float z);
int l3_surface_bridge(float x,float z,float radius,float *deck);
/* The renderer must select the canonical surface within 3.05 m of the player.
 * Far LODs remain visual approximations; never use them for movement. */
int l3_surface_near(unsigned instance,float x,float z);
#endif
