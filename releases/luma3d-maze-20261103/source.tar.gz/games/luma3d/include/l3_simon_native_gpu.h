#ifndef L3_SIMON_NATIVE_GPU_H
#define L3_SIMON_NATIVE_GPU_H
#include "l3_simon_gpu.h"
typedef struct {unsigned width,height,x,y,w,h,scale_num,scale_den;} L3SimonNativeLayout;
int l3_simon_native_layout(unsigned,unsigned,L3SimonNativeLayout *);
int l3_simon_native_assets(const L3SimonNativeLayout *,L3SimonGpuAssets *);
int l3_simon_native_draw(gpu_v1_context *,const L3SimonNativeLayout *,const L3SimonGpuAssets *,const L3SimonLightFrame *,uint32_t page,uint32_t depth,unsigned *quads);
#endif
