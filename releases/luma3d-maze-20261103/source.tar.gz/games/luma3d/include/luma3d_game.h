#ifndef LUMA3D_GAME_H
#define LUMA3D_GAME_H

#include <stdint.h>
#include "luma3d_arcade_core.h"

/* Metres, X east / Y up / Z south. Yaw 0 faces +Z; angles in radians.
 * The renderer and collision query must use the SAME terrain triangles.
 * All pointed-to world data must outlive L3Game. No graphics dependencies. */
typedef struct { float x, y, z; } L3Vec3;

enum {
    L3_JUMP = 1u << 0,
    L3_SPRINT = 1u << 1,
    L3_INTERACT = 1u << 2,
    L3_TOGGLE_AUTO = 1u << 3,
    L3_JOURNAL = 1u << 4
};

typedef struct {
    /* Camera relative: W = move_z +1, D = move_x +1. Clamp to [-1,1].
     * look_x/y are angular input rates, not per-frame mouse deltas.
     * Positive look_x turns right: right=cross(forward,world_up).
     * pressed contains edges; held contains continuously held buttons. */
    float move_x, move_z, look_x, look_y;
    uint32_t pressed, held;
    uint32_t mini_pressed, mini_held;
} L3Input;

typedef float (*L3HeightQuery)(void *context, float x, float z);
/* Closed solid capsule test. y is feet; radius and height are metres.
 * Include buildings and impassable deep water; include bridge surfaces in
 * height(), not as full-height solid boxes. Camera calls use height .4. */
typedef int (*L3BlockedQuery)(void *context, float x, float y, float z,
                            float radius, float height);

typedef struct {
    void *context;
    L3HeightQuery height;
    L3BlockedQuery blocked;
    float min_x, max_x, min_z, max_z;
    L3Vec3 spawn;
    float spawn_yaw;
    const L3Vec3 *route;
    uint32_t route_count;
    const L3Vec3 *collectibles;
    uint32_t collectible_count; /* 0..32. Index is stable for this slice. */
    L3Vec3 goal;
    float goal_radius; /* <=0 defaults to 2.5 m. All collectibles required. */
} L3World;

typedef struct {
    L3Vec3 position, velocity; /* position at feet */
    float yaw, speed, walk_phase;
    int grounded;
} L3Player;

typedef struct {
    L3Vec3 eye, target;
    float yaw, pitch, distance;
} L3Camera;

typedef struct {
    unsigned phase, relay_step, discovered, wrong_sequences;
    int dialogue, page, journal, nearest;
    float dialogue_time, toast_time;
    unsigned toast, revision;
    unsigned workshop_phase, wind_a, wind_b, workshop_mode, workshop_point;
    unsigned region, amber_phase, amber_intake, amber_sluice, amber_point;
    unsigned amber_met_nils;
    float amber_lift, amber_focus;
    float workshop_wait, workshop_focus, wind_angle_a, wind_angle_b;
} L3Story;

typedef struct {
    L3ArcadeState arcade;
    unsigned revision, pending_us;
} L3Activities;

typedef struct {
    L3World world;
    L3Story story;
    L3Activities activities;
    L3Player player;
    L3Camera camera;
    float time, distance_walked;
    uint32_t collected_mask, collected_count;
    int objective_complete, autopilot;
    uint32_t route_index, completed_routes;
    int route_direction;
    float camera_manual_seconds, coyote_seconds, jump_buffer_seconds;
    /* Diagnostic only: stationary against an obstacle, never teleporting. */
    float autopilot_stuck_seconds;
    unsigned showcase_stage,showcase_status; /* transient demo HUD; never saved */
    /* LUMA3D VILLAGE V6: optional zone state, persisted explicitly. */
    unsigned village_phase, village_mask, village_step, village_wrong;
    unsigned village_reward;
    unsigned village_demo_active; /* transient presentation, never saved */
    unsigned char village_order[3];
    /* Optional Serres state, explicitly serialized in V7. */
    unsigned garden_invited, garden_seeds, garden_reward;
    int valid;
} L3Game;

/* Returns 0 for invalid configuration. Does not mutate pointed-to world data.
 * Auto mode physically walks route forward/back; manual action takes control. */
int l3_game_init(L3Game *game, const L3World *world, int autopilot);
/* Main normally calls at 1/60 s. Finite positive dt is capped to .1 s and
 * subdivided to <=1/60; zero, negative and nonfinite deltas are no-ops.
 * Frontend must keep pressed edges pending until a positive simulation step. */
void l3_game_step(L3Game *game, const L3Input *input, float dt);

/* This first authored mission is deliberately separate from the R3 benchmark. */
void l3_story_init(L3Game *g);
int l3_story_before(L3Game *g, uint32_t pressed, float dt);
void l3_story_after(L3Game *g);
L3Vec3 l3_story_auto_target(L3Game *g);
L3Vec3 l3_story_site(const L3Game *g, unsigned site);
const char *l3_story_objective(const L3Game *g);
const char *l3_story_speaker(const L3Game *g);
const char *l3_story_dialogue(const L3Game *g);
const char *l3_story_prompt(const L3Game *g);

/* Transactional safe grounded relocation for save/load, using the same
 * terrain, NPC collisions and immediate camera update as normal play. */
int l3_game_restore_position(L3Game *, L3Vec3);
int l3_game_position_valid(const L3Game *, L3Vec3);

#endif
