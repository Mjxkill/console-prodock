#ifndef L3_MAZE_MOTION_H
#define L3_MAZE_MOTION_H
#include "l3_mini_actors.h"
#include "l3_mini_trace.h"
#define L3_MAZE_SEGMENTS 8
/* Presentation only. Each segment is an observed legal axis-aligned move;
 * it is never used by collision, AI, rewards or save serialization. */
typedef struct {double start,end;uint16_t x0,y0,x1,y1;} L3MazeSegment;
typedef struct {L3MazeSegment segments[L3_MAZE_SEGMENTS];unsigned head,count;
 uint16_t settled_x,settled_y,logical_x,logical_y;} L3MazeTrack;
typedef struct {L3MazeTrack actor[3];L3MiniActors latest;double time;
 unsigned valid;uint32_t epoch;unsigned moves,teleports,overflows,resets,contacts,contact_fallbacks;} L3MazeMotion;
int l3_maze_motion_observe_events(L3MazeMotion *,const L3MiniView *,const L3MiniActors *,double,uint32_t,const L3MiniTrace *);
void l3_maze_motion_reset(L3MazeMotion *);
/* Non-monotone time without a new epoch is rejected transactionally. Respawn,
 * load and nonadjacent jumps reset the affected presentation, never lerp walls. */
int l3_maze_motion_observe(L3MazeMotion *,const L3MiniView *,const L3MiniActors *,double seconds,uint32_t epoch);
int l3_maze_motion_observe_trace(L3MazeMotion *,const L3MiniView *,const L3MiniActors *,double seconds,uint32_t epoch,unsigned warp_mask);
int l3_maze_motion_sample(const L3MazeMotion *,double seconds,L3MiniActors *);
#endif
