#ifndef L3_PUZZLE_PRESENTATION_H
#define L3_PUZZLE_PRESENTATION_H
#include "luma3d_render.h"
#include "l3_puzzle_gpu.h"
typedef struct {
    unsigned kind,status,score,target,lives,progress,won,showcase,stage;
} L3PuzzleChromeKey;
typedef struct {
    uint8_t *number_back;unsigned nx,ny,nw,nh,revision,page_revision[2];
    L3PuzzleChromeKey key;unsigned valid,rasterized_pixels,scanned_bytes,published_bytes,asset_bytes;
} L3PuzzleUiCache;
typedef struct L3PuzzlePresentation {
    L3PuzzleMotion motion;
    L3PuzzleLayout layout;L3PuzzleGpuAssets assets;L3PuzzleUiCache ui;
    L3MotionFrame page_frame[2];unsigned page_valid[2],assets_valid,kind,width,height;
    unsigned observed_epoch,frames,skipped,quads,copy_pixels;
} L3PuzzlePresentation;
int l3_puzzle_presentation_open(L3Render *);
void l3_puzzle_presentation_close(L3Render *);
void l3_puzzle_presentation_reset(L3Render *);
/* Same observer callback ABI as the integrator; trace_flags is ignored here. */
void l3_puzzle_presentation_observe(void *,const L3ArcadeView *,const L3ArcadeView *,
                                  uint32_t pressed,uint32_t held,uint32_t trace_flags,double seconds,uint32_t epoch);
/* Only BLOCKS / MERGE1024. Calls actual V1 emitter on r->gpu, caller flushes
 * before PRESENT. Native scene format3, immutable indexed window. No save. */
int l3_puzzle_motion_prepare(L3Render *,const L3Game *,struct prodock_scene *,double seconds);
/* Defined by l3_puzzle_ui.inc included once at end of existing mini_ui.c. */
int l3_puzzle_ui_bake(L3Render *,const L3Game *,const L3MiniView *,const L3PuzzleLayout *,L3PuzzleGpuAssets *,L3PuzzleUiCache *);
int l3_puzzle_ui_chrome(L3Render *,const L3Game *,const L3MiniView *,struct prodock_scene *,L3PuzzleUiCache *);
#endif
