#ifndef L3_SIMON_LIGHT_H
#define L3_SIMON_LIGHT_H
#include "l3_simon.h"
/* Presentation only. No fields are added to engine/save. Time is monotone
 * seconds, independent of engine dt; sampling never clamps elapsed time. */
typedef struct {
    double start[4],last_time,pause_time;
    unsigned duration[4],gain[4],epoch,valid,paused,triggers;
    L3SimonView latest;
} L3SimonLight;
typedef struct {
    unsigned level_q8[4],radius_q8[4],press_q8[4];
    unsigned phase,length,index,status;
} L3SimonLightFrame;
void l3_simon_light_reset(L3SimonLight *);
int l3_simon_light_observe(L3SimonLight *,const L3SimonView *before,const L3SimonView *after,
                         uint32_t pressed,double seconds,uint32_t epoch);
int l3_simon_light_sample(L3SimonLight *,double seconds,L3SimonLightFrame *);
int l3_simon_light_pause(L3SimonLight *,int paused,double seconds);
#endif
