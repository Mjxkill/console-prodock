#ifndef L3_SIMON_PRESENTATION_H
#define L3_SIMON_PRESENTATION_H
#include "luma3d_render.h"
#include "l3_simon_native_gpu.h"
typedef struct L3SimonPresentation {
    uint16_t *entry_background;unsigned base_ready[2];
    L3SimonLight light;L3SimonNativeLayout layout;L3SimonGpuAssets assets;
    L3SimonLightFrame page_light[2];unsigned page_valid[2],assets_valid,epoch,ui_valid,ui_revision,ui_page[2];
    unsigned ui_key[7],frames,skipped,quads,base_bytes,asset_bytes,ui_raster_pixels,ui_scan_bytes,ui_published_bytes;
} L3SimonPresentation;
int l3_simon_presentation_open(L3Render *);
void l3_simon_presentation_reset(L3Render *);
void l3_simon_presentation_close(L3Render *);
void l3_simon_presentation_observe(void *,const L3ArcadeView *,const L3ArcadeView *,uint32_t,uint32_t,uint32_t,double,uint32_t);
int l3_simon_presentation_prepare(L3Render *,const L3Game *,struct prodock_scene *,double);
#endif
