#ifndef LUMA3D_SHOWCASE_H
#define LUMA3D_SHOWCASE_H
#include "luma3d_game.h"
/* Demo controller owns only its schedule. Every movement/action reaches the
 * ordinary game/engine API; the only new-game reset is the explicit loop. */
typedef struct {
 unsigned stage,mode,point,presses,loops,completed,visited,won;
 unsigned frames,event_frame,commands,boss_seen,checkpoint_seen,crystal_seen;
 unsigned status; /* 0 stopped, 1 running, 2 complete, 3 blocked */
 float elapsed,stage_time,wait,action_left,cooldown;
 uint32_t action_pressed,action_held;
 double adviser_seconds; /* diagnostic only; excluded from all saves */
 unsigned adviser_calls;
 int action_pending,once;
 L3World initial_world;
} L3Showcase;
void l3_showcase_init(L3Showcase *,L3Game *,int once);
void l3_showcase_step(L3Showcase *,L3Game *,float dt);
void l3_showcase_presented(L3Showcase *);
void l3_showcase_cancel(L3Showcase *,L3Game *);
const char *l3_showcase_title(unsigned stage);
unsigned l3_showcase_stages(void);
#endif
