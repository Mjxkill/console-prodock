#ifndef L3_SUBMIT_DIAG_H
#define L3_SUBMIT_DIAG_H
#include <stdint.h>
/* Immutable API: all hardware counters wrap modulo2^32; time units explicit. */
typedef struct {
    uint32_t feed_us, wait_us, cache_us, cycles, vertices, triangles;
    uint32_t errors, fault;
} L3SubmitCounters;
typedef struct {
    uint64_t batches, commands, geometry_commands, draws, failed_batches;
    uint64_t sampled_batches, invalid_samples, wall_ns;
    uint64_t feed_us, wait_us, cache_us, cycles, vertices, triangles;
} L3SubmitDiag;
int l3_submit_diag_observe(L3SubmitDiag *stats, int hardware,
                           const uint32_t commands[][8], unsigned count,
                           const L3SubmitCounters *before,
                           const L3SubmitCounters *after,
                           uint64_t wall_ns, int submit_result);
#endif
