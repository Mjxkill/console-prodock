#ifndef LUMA3D_AMBER_H
#define LUMA3D_AMBER_H
#include "luma3d_game.h"
float l3_amber_ground(float x,float z);
float l3_amber_floor(const L3Game *,float x,float z,float ground);
int l3_amber_blocked(const L3Game *,float x,float y,float z,float radius,float height);
void l3_amber_bind(L3Game *,unsigned region);
int l3_amber_transition(L3Game *,unsigned region);
L3Vec3 l3_amber_site(const L3Game *,unsigned site);
int l3_amber_interact(L3Game *,int site);
void l3_amber_dialogue_done(L3Game *,int dialogue);
int l3_amber_target(L3Game *,L3Vec3 *);
int l3_amber_advance(L3Game *);
int l3_amber_wanted(const L3Game *);
void l3_amber_rejoin(L3Game *);
void l3_amber_tick(L3Game *,float dt);
int l3_amber_state_ok(const L3Game *);
const char *l3_amber_objective(const L3Game *);
const char *l3_amber_speaker(int dialogue);
const char *l3_amber_dialogue(const L3Game *);
const char *l3_amber_prompt(const L3Game *);
unsigned l3_amber_dialogue_site(int dialogue);
#endif
