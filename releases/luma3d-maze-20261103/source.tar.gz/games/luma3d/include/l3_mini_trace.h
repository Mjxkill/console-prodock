#ifndef L3_MINI_TRACE_H
#define L3_MINI_TRACE_H
#include "l3_minigames.h"
/* Transient presentation telemetry. Never serialized or used for decisions.
 * Bits 0/1/2 identify player/ghost0/ghost1 resets performed by the real engine.
 * A trace may include multiple contacts in one accepted step. */
enum { L3_MAZE_COLLECT=1, L3_MAZE_CONTACT_POWER, L3_MAZE_CONTACT_DEATH,
       L3_MAZE_CONTACT_LOST };
#define L3_MAZE_TRACE_EVENTS 32u
typedef struct {
    uint8_t kind,actor_mask,x,y; /* Logical cell before any respawn. */
    uint8_t tick,detail; /* Tick within this call; collect detail=board value2/3. */
    uint8_t actor_x[3],actor_y[3],respawn_x[3],respawn_y[3];
} L3MazeEvent;
typedef struct {
    uint32_t maze_warp_mask;
    unsigned event_count,event_overflow,tick,ticks;
    L3MazeEvent events[L3_MAZE_TRACE_EVENTS];
} L3MiniTrace;
uint32_t l3_mini_step_trace(L3MiniState *,uint32_t pressed,uint32_t held,
                            uint32_t dt_ms,L3MiniTrace *);
#endif
