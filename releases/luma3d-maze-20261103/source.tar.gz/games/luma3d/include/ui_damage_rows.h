#ifndef L3_UI_DAMAGE_ROWS_H
#define L3_UI_DAMAGE_ROWS_H
#include <stdint.h>
#include <string.h>

/* Conservative row footprints, in native indexed pixels. They describe CPU
 * canvas writes, never GPU writes. Both pages accumulate old AND new rows
 * over arbitrarily many canvas updates until their own publication succeeds.
 * An invalid/unknown footprint falls back to a full-page publication.
 * One producer owns this state; no writer may bypass marking/reset. */
#define L3_UI_DAMAGE_ROWS_MAX 720u
typedef struct {
    uint8_t footprint[L3_UI_DAMAGE_ROWS_MAX];
    uint8_t dirty[2][L3_UI_DAMAGE_ROWS_MAX];
    unsigned height, valid, building, full[2];
} L3UiDamageRows;

static inline void l3_rows_reset(L3UiDamageRows *s)
{
    memset(s, 0, sizeof(*s));
    s->full[0] = s->full[1] = 1;
}

/* A bounded clear must read the quiescent footprint BEFORE it calls
 * l3_rows_begin: begin consumes that footprint (folding it into both
 * pending-page masks and clearing it), so a clear run after begin would
 * find nothing left to bound the erase. Erasure damages the previous
 * footprint; clearing the current footprint must not clear either
 * pending-page mask. */
static inline void l3_rows_begin(L3UiDamageRows *s, unsigned height)
{
    if (!height || height > L3_UI_DAMAGE_ROWS_MAX) {
        l3_rows_reset(s);
        return;
    }
    if (!s->valid || s->height != height || s->building) {
        l3_rows_reset(s);
        s->height = height;
        s->valid = 1;
    }
    for (unsigned y = 0; y < height; y++) {
        s->dirty[0][y] |= s->footprint[y];
        s->dirty[1][y] |= s->footprint[y];
        s->footprint[y] = 0;
    }
    s->building = 1;
}

/* Half-open vertical interval, clipped with signed-wide arithmetic. Font
 * antialiasing lies within its reported height; panels add their +2 shadow.
 * A reversed/unknown interval loses the optimisation, never erasure data. */
static inline void l3_rows_mark(L3UiDamageRows *s, int64_t first, int64_t end)
{
    if (!s->valid || !s->building || end < first) {
        l3_rows_reset(s);
        return;
    }
    if (first < 0) first = 0;
    if (end > (int64_t)s->height) end = s->height;
    if (first >= end) return;
    memset(s->footprint + (unsigned)first, 1, (size_t)(end - first));
}

static inline void l3_rows_end(L3UiDamageRows *s)
{
    if (!s->valid || !s->building) {
        l3_rows_reset(s);
        return;
    }
    for (unsigned y = 0; y < s->height; y++) {
        s->dirty[0][y] |= s->footprint[y];
        s->dirty[1][y] |= s->footprint[y];
    }
    s->building = 0;
}

static inline int l3_rows_full(const L3UiDamageRows *s, unsigned page,
                             unsigned height)
{
    return page > 1 || !s->valid || s->building || s->height != height || s->full[page];
}

/* The caller clears only after ALL emitted spans succeeded. On a partial
 * failure the existing shadow may contain a prefix, but damage is retained. */
static inline void l3_rows_consumed(L3UiDamageRows *s, unsigned page)
{
    if (page > 1 || !s->valid || s->building) return;
    memset(s->dirty[page], 0, s->height);
    s->full[page] = 0;
}
#endif
