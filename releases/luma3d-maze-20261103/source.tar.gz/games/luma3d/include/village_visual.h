/* VILLAGE_SHARED_SKY_01 */
#ifndef LUMA_VILLAGE_VISUAL_H
#define LUMA_VILLAGE_VISUAL_H
#include "luma3d_village.h"
/* Private world renderer module, included after draw/upload helpers.
 * Metres, native G3D1 mesh format, physical GPU addresses from upload().
 * Immutable foliage and halo geometry are uploaded once into the existing
 * checked 8..14 MiB arena. No per-frame texture/mesh publication is added.
 * All additions use the same terrain height as walking; trunks sit outside
 * the path. Existing physics and saved state remain authoritative. */
static const float village_props[5][4]={
    {28.3f,119.1f,.82f,.5f},{38.5f,119.6f,.72f,2.2f},
    {38.0f,108.4f,.78f,-.5f},{47.5f,117.5f,.72f,1.2f},
    {53.0f,102.8f,.62f,-.8f}
};
static int village_resources(L3Render *r,const L3Game *g) {
    if(r->village_ready)return 1;
    static const char *names[]={"oak_low_budget","pine_far_budget","rock_far_budget"};
    for(unsigned k=0;k<3;k++){
        unsigned i;for(i=0;i<l3_asset_mesh_count;i++)if(!strcmp(names[k],l3_asset_meshes[i].name))break;
        if(i==l3_asset_mesh_count||l3_asset_meshes[i].group_count!=1)return 0;
        r->village_mesh[k]=i;
    }
    r->village_sky_texture=upload(r,l3_sky_assets.texture,l3_sky_assets.texture_bytes);
    r->village_sky_mesh=(gpu_geom_mesh){upload(r,l3_sky_assets.vertices,l3_sky_assets.vertices_bytes),
        upload(r,l3_sky_assets.faces,l3_sky_assets.faces_bytes),l3_sky_assets.vertex_count,l3_sky_assets.face_count};
    if(!r->village_sky_texture||!r->village_sky_mesh.vertices||!r->village_sky_mesh.faces)return 0;
    /* Soft emissive pool, ARGB4444. Generated once, not a prerendered scene. */
    uint16_t halo[32*32];
    for(unsigned y=0;y<32;y++)for(unsigned x=0;x<32;x++){
        float dx=((float)x-15.5f)/15.5f,dz=((float)y-15.5f)/15.5f;
        float a=fmaxf(0,1-dx*dx-dz*dz);unsigned alpha=(unsigned)lroundf(15*a*a);
        halo[y*32+x]=(uint16_t)((alpha<<12)|0xafeu);
    }
    r->village_texture=upload(r,halo,sizeof halo);
    gpu_geom_vertex vertices[16]={{0}};gpu_geom_face faces[8]={{{0}}};
    for(unsigned k=0;k<9;k++){
        L3Vec3 p;
        if(k<5)p=(L3Vec3){village_props[k][0],0,village_props[k][1]};
        else{
            /* Site positions have one owner: gameplay API. Visual markers
             * sit beside that point, inside interaction reach, off the path. */
            p=l3_village_site(g,k-5);p.x-=1.5f;p.z-=1.2f;
        }
        p.y=g->world.height(g->world.context,p.x,p.z);
        if(!isfinite(p.y))return 0;r->village_ground[k]=p;
        if(k<5)continue;
        unsigned n=k-5;float radius=n==3?1.05f:.72f;
        for(unsigned v=0;v<4;v++){
            L3Vec3 q={p.x+((v==1||v==2)?radius:-radius),p.y+.55f,
                p.z+(v>=2?radius:-radius)};
            if(!gpu_geom_fixed(q.x,&vertices[n*4+v].x)||!gpu_geom_fixed(q.y,&vertices[n*4+v].y)||
               !gpu_geom_fixed(q.z,&vertices[n*4+v].z))return 0;
        }
        static const unsigned ids[2][3]={{0,1,2},{0,2,3}};
        for(unsigned f=0;f<2;f++){
            gpu_geom_face *dst=&faces[n*2+f];dst->words[0]=3u<<24;
            for(unsigned v=0;v<3;v++){
                unsigned corner=ids[f][v];dst->words[0]|=(n*4+corner)<<(v*8);
                dst->words[v+1]=((corner==1||corner==2)?31u<<16:0)|(corner>=2?31u:0);
            }
            dst->words[4]=32767;dst->words[6]=256u|(256u<<9)|(256u<<18);
        }
    }
    r->village_halo_mesh=(gpu_geom_mesh){upload(r,vertices,sizeof vertices),upload(r,faces,sizeof faces),16,8};
    if(!r->village_texture||!r->village_halo_mesh.vertices||!r->village_halo_mesh.faces)return 0;
    r->village_ready=1;return 1;
}
static int village_environment(L3Render *r,const L3Game *g) {
    if(g->story.region)return 1;
    if(!village_resources(r,g))return 0;
    L3Vec3 rows[3]={r->right,r->down,r->forward};gpu_geom_transform sky;
    for(unsigned a=0;a<3;a++){
        if(!gpu_geom_fixed(rows[a].x,&sky.values[a*4])||!gpu_geom_fixed(rows[a].y,&sky.values[a*4+1])||
           !gpu_geom_fixed(rows[a].z,&sky.values[a*4+2]))return 0;
        sky.values[a*4+3]=0; /* translation invariant sky, camera rotation preserved */
    }
    gpu_geom_light light={0,32767,0,256,0};
    gpu_material mat={.flags=1|16,.alpha=256,.r=256,.g=256,.b=256};
    gpu_texture_level tex={r->village_sky_texture,512,256,1024,GPU_ARGB4444,0,0,0};
    if(!gpu_geom_set_transform(&r->gpu,&sky)||!gpu_geom_set_light(&r->gpu,&light)||
       !gpu_v1_material(&r->gpu,&mat)||!gpu_v1_texture(&r->gpu,&tex)||
       !gpu_geom_draw(&r->gpu,&r->village_sky_mesh,0))return 0;
    r->draws++;r->triangles+=l3_sky_assets.face_count;
    for(unsigned k=0;k<9;k++){
        float scale=k<5?village_props[k][2]:k==8?.48f:.34f;
        float yaw=k<5?village_props[k][3]:(k-5)*.4f;
        unsigned mesh=r->village_mesh[k<3?0:k<5?1:2];
        float sway=k<5?.018f*sinf(g->time*.85f+k*1.7f):0;
        if(!draw_ex(r,g,mesh,r->village_ground[k],(L3Vec3){scale,scale,scale},
                    yaw,0,sway,1))return 0;
    }
    return !r->failed;
}
/* Alpha halos are submitted after opaque world/hero geometry, depth tested,
 * without depth writes. Near objects therefore correctly occlude them. */
static int village_glow(L3Render *r,const L3Game *g) {
    if(g->story.region||!r->village_ready)return 1;
    L3Vec3 rows[3]={r->right,r->down,r->forward};gpu_geom_transform transform;
    for(unsigned a=0;a<3;a++){
        if(!gpu_geom_fixed(rows[a].x,&transform.values[a*4])||!gpu_geom_fixed(rows[a].y,&transform.values[a*4+1])||
           !gpu_geom_fixed(rows[a].z,&transform.values[a*4+2])||
           !gpu_geom_fixed(-dot(rows[a],g->camera.eye),&transform.values[a*4+3]))return 0;
    }
    gpu_geom_light light={0,32767,0,256,0};
    /* Reward persists with the quest: the resting turquoise echoes become
     * a warmer, steady gold memory. No texture rewrite or extra pass. */
    unsigned reward=g->village_reward!=0;
    gpu_material mat={.flags=1|2|16|32,
        .alpha=(unsigned)((reward?90:65)+(reward?8:18)*sinf(g->time*1.4f)),
        .r=reward?256:180,.g=reward?210:256,.b=reward?100:256};
    gpu_texture_level tex={r->village_texture,32,32,64,GPU_ARGB4444,0,0,0};
    if(!gpu_geom_set_transform(&r->gpu,&transform)||!gpu_geom_set_light(&r->gpu,&light)||
       !gpu_v1_material(&r->gpu,&mat)||!gpu_v1_texture(&r->gpu,&tex)||
       !gpu_geom_draw(&r->gpu,&r->village_halo_mesh,0))return 0;
    r->draws++;r->triangles+=8;return !r->failed;
}
#endif
