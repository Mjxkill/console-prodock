#ifndef L3_FESTIVAL_H
#define L3_FESTIVAL_H
/* A separate expansion context: the paused LUMA campaign and its V5 save
 * remain owned by the original game. This extension is common to both GPUs. */
#include "luma3d_render.h"
#include "l3_table.h"
#include "memory_scene.h"
#include "l3_card_motion.h"
#include "l3_festival_profile.h"
#include "ui_damage_rows.h"
enum {L3_FESTIVAL_GARDEN=4,L3_FESTIVAL_MEMORY=5,L3_FESTIVAL_STANDS=5};
/* ---- Candidate overlay state (owned/overlay_block.c) --------------------
 * Two CPU shadows of the physical indexed pages at 20/21 MiB plus one exact
 * visible-state key for the cached raster. The VRAM is never read back. */
#define L3_FESTIVAL_HINT_MAX 512
typedef struct {
    unsigned kind,automatic;              /* always displayed */
    unsigned map,nearest,visited;         /* garden only */
    unsigned moves,status,turn;           /* the four tables only */
    unsigned selection,row,source,color;  /* per table, see overlay_key() */
    unsigned scores[2];                   /* Othello only */
    uint8_t guessed[26];                  /* Hangman only */
    unsigned hint_len;                    /* 0xFFFFFFFF: hint longer than the key */
    char hint[L3_FESTIVAL_HINT_MAX];      /* -> always redraw, never a false match */
    unsigned valid;                       /* a raster is cached for this key */
} L3FestivalOverlayKey;
typedef struct {
    uint8_t *shadow[2];                   /* exact bytes published on each page */
    unsigned shadow_w,shadow_h;           /* dimensions the shadows were sized for */
    unsigned shadow_valid[2];             /* page holds a fully published image */
    unsigned pending_pages;               /* two-bit mask of pages not yet current */
    L3UiDamageRows rows;                 /* pending damage per physical page */
    L3FestivalOverlayKey key;             /* visible state of the cached raster */
} L3FestivalOverlay;
typedef struct L3Festival {
    unsigned active,automatic,kind,stage,map,revision,turns,initialized;
    unsigned sample_limit,memory_sample_limit; /* Opt-in diagnostic; never serialized. */
    unsigned selection,row,source,source_row,color,escape,assets,base_ready[2],ui_page[2];
    unsigned won,visited,poses_n,old_n,baked_kind,page_n[2],page_valid[2];
    float time,action_time,transition,scene_time,x,z,vx,vz,yaw,held_until,move_x,move_z;
    float camera_x,camera_z,light_mood;
    L3MemoryScene memory;unsigned memory_visited;
    L3TableState games[L3_TABLE_COUNT];L3TableView view;L3TableTrace trace;
    L3FestivalPose poses[256],old[256],page_poses[2][256];
    L3CardMotion motion;
    uint8_t *ui;
    uint16_t *background;
    /* Candidate additions: overlay shadows, cached raster key and the
       recorded dimensions that keep the original allocations resize safe. */
    L3FestivalOverlay overlay;
    /* Aggregate CPU profile of the festival render path. It is armed
       only when the renderer already asked for the festival metrics,
       so a normal run reads no clock and prints nothing. */
    L3FestivalProfile profile;
    unsigned cpu_profile_enabled; /* Explicit diagnostic switch, default OFF. */
    unsigned ui_w,ui_h;                 /* dimensions of f->ui */
    unsigned background_w,background_h; /* dimensions of f->background */
    gpu_geom_mesh meshes[28];unsigned mesh_texture[28],mesh_count,geometry_ready;
    unsigned lighting_mesh_first,lighting_mesh_count;
    unsigned grove_mesh_first,grove_mesh_count;
    L3Vec3 grove_center[2];float grove_radius[2];
} L3Festival;
L3Festival *l3_festival_create(int automatic);
void l3_festival_destroy(L3Festival *);
int l3_festival_memory_load(L3Festival *,const char *);
int l3_festival_memory_save(const L3Festival *,const char *);
int l3_festival_load(L3Festival *,const char *path);
int l3_festival_save(const L3Festival *,const char *path);
void l3_festival_enter(L3Festival *,unsigned game);
void l3_festival_leave(L3Render *,L3Festival *);
void l3_festival_key(L3Render *,L3Festival *,int c);
void l3_festival_step(L3Festival *,float dt);
int l3_festival_render(L3Render *,L3Festival *,struct prodock_scene *);
#endif
